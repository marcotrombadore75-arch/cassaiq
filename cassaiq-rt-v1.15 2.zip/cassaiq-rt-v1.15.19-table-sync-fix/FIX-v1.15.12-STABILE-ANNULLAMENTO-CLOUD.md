# CassaIQ RT v1.15.12 / build 143

## Base
Ripartita integralmente dalla v1.15.10, cioè la build che ha completato con successo un annullamento DCO reale.

## Correzione regressione v1.15.11
La velocizzazione dell annullamento introdotta in v1.15.11 è stata rimossa completamente.
Il timer e i ritardi dei click del flusso annullo sono identici alla v1.15.10 funzionante.

## UX DCO mantenuta
Resta l overlay centrale durante Collega al DCO e il blocco anti-doppio click, già testati con successo.

## Operazioni di emergenza
Aggiunto avviso che la funzione è precauzionale e non sostituisce il registro manuale delle emergenze né gli adempimenti fiscali previsti.

## Persistenza annullamenti Supabase
Incluso supabase-dco-annullamenti-v1.15.12.sql.
Dopo l esecuzione della migrazione, la sincronizzazione prova anche a riallineare al cloud gli annullamenti già presenti nel localStorage del dispositivo. Questo non ripete mai l annullamento fiscale.
