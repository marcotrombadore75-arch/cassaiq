# CassaIQ RT v1.14.75 — Ristampa cucina dalla cassa

- Nel dettaglio di un tavolo occupato e disponibile il nuovo pulsante **Ristampa cucina**.
- La ristampa invia nuovamente alla stampante cucina tutte le righe della comanda aperta del tavolo, con le note aggregate.
- La ristampa e sempre un'azione manuale e non modifica stato, quantità, totale o dati fiscali della comanda.
- Funziona anche se la stampa automatica cucina e disattivata, purche IP/porta siano configurati.
- Le nuove comande create dalla cassa continuano a essere stampate automaticamente quando la funzione cucina e attiva.
- Motore DCO, timer 350/1100 ms, isolamento emissioni, Epson e Active WebView invariati.
