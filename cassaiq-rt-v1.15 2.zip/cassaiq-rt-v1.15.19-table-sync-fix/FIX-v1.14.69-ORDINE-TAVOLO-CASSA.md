# CassaIQ RT v1.14.69 — Ordine tavolo dalla cassa

Base funzionale: v1.14.68. Il motore DCO rapido, i timer e la logica di isolamento emissione non sono stati modificati.

## Aggiunta
- Da **Tavoli** è disponibile **Nuovo ordine** per un tavolo libero e **+ Aggiungi** per un tavolo occupato.
- Nella finestra della comanda è disponibile **+ Aggiungi ordine**.
- La cassa entra in modalità **Ordine da cassa**: si usano lo stesso catalogo e le stesse quantità del POS.
- Il pulsante **PAGA** diventa **AGGIUNGI AL TAVOLO**: non apre il pagamento e non emette alcun documento fiscale.
- L'ordine viene scritto nelle stesse tabelle `orders` / `order_items` usate da CassaIQ Client e il tavolo diventa `occupied`.
- Le aggiunte dalla cassa si sommano alle comande già aperte del Client e vengono portate insieme nel carrello al momento del pagamento.
- I prodotti a prezzo variabile del catalogo restano supportati; il prezzo manuale generico è escluso dagli ordini tavolo per evitare righe non riconducibili a un prodotto/reparto al pagamento.

Versioni native: iOS build 100, Android versionCode 100.
