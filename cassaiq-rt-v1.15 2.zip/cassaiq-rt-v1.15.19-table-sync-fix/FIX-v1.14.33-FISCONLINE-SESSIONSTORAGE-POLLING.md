# CassaIQ RT v1.14.33 — Fisconline secure polling hardening

Correzione mirata del login automatico Fisconline su iOS/WKWebView.

- Mantiene RSA-OAEP: credenziali mai concatenate in chiaro negli script `executeScript`.
- Il risultato asincrono del probe/fill viene duplicato in `sessionStorage`, oltre al marker `window`, per rendere il polling persistente tra chiamate `executeScript`.
- La chiave privata RSA temporanea viene esportata come JWK e conservata solo per pochi secondi nella `sessionStorage` della pagina ufficiale AdE; non viene restituita all'app, non viene loggata e viene rimossa prima della decifratura/fine operazione.
- Resta un fallback in-memory con `CryptoKey` per compatibilità.
- Primo poll ritardato di 260 ms, retry ogni 220 ms, timeout aumentato a 18 s e tolleranza a callback transitorie di WKWebView.
- Cleanup best-effort di chiavi e marker temporanei anche in caso di errore.
- Emissione DCO, anti-doppia-emissione, stampa MUNBYN, numero documento e SPID fallback invariati.
