-- CassaIQ RT v1.12.7 - verifica/riparazione archivio statistiche
-- Eseguire una sola volta nel SQL Editor di Supabase. È sicuro da rieseguire.

begin;

create table if not exists public.sales (
  id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  sold_at timestamptz not null default now(),
  total numeric(12,2) not null default 0,
  payment_method text,
  receipt_number text,
  item_count integer default 0,
  cash_received numeric(12,2) default 0,
  change_due numeric(12,2) default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.sale_items (
  id uuid primary key,
  sale_id uuid not null references public.sales(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id uuid,
  product_name text not null,
  quantity numeric(12,3) not null,
  unit_price numeric(12,2) not null,
  line_total numeric(12,2) not null,
  created_at timestamptz not null default now()
);

alter table public.sales add column if not exists subtotal numeric(12,2);
alter table public.sales add column if not exists discount_amount numeric(12,2) default 0;
alter table public.sales add column if not exists payment_method text;
alter table public.sales add column if not exists receipt_number text;
alter table public.sales add column if not exists item_count integer default 0;
alter table public.sales add column if not exists cash_received numeric(12,2) default 0;
alter table public.sales add column if not exists change_due numeric(12,2) default 0;
alter table public.sale_items add column if not exists category_name text;
alter table public.sale_items add column if not exists department_name text;
alter table public.sale_items add column if not exists vat_rate numeric(5,2) default 0;

update public.sales set subtotal=total where subtotal is null;

-- Allinea il metodo di pagamento ai valori inviati dall'app.
alter table public.sales drop constraint if exists sales_payment_method_valid;
update public.sales
set payment_method = case
  when lower(trim(payment_method)) in ('cash','contanti','contante') then 'Contanti'
  when lower(trim(payment_method)) in ('card','carta','carta di credito','carta di debito','electronic','elettronico','pagamento elettronico') then 'Carta'
  else payment_method
end
where payment_method is not null;
alter table public.sales add constraint sales_payment_method_valid
check (payment_method in ('Contanti','Carta'));

create index if not exists sales_user_date_idx on public.sales(user_id,sold_at desc);
create index if not exists sale_items_user_sale_idx on public.sale_items(user_id,sale_id);

alter table public.sales enable row level security;
alter table public.sale_items enable row level security;

drop policy if exists sales_owner_all on public.sales;
create policy sales_owner_all on public.sales
for all to authenticated
using (auth.uid()=user_id)
with check (auth.uid()=user_id);

drop policy if exists sale_items_owner_all on public.sale_items;
create policy sale_items_owner_all on public.sale_items
for all to authenticated
using (auth.uid()=user_id)
with check (auth.uid()=user_id);

grant select,insert,update,delete on public.sales to authenticated;
grant select,insert,update,delete on public.sale_items to authenticated;

notify pgrst, 'reload schema';
commit;
