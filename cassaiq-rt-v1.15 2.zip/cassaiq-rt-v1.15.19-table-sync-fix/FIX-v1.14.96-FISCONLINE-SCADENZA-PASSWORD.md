# CassaIQ RT v1.14.96 — Promemoria scadenza password Fisconline

- Contatore locale di 90 giorni dalla data di salvataggio/rinnovo della password Fisconline.
- Negli ultimi 7 giorni viene mostrato al massimo un popup al giorno.
- Il popup indica la data stimata di scadenza, quanti giorni restano e i passaggi per rinnovare la password sul sito ufficiale Agenzia delle Entrate.
- Dal popup si può aprire il sito ufficiale e, dopo il rinnovo, salvare in CassaIQ soltanto la nuova password; codice fiscale/nome utente e PIN restano invariati.
- In Impostazioni > Documento Commerciale Online è visibile il contatore con data stimata e giorni rimanenti.
- Quando viene salvata una password diversa o si usa “Salva nuova password”, il contatore riparte automaticamente da 90 giorni.
- Le versioni precedenti non registravano la data del cambio password: per credenziali già presenti al primo avvio della v1.14.96 il primo ciclo parte dalla data dell’aggiornamento; dal rinnovo successivo il conteggio è esatto rispetto alla data salvata da CassaIQ.
- Nessuna password, PIN o credenziale viene salvata nel cloud: il nuovo contatore memorizza solo una data locale.
