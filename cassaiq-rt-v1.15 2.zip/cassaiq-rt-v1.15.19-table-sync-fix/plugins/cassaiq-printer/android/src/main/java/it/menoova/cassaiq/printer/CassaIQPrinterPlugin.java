package it.menoova.cassaiq.printer;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.webkit.CookieManager;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.HttpURLConnection;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.URI;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.net.URL;
import java.io.InputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

@CapacitorPlugin(name = "CassaIQPrinter")
public class CassaIQPrinterPlugin extends Plugin {
    private static final String SECURE_KEY_ALIAS = "CASSAIQ_SECURE_KEY_V1";
    private static final String SECURE_PREFS = "cassaiq_secure_store_v1";
    private static final String LAN_PREFS = "cassaiq_lan_orders_v1";
    private static final String LAN_PENDING_PREFIX = "pending.";
    private static final String LAN_DONE_PREFIX = "done.";
    private static final int LAN_MAX_PAYLOAD = 262144;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ExecutorService lanExecutor = Executors.newCachedThreadPool();
    private volatile ServerSocket lanServerSocket = null;
    private volatile boolean lanServerRunning = false;
    private volatile int lanServerPort = 8765;
    private volatile String lanAllowedOwnerUserId = "";
    private volatile Set<String> lanAuthorizedDeviceIds = Collections.emptySet();

    private byte[] decodeBase64(String encoded) throws Exception {
        byte[] data = Base64.decode(encoded == null ? "" : encoded, Base64.DEFAULT);
        if (data.length == 0) throw new Exception("Dati vuoti.");
        return data;
    }

    private byte[] pdfData(PluginCall call) throws Exception {
        String encoded = call.getString("data", "");
        if (!encoded.isEmpty()) return decodeBase64(encoded);
        String path = call.getString("path", "");
        if (!path.isEmpty()) {
            File file = new File(path.replace("file://", ""));
            try (FileInputStream input = new FileInputStream(file); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[16384]; int read; while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
                byte[] data = output.toByteArray(); if (data.length == 0) throw new Exception("PDF vuoto."); return data;
            }
        }
        throw new Exception("PDF non disponibile o non valido.");
    }

    private String sanitizeFileName(String raw) {
        String name = raw == null || raw.trim().isEmpty() ? "documento-commerciale.pdf" : raw.trim();
        name = name.replaceAll("[^A-Za-z0-9._-]", "-").replaceAll("-+", "-");
        if (!name.toLowerCase().endsWith(".pdf")) name += ".pdf";
        return name;
    }

    private File documentFolder() throws Exception {
        File base = getContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
        if (base == null) base = getContext().getFilesDir();
        File folder = new File(base, "CassaIQ/Documenti");
        if (!folder.exists() && !folder.mkdirs()) throw new Exception("Impossibile creare la cartella documenti.");
        return folder;
    }



    private String htmlDecode(String value) {
        if (value == null) return "";
        return value.replace("&amp;", "&")
                .replace("&quot;", "\"")
                .replace("&#39;", "'")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&nbsp;", " ");
    }

    private String stripHtml(String html) {
        if (html == null) return "";
        return htmlDecode(html.replaceAll("(?is)<[^>]+>", " "))
                .replaceAll("\\s+", " ").trim();
    }

    private String regexFirst(String pattern, String text) {
        if (text == null) return null;
        Matcher m = Pattern.compile(pattern, Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(text);
        return m.find() && m.groupCount() >= 1 ? m.group(1) : null;
    }

    private Map<String, String> hiddenFields(String html) {
        Map<String, String> out = new HashMap<>();
        Matcher tags = Pattern.compile("(?is)<input\\b[^>]*>").matcher(html == null ? "" : html);
        while (tags.find()) {
            String tag = tags.group();
            String type = regexFirst("\\btype\\s*=\\s*[\"']([^\"']*)[\"']", tag);
            if (type == null || !"hidden".equalsIgnoreCase(type)) continue;
            String name = regexFirst("\\bname\\s*=\\s*[\"']([^\"']+)[\"']", tag);
            if (name == null || name.isEmpty()) continue;
            String value = regexFirst("\\bvalue\\s*=\\s*[\"']([^\"']*)[\"']", tag);
            out.put(htmlDecode(name), htmlDecode(value == null ? "" : value));
        }
        return out;
    }

    private String readHttpBody(HttpURLConnection connection) throws Exception {
        InputStream stream;
        int code = connection.getResponseCode();
        if (code >= 200 && code < 400) stream = connection.getInputStream();
        else stream = connection.getErrorStream();
        if (stream == null) return "";
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append('\n');
            return sb.toString();
        }
    }

    private void applyCookies(CookieManager manager, URL url, HttpURLConnection connection) throws Exception {
        Map<String, List<String>> cookieHeaders = manager.get(url.toURI(), Collections.emptyMap());
        for (Map.Entry<String, List<String>> entry : cookieHeaders.entrySet()) {
            if (entry.getKey() == null || entry.getValue() == null) continue;
            for (String value : entry.getValue()) connection.addRequestProperty(entry.getKey(), value);
        }
    }

    private void storeCookies(CookieManager manager, URL url, HttpURLConnection connection) throws Exception {
        manager.put(url.toURI(), connection.getHeaderFields());
    }

    @PluginMethod
    public void renewFisconlinePassword(PluginCall call) {
        final String username = call.getString("username", "").trim();
        final String pin = call.getString("pin", "").trim();
        final String initialPassword = call.getString("initialPassword", "");
        final String password = call.getString("password", "");
        final int timeoutMs = Math.max(5000, Math.min(call.getInt("timeoutMs", 30000), 60000));

        if (username.isEmpty() || pin.isEmpty() || initialPassword.isEmpty() || password.isEmpty()) {
            call.reject("Credenziali Fisconline incomplete.");
            return;
        }

        executor.execute(() -> {
            HttpURLConnection get = null;
            HttpURLConnection post = null;
            try {
                URL startUrl = new URL("https://telematici.agenziaentrate.gov.it/Abilitazione/RipristinaPassword/IRipristinaPassword.jsp");
                CookieManager cookies = new CookieManager(null, CookiePolicy.ACCEPT_ALL);

                get = (HttpURLConnection) startUrl.openConnection();
                get.setConnectTimeout(timeoutMs);
                get.setReadTimeout(timeoutMs);
                get.setUseCaches(false);
                get.setRequestMethod("GET");
                get.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
                get.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Mobile Safari/537.36");
                applyCookies(cookies, startUrl, get);
                int getCode = get.getResponseCode();
                storeCookies(cookies, startUrl, get);
                String html = readHttpBody(get);
                if (getCode < 200 || getCode >= 300 || html.isEmpty()) {
                    throw new Exception("Pagina ripristino Fisconline non disponibile: HTTP " + getCode);
                }

                String action = regexFirst("<form\\b[^>]*(?:id\\s*=\\s*[\"']ripriForm[\"']|name\\s*=\\s*[\"']RipristinaPasswordForm[\"'])[^>]*action\\s*=\\s*[\"']([^\"']+)[\"']", html);
                if (action == null) action = regexFirst("<form\\b[^>]*action\\s*=\\s*[\"']([^\"']*RipristinaPassword\\.do[^\"']*)[\"']", html);
                if (action == null || action.isEmpty()) action = "/Abilitazione/RipristinaPassword/RipristinaPassword.do";
                URL postUrl = new URL(startUrl, action);

                Map<String, String> fields = hiddenFields(html);
                fields.put("codFisc", username);
                fields.put("pincode", pin);
                fields.put("oldpw", initialPassword);
                fields.put("newpw", password);
                fields.put("newpwf", password);

                StringBuilder body = new StringBuilder();
                for (Map.Entry<String, String> entry : fields.entrySet()) {
                    if (body.length() > 0) body.append('&');
                    body.append(URLEncoder.encode(entry.getKey(), StandardCharsets.UTF_8.name()));
                    body.append('=');
                    body.append(URLEncoder.encode(entry.getValue(), StandardCharsets.UTF_8.name()));
                }

                post = (HttpURLConnection) postUrl.openConnection();
                post.setConnectTimeout(timeoutMs);
                post.setReadTimeout(timeoutMs);
                post.setUseCaches(false);
                post.setDoOutput(true);
                post.setRequestMethod("POST");
                post.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                post.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
                post.setRequestProperty("Referer", startUrl.toString());
                post.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Mobile Safari/537.36");
                applyCookies(cookies, postUrl, post);

                byte[] bodyBytes = body.toString().getBytes(StandardCharsets.UTF_8);
                post.setFixedLengthStreamingMode(bodyBytes.length);
                try (OutputStream os = post.getOutputStream()) {
                    os.write(bodyBytes);
                }

                int status = post.getResponseCode();
                storeCookies(cookies, postUrl, post);
                String resultHtml = readHttpBody(post);
                String plain = stripHtml(resultHtml);
                String lower = plain.toLowerCase(java.util.Locale.ROOT);
                boolean success = lower.contains("ripristino password effettuato con successo")
                        || (resultHtml.toLowerCase(java.util.Locale.ROOT).contains("esito_positivo") && lower.contains("successo"));

                String message = "";
                if (success) {
                    message = "Ripristino password effettuato con successo.";
                } else {
                    String err = regexFirst("<(?:span|div|p)[^>]*(?:class\\s*=\\s*[\"'][^\"']*errore_txt[^\"']*[\"']|id\\s*=\\s*[\"']errore[\"'])[^>]*>(.*?)</(?:span|div|p)>", resultHtml);
                    if (err != null) message = stripHtml(err);
                }
                if (message.isEmpty()) message = "Il portale non ha restituito un esito positivo riconoscibile.";

                JSObject result = new JSObject();
                result.put("ok", success);
                result.put("status", status);
                result.put("message", message);
                result.put("responseUrl", post.getURL().toString());
                result.put("transport", "native-ephemeral");
                call.resolve(result);
            } catch (Exception e) {
                call.reject("Rinnovo Fisconline non riuscito: " + (e.getMessage() == null ? e.toString() : e.getMessage()));
            } finally {
                if (get != null) get.disconnect();
                if (post != null) post.disconnect();
            }
        });
    }

    @PluginMethod
    public void downloadPdfWithWebCookies(PluginCall call) {
        String rawUrl = call.getString("url", "").replaceAll("\\s+", "");
        if (!rawUrl.startsWith("https://")) { call.reject("Indirizzo PDF DCO non valido."); return; }
        int timeoutMs = Math.max(5000, Math.min(call.getInt("timeoutMs", 60000), 90000));
        String referer = call.getString("referer", "https://ivaservizi.agenziaentrate.gov.it/ser/documenticommercialionline/#/home").replaceAll("\\s+", "");
        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(rawUrl);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(timeoutMs);
                connection.setReadTimeout(timeoutMs);
                connection.setUseCaches(false);
                connection.setInstanceFollowRedirects(true);
                connection.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,application/pdf;q=0.8,*/*;q=0.7");
                connection.setRequestProperty("Referer", referer);
                connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome Mobile Safari/537.36");
                String cookies = CookieManager.getInstance().getCookie(rawUrl);
                if (cookies != null && !cookies.trim().isEmpty()) connection.setRequestProperty("Cookie", cookies);
                int status = connection.getResponseCode();
                String type = connection.getContentType() == null ? "" : connection.getContentType();
                InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
                ByteArrayOutputStream output = new ByteArrayOutputStream();
                if (stream != null) { byte[] buffer = new byte[16384]; int read; while ((read = stream.read(buffer)) != -1) output.write(buffer, 0, read); stream.close(); }
                byte[] data = output.toByteArray();
                if (status < 200 || status >= 300) throw new Exception("HTTP " + status + (type.isEmpty() ? "" : " · " + type));
                if (data.length < 5 || data[0] != '%' || data[1] != 'P' || data[2] != 'D' || data[3] != 'F') throw new Exception("La risposta DCO non contiene un PDF valido · HTTP " + status + (type.isEmpty() ? "" : " · " + type));
                JSObject result = new JSObject(); result.put("ok", true); result.put("data", Base64.encodeToString(data, Base64.NO_WRAP)); result.put("bytes", data.length); result.put("status", status); result.put("contentType", type); result.put("responseUrl", connection.getURL().toString()); result.put("transport", "android-webview-cookie-manager"); result.put("cookieCount", cookies == null || cookies.isEmpty() ? 0 : cookies.split(";").length); call.resolve(result);
            } catch (Exception error) { call.reject("Download PDF DCO non riuscito: " + safeMessage(error)); }
            finally { if (connection != null) connection.disconnect(); }
        });
    }

    @PluginMethod
    public void savePdf(PluginCall call) {
        executor.execute(() -> {
            try {
                byte[] pdf = pdfData(call);
                String fileName = sanitizeFileName(call.getString("fileName", "documento-commerciale.pdf"));
                File file = new File(documentFolder(), fileName);
                try (FileOutputStream out = new FileOutputStream(file)) { out.write(pdf); }
                JSObject result = new JSObject(); result.put("ok", true); result.put("path", file.getAbsolutePath()); result.put("uri", file.toURI().toString()); result.put("fileName", fileName); result.put("bytes", pdf.length); call.resolve(result);
            } catch (Exception error) { call.reject("Salvataggio PDF non riuscito: " + safeMessage(error)); }
        });
    }

    private byte[] renderPdfToEscPos(byte[] pdf, int requestedWidth, int requestedThreshold, int[] pageCountOut) throws Exception {
        int width = Math.max(384, Math.min(requestedWidth, 640));
        int threshold = Math.max(80, Math.min(requestedThreshold, 240));
        int bytesPerRow = (width + 7) / 8;
        File temp = File.createTempFile("cassaiq-dco-", ".pdf", getContext().getCacheDir());
        try (FileOutputStream out = new FileOutputStream(temp)) { out.write(pdf); }
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        output.write(new byte[]{0x1b,0x40,0x1b,0x61,0x01});
        try (ParcelFileDescriptor descriptor = ParcelFileDescriptor.open(temp, ParcelFileDescriptor.MODE_READ_ONLY); PdfRenderer renderer = new PdfRenderer(descriptor)) {
            int pages = Math.min(renderer.getPageCount(), 4); pageCountOut[0] = pages;
            for (int pageIndex=0; pageIndex<pages; pageIndex++) {
                try (PdfRenderer.Page page = renderer.openPage(pageIndex)) {
                    int height = Math.max(1, Math.min(Math.round((float) width * page.getHeight() / Math.max(1, page.getWidth())), 12000));
                    Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                    bitmap.eraseColor(Color.WHITE);
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT);
                    int[] pixels = new int[width * height]; bitmap.getPixels(pixels, 0, width, 0, 0, width, height); bitmap.recycle();
                    int startY = 0;
                    while (startY < height) {
                        int bandHeight = Math.min(256, height - startY);
                        output.write(new byte[]{0x1d,0x76,0x30,0x00,(byte)(bytesPerRow & 0xff),(byte)((bytesPerRow >> 8)&0xff),(byte)(bandHeight & 0xff),(byte)((bandHeight >> 8)&0xff)});
                        byte[] raster = new byte[bytesPerRow * bandHeight];
                        for (int localY=0; localY<bandHeight; localY++) {
                            int y=startY+localY;
                            for (int x=0; x<width; x++) {
                                int c=pixels[y*width+x]; int gray=(Color.red(c)*30 + Color.green(c)*59 + Color.blue(c)*11)/100;
                                if (gray < threshold) raster[localY*bytesPerRow+x/8] |= (byte)(0x80 >> (x%8));
                            }
                        }
                        output.write(raster); output.write(0x0a); startY += bandHeight;
                    }
                    output.write(new byte[]{0x0a,0x0a});
                }
            }
        } finally { temp.delete(); }
        output.write(new byte[]{0x0a,0x0a,0x1d,0x56,0x00});
        return output.toByteArray();
    }

    private int sendNetwork(String host, int port, int timeoutMs, byte[] payload) throws Exception {
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(host, port), timeoutMs); socket.setSoTimeout(timeoutMs);
            OutputStream output = socket.getOutputStream(); output.write(payload); output.flush(); return payload.length;
        }
    }

    @PluginMethod
    public void printNetwork(PluginCall call) {
        String host=call.getString("host","").trim(); int port=call.getInt("port",9100); int timeoutMs=Math.max(1000,Math.min(call.getInt("timeoutMs",7000),30000));
        if(host.isEmpty()){call.reject("Inserisci l'indirizzo IP della stampante.");return;} if(port<1||port>65535){call.reject("Porta di rete non valida.");return;}
        final byte[] payload; try{payload=decodeBase64(call.getString("data",""));}catch(Exception e){call.reject("Dati di stampa non validi.");return;}
        executor.execute(()->{try{int bytes=sendNetwork(host,port,timeoutMs,payload);JSObject r=new JSObject();r.put("ok",true);r.put("bytes",bytes);call.resolve(r);}catch(Exception e){call.reject("Stampante non raggiungibile: "+safeMessage(e));}});
    }

    @PluginMethod
    public void printPdfNetwork(PluginCall call) {
        String host=call.getString("host","").trim(); int port=call.getInt("port",9100); int timeoutMs=Math.max(2000,Math.min(call.getInt("timeoutMs",20000),60000));
        if(host.isEmpty()){call.reject("Inserisci l'indirizzo IP della stampante.");return;}
        executor.execute(()->{try{byte[] pdf=pdfData(call);int[] pages={0};byte[] payload=renderPdfToEscPos(pdf,call.getInt("width",576),call.getInt("threshold",185),pages);int bytes=sendNetwork(host,port,timeoutMs,payload);JSObject r=new JSObject();r.put("ok",true);r.put("bytes",bytes);r.put("pages",pages[0]);r.put("sourceBytes",pdf.length);call.resolve(r);}catch(Exception e){call.reject("Stampa PDF non riuscita: "+safeMessage(e));}});
    }


    private SharedPreferences lanPrefs() {
        return getContext().getSharedPreferences(LAN_PREFS, android.content.Context.MODE_PRIVATE);
    }

    private void pruneLanDone() {
        long cutoff = System.currentTimeMillis() - 7L * 24L * 60L * 60L * 1000L;
        SharedPreferences prefs = lanPrefs();
        SharedPreferences.Editor editor = null;
        for (Map.Entry<String, ?> entry : prefs.getAll().entrySet()) {
            String key = entry.getKey();
            if (!key.startsWith(LAN_DONE_PREFIX)) continue;
            long when = 0L;
            Object value = entry.getValue();
            if (value instanceof Long) when = (Long) value;
            else {
                try { when = Long.parseLong(String.valueOf(value)); } catch (Exception ignored) {}
            }
            if (when > 0 && when < cutoff) {
                if (editor == null) editor = prefs.edit();
                editor.remove(key);
            }
        }
        if (editor != null) editor.apply();
    }

    private String localIpv4() {
        try {
            String fallback = "";
            for (NetworkInterface nif : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                try {
                    if (!nif.isUp() || nif.isLoopback()) continue;
                } catch (Exception ignored) {}
                for (InetAddress address : Collections.list(nif.getInetAddresses())) {
                    if (!(address instanceof Inet4Address) || address.isLoopbackAddress()) continue;
                    String host = address.getHostAddress();
                    if (host == null || host.isEmpty()) continue;
                    if (address.isSiteLocalAddress()) return host;
                    if (fallback.isEmpty()) fallback = host;
                }
            }
            return fallback;
        } catch (Exception ignored) {
            return "";
        }
    }

    private synchronized void stopLanServerInternal() {
        lanServerRunning = false;
        ServerSocket server = lanServerSocket;
        lanServerSocket = null;
        if (server != null) {
            try { server.close(); } catch (Exception ignored) {}
        }
    }

    private synchronized void startLanServerInternal(int port) throws Exception {
        stopLanServerInternal();
        pruneLanDone();
        ServerSocket server = new ServerSocket();
        server.setReuseAddress(true);
        server.bind(new InetSocketAddress(port));
        lanServerPort = port;
        lanServerSocket = server;
        lanServerRunning = true;
        lanExecutor.execute(() -> {
            while (lanServerRunning && lanServerSocket == server && !server.isClosed()) {
                try {
                    Socket client = server.accept();
                    lanExecutor.execute(() -> handleLanClient(client));
                } catch (Exception error) {
                    if (lanServerRunning && lanServerSocket == server) {
                        android.util.Log.w("CassaIQLAN", "Server LAN interrotto: " + safeMessage(error));
                    }
                    break;
                }
            }
        });
    }

    private void writeLanResponse(Socket socket, org.json.JSONObject response) {
        try {
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8));
            writer.write(response.toString());
            writer.write("\n");
            writer.flush();
        } catch (Exception ignored) {}
    }

    private void handleLanClient(Socket socket) {
        try (Socket client = socket) {
            client.setSoTimeout(6000);
            BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8));
            String line = reader.readLine();
            if (line == null || line.trim().isEmpty()) throw new Exception("Payload LAN vuoto.");
            if (line.length() > LAN_MAX_PAYLOAD) throw new Exception("Payload LAN troppo grande.");
            org.json.JSONObject request = new org.json.JSONObject(line);
            String type = request.optString("type", "");
            if ("cassaiq_probe".equals(type)) {
                org.json.JSONObject response = new org.json.JSONObject();
                response.put("ok", true);
                response.put("status", "pong");
                response.put("ready", !lanAllowedOwnerUserId.isEmpty());
                response.put("cash_ip", localIpv4());
                response.put("port", lanServerPort);
                writeLanResponse(client, response);
                return;
            }
            if (!"cassaiq_order".equals(type)) throw new Exception("Tipo messaggio LAN non valido.");
            String ownerUserId = request.optString("owner_user_id", "").trim();
            String deviceId = request.optString("device_id", "").trim();
            if (lanAllowedOwnerUserId.isEmpty()) throw new Exception("CassaIQ non autenticata per la rete locale.");
            if (!lanAllowedOwnerUserId.equals(ownerUserId)) throw new Exception("Account CassaIQ non corrispondente.");
            Set<String> allowedDevices = lanAuthorizedDeviceIds;
            if (!allowedDevices.isEmpty() && !allowedDevices.contains(deviceId)) throw new Exception("CassaIQ Client non autorizzato.");
            String orderId = request.optString("order_id", "").trim();
            if (!orderId.matches("[A-Za-z0-9-]{8,80}")) throw new Exception("ID comanda LAN non valido.");
            org.json.JSONArray items = request.optJSONArray("items");
            if (items == null || items.length() < 1 || items.length() > 200) throw new Exception("Righe comanda LAN non valide.");

            SharedPreferences prefs = lanPrefs();
            String pendingKey = LAN_PENDING_PREFIX + orderId;
            String doneKey = LAN_DONE_PREFIX + orderId;
            boolean duplicate = prefs.contains(pendingKey) || prefs.contains(doneKey);
            if (!duplicate) {
                if (!prefs.edit().putString(pendingKey, request.toString()).commit()) {
                    throw new Exception("Impossibile salvare la comanda nella coda locale.");
                }
            }

            org.json.JSONObject response = new org.json.JSONObject();
            response.put("ok", true);
            response.put("status", duplicate ? "already_received" : "received");
            response.put("order_id", orderId);
            response.put("duplicate", duplicate);
            response.put("cash_ip", localIpv4());
            writeLanResponse(client, response);
        } catch (Exception error) {
            try {
                org.json.JSONObject response = new org.json.JSONObject();
                response.put("ok", false);
                response.put("error", safeMessage(error));
                writeLanResponse(socket, response);
            } catch (Exception ignored) {}
            try { socket.close(); } catch (Exception ignored) {}
        }
    }

    @PluginMethod
    public void lanServerStart(PluginCall call) {
        int port = Math.max(1024, Math.min(call.getInt("port", 8765), 65535));
        String ownerUserId = call.getString("ownerUserId", "").trim();
        String deviceCsv = call.getString("authorizedDeviceIdsCsv", "").trim();
        Set<String> authorized = new HashSet<>();
        if (!deviceCsv.isEmpty()) for (String part : deviceCsv.split(",")) { String id = part.trim(); if (!id.isEmpty()) authorized.add(id); }
        lanAllowedOwnerUserId = ownerUserId;
        lanAuthorizedDeviceIds = Collections.unmodifiableSet(authorized);
        executor.execute(() -> {
            try {
                startLanServerInternal(port);
                JSObject result = new JSObject();
                result.put("ok", true);
                result.put("running", true);
                result.put("port", lanServerPort);
                result.put("ip", localIpv4());
                call.resolve(result);
            } catch (Exception error) {
                stopLanServerInternal();
                call.reject("Server LAN non avviato: " + safeMessage(error));
            }
        });
    }

    @PluginMethod
    public void lanServerStop(PluginCall call) {
        stopLanServerInternal();
        JSObject result = new JSObject();
        result.put("ok", true);
        result.put("running", false);
        result.put("port", lanServerPort);
        result.put("ip", localIpv4());
        call.resolve(result);
    }

    @PluginMethod
    public void lanServerStatus(PluginCall call) {
        JSObject result = new JSObject();
        result.put("ok", true);
        result.put("running", lanServerRunning && lanServerSocket != null && !lanServerSocket.isClosed());
        result.put("port", lanServerPort);
        result.put("ip", localIpv4());
        int pending = 0;
        for (String key : lanPrefs().getAll().keySet()) if (key.startsWith(LAN_PENDING_PREFIX)) pending++;
        result.put("pending", pending);
        call.resolve(result);
    }

    @PluginMethod
    public void lanGetPendingOrders(PluginCall call) {
        int max = Math.max(1, Math.min(call.getInt("max", 50), 200));
        executor.execute(() -> {
            try {
                JSArray orders = new JSArray();
                int count = 0;
                for (Map.Entry<String, ?> entry : lanPrefs().getAll().entrySet()) {
                    if (!entry.getKey().startsWith(LAN_PENDING_PREFIX) || count >= max) continue;
                    Object value = entry.getValue();
                    if (!(value instanceof String)) continue;
                    try {
                        orders.put(new org.json.JSONObject((String) value));
                        count++;
                    } catch (Exception ignored) {}
                }
                JSObject result = new JSObject();
                result.put("ok", true);
                result.put("orders", orders);
                result.put("count", count);
                call.resolve(result);
            } catch (Exception error) {
                call.reject("Lettura coda LAN non riuscita: " + safeMessage(error));
            }
        });
    }

    @PluginMethod
    public void lanAcknowledgeOrder(PluginCall call) {
        String orderId = call.getString("orderId", "").trim();
        if (!orderId.matches("[A-Za-z0-9-]{8,80}")) { call.reject("ID comanda LAN non valido."); return; }
        executor.execute(() -> {
            try {
                SharedPreferences prefs = lanPrefs();
                if (!prefs.edit()
                        .remove(LAN_PENDING_PREFIX + orderId)
                        .putLong(LAN_DONE_PREFIX + orderId, System.currentTimeMillis())
                        .commit()) throw new Exception("Aggiornamento coda locale non riuscito.");
                pruneLanDone();
                JSObject result = new JSObject(); result.put("ok", true); result.put("orderId", orderId); call.resolve(result);
            } catch (Exception error) {
                call.reject("Conferma comanda LAN non riuscita: " + safeMessage(error));
            }
        });
    }

    @PluginMethod
    public void lanSendOrder(PluginCall call) {
        String host = call.getString("host", "").trim();
        int port = Math.max(1024, Math.min(call.getInt("port", 8765), 65535));
        int timeoutMs = Math.max(1000, Math.min(call.getInt("timeoutMs", 5000), 15000));
        String payload = call.getString("payload", "");
        if (host.isEmpty()) { call.reject("LAN_CONNECT_FAILED: IP CassaIQ non impostato."); return; }
        if (payload.trim().isEmpty() || payload.length() > LAN_MAX_PAYLOAD) { call.reject("Payload LAN non valido."); return; }
        try { new org.json.JSONObject(payload); } catch (Exception e) { call.reject("Payload LAN non valido."); return; }

        executor.execute(() -> {
            boolean connected = false;
            try (Socket socket = new Socket()) {
                try {
                    socket.connect(new InetSocketAddress(host, port), timeoutMs);
                    connected = true;
                } catch (Exception connectError) {
                    throw new Exception("LAN_CONNECT_FAILED: " + safeMessage(connectError));
                }
                socket.setSoTimeout(timeoutMs);
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8));
                writer.write(payload);
                writer.write("\n");
                writer.flush();

                BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                String responseLine = reader.readLine();
                if (responseLine == null || responseLine.trim().isEmpty()) throw new Exception("LAN_ACK_UNCERTAIN: nessuna conferma dalla cassa.");
                org.json.JSONObject response = new org.json.JSONObject(responseLine);
                if (!response.optBoolean("ok", false)) throw new Exception("LAN_REJECTED: " + response.optString("error", "comanda rifiutata"));
                JSObject result = new JSObject(response.toString());
                call.resolve(result);
            } catch (Exception error) {
                String message = safeMessage(error);
                if (connected && !message.startsWith("LAN_")) message = "LAN_ACK_UNCERTAIN: " + message;
                call.reject(message);
            }
        });
    }

    @PluginMethod
    public void lanLocalIp(PluginCall call) {
        JSObject result = new JSObject();
        result.put("ip", localIpv4());
        call.resolve(result);
    }

    private SharedPreferences securePrefs() {
        return getContext().getSharedPreferences(SECURE_PREFS, android.content.Context.MODE_PRIVATE);
    }

    private SecretKey getOrCreateSecretKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (keyStore.containsAlias(SECURE_KEY_ALIAS)) {
            java.security.Key key = keyStore.getKey(SECURE_KEY_ALIAS, null);
            if (key instanceof SecretKey) return (SecretKey) key;
        }
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(
                SECURE_KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build());
        return generator.generateKey();
    }

    private String encryptSecureValue(String value) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey());
        byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
        return Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP) + ":" + Base64.encodeToString(encrypted, Base64.NO_WRAP);
    }

    private String decryptSecureValue(String stored) throws Exception {
        if (stored == null || stored.isEmpty()) return "";
        String[] parts = stored.split(":", 2);
        if (parts.length != 2) throw new Exception("Formato archivio sicuro non valido.");
        byte[] iv = Base64.decode(parts[0], Base64.DEFAULT);
        byte[] encrypted = Base64.decode(parts[1], Base64.DEFAULT);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), new GCMParameterSpec(128, iv));
        return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
    }

    @PluginMethod
    public void secureSet(PluginCall call) {
        String key = call.getString("key", "").trim();
        String value = call.getString("value", "");
        if (key.isEmpty()) { call.reject("Chiave archivio sicuro non valida."); return; }
        executor.execute(() -> {
            try {
                String encrypted = encryptSecureValue(value);
                if (!securePrefs().edit().putString(key, encrypted).commit()) throw new Exception("Scrittura archivio sicuro non riuscita.");
                JSObject result = new JSObject(); result.put("ok", true); call.resolve(result);
            } catch (Exception error) { call.reject("Salvataggio sicuro non riuscito: " + safeMessage(error)); }
        });
    }

    @PluginMethod
    public void secureGet(PluginCall call) {
        String key = call.getString("key", "").trim();
        if (key.isEmpty()) { call.reject("Chiave archivio sicuro non valida."); return; }
        executor.execute(() -> {
            try {
                String stored = securePrefs().getString(key, "");
                String value = stored == null || stored.isEmpty() ? "" : decryptSecureValue(stored);
                JSObject result = new JSObject(); result.put("value", value); call.resolve(result);
            } catch (Exception error) { call.reject("Lettura archivio sicuro non riuscita: " + safeMessage(error)); }
        });
    }

    @PluginMethod
    public void secureRemove(PluginCall call) {
        String key = call.getString("key", "").trim();
        if (key.isEmpty()) { call.reject("Chiave archivio sicuro non valida."); return; }
        executor.execute(() -> {
            try {
                securePrefs().edit().remove(key).apply();
                JSObject result = new JSObject(); result.put("ok", true); call.resolve(result);
            } catch (Exception error) { call.reject("Eliminazione archivio sicuro non riuscita: " + safeMessage(error)); }
        });
    }

    private static String safeMessage(Exception error){String message=error.getMessage();return message==null||message.trim().isEmpty()?error.getClass().getSimpleName():message;}
    @Override protected void handleOnDestroy(){stopLanServerInternal();lanExecutor.shutdownNow();executor.shutdownNow();super.handleOnDestroy();}
}
