import Foundation
import Capacitor
import Darwin
import Network
import PDFKit
import Security
import UIKit
import WebKit

@objc(CassaIQPrinterPlugin)
public class CassaIQPrinterPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "CassaIQPrinterPlugin"
    public let jsName = "CassaIQPrinter"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "printNetwork", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "savePdf", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "downloadPdfWithWebCookies", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "renewFisconlinePassword", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "printPdfNetwork", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "secureSet", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "secureGet", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "secureRemove", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "lanServerStart", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "lanServerStop", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "lanServerStatus", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "lanGetPendingOrders", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "lanAcknowledgeOrder", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "lanLocalIp", returnType: CAPPluginReturnPromise)
    ]

    private let secureService = "it.menoova.cassaiq.secure"
    private let lanQueue = DispatchQueue(label: "it.menoova.cassaiq.lan", qos: .userInitiated)
    private var lanListener: NWListener?
    private var lanServerRunning = false
    private var lanServerPort = 8765
    private var lanAllowedOwnerUserId = ""
    private var lanAuthorizedDeviceIds = Set<String>()
    private let lanPendingPrefix = "cassaiq.lan.pending."
    private let lanDonePrefix = "cassaiq.lan.done."
    private let lanMaxPayload = 262_144

    @objc public func printNetwork(_ call: CAPPluginCall) {
        guard let host = call.getString("host")?.trimmingCharacters(in: .whitespacesAndNewlines), !host.isEmpty else {
            call.reject("Inserisci l'indirizzo IP della stampante.")
            return
        }
        let portValue = call.getInt("port") ?? 9100
        guard let port = NWEndpoint.Port(rawValue: UInt16(clamping: portValue)) else {
            call.reject("Porta di rete non valida.")
            return
        }
        guard let base64 = call.getString("data"), let payload = Data(base64Encoded: base64), !payload.isEmpty else {
            call.reject("Dati di stampa non validi.")
            return
        }

        let timeoutMs = max(1000, min(call.getInt("timeoutMs") ?? 7000, 30000))
        let queue = DispatchQueue(label: "it.menoova.cassaiq.printer.network", qos: .userInitiated)
        let connection = NWConnection(host: NWEndpoint.Host(host), port: port, using: .tcp)
        let lock = NSLock()
        var completed = false

        func finish(_ action: @escaping () -> Void) {
            lock.lock()
            if completed {
                lock.unlock()
                return
            }
            completed = true
            lock.unlock()
            connection.cancel()
            DispatchQueue.main.async(execute: action)
        }

        let timeout = DispatchWorkItem {
            finish { call.reject("Connessione scaduta. Verifica IP, porta e rete locale.") }
        }
        queue.asyncAfter(deadline: .now() + .milliseconds(timeoutMs), execute: timeout)

        connection.stateUpdateHandler = { state in
            switch state {
            case .ready:
                connection.send(content: payload, completion: .contentProcessed { error in
                    timeout.cancel()
                    if let error = error {
                        finish { call.reject("Invio alla stampante non riuscito: \(error.localizedDescription)") }
                    } else {
                        finish { call.resolve(["ok": true, "bytes": payload.count]) }
                    }
                })
            case .failed(let error):
                timeout.cancel()
                finish { call.reject("Stampante non raggiungibile: \(error.localizedDescription)") }
            case .cancelled:
                break
            default:
                break
            }
        }
        connection.start(queue: queue)
    }


    private func sanitizedFileName(_ raw: String) -> String {
        let base = raw.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "documento-commerciale.pdf" : raw
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_."))
        let cleaned = base.unicodeScalars.map { allowed.contains($0) ? Character(String($0)) : "-" }
        var name = String(cleaned).replacingOccurrences(of: "--", with: "-")
        if !name.lowercased().hasSuffix(".pdf") { name += ".pdf" }
        return name
    }

    private func documentsFolder() throws -> URL {
        let base = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let folder = base.appendingPathComponent("CassaIQ", isDirectory: true).appendingPathComponent("Documenti", isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true, attributes: nil)
        return folder
    }

    private func pdfData(from call: CAPPluginCall) throws -> Data {
        if let encoded = call.getString("data"), !encoded.isEmpty, let data = Data(base64Encoded: encoded), !data.isEmpty {
            return data
        }
        if let rawPath = call.getString("path"), !rawPath.isEmpty {
            let url: URL
            if rawPath.hasPrefix("file://"), let parsed = URL(string: rawPath) { url = parsed }
            else { url = URL(fileURLWithPath: rawPath) }
            let data = try Data(contentsOf: url)
            if !data.isEmpty { return data }
        }
        throw NSError(domain: "CassaIQPrinter", code: 10, userInfo: [NSLocalizedDescriptionKey: "PDF non disponibile o non valido."])
    }



    private func htmlDecoded(_ value: String) -> String {
        value
            .replacingOccurrences(of: "&amp;", with: "&")
            .replacingOccurrences(of: "&quot;", with: "\"")
            .replacingOccurrences(of: "&#39;", with: "'")
            .replacingOccurrences(of: "&lt;", with: "<")
            .replacingOccurrences(of: "&gt;", with: ">")
            .replacingOccurrences(of: "&nbsp;", with: " ")
    }

    private func stripHtml(_ html: String) -> String {
        let noTags = html.replacingOccurrences(of: "<[^>]+>", with: " ", options: .regularExpression)
        return htmlDecoded(noTags).replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func formEncode(_ value: String) -> String {
        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: "&+=?")
        return value.addingPercentEncoding(withAllowedCharacters: allowed)?
            .replacingOccurrences(of: "%20", with: "+") ?? ""
    }

    private func regexFirst(_ pattern: String, in text: String, group: Int = 1) -> String? {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive, .dotMatchesLineSeparators]) else { return nil }
        let ns = text as NSString
        guard let match = regex.firstMatch(in: text, range: NSRange(location: 0, length: ns.length)),
              group < match.numberOfRanges else { return nil }
        let r = match.range(at: group)
        guard r.location != NSNotFound else { return nil }
        return ns.substring(with: r)
    }

    private func hiddenFormFields(_ html: String) -> [String: String] {
        var result: [String: String] = [:]
        guard let regex = try? NSRegularExpression(pattern: "<input\\b[^>]*>", options: [.caseInsensitive, .dotMatchesLineSeparators]) else { return result }
        let ns = html as NSString
        for match in regex.matches(in: html, range: NSRange(location: 0, length: ns.length)) {
            let tag = ns.substring(with: match.range)
            let type = regexFirst("\\btype\\s*=\\s*[\"']([^\"']*)[\"']", in: tag)?.lowercased() ?? ""
            guard type == "hidden" else { continue }
            guard let name = regexFirst("\\bname\\s*=\\s*[\"']([^\"']+)[\"']", in: tag), !name.isEmpty else { continue }
            let value = regexFirst("\\bvalue\\s*=\\s*[\"']([^\"']*)[\"']", in: tag) ?? ""
            result[htmlDecoded(name)] = htmlDecoded(value)
        }
        return result
    }

    @objc public func renewFisconlinePassword(_ call: CAPPluginCall) {
        let username = (call.getString("username") ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let pin = (call.getString("pin") ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let initialPassword = call.getString("initialPassword") ?? ""
        let password = call.getString("password") ?? ""
        let timeoutMs = max(5000, min(call.getInt("timeoutMs") ?? 30000, 60000))

        guard !username.isEmpty, !pin.isEmpty, !initialPassword.isEmpty, !password.isEmpty else {
            call.reject("Credenziali Fisconline incomplete.")
            return
        }

        guard let startURL = URL(string: "https://telematici.agenziaentrate.gov.it/Abilitazione/RipristinaPassword/IRipristinaPassword.jsp") else {
            call.reject("URL ripristino Fisconline non valido.")
            return
        }

        // Sessione HTTP EPHEMERAL: nessun cookie viene letto o scritto nella WKWebView DCO.
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = TimeInterval(timeoutMs) / 1000.0
        config.timeoutIntervalForResource = TimeInterval(timeoutMs) / 1000.0
        config.httpShouldSetCookies = true
        config.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        let session = URLSession(configuration: config)

        var getRequest = URLRequest(url: startURL)
        getRequest.httpMethod = "GET"
        getRequest.setValue("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", forHTTPHeaderField: "Accept")
        getRequest.setValue("Mozilla/5.0 (iPad; CPU OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148", forHTTPHeaderField: "User-Agent")

        session.dataTask(with: getRequest) { [weak self] data, response, error in
            guard let self = self else { return }
            if let error = error {
                session.finishTasksAndInvalidate()
                DispatchQueue.main.async { call.reject("Apertura ripristino Fisconline non riuscita: \(error.localizedDescription)") }
                return
            }
            guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode), let data = data, !data.isEmpty else {
                let code = (response as? HTTPURLResponse)?.statusCode ?? 0
                session.finishTasksAndInvalidate()
                DispatchQueue.main.async { call.reject("Pagina ripristino Fisconline non disponibile: HTTP \(code).") }
                return
            }

            let html = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1) ?? ""
            guard !html.isEmpty else {
                session.finishTasksAndInvalidate()
                DispatchQueue.main.async { call.reject("Pagina ripristino Fisconline vuota.") }
                return
            }

            let actionRaw = self.regexFirst("<form\\b[^>]*(?:id\\s*=\\s*[\"']ripriForm[\"']|name\\s*=\\s*[\"']RipristinaPasswordForm[\"'])[^>]*action\\s*=\\s*[\"']([^\"']+)[\"']", in: html)
                ?? self.regexFirst("<form\\b[^>]*action\\s*=\\s*[\"']([^\"']*RipristinaPassword\\.do[^\"']*)[\"']", in: html)
                ?? "/Abilitazione/RipristinaPassword/RipristinaPassword.do"

            guard let postURL = URL(string: actionRaw, relativeTo: startURL)?.absoluteURL else {
                session.finishTasksAndInvalidate()
                DispatchQueue.main.async { call.reject("Destinazione ripristino Fisconline non riconosciuta.") }
                return
            }

            var fields = self.hiddenFormFields(html)
            fields["codFisc"] = username
            fields["pincode"] = pin
            fields["oldpw"] = initialPassword
            fields["newpw"] = password
            fields["newpwf"] = password

            let body = fields.sorted(by: { $0.key < $1.key })
                .map { "\(self.formEncode($0.key))=\(self.formEncode($0.value))" }
                .joined(separator: "&")

            var post = URLRequest(url: postURL)
            post.httpMethod = "POST"
            post.httpBody = body.data(using: .utf8)
            post.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
            post.setValue(startURL.absoluteString, forHTTPHeaderField: "Referer")
            post.setValue("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", forHTTPHeaderField: "Accept")
            post.setValue("Mozilla/5.0 (iPad; CPU OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148", forHTTPHeaderField: "User-Agent")

            session.dataTask(with: post) { resultData, resultResponse, resultError in
                defer { session.finishTasksAndInvalidate() }
                if let resultError = resultError {
                    DispatchQueue.main.async { call.reject("Invio ripristino Fisconline non riuscito: \(resultError.localizedDescription)") }
                    return
                }
                guard let resultHttp = resultResponse as? HTTPURLResponse, let resultData = resultData else {
                    DispatchQueue.main.async { call.reject("Risposta ripristino Fisconline non disponibile.") }
                    return
                }

                let resultHtml = String(data: resultData, encoding: .utf8) ?? String(data: resultData, encoding: .isoLatin1) ?? ""
                let lower = self.stripHtml(resultHtml).lowercased()
                let success = lower.contains("ripristino password effettuato con successo")
                    || (resultHtml.lowercased().contains("esito_positivo") && lower.contains("successo"))

                var message = ""
                if success {
                    message = "Ripristino password effettuato con successo."
                } else if let err = self.regexFirst("<(?:span|div|p)[^>]*(?:class\\s*=\\s*[\"'][^\"']*errore_txt[^\"']*[\"']|id\\s*=\\s*[\"']errore[\"'])[^>]*>(.*?)</(?:span|div|p)>", in: resultHtml) {
                    message = self.stripHtml(err)
                }
                if message.isEmpty {
                    message = "Il portale non ha restituito un esito positivo riconoscibile."
                }

                DispatchQueue.main.async {
                    call.resolve([
                        "ok": success,
                        "status": resultHttp.statusCode,
                        "message": message,
                        "responseUrl": resultResponse?.url?.absoluteString ?? postURL.absoluteString,
                        "transport": "native-ephemeral"
                    ])
                }
            }.resume()
        }.resume()
    }

    @objc public func downloadPdfWithWebCookies(_ call: CAPPluginCall) {
        let rawUrl = (call.getString("url") ?? "").components(separatedBy: .whitespacesAndNewlines).joined()
        guard let url = URL(string: rawUrl), url.scheme == "https" else {
            call.reject("Indirizzo PDF DCO non valido.")
            return
        }
        let timeoutMs = max(5000, min(call.getInt("timeoutMs") ?? 60000, 90000))
        let referer = (call.getString("referer") ?? "https://ivaservizi.agenziaentrate.gov.it/ser/documenticommercialionline/#/home").components(separatedBy: .whitespacesAndNewlines).joined()
        let cookieStore = WKWebsiteDataStore.default().httpCookieStore
        cookieStore.getAllCookies { cookies in
            var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: TimeInterval(timeoutMs) / 1000.0)
            request.httpMethod = "GET"
            request.setValue("text/html,application/xhtml+xml,application/xml;q=0.9,application/pdf;q=0.8,*/*;q=0.7", forHTTPHeaderField: "Accept")
            request.setValue(referer, forHTTPHeaderField: "Referer")
            request.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148", forHTTPHeaderField: "User-Agent")
            let relevant = cookies.filter { cookie in
                let domain = cookie.domain.trimmingCharacters(in: CharacterSet(charactersIn: ".")).lowercased()
                let host = (url.host ?? "").lowercased()
                return host == domain || host.hasSuffix("." + domain)
            }
            let cookieHeaders = HTTPCookie.requestHeaderFields(with: relevant)
            for (key, value) in cookieHeaders { request.setValue(value, forHTTPHeaderField: key) }

            let configuration = URLSessionConfiguration.ephemeral
            configuration.timeoutIntervalForRequest = TimeInterval(timeoutMs) / 1000.0
            configuration.timeoutIntervalForResource = TimeInterval(timeoutMs) / 1000.0
            configuration.httpShouldSetCookies = true
            let session = URLSession(configuration: configuration)
            let task = session.dataTask(with: request) { data, response, error in
                defer { session.finishTasksAndInvalidate() }
                if let error = error {
                    DispatchQueue.main.async { call.reject("Download PDF DCO non riuscito: \(error.localizedDescription)") }
                    return
                }
                guard let http = response as? HTTPURLResponse else {
                    DispatchQueue.main.async { call.reject("Risposta HTTP DCO non disponibile.") }
                    return
                }
                let contentType = http.value(forHTTPHeaderField: "Content-Type") ?? ""
                guard (200...299).contains(http.statusCode), let data = data, !data.isEmpty else {
                    DispatchQueue.main.async { call.reject("Download PDF DCO rifiutato: HTTP \(http.statusCode) \(contentType)") }
                    return
                }
                guard data.count >= 5, String(data: data.prefix(5), encoding: .ascii) == "%PDF", PDFDocument(data: data) != nil else {
                    DispatchQueue.main.async { call.reject("La risposta DCO non contiene un PDF valido: HTTP \(http.statusCode) \(contentType)") }
                    return
                }
                DispatchQueue.main.async {
                    call.resolve([
                        "ok": true,
                        "data": data.base64EncodedString(),
                        "bytes": data.count,
                        "status": http.statusCode,
                        "contentType": contentType,
                        "responseUrl": http.url?.absoluteString ?? rawUrl,
                        "transport": "ios-wk-cookie-store",
                        "cookieCount": relevant.count
                    ])
                }
            }
            task.resume()
        }
    }

    @objc public func savePdf(_ call: CAPPluginCall) {
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let data = try self.pdfData(from: call)
                guard PDFDocument(data: data) != nil else { throw NSError(domain: "CassaIQPrinter", code: 11, userInfo: [NSLocalizedDescriptionKey: "Il file ricevuto non è un PDF leggibile."]) }
                let fileName = self.sanitizedFileName(call.getString("fileName") ?? "documento-commerciale.pdf")
                let url = try self.documentsFolder().appendingPathComponent(fileName)
                try data.write(to: url, options: .atomic)
                DispatchQueue.main.async { call.resolve(["ok": true, "path": url.path, "uri": url.absoluteString, "fileName": fileName, "bytes": data.count]) }
            } catch {
                DispatchQueue.main.async { call.reject("Salvataggio PDF non riuscito: \(error.localizedDescription)") }
            }
        }
    }

    private func escPosRaster(pdfData: Data, width requestedWidth: Int, threshold requestedThreshold: Int) throws -> (Data, Int) {
        guard let document = PDFDocument(data: pdfData), document.pageCount > 0 else {
            throw NSError(domain: "CassaIQPrinter", code: 12, userInfo: [NSLocalizedDescriptionKey: "PDF non leggibile."])
        }

        let printerWidth = max(384, min(requestedWidth, 640))
        let threshold = UInt8(max(80, min(requestedThreshold, 240)))
        // La diagnostica del contenuto usa una soglia leggermente più chiara della stampa,
        // ma ignora i watermark molto tenui del PDF dell'Agenzia.
        let analysisThreshold = UInt8(max(185, min(Int(threshold) + 24, 218)))
        let bytesPerRow = (printerWidth + 7) / 8
        var output = Data([0x1b, 0x40, 0x1b, 0x61, 0x01])
        let pages = min(document.pageCount, 4)

        func appendRaster(_ pixels: [UInt8], width: Int, height: Int) {
            guard width == printerWidth, height > 0 else { return }
            var startY = 0
            while startY < height {
                let bandHeight = min(256, height - startY)
                let xL = UInt8(bytesPerRow & 0xff), xH = UInt8((bytesPerRow >> 8) & 0xff)
                let yL = UInt8(bandHeight & 0xff), yH = UInt8((bandHeight >> 8) & 0xff)
                output.append(contentsOf: [0x1d, 0x76, 0x30, 0x00, xL, xH, yL, yH])
                var raster = [UInt8](repeating: 0, count: bytesPerRow * bandHeight)
                for localY in 0..<bandHeight {
                    let y = startY + localY
                    for x in 0..<printerWidth where pixels[y * printerWidth + x] < threshold {
                        raster[localY * bytesPerRow + x / 8] |= UInt8(0x80 >> (x % 8))
                    }
                }
                output.append(contentsOf: raster)
                startY += bandHeight
            }
            output.append(contentsOf: [0x0a, 0x0a])
        }

        func inkBounds(_ gray: [UInt8], width: Int, height: Int, y0: Int, y1: Int) -> (Int, Int, Int, Int)? {
            var minX = width, maxX = -1, minY = height, maxY = -1
            let lowY = max(0, y0), highY = min(height - 1, y1)
            guard lowY <= highY else { return nil }
            for y in lowY...highY {
                let row = y * width
                for x in 0..<width where gray[row + x] < analysisThreshold {
                    minX = min(minX, x); maxX = max(maxX, x)
                    minY = min(minY, y); maxY = max(maxY, y)
                }
            }
            return maxX >= minX && maxY >= minY ? (minX, maxX, minY, maxY) : nil
        }

        func horizontalBands(_ gray: [UInt8], width: Int, height: Int) -> [(Int, Int)] {
            let minimumInk = max(2, width / 700)
            var active = [Bool](repeating: false, count: height)
            for y in 0..<height {
                let row = y * width
                var count = 0
                for x in 0..<width where gray[row + x] < analysisThreshold {
                    count += 1
                    if count >= minimumInk { active[y] = true; break }
                }
            }

            // Unisce le righe vicine in blocchi logici: intestazione, tabella, totali, footer.
            let allowedGap = max(24, Int(CGFloat(height) * 0.012))
            var result: [(Int, Int)] = []
            var start: Int? = nil, lastActive = 0, gap = 0
            for y in 0..<height {
                if active[y] {
                    if start == nil { start = y }
                    lastActive = y; gap = 0
                } else if start != nil {
                    gap += 1
                    if gap > allowedGap {
                        result.append((max(0, start! - 12), min(height - 1, lastActive + 12)))
                        start = nil; gap = 0
                    }
                }
            }
            if let start { result.append((max(0, start - 12), min(height - 1, lastActive + 12))) }
            if result.isEmpty, let all = inkBounds(gray, width: width, height: height, y0: 0, y1: height - 1) {
                return [(all.2, all.3)]
            }
            return result
        }

        func segmentColumns(_ gray: [UInt8], width: Int, band: (Int, Int), x0: Int, x1: Int) -> [(Int, Int)] {
            let cropWidth = x1 - x0 + 1
            // Con il PDF A4 adattato in una sola colonna i caratteri risultano troppo piccoli.
            // Manteniamo almeno ~1,7 dot per punto tipografico e, quando serve,
            // dividiamo il blocco in pannelli consecutivi con una piccola sovrapposizione.
            let maximumSourceWidth = max(printerWidth, Int(CGFloat(printerWidth) / 0.86))
            if cropWidth <= maximumSourceWidth { return [(x0, x1)] }

            let bandHeight = band.1 - band.0 + 1
            let minimumColumnInk = max(1, bandHeight / 260)
            var columnActive = [Bool](repeating: false, count: cropWidth)
            for localX in 0..<cropWidth {
                let x = x0 + localX
                var count = 0
                for y in band.0...band.1 where gray[y * width + x] < analysisThreshold {
                    count += 1
                    if count >= minimumColumnInk { columnActive[localX] = true; break }
                }
            }

            // Prima prova a separare colonne realmente distinte, per esempio etichette e importi.
            var logical: [(Int, Int)] = []
            var runStart: Int? = nil, last = 0, gap = 0
            let splitGap = max(42, cropWidth / 18)
            for i in 0..<cropWidth {
                if columnActive[i] {
                    if runStart == nil { runStart = i }
                    last = i; gap = 0
                } else if runStart != nil {
                    gap += 1
                    if gap > splitGap {
                        logical.append((x0 + max(0, runStart! - 12), x0 + min(cropWidth - 1, last + 12)))
                        runStart = nil; gap = 0
                    }
                }
            }
            if let runStart { logical.append((x0 + max(0, runStart - 12), x0 + min(cropWidth - 1, last + 12))) }
            if logical.count > 1 && logical.allSatisfy({ $0.1 - $0.0 + 1 <= maximumSourceWidth }) { return logical }

            // Tabelle molto larghe vengono stampate in due o più pannelli da sinistra a destra.
            let overlap = 36
            let step = max(1, maximumSourceWidth - overlap)
            var panels: [(Int, Int)] = []
            var current = x0
            while current <= x1 {
                let end = min(x1, current + maximumSourceWidth - 1)
                panels.append((current, end))
                if end >= x1 { break }
                current += step
            }
            return panels
        }

        func scaledPanel(_ gray: [UInt8], sourceWidth: Int, sourceHeight: Int, region: (Int, Int, Int, Int)) -> ([UInt8], Int) {
            let x0 = max(0, region.0), x1 = min(sourceWidth - 1, region.1)
            let y0 = max(0, region.2), y1 = min(sourceHeight - 1, region.3)
            let regionWidth = max(1, x1 - x0 + 1), regionHeight = max(1, y1 - y0 + 1)
            let scale = min(2.25, CGFloat(printerWidth) / CGFloat(regionWidth))
            let targetWidth = min(printerWidth, max(1, Int((CGFloat(regionWidth) * scale).rounded(.up))))
            let targetHeight = max(1, min(12000, Int((CGFloat(regionHeight) * scale).rounded(.up))))
            let left = max(0, (printerWidth - targetWidth) / 2)
            var target = [UInt8](repeating: 255, count: printerWidth * targetHeight)

            for ty in 0..<targetHeight {
                let sy0 = min(regionHeight - 1, Int(CGFloat(ty) / scale))
                let sy1 = min(regionHeight - 1, Int(CGFloat(ty + 1) / scale))
                for tx in 0..<targetWidth {
                    let sx0 = min(regionWidth - 1, Int(CGFloat(tx) / scale))
                    let sx1 = min(regionWidth - 1, Int(CGFloat(tx + 1) / scale))
                    var darkest = UInt8(255)
                    // Il valore più scuro nell'area preserva i tratti sottili durante il ridimensionamento.
                    for sy in sy0...max(sy0, sy1) {
                        let row = (y0 + sy) * sourceWidth
                        for sx in sx0...max(sx0, sx1) { darkest = min(darkest, gray[row + x0 + sx]) }
                    }
                    target[ty * printerWidth + left + tx] = darkest
                }
            }
            return (target, targetHeight)
        }

        for pageIndex in 0..<pages {
            guard let page = document.page(at: pageIndex) else { continue }
            let bounds = page.bounds(for: .mediaBox)
            guard bounds.width > 0, bounds.height > 0 else { continue }

            // Render ad alta risoluzione per ottenere testo leggibile anche dopo i ritagli.
            let renderScale: CGFloat = 2.0
            let renderWidth = max(1, min(Int(ceil(bounds.width * renderScale)), 2400))
            let renderHeight = max(1, min(Int(ceil(bounds.height * renderScale)), 4000))
            let scaleX = CGFloat(renderWidth) / bounds.width
            let scaleY = CGFloat(renderHeight) / bounds.height
            let format = UIGraphicsImageRendererFormat.default()
            format.scale = 1; format.opaque = true
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: renderWidth, height: renderHeight), format: format)
            let image = renderer.image { context in
                UIColor.white.setFill()
                context.fill(CGRect(x: 0, y: 0, width: renderWidth, height: renderHeight))
                let cg = context.cgContext
                cg.saveGState()
                cg.translateBy(x: 0, y: CGFloat(renderHeight))
                cg.scaleBy(x: scaleX, y: -scaleY)
                cg.translateBy(x: -bounds.minX, y: -bounds.minY)
                page.draw(with: .mediaBox, to: cg)
                cg.restoreGState()
            }
            guard let cgImage = image.cgImage else { continue }

            var rawGray = [UInt8](repeating: 255, count: renderWidth * renderHeight)
            let colorSpace = CGColorSpaceCreateDeviceGray()
            let ok = rawGray.withUnsafeMutableBytes { ptr -> Bool in
                guard let ctx = CGContext(data: ptr.baseAddress, width: renderWidth, height: renderHeight, bitsPerComponent: 8, bytesPerRow: renderWidth, space: colorSpace, bitmapInfo: CGImageAlphaInfo.none.rawValue) else { return false }
                ctx.setFillColor(gray: 1, alpha: 1)
                ctx.fill(CGRect(x: 0, y: 0, width: renderWidth, height: renderHeight))
                // Manteniamo lo stesso rendering della versione precedente e correggiamo
                // l'ordine delle righe subito dopo: così eliminiamo solo il ribaltamento verticale.
                ctx.translateBy(x: 0, y: CGFloat(renderHeight))
                ctx.scaleBy(x: 1, y: -1)
                ctx.interpolationQuality = .high
                ctx.draw(cgImage, in: CGRect(x: 0, y: 0, width: renderWidth, height: renderHeight))
                return true
            }
            if !ok { throw NSError(domain: "CassaIQPrinter", code: 13, userInfo: [NSLocalizedDescriptionKey: "Impossibile convertire il PDF per la stampante."]) }

            // I byte del CGContext sono ordinati dal basso verso l'alto: ESC/POS li stampava capovolti.
            // Invertiamo soltanto l'asse verticale, senza specchiare il documento.
            var gray = [UInt8](repeating: 255, count: rawGray.count)
            for y in 0..<renderHeight {
                let source = (renderHeight - 1 - y) * renderWidth
                let destination = y * renderWidth
                gray.replaceSubrange(destination..<(destination + renderWidth), with: rawGray[source..<(source + renderWidth)])
            }

            let bands = horizontalBands(gray, width: renderWidth, height: renderHeight)
            for band in bands {
                guard let bounds = inkBounds(gray, width: renderWidth, height: renderHeight, y0: band.0, y1: band.1) else { continue }
                let paddedX0 = max(0, bounds.0 - 18), paddedX1 = min(renderWidth - 1, bounds.1 + 18)
                let paddedY0 = max(0, bounds.2 - 10), paddedY1 = min(renderHeight - 1, bounds.3 + 10)
                let columns = segmentColumns(gray, width: renderWidth, band: (paddedY0, paddedY1), x0: paddedX0, x1: paddedX1)
                for column in columns {
                    let panel = scaledPanel(gray, sourceWidth: renderWidth, sourceHeight: renderHeight, region: (column.0, column.1, paddedY0, paddedY1))
                    appendRaster(panel.0, width: printerWidth, height: panel.1)
                }
            }
            output.append(contentsOf: [0x0a, 0x0a])
        }
        output.append(contentsOf: [0x0a, 0x0a, 0x1d, 0x56, 0x00])
        return (output, pages)
    }

    private func sendNetworkPayload(host: String, portValue: Int, payload: Data, timeoutMs: Int, completion: @escaping (Result<Int, Error>) -> Void) {
        guard let port = NWEndpoint.Port(rawValue: UInt16(clamping: portValue)) else {
            completion(.failure(NSError(domain: "CassaIQPrinter", code: 14, userInfo: [NSLocalizedDescriptionKey: "Porta di rete non valida."])))
            return
        }
        let queue = DispatchQueue(label: "it.menoova.cassaiq.printer.pdfnetwork", qos: .userInitiated)
        let connection = NWConnection(host: NWEndpoint.Host(host), port: port, using: .tcp)
        let lock = NSLock(); var completed = false
        func finish(_ result: Result<Int, Error>) {
            lock.lock(); if completed { lock.unlock(); return }; completed = true; lock.unlock()
            connection.cancel(); completion(result)
        }
        let timeout = DispatchWorkItem { finish(.failure(NSError(domain: "CassaIQPrinter", code: 15, userInfo: [NSLocalizedDescriptionKey: "Connessione scaduta. Verifica IP, porta e rete locale."]))) }
        queue.asyncAfter(deadline: .now() + .milliseconds(timeoutMs), execute: timeout)
        connection.stateUpdateHandler = { state in
            switch state {
            case .ready:
                connection.send(content: payload, completion: .contentProcessed { error in
                    timeout.cancel()
                    if let error = error { finish(.failure(error)) } else { finish(.success(payload.count)) }
                })
            case .failed(let error): timeout.cancel(); finish(.failure(error))
            default: break
            }
        }
        connection.start(queue: queue)
    }

    @objc public func printPdfNetwork(_ call: CAPPluginCall) {
        guard let host = call.getString("host")?.trimmingCharacters(in: .whitespacesAndNewlines), !host.isEmpty else { call.reject("Inserisci l'indirizzo IP della stampante."); return }
        let port = call.getInt("port") ?? 9100
        let timeout = max(2000, min(call.getInt("timeoutMs") ?? 20000, 60000))
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let pdf = try self.pdfData(from: call)
                let converted = try self.escPosRaster(pdfData: pdf, width: call.getInt("width") ?? 576, threshold: call.getInt("threshold") ?? 185)
                self.sendNetworkPayload(host: host, portValue: port, payload: converted.0, timeoutMs: timeout) { result in
                    DispatchQueue.main.async {
                        switch result {
                        case .success(let bytes): call.resolve(["ok": true, "bytes": bytes, "pages": converted.1, "sourceBytes": pdf.count])
                        case .failure(let error): call.reject("Stampa PDF non riuscita: \(error.localizedDescription)")
                        }
                    }
                }
            } catch { DispatchQueue.main.async { call.reject("Preparazione stampa PDF non riuscita: \(error.localizedDescription)") } }
        }
    }

    // MARK: - CassaIQ LAN server (iPad / iPhone)

    private func lanOrderIdIsValid(_ value: String) -> Bool {
        value.range(of: #"^[A-Za-z0-9-]{8,80}$"#, options: .regularExpression) != nil
    }

    private func lanPruneDone() {
        let cutoff = Date().timeIntervalSince1970 - 7 * 24 * 60 * 60
        let defaults = UserDefaults.standard
        for (key, value) in defaults.dictionaryRepresentation() where key.hasPrefix(lanDonePrefix) {
            let timestamp: Double
            if let number = value as? NSNumber { timestamp = number.doubleValue }
            else { timestamp = Double(String(describing: value)) ?? 0 }
            if timestamp > 0 && timestamp < cutoff { defaults.removeObject(forKey: key) }
        }
    }

    private func localIpv4() -> String {
        var interfaces: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&interfaces) == 0, let first = interfaces else { return "" }
        defer { freeifaddrs(interfaces) }

        var wifi = ""
        var fallback = ""
        var cursor: UnsafeMutablePointer<ifaddrs>? = first
        while let current = cursor {
            defer { cursor = current.pointee.ifa_next }
            guard let address = current.pointee.ifa_addr,
                  address.pointee.sa_family == UInt8(AF_INET) else { continue }
            let name = String(cString: current.pointee.ifa_name)
            if name == "lo0" { continue }
            var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            let result = getnameinfo(address,
                                     socklen_t(address.pointee.sa_len),
                                     &host,
                                     socklen_t(host.count),
                                     nil,
                                     0,
                                     NI_NUMERICHOST)
            guard result == 0 else { continue }
            let ip = String(cString: host)
            guard !ip.isEmpty, ip != "127.0.0.1" else { continue }
            if name == "en0" { wifi = ip }
            if fallback.isEmpty && (ip.hasPrefix("10.") || ip.hasPrefix("192.168.") || ip.range(of: #"^172\.(1[6-9]|2[0-9]|3[0-1])\."#, options: .regularExpression) != nil) {
                fallback = ip
            }
        }
        return wifi.isEmpty ? fallback : wifi
    }

    private func lanPendingCount() -> Int {
        UserDefaults.standard.dictionaryRepresentation().keys.filter { $0.hasPrefix(lanPendingPrefix) }.count
    }

    private func lanSendResponse(_ response: [String: Any], on connection: NWConnection) {
        guard JSONSerialization.isValidJSONObject(response),
              var data = try? JSONSerialization.data(withJSONObject: response, options: []) else {
            connection.cancel()
            return
        }
        data.append(0x0a)
        connection.send(content: data, completion: .contentProcessed { _ in connection.cancel() })
    }

    private func lanErrorResponse(_ message: String, on connection: NWConnection) {
        lanSendResponse(["ok": false, "error": message], on: connection)
    }

    private func lanHandleMessage(_ data: Data, on connection: NWConnection) {
        do {
            guard data.count <= lanMaxPayload else { throw NSError(domain: "CassaIQLAN", code: 1, userInfo: [NSLocalizedDescriptionKey: "Payload LAN troppo grande."]) }
            guard let object = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                throw NSError(domain: "CassaIQLAN", code: 2, userInfo: [NSLocalizedDescriptionKey: "Payload LAN non valido."])
            }
            let type = (object["type"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            if type == "cassaiq_probe" {
                lanSendResponse([
                    "ok": true,
                    "status": "pong",
                    "ready": !lanAllowedOwnerUserId.isEmpty,
                    "cash_ip": localIpv4(),
                    "port": lanServerPort
                ], on: connection)
                return
            }
            guard type == "cassaiq_order" else { throw NSError(domain: "CassaIQLAN", code: 3, userInfo: [NSLocalizedDescriptionKey: "Tipo messaggio LAN non valido."]) }

            let ownerUserId = (object["owner_user_id"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            let deviceId = (object["device_id"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            guard !lanAllowedOwnerUserId.isEmpty else { throw NSError(domain: "CassaIQLAN", code: 4, userInfo: [NSLocalizedDescriptionKey: "CassaIQ non autenticata per la rete locale."]) }
            guard ownerUserId == lanAllowedOwnerUserId else { throw NSError(domain: "CassaIQLAN", code: 5, userInfo: [NSLocalizedDescriptionKey: "Account CassaIQ non corrispondente."]) }
            if !lanAuthorizedDeviceIds.isEmpty && !lanAuthorizedDeviceIds.contains(deviceId) {
                throw NSError(domain: "CassaIQLAN", code: 6, userInfo: [NSLocalizedDescriptionKey: "CassaIQ Client non autorizzato."])
            }

            let orderId = (object["order_id"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            guard lanOrderIdIsValid(orderId) else { throw NSError(domain: "CassaIQLAN", code: 7, userInfo: [NSLocalizedDescriptionKey: "ID comanda LAN non valido."]) }
            guard let items = object["items"] as? [Any], !items.isEmpty, items.count <= 200 else {
                throw NSError(domain: "CassaIQLAN", code: 8, userInfo: [NSLocalizedDescriptionKey: "Righe comanda LAN non valide."])
            }

            let defaults = UserDefaults.standard
            let pendingKey = lanPendingPrefix + orderId
            let doneKey = lanDonePrefix + orderId
            let duplicate = defaults.object(forKey: pendingKey) != nil || defaults.object(forKey: doneKey) != nil
            if !duplicate {
                let canonical = try JSONSerialization.data(withJSONObject: object, options: [])
                guard let json = String(data: canonical, encoding: .utf8) else {
                    throw NSError(domain: "CassaIQLAN", code: 9, userInfo: [NSLocalizedDescriptionKey: "Impossibile salvare la comanda nella coda locale."])
                }
                defaults.set(json, forKey: pendingKey)
                _ = defaults.synchronize()
            }

            lanSendResponse([
                "ok": true,
                "status": duplicate ? "already_received" : "received",
                "order_id": orderId,
                "duplicate": duplicate,
                "cash_ip": localIpv4()
            ], on: connection)
        } catch {
            lanErrorResponse(error.localizedDescription, on: connection)
        }
    }

    private func lanHandleConnection(_ connection: NWConnection) {
        connection.start(queue: lanQueue)
        var buffer = Data()

        func receiveMore() {
            connection.receive(minimumIncompleteLength: 1, maximumLength: 32_768) { [weak self] data, _, isComplete, error in
                guard let self = self else { connection.cancel(); return }
                if let data = data, !data.isEmpty {
                    buffer.append(data)
                    if buffer.count > self.lanMaxPayload + 1 {
                        self.lanErrorResponse("Payload LAN troppo grande.", on: connection)
                        return
                    }
                    if let newline = buffer.firstIndex(of: 0x0a) {
                        let message = Data(buffer[..<newline])
                        if message.isEmpty { self.lanErrorResponse("Payload LAN vuoto.", on: connection) }
                        else { self.lanHandleMessage(message, on: connection) }
                        return
                    }
                }
                if let error = error {
                    self.lanErrorResponse(error.localizedDescription, on: connection)
                    return
                }
                if isComplete {
                    if buffer.isEmpty { self.lanErrorResponse("Payload LAN vuoto.", on: connection) }
                    else { self.lanHandleMessage(buffer, on: connection) }
                    return
                }
                receiveMore()
            }
        }
        receiveMore()
    }

    private func lanStopInternal() {
        lanServerRunning = false
        lanListener?.newConnectionHandler = nil
        lanListener?.cancel()
        lanListener = nil
    }

    @objc public func lanServerStart(_ call: CAPPluginCall) {
        let requestedPort = max(1024, min(call.getInt("port") ?? 8765, 65535))
        let ownerUserId = (call.getString("ownerUserId") ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let deviceCsv = (call.getString("authorizedDeviceIdsCsv") ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let devices = Set(deviceCsv.split(separator: ",").map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty })

        lanQueue.async {
            self.lanStopInternal()
            self.lanPruneDone()
            self.lanAllowedOwnerUserId = ownerUserId
            self.lanAuthorizedDeviceIds = devices
            self.lanServerPort = requestedPort
            guard let port = NWEndpoint.Port(rawValue: UInt16(requestedPort)) else {
                DispatchQueue.main.async { call.reject("Server LAN non avviato: porta non valida.") }
                return
            }
            do {
                let listener = try NWListener(using: .tcp, on: port)
                self.lanListener = listener
                var completed = false
                listener.newConnectionHandler = { [weak self] connection in self?.lanHandleConnection(connection) }
                listener.stateUpdateHandler = { [weak self] state in
                    guard let self = self else { return }
                    switch state {
                    case .ready:
                        self.lanServerRunning = true
                        if !completed {
                            completed = true
                            let ip = self.localIpv4()
                            DispatchQueue.main.async { call.resolve(["ok": true, "running": true, "port": self.lanServerPort, "ip": ip]) }
                        }
                    case .failed(let error):
                        self.lanServerRunning = false
                        if !completed {
                            completed = true
                            DispatchQueue.main.async { call.reject("Server LAN non avviato: \(error.localizedDescription)") }
                        }
                    case .cancelled:
                        self.lanServerRunning = false
                    default:
                        break
                    }
                }
                listener.start(queue: self.lanQueue)
            } catch {
                self.lanStopInternal()
                DispatchQueue.main.async { call.reject("Server LAN non avviato: \(error.localizedDescription)") }
            }
        }
    }

    @objc public func lanServerStop(_ call: CAPPluginCall) {
        lanQueue.async {
            self.lanStopInternal()
            let response: [String: Any] = ["ok": true, "running": false, "port": self.lanServerPort, "ip": self.localIpv4()]
            DispatchQueue.main.async { call.resolve(response) }
        }
    }

    @objc public func lanServerStatus(_ call: CAPPluginCall) {
        lanQueue.async {
            let response: [String: Any] = [
                "ok": true,
                "running": self.lanServerRunning && self.lanListener != nil,
                "port": self.lanServerPort,
                "ip": self.localIpv4(),
                "pending": self.lanPendingCount()
            ]
            DispatchQueue.main.async { call.resolve(response) }
        }
    }

    @objc public func lanGetPendingOrders(_ call: CAPPluginCall) {
        let maximum = max(1, min(call.getInt("max") ?? 50, 200))
        lanQueue.async {
            var orders: [[String: Any]] = []
            let defaults = UserDefaults.standard
            let keys = defaults.dictionaryRepresentation().keys.filter { $0.hasPrefix(self.lanPendingPrefix) }.sorted()
            for key in keys.prefix(maximum) {
                guard let json = defaults.string(forKey: key), let data = json.data(using: .utf8),
                      let row = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { continue }
                orders.append(row)
            }
            DispatchQueue.main.async { call.resolve(["ok": true, "orders": orders, "count": orders.count]) }
        }
    }

    @objc public func lanAcknowledgeOrder(_ call: CAPPluginCall) {
        let orderId = (call.getString("orderId") ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        guard lanOrderIdIsValid(orderId) else { call.reject("ID comanda LAN non valido."); return }
        lanQueue.async {
            let defaults = UserDefaults.standard
            defaults.removeObject(forKey: self.lanPendingPrefix + orderId)
            defaults.set(Date().timeIntervalSince1970, forKey: self.lanDonePrefix + orderId)
            _ = defaults.synchronize()
            self.lanPruneDone()
            DispatchQueue.main.async { call.resolve(["ok": true, "orderId": orderId]) }
        }
    }

    @objc public func lanLocalIp(_ call: CAPPluginCall) {
        lanQueue.async {
            let ip = self.localIpv4()
            DispatchQueue.main.async { call.resolve(["ip": ip]) }
        }
    }

    private func secureQuery(_ key: String) -> [String: Any] {
        [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: secureService,
            kSecAttrAccount as String: key
        ]
    }

    @objc public func secureSet(_ call: CAPPluginCall) {
        guard let key = call.getString("key")?.trimmingCharacters(in: .whitespacesAndNewlines), !key.isEmpty else {
            call.reject("Chiave archivio sicuro non valida.")
            return
        }
        let value = call.getString("value") ?? ""
        guard let data = value.data(using: .utf8) else {
            call.reject("Valore archivio sicuro non valido.")
            return
        }
        let query = secureQuery(key)
        let updateAttributes: [String: Any] = [kSecValueData as String: data]
        var status = SecItemUpdate(query as CFDictionary, updateAttributes as CFDictionary)
        if status == errSecItemNotFound {
            var add = query
            add[kSecValueData as String] = data
            add[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
            status = SecItemAdd(add as CFDictionary, nil)
        }
        guard status == errSecSuccess else {
            call.reject("Salvataggio Keychain non riuscito (\(status)).")
            return
        }
        call.resolve(["ok": true])
    }

    @objc public func secureGet(_ call: CAPPluginCall) {
        guard let key = call.getString("key")?.trimmingCharacters(in: .whitespacesAndNewlines), !key.isEmpty else {
            call.reject("Chiave archivio sicuro non valida.")
            return
        }
        var query = secureQuery(key)
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        if status == errSecItemNotFound {
            call.resolve(["value": ""])
            return
        }
        guard status == errSecSuccess, let data = item as? Data, let value = String(data: data, encoding: .utf8) else {
            call.reject("Lettura Keychain non riuscita (\(status)).")
            return
        }
        call.resolve(["value": value])
    }

    @objc public func secureRemove(_ call: CAPPluginCall) {
        guard let key = call.getString("key")?.trimmingCharacters(in: .whitespacesAndNewlines), !key.isEmpty else {
            call.reject("Chiave archivio sicuro non valida.")
            return
        }
        let status = SecItemDelete(secureQuery(key) as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            call.reject("Eliminazione Keychain non riuscita (\(status)).")
            return
        }
        call.resolve(["ok": true])
    }
}
