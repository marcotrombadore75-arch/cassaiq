# CassaIQ RT v1.15.5 / build 136

## Diagnostica manuale
- Rimossa l'apertura dell'email dal pulsante di diagnostica.
- Il cliente invia il report solo manualmente e su richiesta dell'assistenza.
- Il report viene salvato in Supabase e restituisce un codice `CQ-XXXXXXXX`.
- Password, PIN, token, cookie, chiavi API e credenziali vengono oscurati prima dell'invio.
- Nessun invio automatico o in background.
- Il motore fiscale DCO non è stato modificato.

## Ticket cucina
- Il nome del tavolo è ora stampato in doppia dimensione e grassetto.
- Vale sia per le comande normali sia per gli aggiornamenti.
