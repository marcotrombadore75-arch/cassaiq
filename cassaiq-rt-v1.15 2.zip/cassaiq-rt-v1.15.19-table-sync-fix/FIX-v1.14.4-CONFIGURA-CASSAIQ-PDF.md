# CassaIQ RT 1.14.4 — Configura CassaIQ e recupero PDF DCO

Versione: **1.14.4**  
Build iOS: **34**  
Android versionCode: **34**

## Modifiche

- La voce “Documento commerciale online” è stata rinominata **Configura CassaIQ**.
- Unica pagina pratica con scelta **Epson RT** oppure **DCO + MUNBYN**.
- Area RT: IP Epson, test connessione e salvataggio diretto.
- Area DCO: collegamento SPID, configurazione MUNBYN, test stampa, recupero PDF e ristampa.
- Diagnostica DCO mantenuta ma chiusa in un pannello espandibile.
- Un errore di caricamento durante l’apertura del PDF non viene più interpretato automaticamente come mancata emissione.
- CassaIQ verifica prima lo stato della schermata finale e l’identificativo del documento.
- Se il documento è emesso ma il PDF non è disponibile, mostra un messaggio specifico, mantiene il blocco anti-duplicazione e consente “Riprova recupero PDF”.
