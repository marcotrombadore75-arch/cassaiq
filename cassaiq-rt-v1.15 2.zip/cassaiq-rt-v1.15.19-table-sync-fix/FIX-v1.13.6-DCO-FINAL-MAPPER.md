# CassaIQ 1.13.6 — DCO final mapper

- Mappatura confermata della pagina `#/generazione/wizard3` (Verifica dati).
- Consente il passaggio ufficiale “Vai a Conferma e stampa” e l’informativa “Ho capito” per raggiungere la schermata successiva.
- Blocca i pulsanti e i submit che possono confermare, emettere, trasmettere o stampare fiscalmente il documento.
- Barra CassaIQ con comandi “Mappa conferma” e “Continua mappatura”.
- Diagnostica estesa per rilevare schermata finale, progressivo, stampa e download.
- Nessuna vendita viene salvata, azzerata o emessa durante il test.
- Versione 1.13.6, build/versionCode 26.
