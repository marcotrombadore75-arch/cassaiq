# CassaIQ RT v1.14.62 — DCO operation isolation

Base: v1.14.60 (derivata dalla v1.14.55 veloce, con WebView iOS visibile come nella v1.14.20).

Obiettivo: rendere affidabili le emissioni consecutive senza chiudere la sessione Fisconline.

Modifiche DCO:
- La prova di nuova emissione non scandisce più globalmente `$rootScope`.
- Un documento viene considerato emesso solo da evidenza corrente: controllo visibile “Scarica e stampa file” o URL corrente `/documenti/<id>/stampa`.
- L’ID viene accettato solo dopo `Procedi` e deve essere diverso dall’ultimo documento locale.
- Il numero ufficiale viene recuperato soltanto da scope/metadata associati allo stesso ID appena accettato.
- I messaggi metadata tardivi con ID diverso vengono ignorati.
- Ogni vendita usa un token operativo nuovo; il bridge delle route legge sempre il token attivo invece di conservare quello della prima vendita.
- A fine vendita/abort vengono cancellati timer, watcher, quick state, PDF state e click differiti CassaIQ, mantenendo cookie e sessione Fisconline.
- Se la Home DCO è già autenticata e completa, la seconda vendita la riutilizza senza reload inutile.
- Le URL di stampa intercettate da loadstart/loaderror passano dallo stesso controllo ID e non lasciano `dcoBrowserLoading` bloccato.
- La barra/safety guard del laboratorio DCO non può più intercettare i click automatici durante una vendita; il controllo “documento emesso” considera solo il download visibile.
- Il `loaderror` di wizard4 prima di `Procedi` viene trattato come transitorio e non come prova fiscale.

Prestazioni lasciate invariate: runner preparatorio 350 ms, runner finale 1100 ms, meta watcher 1200 ms.

Versione app: 1.14.62
- iOS build: 93
- Android versionCode: 93
