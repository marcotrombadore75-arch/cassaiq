# CassaIQ RT 1.14.94 — invio diagnostica assistenza

- In fondo a **Diagnostica DCO** è stato aggiunto **Invia diagnostica all’assistenza**.
- Destinatario precompilato: `support@menoova.it`.
- Oggetto con app/versione e corpo con piattaforma, data e diagnostica tecnica già sanitizzata.
- Password, PIN e valori digitati restano esclusi.
- Per diagnostiche molto lunghe, il messaggio viene abbreviato e il testo completo viene copiato negli appunti quando possibile.
