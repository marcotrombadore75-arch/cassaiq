# CassaIQ RT — installazione su Mac e prova nel Simulatore iOS

Questa versione del progetto è pronta anche per iOS. Android resta invariato:
i comandi che usavi su Windows continuano a funzionare.

---

## 1. Cosa serve sul Mac

| Strumento | Come ottenerlo | Note |
|---|---|---|
| **Xcode** | Mac App Store (gratuito, ~10 GB) | Apri Xcode una volta dopo l'installazione per accettare la licenza e far scaricare i componenti |
| **Node.js LTS** | https://nodejs.org | Versione 18 o superiore |
| **CocoaPods** | `brew install cocoapods` oppure `sudo gem install cocoapods` | Gestisce le librerie native iOS |

Per il **Simulatore non serve nessun account Apple a pagamento** e non serve
firmare l'app. L'account (anche gratuito) serve solo per installare su un
iPhone o iPad reale.

---

## 2. Avvio rapido (consigliato)

Copia la cartella del progetto sul Mac, apri il **Terminale** dentro la cartella
e lancia:

```bash
chmod +x scripts/run-ios-sim.command
./scripts/run-ios-sim.command
```

Lo script controlla i prerequisiti, installa le dipendenze, crea il progetto
iOS, applica la configurazione e avvia l'app nel Simulatore. Dopo la prima
volta puoi anche solo fare doppio clic sul file `run-ios-sim.command`.

## 3. Avvio manuale (se preferisci i comandi uno per uno)

```bash
npm install          # dipendenze
npm run ios:add      # crea la cartella ios/ (solo la prima volta)
npm run ios:sync     # copia www/ nel progetto iOS + configura Info.plist
npm run ios:open     # apre Xcode
```

In Xcode: scegli un simulatore dal menu in alto (per la vista cassa completa a
tre colonne conviene un **iPad Pro**) e premi ▶︎ Play.

In alternativa, senza aprire Xcode: `npm run ios:run`.

> Ogni volta che modifichi qualcosa dentro `www/`, rilancia `npm run ios:sync`,
> altrimenti il simulatore mostra ancora la versione precedente.

---

## 4. Cosa è stato aggiunto per iOS

**Accesso al registratore Epson.** iOS blocca per impostazione predefinita le
connessioni HTTP non cifrate, e l'Epson risponde su `http://<ip>/cgi-bin/fpmate.cgi`.
Lo script `scripts/configure-ios.mjs` inserisce nel file `Info.plist`
l'eccezione per la rete locale (`NSAllowsLocalNetworking`) e il testo della
richiesta di permesso "rete locale" che iOS mostra all'utente. Senza queste due
voci il test connessione fallirebbe sempre, anche con l'IP giusto.

**Modalità cassa a schermo intero**, equivalente a quella già presente su
Android: barra di stato nascosta, niente finestre affiancate, rotazione libera.

**Chiave abbonamento per piattaforma.** RevenueCat usa chiavi diverse per Apple
e Google. Ora `www/config.js` sceglie da sola quella giusta a seconda del
dispositivo: metti la chiave Apple in `REVENUECAT_IOS_API_KEY` dentro `.env`
(inizia con `appl_`). Se la lasci vuota, l'app funziona lo stesso e la sezione
abbonamento resta semplicemente disattivata — utile proprio nel Simulatore,
dove gli acquisti non sono comunque testabili.

**Nomi file resi compatibili.** Sei immagini della libreria avevano accenti nel
nome (`caffè-espresso.svg`, `tiramisù.svg`, …). macOS e Windows salvano gli
accenti in modo diverso e i riferimenti si sarebbero rotti: ora sono in forma
semplice (`caffe-espresso.svg`, `tiramisu.svg`) con tutti i collegamenti
aggiornati.

---

## 5. Provare la stampa fiscale dal Simulatore

Il Simulatore usa la rete del Mac, quindi **se il Mac è collegato alla stessa
rete dell'Epson, il test connessione e l'emissione funzionano davvero**.
Nell'app: icona ingranaggio → Epson → inserisci l'IP → *Prova connessione*.

Se il test fallisce, controlla nell'ordine:
1. Il Mac e l'Epson sono sulla stessa rete Wi‑Fi/LAN (non su reti ospite separate).
2. L'IP è quello giusto: dal Mac prova `curl -v http://<ip>/cgi-bin/fpmate.cgi`.
3. Su dispositivo reale, iOS chiede il permesso "rete locale" al primo tentativo:
   se lo neghi, va riattivato in *Impostazioni → Privacy → Rete locale*.

---

## 6. Problemi frequenti

**`pod: command not found`** → installa CocoaPods (vedi tabella al punto 1).

**Errori sui Pod dopo un aggiornamento** → rigenera le dipendenze native:
```bash
cd ios/App && pod install --repo-update && cd ../..
```

**Il simulatore mostra la versione vecchia** → manca il sync: `npm run ios:sync`.

**Voglio ripartire da zero con iOS** → cancella la cartella `ios/` e rifai
`npm run ios:add`. Non perdi nulla: quella cartella è generata, il tuo codice
sta tutto in `www/`.

**Installare su iPad reale** → in Xcode, pannello *Signing & Capabilities*,
scegli il tuo Apple ID come *Team*. Con un account gratuito l'app resta valida
7 giorni, poi va reinstallata.

---

## Test della stampante MUNBYN 80 mm

Questa versione include un plugin nativo locale in `plugins/cassaiq-printer`.
Dopo `npm install`, il comando `npm run ios:sync` lo collega automaticamente
al progetto Xcode tramite Swift Package Manager.

Per la prova su iPad reale:

1. apri **Impostazioni → Test stampante 80 mm**;
2. prova prima la rete con `192.168.1.201` e porta `9100`;
3. per Bluetooth premi **Cerca stampanti Bluetooth** e seleziona `TM-m30-b001`;
4. consenti a CassaIQ l'accesso a Bluetooth e rete locale quando richiesto.

La schermata produce solo stampe di prova non fiscali.
