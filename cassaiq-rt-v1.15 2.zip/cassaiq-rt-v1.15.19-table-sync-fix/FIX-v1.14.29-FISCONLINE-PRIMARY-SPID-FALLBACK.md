# CassaIQ RT 1.14.29 — Fisconline principale, SPID accesso alternativo

Versione 1.14.29 · build iOS 59 · Android versionCode 59.

## Modifica
- Fisconline è ora il metodo DCO principale e persistente.
- SPID/CIE/CNS non è più presentato come scelta equivalente: è raccolto in “Accesso alternativo”.
- Una sessione aperta con SPID resta utilizzabile, ma non cambia la preferenza persistente: alla successiva necessità di ricollegamento CassaIQ prova Fisconline.
- Le installazioni provenienti da versioni precedenti vengono migrate a Fisconline come metodo preferito.
- Se Fisconline non è configurato, l’utente può comunque aprire manualmente SPID/CIE/CNS dall’area alternativa.

## Sicurezza e flusso invariati
- secureGet/secureSet/secureRemove e archivio Keychain/Android Keystore invariati.
- Protezione anti-doppia-emissione invariata.
- Emissione DCO, recupero numero ufficiale, stampa MUNBYN e taglio carta invariati.
- Epson RT invariato.
