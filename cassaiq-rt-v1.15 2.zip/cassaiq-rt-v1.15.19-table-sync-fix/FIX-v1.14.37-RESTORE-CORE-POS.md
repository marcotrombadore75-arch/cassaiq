# CassaIQ RT v1.14.37 — ripristino core POS

Correzione regressione introdotta in v1.14.36.

Ripristinate senza modifiche dalla v1.14.35 le funzioni core eliminate accidentalmente durante il refactoring Fisconline:

- `fiscalMode()`
- `DCO_BUSINESS_FIELDS`
- `dcoBusinessProfileStorageKey()`
- `dcoBusinessProfile()`
- `dcoBusinessProfileFromForm()`
- `dcoBusinessValidation()`
- `dcoFillBusinessForm()`
- `renderDcoBusinessStatus()`
- `dcoSaveBusinessProfile()`
- `dcoRequireBusinessProfile()`

Lo state machine Fisconline della v1.14.36 resta invariato.
La regressione impediva a `renderConfigFiscalMode()` / `renderCart()` di completarsi e quindi bloccava l'inizializzazione della cassa prima di `renderProducts()`.
