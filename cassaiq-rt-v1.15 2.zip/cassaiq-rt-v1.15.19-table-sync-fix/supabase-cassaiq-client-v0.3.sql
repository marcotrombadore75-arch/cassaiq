-- CassaIQ Client v0.3.0 - pairing dispositivo SENZA Supabase Auth anonimo
-- Eseguire UNA VOLTA nel SQL Editor dello stesso progetto Supabase di CassaIQ.
-- Può essere eseguito anche se è già stato eseguito il precedente v0.2.
-- Il Client usa solo la publishable key + un token dispositivo generato dopo il codice monouso.

create extension if not exists pgcrypto;

create table if not exists public.cassaiq_pairing_codes (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid not null references auth.users(id) on delete cascade,
  code text not null unique check (code ~ '^[0-9]{6}$'),
  expires_at timestamptz not null,
  used_at timestamptz,
  used_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.cassaiq_client_devices (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid not null references auth.users(id) on delete cascade,
  token_hash text not null,
  status text not null default 'active' check (status in ('active','revoked')),
  device_name text,
  paired_at timestamptz not null default now(),
  last_seen_at timestamptz,
  revoked_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.cassaiq_pairing_codes add column if not exists used_device_id uuid references public.cassaiq_client_devices(id) on delete set null;

create table if not exists public.restaurant_tables (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  sort_order integer not null default 0,
  status text not null default 'free' check (status in ('free','occupied','bill_requested')),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid not null references auth.users(id) on delete cascade,
  table_id uuid references public.restaurant_tables(id) on delete set null,
  created_by uuid references auth.users(id) on delete restrict,
  status text not null default 'sent' check (status in ('draft','sent','accepted','closed','cancelled')),
  notes text,
  subtotal numeric(12,2) not null default 0,
  total numeric(12,2) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.orders alter column created_by drop not null;
alter table public.orders add column if not exists created_by_device_id uuid references public.cassaiq_client_devices(id) on delete set null;

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  owner_user_id uuid not null references auth.users(id) on delete cascade,
  product_id uuid,
  product_name text not null,
  quantity numeric(12,3) not null check (quantity > 0),
  unit_price numeric(12,2) not null check (unit_price >= 0),
  line_total numeric(12,2) not null check (line_total >= 0),
  notes text,
  created_at timestamptz not null default now()
);

create index if not exists cassaiq_client_devices_owner_idx on public.cassaiq_client_devices(owner_user_id,status);
create index if not exists pairing_codes_owner_idx on public.cassaiq_pairing_codes(owner_user_id,expires_at desc);
create index if not exists restaurant_tables_owner_idx on public.restaurant_tables(owner_user_id,sort_order);
create index if not exists orders_owner_status_idx on public.orders(owner_user_id,status,created_at desc);
create index if not exists order_items_order_idx on public.order_items(order_id);

alter table public.cassaiq_client_devices enable row level security;
alter table public.cassaiq_pairing_codes enable row level security;
alter table public.restaurant_tables enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

-- Il titolare gestisce dispositivi, codici, tavoli e comande dalla CassaIQ principale.
drop policy if exists cassaiq_client_devices_owner_all on public.cassaiq_client_devices;
create policy cassaiq_client_devices_owner_all on public.cassaiq_client_devices
for all using (auth.uid()=owner_user_id) with check (auth.uid()=owner_user_id);

drop policy if exists pairing_codes_owner_all on public.cassaiq_pairing_codes;
create policy pairing_codes_owner_all on public.cassaiq_pairing_codes
for all using (auth.uid()=owner_user_id) with check (auth.uid()=owner_user_id);

drop policy if exists restaurant_tables_owner_all on public.restaurant_tables;
create policy restaurant_tables_owner_all on public.restaurant_tables
for all using (auth.uid()=owner_user_id) with check (auth.uid()=owner_user_id);

drop policy if exists orders_owner_all on public.orders;
create policy orders_owner_all on public.orders
for all using (auth.uid()=owner_user_id) with check (auth.uid()=owner_user_id);

drop policy if exists order_items_owner_all on public.order_items;
create policy order_items_owner_all on public.order_items
for all using (auth.uid()=owner_user_id) with check (auth.uid()=owner_user_id);

-- Codice monouso generato dalla CassaIQ principale. Validità: 5 minuti.
create or replace function public.cassaiq_create_pairing_code()
returns table(code text, expires_at timestamptz)
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_owner uuid:=auth.uid();
  v_code text;
  v_expires timestamptz:=now()+interval '5 minutes';
begin
  if v_owner is null then raise exception 'AUTH_REQUIRED'; end if;
  delete from public.cassaiq_pairing_codes where owner_user_id=v_owner and used_at is null;
  loop
    v_code:=lpad((floor(random()*1000000))::int::text,6,'0');
    begin
      insert into public.cassaiq_pairing_codes(owner_user_id,code,expires_at)
      values(v_owner,v_code,v_expires);
      exit;
    exception when unique_violation then
      null;
    end;
  end loop;
  return query select v_code,v_expires;
end;
$$;

-- Il Client scambia il codice breve con un token dispositivo lungo.
-- Il token in chiaro viene restituito una sola volta e nel DB resta solo SHA-256.
create or replace function public.cassaiq_client_pair(p_code text,p_device_name text default 'CassaIQ Client')
returns table(device_id uuid,owner_user_id uuid,device_token text,status text)
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_pair public.cassaiq_pairing_codes%rowtype;
  v_device uuid:=gen_random_uuid();
  v_token text:=encode(gen_random_bytes(32),'hex');
begin
  select * into v_pair
  from public.cassaiq_pairing_codes
  where code=trim(p_code) and used_at is null and expires_at>now()
  for update;
  if not found then raise exception 'PAIRING_CODE_INVALID_OR_EXPIRED'; end if;

  insert into public.cassaiq_client_devices(id,owner_user_id,token_hash,status,device_name,paired_at,last_seen_at)
  values(v_device,v_pair.owner_user_id,encode(digest(v_token,'sha256'),'hex'),'active',left(coalesce(nullif(trim(p_device_name),''),'CassaIQ Client'),80),now(),now());

  update public.cassaiq_pairing_codes
  set used_at=now(),used_device_id=v_device
  where id=v_pair.id;

  return query select v_device,v_pair.owner_user_id,v_token,'active'::text;
end;
$$;

-- Snapshot autorizzato di catalogo + tavoli. Nessun accesso diretto alle tabelle dal Client.
create or replace function public.cassaiq_client_bootstrap(p_device_id uuid,p_device_token text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_owner uuid;
  v_categories jsonb;
  v_products jsonb;
  v_tables jsonb;
begin
  select d.owner_user_id into v_owner
  from public.cassaiq_client_devices d
  where d.id=p_device_id
    and d.status='active'
    and d.token_hash=encode(digest(coalesce(p_device_token,''),'sha256'),'hex');
  if v_owner is null then raise exception 'DEVICE_NOT_AUTHORIZED'; end if;

  update public.cassaiq_client_devices set last_seen_at=now() where id=p_device_id;

  select coalesce(jsonb_agg(jsonb_build_object(
    'id',c.id,
    'name',c.name,
    'icon',coalesce(c.icon,''),
    'color',coalesce(to_jsonb(c)->>'color','')
  ) order by coalesce((to_jsonb(c)->>'sort_order')::int,0),c.created_at),'[]'::jsonb)
  into v_categories
  from public.categories c
  where c.user_id=v_owner and coalesce(c.active,true)=true;

  select coalesce(jsonb_agg(jsonb_build_object(
    'id',p.id,
    'name',p.name,
    'price',p.price,
    'category_id',p.category_id,
    'image_library_id',coalesce(to_jsonb(p)->>'image_library_id',''),
    'show_price',coalesce((to_jsonb(p)->>'show_price')::boolean,true),
    'variable_price',coalesce((to_jsonb(p)->>'variable_price')::boolean,false)
  ) order by coalesce((to_jsonb(p)->>'sort_order')::int,0),p.created_at),'[]'::jsonb)
  into v_products
  from public.products p
  where p.user_id=v_owner and coalesce(p.active,true)=true;

  select coalesce(jsonb_agg(jsonb_build_object(
    'id',t.id,
    'name',t.name,
    'sort_order',t.sort_order,
    'status',t.status
  ) order by t.sort_order,t.name),'[]'::jsonb)
  into v_tables
  from public.restaurant_tables t
  where t.owner_user_id=v_owner and t.active=true;

  return jsonb_build_object(
    'owner_user_id',v_owner,
    'categories',v_categories,
    'products',v_products,
    'tables',v_tables
  );
end;
$$;

-- Crea la comanda lato server usando nome/prezzo ufficiali del catalogo.
create or replace function public.cassaiq_client_send_order(
  p_device_id uuid,
  p_device_token text,
  p_table_id uuid,
  p_items jsonb,
  p_notes text default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_owner uuid;
  v_order_id uuid:=gen_random_uuid();
  v_item jsonb;
  v_product_id uuid;
  v_name text;
  v_db_price numeric(12,2);
  v_variable boolean;
  v_qty numeric(12,3);
  v_unit numeric(12,2);
  v_total numeric(12,2):=0;
begin
  select d.owner_user_id into v_owner
  from public.cassaiq_client_devices d
  where d.id=p_device_id
    and d.status='active'
    and d.token_hash=encode(digest(coalesce(p_device_token,''),'sha256'),'hex');
  if v_owner is null then raise exception 'DEVICE_NOT_AUTHORIZED'; end if;

  if not exists(select 1 from public.restaurant_tables t where t.id=p_table_id and t.owner_user_id=v_owner and t.active=true)
    then raise exception 'TABLE_NOT_AVAILABLE';
  end if;
  if p_items is null or jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 or jsonb_array_length(p_items)>200
    then raise exception 'INVALID_ORDER_ITEMS';
  end if;

  insert into public.orders(id,owner_user_id,table_id,created_by,created_by_device_id,status,notes,subtotal,total,created_at,updated_at)
  values(v_order_id,v_owner,p_table_id,null,p_device_id,'sent',nullif(left(coalesce(p_notes,''),500),''),0,0,now(),now());

  for v_item in select value from jsonb_array_elements(p_items)
  loop
    begin
      v_product_id:=(v_item->>'product_id')::uuid;
      v_qty:=(v_item->>'quantity')::numeric;
    exception when others then
      raise exception 'INVALID_ORDER_ITEM';
    end;
    if v_qty<=0 or v_qty>99 then raise exception 'INVALID_ORDER_ITEM'; end if;

    select p.name,p.price,coalesce((to_jsonb(p)->>'variable_price')::boolean,false)
    into v_name,v_db_price,v_variable
    from public.products p
    where p.id=v_product_id and p.user_id=v_owner and coalesce(p.active,true)=true;
    if not found then raise exception 'PRODUCT_NOT_AVAILABLE'; end if;

    if v_variable then
      begin v_unit:=(v_item->>'unit_price')::numeric; exception when others then raise exception 'INVALID_VARIABLE_PRICE'; end;
      if v_unit<0 or v_unit>999999 then raise exception 'INVALID_VARIABLE_PRICE'; end if;
    else
      v_unit:=v_db_price;
    end if;

    v_total:=v_total+(v_qty*v_unit);
    insert into public.order_items(id,order_id,owner_user_id,product_id,product_name,quantity,unit_price,line_total,notes,created_at)
    values(gen_random_uuid(),v_order_id,v_owner,v_product_id,v_name,v_qty,v_unit,v_qty*v_unit,nullif(left(coalesce(v_item->>'notes',''),300),''),now());
  end loop;

  update public.orders set subtotal=v_total,total=v_total,updated_at=now() where id=v_order_id;
  update public.restaurant_tables set status='occupied',updated_at=now() where id=p_table_id and owner_user_id=v_owner;
  update public.cassaiq_client_devices set last_seen_at=now() where id=p_device_id;

  return jsonb_build_object('order_id',v_order_id,'total',v_total,'status','sent');
end;
$$;

create or replace function public.cassaiq_client_disconnect(p_device_id uuid,p_device_token text)
returns boolean
language plpgsql
security definer
set search_path=public,extensions
as $$
begin
  update public.cassaiq_client_devices d
  set status='revoked',revoked_at=now(),last_seen_at=now()
  where d.id=p_device_id
    and d.status='active'
    and d.token_hash=encode(digest(coalesce(p_device_token,''),'sha256'),'hex');
  return found;
end;
$$;

revoke all on function public.cassaiq_create_pairing_code() from public;
revoke all on function public.cassaiq_client_pair(text,text) from public;
revoke all on function public.cassaiq_client_bootstrap(uuid,text) from public;
revoke all on function public.cassaiq_client_send_order(uuid,text,uuid,jsonb,text) from public;
revoke all on function public.cassaiq_client_disconnect(uuid,text) from public;

grant execute on function public.cassaiq_create_pairing_code() to authenticated;
grant execute on function public.cassaiq_client_pair(text,text) to anon,authenticated;
grant execute on function public.cassaiq_client_bootstrap(uuid,text) to anon,authenticated;
grant execute on function public.cassaiq_client_send_order(uuid,text,uuid,jsonb,text) to anon,authenticated;
grant execute on function public.cassaiq_client_disconnect(uuid,text) to anon,authenticated;
