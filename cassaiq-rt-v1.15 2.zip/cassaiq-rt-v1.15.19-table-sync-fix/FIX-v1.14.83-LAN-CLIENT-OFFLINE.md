# CassaIQ RT v1.14.83 / build 114 — LAN Client offline

Questa build aggiunge il primo canale locale Android per CassaIQ Client.

## Flusso
Client -> TCP LAN porta 8765 -> CassaIQ RT -> coda locale persistente -> stampa cucina -> sincronizzazione Supabase quando disponibile.

## Sicurezza e affidabilità
- La cassa verifica owner_user_id e, quando disponibile, l’elenco dei Client autorizzati.
- La coda nativa Android viene salvata prima dell’ACK al Client.
- Ogni comanda ha un ID univoco e viene deduplicata anche dopo un riavvio.
- La stampa cucina viene marcata come tentata prima dell’invio per evitare ristampe automatiche ambigue.
- Tavoli e comande LAN restano disponibili localmente senza Internet; il cloud viene riallineato successivamente.

## Limite v1
Il server LAN nativo è implementato sul percorso Android. Su iOS resta il comportamento cloud precedente.
