# CassaIQ 1.13.7 — Prima emissione DCO reale controllata

- Mappa confermata fino a `#/generazione/wizard4`.
- Il pulsante ufficiale `Procedi` richiama `vm.inviaDocumento()` ed è ora bloccato per impostazione predefinita.
- Prova reale persistente: abilita un blocco che impedisce l'emissione Epson.
- Armamento DCO di 90 secondi con conferma vendita reale, totale esatto e parola `EMETTI`.
- Dopo l'armamento l'utente preme manualmente i pulsanti ufficiali `Procedi` e `Conferma`.
- Nessun salvataggio automatico nelle statistiche e nessuna stampa automatica MUNBYN in questa fase.
- Versione 1.13.7, build/versionCode 27.
