# CassaIQ RT v1.14.55 — Numero documento immediato

Build sperimentale derivata dalla v1.14.54 runner rapido.

## Obiettivo
Ridurre il tempo tra `Emissione rilevata` e l’avvio della stampa MUNBYN senza modificare la fase fiscale.

## Modifica
- Il numero documento ufficiale è ora il requisito sufficiente per avviare la copia di cortesia.
- La data ufficiale non blocca più la stampa: se non è ancora esposta dal portale viene usata l’ora locale della vendita.
- Se il numero non è già presente nel risultato dell’emissione, CassaIQ installa nella WebView un osservatore locale (60 ms, massimo 1,2 s) che legge solo i metadati e avvisa l’app appena compare il numero.
- Se l’osservatore non trova il numero, resta attivo il precedente polling di recupero come fallback.

## Invariato
- Runner preparatorio 350 ms.
- Fase finale 1100 ms.
- Anti-doppia-emissione.
- Timeout e controlli fiscali.
- Sequenza `Procedi` / `Conferma`.
- Recupero PDF e logica di stampa MUNBYN.

## Versioni
- App: 1.14.55
- iOS build: 86
- Android versionCode: 86
