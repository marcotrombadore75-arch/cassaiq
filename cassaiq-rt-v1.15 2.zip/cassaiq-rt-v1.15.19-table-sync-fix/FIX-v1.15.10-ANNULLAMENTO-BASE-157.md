# CassaIQ RT v1.15.10 / build 141 — annullamento DCO su base v1.15.7

## Principio della correzione
Questa build riparte dal pacchetto v1.15.7 che nei test reali ha già completato correttamente:

Home DCO → Generazione → Annullo → Numero progressivo → recupero documento originario → Verifica dati.

Non usa il nuovo stato persistente dentro la pagina DCO introdotto nelle 1.15.8/1.15.9 e non usa il recupero sessione dell'annullamento che poteva fermarsi sulla Home DCO.

## Estensione oltre il punto già verificato
Solo dopo che la schermata Verifica dati contiene sia “Annullo” sia il progressivo originario, CassaIQ arma la fase finale e usa lo stesso schema già collaudato dal normale motore DCO:

Verifica dati → Vai a Conferma e stampa → Ho capito (se presente) → Procedi → Conferma → rilevamento del nuovo documento DCO.

## Sicurezze
- doppia conferma utente prima dell'avvio;
- nessun invio se Verifica dati non contiene Annullo e documento originario;
- Procedi non viene ripetuto;
- se l'app si chiude dopo Procedi, stato “ANNULLAMENTO DA VERIFICARE”;
- il documento originale viene marcato ANNULLATO solo dopo evidenza di un nuovo ID DCO diverso dall'ID originale;
- le vendite annullate restano nello storico ma sono escluse dai totali statistici;
- nessuna modifica al normale motore di emissione DCO.
