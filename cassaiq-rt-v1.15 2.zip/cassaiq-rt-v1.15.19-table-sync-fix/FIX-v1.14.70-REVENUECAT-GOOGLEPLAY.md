# CassaIQ RT v1.14.70 — RevenueCat Google Play

Base: v1.14.69.

Modifica mirata:
- configurata la Public SDK Key Android reale RevenueCat (`goog_...`) al posto della chiave Test Store;
- Android `versionCode` 101 / `versionName` 1.14.70;
- iOS mantenuto coerente a build 101 / 1.14.70;
- entitlement `pro`, Offering `default` e package mensile restano gestiti dalla dashboard RevenueCat;
- nessuna modifica al motore DCO, ordini tavolo, stampa o altre funzioni della v1.14.69.

Per la release Android usare `npm run android:release-sync`, che esegue anche il controllo della chiave `goog_...`.
