# Test RevenueCat su simulatore iPad

1. Verifica di avere già eseguito `supabase-trial-month.sql` in Supabase.
2. Da Terminale, nella cartella del progetto:

```bash
npm install
npm run ios:sync
npm run ios:open
```

3. In Xcode seleziona un simulatore iPad e premi Run.
4. Accedi o registrati: la prova gratuita viene letta dalla tabella `profiles` di Supabase.
5. Apri **Impostazioni → Abbonamento**.
6. Premi **Abbonati**. La chiave `test_` apre il flusso RevenueCat Test Store, dove puoi simulare successo, errore o annullamento.
7. Dopo il successo deve apparire **Piano Pro attivo** e l'entitlement `pro` deve risultare attivo nella dashboard RevenueCat.
8. Prova anche **Ripristina acquisti**.

## Test scadenza prova

Per un account di test puoi impostare temporaneamente `trial_ends_at` nel passato dalla Table Editor di Supabase. Al riavvio l'app deve mostrare “La prova gratuita è terminata” e consentire l'accesso solo ad Area utente e Abbonamento. Ripristina poi la data futura per continuare i test.

## Importante

Questa build usa la chiave RevenueCat Test Store su iOS e Android. Non deve essere caricata su App Store Connect o Google Play. Prima della pubblicazione vanno inserite le chiavi reali `appl_...` e `goog_...`.
