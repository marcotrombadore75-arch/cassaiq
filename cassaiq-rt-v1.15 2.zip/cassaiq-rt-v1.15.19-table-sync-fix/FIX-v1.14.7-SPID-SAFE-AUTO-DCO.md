# CassaIQ RT 1.14.7 — SPID sicuro e apertura DCO automatica

Versione: **1.14.7**  
Build iOS: **37**  
Android versionCode: **37**

## Problema corretto

La versione 1.14.6 apriva il DCO direttamente dalla pagina `InstradamentofcWeb/wizard`, prima che il portale avesse confermato davvero il profilo fiscale. Il DCO rimandava quindi alla pagina di accesso e il collegamento entrava in un ciclo.

## Nuovo flusso

1. CassaIQ apre il percorso ufficiale dell’Agenzia delle Entrate.
2. L’utente completa soltanto SPID.
3. CassaIQ aspetta che nella pagina Fatture e Corrispettivi siano realmente presenti nome/profilo/Partita IVA.
4. CassaIQ usa il collegamento ufficiale “Documento commerciale online”.
5. Nel wizard seleziona automaticamente “Me stesso” o l’unica utenza disponibile, quando identificabile in modo sicuro.
6. Solo dopo la conferma dell’utenza apre il DCO.
7. Il collegamento viene salvato soltanto quando la home DCO mostra Generazione e Visualizzazione per due controlli consecutivi.

## Protezioni

- nessuna apertura anticipata del DCO dalla pagina SPID o dal wizard non autenticato;
- nessun ciclo automatico quando ricompare la pagina di login;
- timeout di `executeScript` durante una navigazione trattato come attesa, non come errore definitivo;
- uso del comando ufficiale del portale prima dei fallback di navigazione;
- Epson, emissione DCO, recupero PDF e MUNBYN invariati.
