# CassaIQ RT 1.14.2 — timeout durante il cambio pagina DCO

- Non esegue `executeScript` mentre il browser DCO sta caricando una nuova pagina.
- Rimuove il doppio ciclo di polling della vendita automatica.
- Un timeout transitorio prima dell’invio non interrompe più immediatamente la vendita: attende il completamento della navigazione e riprova.
- Prima di `Procedi` o dell’eventuale `Conferma` finale salva un blocco anti-duplicazione.
- Se il browser non risponde dopo l’armamento finale, CassaIQ interrompe il flusso e richiede la verifica nel portale prima di ripetere.
- Timeout complessivi invariati e basati sull’avanzamento reale.

Versione: 1.14.2  
Build iOS: 32  
Android versionCode: 32
