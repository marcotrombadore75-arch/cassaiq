# CassaIQ RT v1.14.88 / build 119

- Categoria speciale `Supplementi`: resta configurabile in Prodotti ma non appare nel catalogo vendita principale.
- Nuovo tasto `SUPPL.` su ogni riga del carrello; selezione/rimozione supplementi e aggiornamento immediato del totale.
- Rimosso il tasto meno separato a sinistra: la quantità si gestisce soltanto con `− / +`; a zero la riga viene eliminata.
- Supplementi inclusi in Epson, DCO, statistiche e ordini tavolo.
- Comande cucina mostrano i supplementi insieme alla riga prodotto.
- Ordini in attesa conservano i supplementi.
- Nessuna migrazione Supabase richiesta: si usa una normale categoria chiamata `Supplementi`.
- Aggiunto anche il pulsante diretto `Come ottenere le credenziali Fisconline` nella schermata di configurazione DCO, collegato alla guida YouTube.
