# CassaIQ 1.13.5 — DCO cart prefill

- Mappatura confermata della pagina `#/generazione/wizard2`.
- Compilazione assistita di massimo 8 righe dal carrello CassaIQ.
- Campi gestiti: quantità, descrizione, prezzo lordo, IVA, pagamento e sconto globale.
- IVA ammesse nella prima prova: 4%, 5%, 10%, 22%.
- Pagamenti gestiti: Contanti e Carta.
- Accesso alla pagina ufficiale “Verifica dati” consentito.
- Emissione, conferma e invio fiscale finale bloccati tramite guardia locale.
- Nessuna vendita viene salvata o azzerata durante la prova.
- Versione 1.13.5, build/versionCode 25.
