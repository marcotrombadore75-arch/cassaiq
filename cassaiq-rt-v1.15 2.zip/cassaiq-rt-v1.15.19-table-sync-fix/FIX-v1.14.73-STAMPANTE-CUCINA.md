# CassaIQ RT v1.14.73 — Stampante cucina

- Aggiunta terza stampante ESC/POS di rete, indipendente da Epson RT e dalla stampante copia cliente DCO.
- Configurazione: attiva/disattiva, IP, porta, test e salvataggio cloud.
- La configurazione viene salvata in `business_profiles` e resa disponibile ai CassaIQ Client autorizzati.
- Le comande create direttamente dalla cassa vengono stampate subito in cucina dopo il salvataggio cloud.
- Il ticket cucina non contiene prezzi: tavolo, data/ora, quantita, prodotti, eventuali note, origine e riferimento breve ordine.
- Un errore di stampa cucina non annulla la comanda gia salvata: viene mostrato un avviso e la comanda resta valida.
- Nessuna modifica al motore DCO, ai timer 350/1100 ms, Epson RT, Active WebView o protezioni anti-doppia emissione.

Prima del test eseguire in Supabase `supabase-kitchen-printer-v1.14.73.sql`.
