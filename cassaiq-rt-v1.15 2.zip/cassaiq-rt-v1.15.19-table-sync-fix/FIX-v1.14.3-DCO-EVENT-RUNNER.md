# CassaIQ RT 1.14.3 — esecutore DCO guidato dagli eventi

Versione: **1.14.3**  
Build iOS: **33**  
Android versionCode: **33**

## Problema corretto

Il portale DCO è un'applicazione Angular. Quando un pulsante cambia pagina, il contesto WebKit
può terminare prima che il callback di `executeScript` ritorni a CassaIQ. La vendita rimaneva
quindi su “Preparazione conferma finale…” e terminava con “Risposta del browser DCO scaduta”.

## Nuovo funzionamento

- il browser DCO resta aperto per tutta l'operazione;
- prima di ogni clic che cambia pagina, lo script invia a CassaIQ lo stato raggiunto;
- il clic viene eseguito solo dopo un breve intervallo, così l'app riceve prima la conferma;
- i cambi di rotta Angular vengono comunicati tramite il canale `cordova_iab`;
- dopo ogni cambio pagina l'esecutore viene reiniettato e riprende dal punto corretto;
- apertura del documento esclusivamente tramite “Genera il tuo documento / Generazione”;
- rimosso il passaggio diretto tramite modifica dell'hash interno;
- blocco anti-duplicazione salvato prima di `Procedi` o dell'eventuale `Conferma`;
- in caso di esito finale incerto, nuove emissioni restano bloccate fino alla verifica nel DCO;
- Epson, recupero PDF ufficiale e stampa MUNBYN restano invariati.

## Prova

Se una prova precedente è arrivata alla richiesta finale, controllare prima **Visualizzazione**
nel portale DCO. Se non è stato generato alcun documento:

1. lasciare il prodotto nel carrello;
2. scegliere **Paga**;
3. scegliere **Contanti**;
4. premere **Emetti e stampa**.

Dopo “Richiesta di emissione all'Agenzia delle Entrate” non ripetere il pagamento finché
l'esito non è stato verificato.
