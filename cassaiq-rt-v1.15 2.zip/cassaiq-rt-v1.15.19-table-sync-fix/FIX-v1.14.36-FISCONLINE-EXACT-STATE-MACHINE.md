# CassaIQ RT v1.14.36 — Fisconline exact IAM state machine

Correzione basata sul comportamento osservato nell’APK di riferimento, senza copiarne codice o asset.

## Login Fisconline
- apertura diretta `https://iampe.agenziaentrate.gov.it/sam/UI/Login?realm=/agenziaentrate`
- pannello esatto `#tab-4` (Fisconline/Entratel)
- campi esatti `#username-fo-ent` / `IDToken1`, `#password-fo-ent-1` / `IDToken2`, `#pin-fo-ent` / `IDToken3`
- submit esatto `#tab-4 [type="submit"]`
- credenziali inviate una sola volta per tentativo; nessun retry automatico mentre IAM attende
- esito positivo riconosciuto da uscita da IAM / `#user-info`
- errori password scaduta, credenziali rifiutate e utenza disabilitata bloccano nuovi tentativi

## Percorso successivo
1. IAM login
2. `InstradamentofcWeb/wizard` per utenza di lavoro
3. `InstradamentofcWeb/home`
4. Documento Commerciale Online

Keychain iOS / Android Keystore e canale RSA-OAEP restano invariati. SPID resta fallback.
