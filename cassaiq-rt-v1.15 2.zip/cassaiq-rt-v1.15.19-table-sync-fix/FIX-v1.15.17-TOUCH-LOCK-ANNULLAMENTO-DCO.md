# CassaIQ RT v1.15.17 / build 148

## Blocco touch durante annullamento DCO

- Durante tutto il flusso automatico di annullamento viene inserito un livello trasparente sopra la pagina DCO che intercetta touch, pointer, click, trascinamento, scroll e menu contestuale.
- I click automatici di CassaIQ continuano a funzionare perché vengono eseguiti via script direttamente sugli elementi del portale.
- Il livello di protezione viene reinstallato a ogni `loadstop` e anche dal runner dell'annullamento, così resta attivo durante i cambi pagina.
- Il banner ora indica: `TOUCH BLOCCATO`.
- Banner e blocco touch vengono rimossi insieme quando l'annullamento termina o viene interrotto.
- Emissione DCO normale invariata.

Nota: il blocco riguarda l'intera area web del portale Agenzia Entrate. Eventuali controlli nativi della finestra InAppBrowser (fuori dalla pagina web) non sono elementi DOM e non vengono intercettati da questo livello.
