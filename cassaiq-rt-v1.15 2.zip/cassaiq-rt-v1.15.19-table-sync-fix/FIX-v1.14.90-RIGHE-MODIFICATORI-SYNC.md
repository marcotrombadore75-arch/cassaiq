# CassaIQ RT v1.14.90 / build 121

- Se una riga ha quantità maggiore di 1 e si apre **SUPPL.**, CassaIQ separa automaticamente una singola unità prima di applicare `+` o `-`.
- La stessa pizza/prodotto può quindi comparire su più righe con modificatori diversi senza applicare il supplemento a tutta la quantità.
- I nuovi tocchi sul prodotto si sommano alla riga normale, non a una riga già personalizzata.
- Le comande del Client mantengono separate le righe con note/modificatori diversi e, quando possibile, ricostruiscono i supplementi nel carrello della cassa.
- Stampa cucina: i simboli Unicode vengono normalizzati in ASCII (`-`, `+`, `|`) per evitare il `?` al posto del meno.
- Vendite rimaste solo locali: al ritorno di Internet parte il recupero automatico, a piccoli blocchi e rispettando il limite di sincronizzazione per evitare raffiche di richieste.
- Nessuna modifica SQL richiesta.
