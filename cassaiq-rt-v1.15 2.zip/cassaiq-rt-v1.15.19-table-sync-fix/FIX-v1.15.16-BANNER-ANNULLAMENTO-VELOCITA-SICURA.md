# CassaIQ RT v1.15.16 / build 147

## Correzione banner DCO
- Il banner rosso “CassaIQ · ANNULLAMENTO DCO IN CORSO · NON CHIUDERE” resta visibile esclusivamente durante un annullamento reale.
- Alla conclusione o interruzione dell’annullamento viene rimosso dal portale DCO.
- Prima di una normale emissione CassaIQ elimina comunque un eventuale banner residuo dalla WebView riutilizzata.

## Velocizzazione prudente annullamento
- Nessuna modifica ai click fiscali critici: i ritardi di click restano a 180 ms.
- La fase finale (Verifica / Conferma / Procedi e attesa esito) conserva il polling prudente di 420 ms.
- Solo la fase preparatoria reversibile usa un polling fallback di 360 ms invece di 420 ms.
- Avvio del primo controllo ridotto da 550 ms a 450 ms.
- Gli eventi reali di caricamento pagina mantengono i controlli rapidi già presenti (120/160 ms).

Obiettivo: ridurre leggermente i tempi morti senza ripetere la regressione della vecchia velocizzazione aggressiva.
