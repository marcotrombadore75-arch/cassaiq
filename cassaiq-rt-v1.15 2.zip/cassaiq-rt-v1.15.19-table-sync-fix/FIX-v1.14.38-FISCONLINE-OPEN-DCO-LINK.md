# CassaIQ RT v1.14.38 — Fisconline: apertura DCO dalla home autenticata

## Situazione (dal log reale)
Il login Fisconline RIESCE: pagina InstradamentofcWeb/home, hasUserInfo:true,
P.IVA corretta, link "Documento Commerciale on line" presente. Ma l'app:
1. rimbalzava di continuo wizard <-> home (selezione utenza in conflitto);
2. una volta stabile sulla home, faceva polling ma NON apriva il DCO.

## Correzioni
1. **Niente più rimbalzo utenza**: se la home autenticata mostra gia' il link
   DCO (hasOfficialDcoLink), l'utenza e' di fatto attiva → si conferma senza
   tornare al wizard.
2. **Apertura DCO immediata**: appena si e' sulla home con il link presente,
   si clicca il comando ufficiale; se il click non naviga, si va SUBITO
   all'href del link (o a DCO_URLS.service) senza attendere i 2,5s che nel
   rimbalzo non maturavano mai. Un flag dcoOpeningServiceLink evita doppie
   aperture ed e' resettato al reset connessione.

## Invariato
Login Fisconline (selettori diretti), cifratura credenziali, emissione DCO,
anti-doppia-emissione, numero documento ufficiale, stampa MUNBYN, SPID.

## Da verificare sull'iPad
Dopo il login Fisconline, l'app deve aprire il DCO da sola (niente polling
infinito) e arrivare alla schermata di emissione. Poi vendita di prova.
