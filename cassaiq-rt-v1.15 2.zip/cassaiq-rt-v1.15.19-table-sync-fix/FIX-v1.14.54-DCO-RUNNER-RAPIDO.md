# CassaIQ RT v1.14.54 — Runner DCO rapido sperimentale

Base: v1.14.51 stabile + diagnostica tempi.

## Obiettivo
Misurare se il divario osservato rispetto all’app di riferimento dipende dalle attese tra i passaggi preparatori del DCO.

## Modifica
- Polling/preparazione DCO: **350 ms**.
- Dopo `final-armed` o `proceed-clicked`: ritorno automatico a **1100 ms**.
- Gli eventi reali `route` / `loadstop` continuano a richiamare subito il controllo.
- Nessuna modifica ai timeout complessivi.
- Nessuna modifica al lock anti-doppia-emissione.
- Nessuna modifica alla verifica di quantità, prodotto, prezzo, IVA o pagamento.
- Nessuna modifica al recupero documento/PDF o alla stampa MUNBYN.
- Diagnostica tempi mantenuta e identificata come `1.14.54 runner-rapido`.

## Versioning test
- App: 1.14.54
- iOS build: 85
- Android versionCode: 85

Questa è una build sperimentale: conservare la v1.14.51 baseline+diagnostica come fallback.
