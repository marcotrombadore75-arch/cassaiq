# CassaIQ RT 1.13.0

- Aggiunto modulo nativo ESC/POS per iOS e Android.
- Test rete TCP/IP su porta configurabile, predefinita 9100.
- Ricerca, collegamento e stampa Bluetooth su iPhone/iPad tramite CoreBluetooth.
- Collegamento Bluetooth SPP su Android per dispositivi già associati.
- Test completo 80 mm, taglio carta e apertura cassetto.
- Preconfigurazione MUNBYN/TM-m30-b001 con IP 192.168.1.201.
- Nuova schermata Impostazioni → Test stampante 80 mm.
- Nessuna modifica al driver fiscale Epson FP-Mate.
- Versione 1.13.0, build 21.
