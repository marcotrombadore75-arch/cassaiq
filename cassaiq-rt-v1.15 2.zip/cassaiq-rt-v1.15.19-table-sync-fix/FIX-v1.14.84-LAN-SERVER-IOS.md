# CassaIQ RT v1.14.84 / build 115 — LAN server iOS

- Aggiunto al plugin nativo iOS `CassaIQPrinter` il server TCP locale sulla porta configurata (default 8765).
- Aggiunti i metodi Capacitor: `lanServerStart`, `lanServerStop`, `lanServerStatus`, `lanGetPendingOrders`, `lanAcknowledgeOrder`, `lanLocalIp`.
- Protocollo compatibile con il server Android v1.14.83: probe `cassaiq_probe`, comande `cassaiq_order`, ACK `received` / `already_received`.
- Deduplicazione persistente delle comande tramite `order_id`; coda locale persistente su iPad prima dell'ACK al Client.
- Gli ID già elaborati restano memorizzati 7 giorni per evitare ristampe in caso di retry.
- IP Wi‑Fi dell'iPad rilevato da interfaccia `en0`; fallback su IPv4 privata locale.
- Aggiornata la descrizione permesso Rete locale iOS per includere CassaIQ Client.
- Nessuna modifica al flusso fiscale Epson/DCO o alla stampa cucina: il codice JS esistente continua a prelevare la coda LAN e stampare una sola volta.

## Test consigliato
1. Installare la build su iPad e autorizzare **Rete locale** quando iPadOS lo richiede.
2. In `Impostazioni → Gestione CassaIQ Client` verificare che compaia `192.168.x.x:8765`.
3. Nel Client inserire quell'IP e usare `Test`.
4. Inviare una comanda con Internet attivo.
5. Disattivare solo Internet/WAN lasciando i dispositivi sulla stessa Wi‑Fi e inviare una seconda comanda.
6. Verificare ACK, ricezione sulla cassa, una sola stampa cucina e successiva sincronizzazione cloud al ritorno di Internet.
