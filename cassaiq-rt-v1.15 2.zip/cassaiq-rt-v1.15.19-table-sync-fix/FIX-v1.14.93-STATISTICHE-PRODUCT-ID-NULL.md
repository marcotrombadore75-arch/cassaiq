# CassaIQ RT v1.14.93 / build 124

## Statistiche prodotti: correzione record storici con `product_id = NULL`

Problema individuato su archivi reali: tutte le righe `sale_items` senza `product_id` venivano aggregate con la stessa chiave JavaScript (`null`). Di conseguenza prodotti diversi potevano comparire sommati sotto il nome della prima riga incontrata.

### Correzione
- Se `product_id` è presente, il raggruppamento usa l'ID prodotto.
- Se `product_id` è assente, CassaIQ usa il nome prodotto normalizzato (trim, spazi multipli e differenze maiuscole/minuscole).
- Se il nome storico senza ID corrisponde in modo univoco a un prodotto attuale del catalogo, viene ricondotto allo stesso gruppo dell'ID attuale: così storico vecchio e vendite nuove restano uniti nella stessa voce.
- Il filtro statistiche per prodotto include anche le vecchie righe senza ID che hanno lo stesso nome normalizzato del prodotto selezionato.
- Nessuna modifica ai dati Supabase e nessun SQL richiesto.

### Esempio del bug risolto
Prima, 19 prodotti diversi con `product_id = NULL` potevano essere sommati tutti come “Bocconcini”. Dopo il fix ciascun prodotto viene classificato correttamente.
