# CassaIQ RT v1.14.68 — DCO session recovery + righe dinamiche

Build iOS: 99  
Android versionCode: 99

## Correzioni

- Rimosso il limite artificiale CassaIQ di 8 righe prodotto dal carrello DCO.
- Il wizard DCO ora conta le righe realmente esposte dal portale. Se il portale offre un controllo esplicito per aggiungere righe, CassaIQ lo usa una riga alla volta e riprende la compilazione.
- Se il portale impone davvero un limite, CassaIQ blocca prima dell'invio con un messaggio esplicito e non divide automaticamente la vendita.
- Preflight della sessione DCO prima della prima vendita dopo 15 minuti dal precedente collegamento o dopo almeno 5 minuti in background.
- Se la vecchia WebView/sessione non è più valida, viene eliminata e CassaIQ ricrea automaticamente la sessione Fisconline, poi riprende la vendita richiesta.
- Se la scadenza viene rilevata durante la preparazione della vendita, la WebView scaduta viene chiusa prima del ricollegamento per evitare lo stato bloccato che richiedeva il riavvio dell'app.
- Motore rapido 350/1100 ms, isolamento tra emissioni e Android Active WebView restano invariati.

## Diagnostica nuova

- `diagnostic:session-preflight-ok`
- `diagnostic:session-preflight-expired`
- `diagnostic:session-preflight-timeout`
- `diagnostic:session-preflight-browser-missing`
- `diagnostic:session-preflight-reconnect-required`

## Nota sulle righe prodotto

Il limite di 8 righe non viene più imposto da CassaIQ. La build non presume però che il portale Agenzia supporti un numero illimitato di righe: usa dinamicamente ciò che il wizard ufficiale rende disponibile e non forza controlli inesistenti.
