# CassaIQ RT v1.14.20

Versione 1.14.20 · build iOS 50 · Android versionCode 50.

## Obiettivo del test

La stampa al cliente non dipende più dal PDF ufficiale DCO.

Dopo che il portale restituisce l'identificativo del documento (`idtrx`), CassaIQ:

1. registra localmente la vendita con numero `DCO-{idtrx}`;
2. genera una copia cliente ESC/POS dai dati originali del carrello;
3. invia subito la stampa alla MUNBYN configurata;
4. chiude il flusso di emissione e torna alla cassa;
5. lascia il recupero del PDF come funzione opzionale di archivio.

## Contenuto della stampa di test

- intestazione CassaIQ RT;
- dicitura Documento commerciale / Copia di cortesia;
- prodotti, quantità, prezzo unitario e totale riga;
- sconto, totale e pagamento;
- contanti ricevuti e resto, quando presenti;
- identificativo `DCO-{idtrx}` e data/ora.

La grafica è volutamente semplice: questa versione serve soprattutto a verificare che la MUNBYN stampi immediatamente al primo tentativo dopo l'emissione.

## Sicurezza

- la vendita fiscale non viene ripetuta se la stampa fallisce;
- il carrello viene svuotato dopo la registrazione del documento DCO;
- la ristampa usa i dati salvati della vendita e non effettua una nuova emissione;
- il PDF può essere recuperato in seguito con “Riprova recupero PDF”, senza una seconda stampa automatica se la copia cliente è già stata stampata.
