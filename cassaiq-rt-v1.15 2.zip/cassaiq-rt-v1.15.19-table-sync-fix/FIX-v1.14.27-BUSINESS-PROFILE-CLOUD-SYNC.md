# CassaIQ RT v1.14.27 — dati attività sincronizzati

Versione 1.14.27, build iOS 57, Android versionCode 57.

## Correzione

I dati dell'attività non restano più confinati nel `localStorage` del singolo dispositivo.
Vengono salvati nella tabella Supabase `business_profiles`, protetta da RLS e collegata
all'utente autenticato.

## Comportamento

- il salvataggio scrive subito una copia locale, così la stampa continua a funzionare anche offline;
- con account e rete disponibili, lo stesso salvataggio esegue l'upsert su Supabase;
- al login e all'avvio, CassaIQ recupera i dati dal cloud;
- se il cloud è ancora vuoto ma sul dispositivo esiste un profilo locale valido, questo viene
  caricato automaticamente su Supabase: è la migrazione della configurazione già presente su iOS;
- eliminando l'account viene eliminato anche `business_profiles`.

## Prima installazione

Eseguire una sola volta nel SQL Editor di Supabase:

`supabase-business-profile-sync.sql`

Per trasferire automaticamente i dati già presenti su iPhone:

1. aggiornare prima l'iPhone alla v1.14.27 e aprire l'app con lo stesso account;
2. attendere la sincronizzazione oppure aprire Configura CassaIQ e premere Salva dati attività;
3. aggiornare/aprire Android con lo stesso account: il profilo viene scaricato.

Le statistiche non sono state modificate in questa versione.
