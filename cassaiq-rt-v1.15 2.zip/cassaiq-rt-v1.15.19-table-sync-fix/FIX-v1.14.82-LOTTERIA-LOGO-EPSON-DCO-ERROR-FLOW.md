# CassaIQ RT v1.14.82 / build 113

## Novità

- Lotteria degli scontrini Epson RT: `printRecLotteryID` viene inserito prima del pagamento quando il pagamento è Carta, il totale è almeno 1,00 € e il codice lotteria è presente e valido.
- Lotteria DCO: lo stesso codice viene portato nella bozza DCO. L'automazione individua il campo del portale in base a etichette/attributi che contengono riferimenti alla lotteria. Se il campo non viene trovato, il flusso si ferma prima dell'invio fiscale.
- Logo Epson RT: lo stesso logo già caricato per il documento DCO viene convertito in BMP 1-bit, centrato su 576 px, codificato Base64 e caricato in NVRAM Epson nello slot 9 tramite `setLogo`. Lo slot 9 viene impostato come HEADER del documento commerciale.
- Disattivazione logo Epson: `setLogo location="1" index="0" option="2"`; il file resta in NVRAM ma non viene stampato.
- Errori DCO senza blocco globale: dopo un errore certamente precedente all'invio finale vengono proposte subito le azioni "Riprova emissione" e "Registra come emergenza".
- Esito DCO incerto: niente reinvio automatico. La vendita viene salvata come `esito_da_verificare`; il lock globale viene rimosso così la cassa può continuare con nuove vendite.
- Recupero dei vecchi lock globali: all'avvio vengono trasferiti in emergenza come esiti da verificare e il blocco globale viene rimosso.

## Sicurezza fiscale

La protezione anti-duplicato resta attiva durante la fase finale DCO. Se CassaIQ non può determinare con certezza se l'Agenzia delle Entrate ha emesso il documento, non offre un retry cieco.

## Test richiesti su hardware/portale

1. Epson FP-81II RT: caricare un logo, premere "Invia logo alla Epson RT", poi emettere un documento commerciale e verificare l'header.
2. Epson FP-81II RT: vendita Carta >= 1,00 € con codice lotteria e verifica stampa/accodamento.
3. DCO: vendita Carta >= 1,00 € con codice lotteria e verifica che il campo del portale venga riconosciuto e compilato.
4. DCO: simulare un errore prima dell'invio finale e verificare il dialogo Riprova/Emergenza.
5. DCO: non forzare un errore dopo il click finale in produzione; se si verifica naturalmente, verificare che l'operazione finisca in "Esito da verificare" senza bloccare nuove vendite.
