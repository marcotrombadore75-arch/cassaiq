# CassaIQ RT v1.14.71 — Link legali Android

Base: v1.14.70 RevenueCat Google Play.

Modifica mirata:
- separati Privacy Policy e Termini per iOS e Android;
- iOS mantiene EULA standard Apple e privacy gia' in uso;
- Android usa `https://menoova.it/cassaiq-termini-android.html` e `https://menoova.it/cassaiq-privacy-android.html`;
- nella schermata Abbonamento, su Android il link viene mostrato come **Termini e condizioni** anziche' **Termini di utilizzo (EULA)**;
- aggiornati i controlli release per verificare i link corretti della singola piattaforma;
- Android versionCode 102 / versionName 1.14.71;
- iOS predisposto a build 102 / 1.14.71 per il prossimo aggiornamento.

Nessuna modifica a DCO, isolamento emissioni, timer, WebView, Epson, ESC/POS, tavoli/comande o RevenueCat.

Prima della build Play Console pubblicare sul sito i due file Android inclusi nella cartella `LEGAL-ANDROID-SITO`.
