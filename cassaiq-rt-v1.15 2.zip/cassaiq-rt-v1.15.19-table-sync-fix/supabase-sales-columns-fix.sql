-- CassaIQ RT - allineamento colonne tabella vendite
-- Aggiunge le colonne che l'app usa quando salva una vendita.
-- Sicuro da rieseguire: "if not exists" non tocca le colonne gia' presenti.

alter table public.sales add column if not exists subtotal        numeric(12,2);
alter table public.sales add column if not exists discount_amount numeric(12,2) default 0;
alter table public.sales add column if not exists payment_method  text;
alter table public.sales add column if not exists receipt_number  text;
alter table public.sales add column if not exists item_count      integer default 0;
alter table public.sales add column if not exists cash_received   numeric(12,2) default 0;
alter table public.sales add column if not exists change_due      numeric(12,2) default 0;

-- Righe della vendita
alter table public.sale_items add column if not exists category_name   text;
alter table public.sale_items add column if not exists department_name text;
alter table public.sale_items add column if not exists vat_rate        numeric(5,2) default 0;

-- Ricarica la cache dello schema di PostgREST (evita errori "schema cache")
notify pgrst, 'reload schema';
