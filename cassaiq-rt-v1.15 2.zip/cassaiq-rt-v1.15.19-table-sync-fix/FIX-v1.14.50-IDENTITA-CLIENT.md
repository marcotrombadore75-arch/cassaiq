# CassaIQ RT v1.14.50 — Identità CassaIQ Client

- I dispositivi CassaIQ Client generici vengono mostrati nella Cassa con un codice breve stabile, ad esempio `Client A7F3C`.
- Il codice è derivato dal UUID del dispositivo già registrato: non richiede nuovo SQL e funziona anche per i Client già collegati.
- Nessuna modifica a pairing, tavoli, ordini, Epson, DCO/Fisconline o stampa.
