# CassaIQ RT v1.14.99 — Stop ciclo continuo diagnostica DCO

- Versione 1.14.99 / build iOS 130 / Android versionCode 130.
- Eliminato il polling diagnostico permanente ogni 1 secondo sulla WebView DCO già collegata.
- Il polling resta attivo solo durante il collegamento Fisconline/SPID.
- Durante l'emissione DCO continua a essere usato esclusivamente il runner dedicato già esistente.
- Dopo un cambio pagina vengono effettuate solo due acquisizioni diagnostiche finite (300 ms e 1800 ms).
- Nessuna modifica al motore fiscale DCO, all'emissione, alla stampa o al rinnovo Fisconline.
- Corretto anche lo stato del pulsante "DCO già collegato", che ora può riabilitarsi correttamente quando la sessione non è più valida.
