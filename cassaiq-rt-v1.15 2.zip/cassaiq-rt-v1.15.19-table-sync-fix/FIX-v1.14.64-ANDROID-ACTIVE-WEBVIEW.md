# CassaIQ RT v1.14.64 — Android active WebView

Base: v1.14.63.

Modifica sperimentale Android mirata ai blocchi casuali della InAppBrowser hidden:
- durante una vendita DCO Android la InAppBrowser viene resa realmente attiva/visibile;
- prima di mostrarla viene iniettato un overlay CassaIQ a pieno schermo che copre il portale;
- il browser Fisconline automatico Android viene creato senza toolbar/location chrome;
- il wizard Agenzia resta quindi mascherato all'utente, ma la WebView non lavora piu' in background;
- isolamento operazione v1.14.62, fallback Verifica v1.14.63, anti-doppio invio e timer 350/1100 ms restano invariati.

Versione app: 1.14.64
Android versionCode: 95
iOS build: 95
