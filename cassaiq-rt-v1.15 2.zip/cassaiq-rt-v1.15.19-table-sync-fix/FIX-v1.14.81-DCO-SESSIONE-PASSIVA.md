# CassaIQ RT v1.14.81 / build 112 — Sessione DCO passiva

## Modifica
Rimossi tutti i controlli preventivi/temporali della sessione Fisconline/DCO:

- nessun polling ogni 60 secondi;
- nessun preflight dopo 15 minuti;
- nessun preflight dopo 5 minuti in background;
- nessuna verifica automatica al resume dell’app.

La sessione DCO viene lasciata intatta finché il portale non segnala realmente `AUTH_REQUIRED` o `SESSION_EXPIRED` durante il flusso di emissione.

In quel caso, prima della fase irreversibile, CassaIQ usa il flusso già esistente `dcoReconnectFisconlineSale()` per:

1. ricreare la WebView DCO;
2. effettuare il login Fisconline automatico con le credenziali salvate;
3. riprendere la vendita preparata.

Dopo un’emissione riuscita, CassaIQ continua a mantenere la stessa sessione e la marca come collegata, senza distruggerla o verificarla periodicamente.

## Invariato
- login Fisconline e canale sicuro;
- automazione di emissione DCO;
- protezione anti-doppia-emissione;
- stampa MUNBYN e logo DCO;
- Epson RT;
- stampa cucina;
- note prodotto;
- sincronizzazione cloud.
