-- Eseguire nel SQL Editor di Supabase
create table if not exists public.sales (id uuid primary key, user_id uuid not null references auth.users(id) on delete cascade, sold_at timestamptz not null default now(), total numeric(12,2) not null default 0, payment_method text not null, receipt_number text, item_count integer not null default 0, cash_received numeric(12,2) default 0, change_due numeric(12,2) default 0, created_at timestamptz not null default now());
create table if not exists public.sale_items (id uuid primary key, sale_id uuid not null references public.sales(id) on delete cascade, user_id uuid not null references auth.users(id) on delete cascade, product_id uuid, product_name text not null, quantity numeric(12,3) not null, unit_price numeric(12,2) not null, line_total numeric(12,2) not null, category_name text, department_name text, vat_rate numeric(5,2) default 0, created_at timestamptz not null default now());
create index if not exists sales_user_date_idx on public.sales(user_id,sold_at desc);
create index if not exists sale_items_user_sale_idx on public.sale_items(user_id,sale_id);
alter table public.sales enable row level security; alter table public.sale_items enable row level security;
drop policy if exists sales_owner_all on public.sales; create policy sales_owner_all on public.sales for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
drop policy if exists sale_items_owner_all on public.sale_items; create policy sale_items_owner_all on public.sale_items for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
