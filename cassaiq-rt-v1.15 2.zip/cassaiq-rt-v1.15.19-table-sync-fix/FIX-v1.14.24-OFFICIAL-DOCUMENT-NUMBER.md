# CassaIQ RT v1.14.24 — numero documento ufficiale DCO

## Correzione

La copia di cortesia non usa più `idtrx` come se fosse il numero fiscale del documento.

CassaIQ mantiene separati:

- `documentId`: identificativo tecnico DCO, usato internamente per dettaglio e PDF;
- `documentNumber`: numero ufficiale `datiTrasmissione.numeroProgressivo` (es. `DCW2026/2019-2431`);
- `documentDate`: data e ora ufficiali del documento (`documentoCommerciale.dataOra`).

## Acquisizione

Dopo l'emissione, il runner legge i riferimenti da `vm.invio` nella pagina finale del DCO. Sono previsti:

- proprietà `vm.invio.datiTrasmissione.numeroProgressivo`;
- proprietà `vm.invio.documentoCommerciale.dataOra`;
- ricerca ricorsiva negli scope Angular;
- fallback sul testo visibile della pagina.

La stampa attende brevemente i riferimenti ufficiali prima di inviare la copia alla MUNBYN.

## Stampa

Nel piede viene stampato:

- `Doc. N. <numero ufficiale>`;
- data e ora ufficiali dell'Agenzia.

L'`idtrx` resta nell'archivio interno e nella diagnostica. Se, in un caso anomalo, il numero ufficiale non è disponibile, viene indicato chiaramente come `Rif. tecnico DCO` e non come numero documento.

## Invariato

- emissione automatica DCO;
- stampa immediata ESC/POS;
- layout 32 colonne;
- guardia anti-doppia stampa;
- PDF opzionale.
