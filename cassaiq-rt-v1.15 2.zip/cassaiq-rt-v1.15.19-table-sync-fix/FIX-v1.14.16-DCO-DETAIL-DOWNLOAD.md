# CassaIQ RT v1.14.16 — Recupero PDF dal dettaglio ufficiale

- Versione 1.14.16, build iOS 46, Android versionCode 46.
- Quando l'ultimo documento è già emesso e il browser si trova nella home DCO, CassaIQ apre direttamente la rotta ufficiale `#/visualizzazione/dettaglio/{id}`.
- Attende il caricamento completo del dettaglio e la comparsa del comando di download.
- Solo dopo usa il comando ufficiale di stampa/download e intercetta il PDF.
- Il recupero non ripete la vendita e mantiene il browser aperto fino a stato terminale.
