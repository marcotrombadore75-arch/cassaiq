# CassaIQ RT v1.15.7 / build 138 — LAB progressivo annullamento DCO

## Obiettivo
Individuare in modo dinamico il campo reale **Numero progressivo** mostrato dal portale DCO dopo la selezione di **Annullo**, senza dipendere da un ID fisso.

## Comportamento LAB
- imposta `operazione = A` (Annullo);
- attende il ridisegno Angular della pagina;
- cerca esclusivamente input visibili/abilitati, privilegiando placeholder `Numero progressivo` e contesto `Documento originario generato online`;
- se trova zero campi attende; se trova piu campi con lo stesso punteggio massimo si ferma;
- valorizza il campo usando sia setter DOM sia `ngModel.$setViewValue` quando disponibile;
- genera eventi `input`, `change`, `blur`;
- sceglie il pulsante `Prosegui` piu vicino al campo per evitare quello del riquadro RT non recuperabile;
- prosegue verso **Verifica dati**;
- blocca sempre `Conferma`, `Procedi`, `Vai a conferma e stampa` e qualsiasi accesso a wizard4.

## Diagnostica
Il LAB riporta ID, name, placeholder e ng-model del campo individuato.

**Nessun annullo fiscale viene inviato da questa build LAB.**
