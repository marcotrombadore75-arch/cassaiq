# CassaIQ RT v1.14.23

- Centratura ESC/POS corretta: quando `ESC a 1` è attivo, le righe vengono inviate senza padding manuale.
- Denominazione, titolo documento e footer risultano realmente centrati.
- Dopo data e ora vengono alimentate 6 righe (`ESC d 6`) prima del comando di taglio.
- Nessuna modifica al flusso fiscale DCO o alla stampa automatica.
