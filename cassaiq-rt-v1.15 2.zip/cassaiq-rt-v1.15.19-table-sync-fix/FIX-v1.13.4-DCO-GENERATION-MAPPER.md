# CassaIQ 1.13.4 — DCO generation mapper

- Confermata la sessione autorizzata fino alla home Documento Commerciale Online.
- Nuovo pulsante **Genera** nella barra CassaIQ interna al browser.
- Il pulsante apre soltanto la schermata “Genera il tuo documento”; non conferma e non invia documenti.
- Diagnostica continua ogni 2,5 secondi per rilevare le rotte SPA senza ricaricamento pagina.
- Mappatura estesa di input, select, pulsanti, link e controlli Angular/ARIA senza leggere i valori.
- Nessuna modifica ai driver Epson o MUNBYN.
- Versione 1.13.4, build 24.
