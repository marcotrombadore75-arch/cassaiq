# CassaIQ RT v1.14.25 — centratura denominazione

La prima riga inviata subito dopo `ESC @` non veniva centrata in modo affidabile dalla MUNBYN.

La denominazione ora usa una centratura esplicita su `RECEIPT_WIDTH = 32`, tramite `printerCenterText`, con allineamento ESC/POS a sinistra. In questo modo la posizione non dipende dall’interpretazione del comando `ESC a 1` sulla prima riga.

Numero documento ufficiale, data, avanzamento carta e taglio restano invariati.

Versione 1.14.25, build iOS 55, Android versionCode 55.
