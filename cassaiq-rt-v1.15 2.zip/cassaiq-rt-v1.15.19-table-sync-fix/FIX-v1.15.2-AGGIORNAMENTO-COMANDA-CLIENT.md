# CassaIQ RT v1.15.2 — aggiornamento comanda da Client

- Riceve il messaggio LAN `replace_order`.
- La comanda selezionata viene marcata `cancelled` e resta nello storico.
- La nuova comanda diventa quella attiva del tavolo.
- In cucina ristampa tutta la nuova comanda con **AGGIORNAMENTO** e **COMANDA PRECEDENTE NON PIU VALIDA**.
- Nessun confronto tra vecchie e nuove righe.
- Routing stampante cucina 1 / 2 invariato.
