# CassaIQ 1.14.0 — DCO rapido dalla cassa

## Flusso
1. Impostazioni → Documento commerciale online → Collega con SPID/CIE/CNS.
2. Selezione utenza di lavoro. CassaIQ nasconde la finestra e torna alla cassa.
3. Carrello → Paga → Contanti/Carta → Emetti e stampa.
4. CassaIQ compila e invia il DCO in background, recupera il PDF ufficiale e lo stampa sulla MUNBYN.

## Sicurezza
- Nessuna password, PIN o OTP viene letta o salvata.
- Se la sessione è scaduta l'invio viene fermato prima della conferma finale.
- Dopo il click finale “Procedi”, un esito dubbio blocca nuove emissioni fino alla verifica manuale nel portale.
- Epson resta disponibile come modalità separata e il relativo codice non è stato modificato.

Versione app 1.14.0, build iOS/Android 30.
