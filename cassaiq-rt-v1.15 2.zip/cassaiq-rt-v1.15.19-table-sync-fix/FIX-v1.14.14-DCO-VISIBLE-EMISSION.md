# CassaIQ RT v1.14.14 — browser DCO visibile durante emissione

Versione 1.14.14, build iOS 44, Android versionCode 44.

- Il browser DCO non viene più nascosto all’avvio della vendita automatica.
- Durante l’emissione resta visibile un pannello CassaIQ che impedisce tocchi accidentali.
- Il browser viene nascosto solo dopo PDF acquisito e conclusione della stampa, oppure su errore certo precedente all’invio.
- Dopo un esito fiscale incerto o un errore PDF il portale resta visibile per permettere la verifica.
- Il recupero PDF robusto e i fallback HTTP della v1.14.13 restano invariati.
