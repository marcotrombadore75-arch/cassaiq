# CassaIQ RT v1.14.97 — Test manuale rinnovo Fisconline

- Versione 1.14.97 / build iOS 128 / Android versionCode 128.
- Nuovo modulo di rinnovo Fisconline completamente separato dal motore DCO.
- Aggiunto campo opzionale "Password iniziale", conservato nello storage sicuro locale insieme alle credenziali Fisconline.
- Aggiunto pulsante "Rinnova ora (test manuale)".
- Il test apre esclusivamente la pagina ufficiale:
  https://telematici.agenziaentrate.gov.it/Abilitazione/RipristinaPassword/IRipristinaPassword.jsp
- CassaIQ invia codice fiscale, PIN, password iniziale e reimposta come nuova password la stessa password Fisconline già salvata.
- Il trasferimento dei valori alla pagina usa un canale WebCrypto RSA-OAEP temporaneo, coerente con la protezione già usata da CassaIQ.
- Il contatore dei 30 giorni viene avviato/reset SOLO quando la pagina ufficiale restituisce un esito positivo.
- In caso di errore il contatore non cambia.
- In questa build il ciclo automatico NON è ancora attivo: prima viene validato il test reale.
- Nessuna modifica al flusso di emissione DCO.
