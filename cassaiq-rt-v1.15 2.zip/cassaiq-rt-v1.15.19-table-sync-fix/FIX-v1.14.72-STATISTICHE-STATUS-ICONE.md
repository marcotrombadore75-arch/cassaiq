# CassaIQ RT v1.14.72 / build 103

Interventi inclusi:

- statistiche: timeout sulle richieste Supabase e sul rinnovo sessione, cosi' lo stato non puo' restare indefinitamente su "sincronizzazione in corso";
- statistiche: merge finale per ID con rilettura del localStorage, per non perdere vendite create mentre una sincronizzazione e' gia' in corso;
- statistiche: nuova sincronizzazione accodata dopo una vendita fiscale riuscita;
- avvio: sincronizzazione statistiche eseguita subito dopo il refresh sessione, prima degli altri dati cloud;
- Impostazioni > Documento Commerciale Online: verde trasparente solo quando la WebView DCO presente risponde come sessione autenticata e valida, rosso trasparente negli altri casi; verifica passiva ogni 60 secondi, al ritorno in primo piano e al ritorno della rete;
- il controllo visivo DCO non naviga, non effettua login, non chiude la WebView e non modifica timer 350/1100 ms o logica di emissione;
- Impostazioni > Operazioni di emergenza: verde trasparente se non esistono operazioni da gestire, rosso trasparente se esistono operazioni da regolarizzare/verificare/in invio;
- icona iOS sostituita con la versione CassaIQ RT azzurra fornita dall'utente, rigenerata per tutte le dimensioni AppIcon;
- Marketing version 1.14.72, iOS build 103, Android versionCode 103.

Motore DCO v1.14.68, Android Active WebView, timer di emissione, isolamento operazioni, Epson e protezioni anti-doppia emissione non modificati.
