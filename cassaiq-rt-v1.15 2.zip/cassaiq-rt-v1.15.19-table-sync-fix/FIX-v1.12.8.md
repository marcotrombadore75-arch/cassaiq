# CassaIQ RT v1.12.8

- Rimossi dalla schermata Cassa il titolo “Categorie” e il pulsante rapido “+”; i filtri categoria restano disponibili.
- Aggiunta pagina completa “FAQ e assistenza” con ricerca, filtri per argomento, apertura/chiusura rapida e contatto email.
- FAQ dedicate a configurazione, Epson/rete, vendite fiscali, prodotti/reparti, cloud/statistiche, account e abbonamento.
- Mantenuto il supporto iPhone + iPad anche dopo `npm run ios:sync`.
- Versione 1.12.8, build/versionCode 19.
- Integrato il fix del vincolo `sales_payment_method_valid` nello script di riparazione statistiche.
- Nessuna modifica ai comandi fiscali Epson.
