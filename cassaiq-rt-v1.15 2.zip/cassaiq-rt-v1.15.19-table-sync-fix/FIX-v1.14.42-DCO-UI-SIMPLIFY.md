# CassaIQ RT v1.14.42 — semplificazione configurazione DCO

- Rimosso il pulsante visibile **Salva e usa DCO**.
- Rimosso il pulsante visibile **Riprova recupero PDF**; la logica PDF interna resta disponibile.
- Mantenuto **Ristampa ultimo documento**.
- SPID/CIE/CNS nascosto dalla UI con `DCO_SPID_UI_ENABLED=false`; tutta la logica resta nel progetto e può essere riattivata impostando il flag a `true`.
- Testi tecnici Keychain/Keystore sostituiti da una informativa semplice sul salvataggio sicuro locale.
- Salvataggio credenziali Fisconline imposta automaticamente il DCO come modalità fiscale.
- Flusso IAM → utenza → DCO, riconnessione automatica, anti-doppia-emissione e stampa MUNBYN non modificati.
