# CassaIQ RT v1.14.85 / build 116

- Rete locale: rimossa la dicitura piattaforma-specifica “ANDROID”; il pannello ora mostra solo **RETE LOCALE**.
- Server LAN iOS/iPadOS: watchdog sullo stato reale `running`, riavvio automatico se il listener cade e riavvio forzato al ritorno in primo piano dopo background/blocco schermo.
- Avvio LAN reso idempotente: aprire/aggiornare Gestione CassaIQ Client non spegne più un listener già sano, evitando finestre temporanee `ECONNREFUSED`.
- Ripristinate le funzioni mancanti `startTableOrderDraft()` e `saveTableOrderFromCart()` usate dai pulsanti **Nuovo ordine**, **+ Aggiungi** e **+ Aggiungi ordine**.
- Gli ordini creati dalla cassa vengono prima salvati localmente, marcano il tavolo occupato, tentano la stampa cucina una sola volta e poi sincronizzano Supabase quando disponibile.
- Nessuna modifica al motore fiscale Epson/DCO.
