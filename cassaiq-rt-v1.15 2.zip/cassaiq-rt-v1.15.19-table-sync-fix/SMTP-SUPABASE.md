# Configurazione SMTP Supabase per CassaIQ

La build include conferma account e recupero password, ma l'invio reale delle email dipende da Supabase. Il servizio interno è adatto soltanto ai test e ha limiti molto bassi. Per la pubblicazione configura un provider SMTP.

## Dati consigliati nel pannello Supabase

Percorso: **Authentication → Emails → SMTP Settings**

- Sender email: `no-reply@menoova.it`
- Sender name: `CassaIQ`
- Host: fornito dal provider SMTP
- Port: `587` con STARTTLS, oppure `465` con TLS, secondo il provider
- Minimum interval per user: `60` secondi
- Username: fornito dal provider
- Password: fornita dal provider

Non inserire la password SMTP nello ZIP o nel codice dell'app. Deve rimanere soltanto nel pannello Supabase.

## URL già previste nell'app

- Conferma email: `https://menoova.it/cassaiq-conferma.html`
- Reset password: `https://menoova.it/cassaiq-reset-password.html`

Carica i due file HTML presenti nella radice di questo progetto sul dominio `menoova.it`, mantenendo esattamente questi nomi.

In **Authentication → URL Configuration** lascia:

- Site URL: `https://menoova.it`
- Redirect URL: `https://menoova.it/cassaiq-conferma.html`
- Redirect URL: `https://menoova.it/cassaiq-reset-password.html`

## Template email

Nel template **Confirm signup**, il pulsante deve usare:

```html
<a href="{{ .ConfirmationURL }}">Conferma email</a>
```

Nel template **Reset password**, il pulsante deve usare:

```html
<a href="{{ .ConfirmationURL }}">Reimposta password</a>
```

## Test finale

1. Registra un nuovo account.
2. Controlla che il link apra `cassaiq-conferma.html`.
3. Dalla schermata login premi **Password dimenticata?**.
4. Controlla che il link apra `cassaiq-reset-password.html`.
5. Imposta la nuova password e accedi dall'app.
