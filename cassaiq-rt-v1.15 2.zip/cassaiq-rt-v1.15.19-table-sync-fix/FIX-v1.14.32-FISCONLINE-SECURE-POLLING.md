# CassaIQ RT v1.14.32 — Fisconline secure polling

- Rimosso postMessage dal solo handshake Fisconline, perché su iOS il callback non arrivava in modo affidabile.
- RSA-OAEP resta invariato: le credenziali non sono mai concatenate negli script in chiaro.
- La WebView salva il risultato asincrono in uno slot temporaneo; CassaIQ lo legge con executeScript sincrono e polling breve.
- Compilazione credenziali e submit sono separati, così la navigazione non può cancellare il risultato prima che l'app lo legga.
- Nessuna modifica al flusso emissione DCO, anti-doppia-emissione, stampa MUNBYN o SPID fallback.
