# CassaIQ RT 1.13.1

- Aggiunta sezione sperimentale Documento Commerciale Online.
- Accesso manuale Fisconline o SPID/CIE/CNS tramite InAppBrowser.
- Sessione mantenuta solo sul dispositivo.
- Diagnostica strutturale con valori dei campi esclusi.
- Emissione, annullo e reso disabilitati.
- Nessuna modifica al driver Epson FP-Mate o alla stampante ESC/POS.
- Versione 1.13.1, build/versionCode 22.
