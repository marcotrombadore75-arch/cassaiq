# CassaIQ RT v1.15.18 / build 149

## Modifica

Rimosso il nome commerciale MUNBYN da tutte le schermate e dai messaggi utente del flusso DCO.

La stampante DCO viene ora indicata in modo generico come **stampante di rete** / **stampante di rete ESC/POS**. Nei punti compatti dell’interfaccia viene usato **Rete**.

## Compatibilità

Non è stata modificata la logica di stampa, il protocollo ESC/POS, l’indirizzo IP, la porta, il flusso DCO, l’annullamento o il blocco touch della v1.15.17. La modifica è volutamente solo terminologica lato utente.
