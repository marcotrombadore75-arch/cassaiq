# CassaIQ RT v1.14.47

- Tavoli occupati: nuovo comando **Apri ordine** e apertura anche toccando la card del tavolo.
- Lettura delle comande aperte (`sent` / `accepted`) e delle relative righe da Supabase.
- Visualizzazione quantità, prezzo, totale, note e numero di comande del tavolo.
- **Porta in cassa** trasferisce la comanda nel carrello CassaIQ mantenendo i prezzi ricevuti e usando il reparto fiscale del prodotto.
- Il carrello mostra il tavolo di provenienza.
- Dopo emissione fiscale riuscita, le comande caricate vengono chiuse e il tavolo torna libero se non sono arrivate altre comande nel frattempo.
- Nessuna modifica alla sequenza di login/routing Fisconline e alla generazione/stampa DCO, salvo l'aggiornamento asincrono dello stato del tavolo dopo emissione già conclusa.
- Versione 1.14.47 · iOS build 77 · Android versionCode 77.
