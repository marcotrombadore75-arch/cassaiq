# CassaIQ RT 1.14.8 — collegamento SPID fino al DCO

Versione: **1.14.8**  
Build iOS: **38**  
Android versionCode: **38**

## Problema rilevato dalla diagnostica

Dopo lo SPID il portale arrivava correttamente a `InstradamentofcWeb/home`, ma CassaIQ non apriva il collegamento ufficiale presente nella pagina. I tentativi generici potevano selezionare elementi non pertinenti o fermarsi senza cambiare pagina.

## Correzioni

- riconoscimento prioritario dell’URL ufficiale `/ser/documenticommercialionline/`;
- esclusione dei pulsanti della barra diagnostica CassaIQ dalla ricerca;
- attesa del passaggio automatico dalla home generale alla pagina “Fatture e corrispettivi”;
- clic sul vero collegamento **Documento Commerciale on line**;
- fallback sullo stesso `href` letto dal collegamento ufficiale se il click WebKit non produce navigazione;
- nessun nuovo tentativo SPID quando la sessione autenticata è già valida;
- firma Debug automatica per l’installazione diretta da Xcode conservata.

Epson, emissione DCO, recupero PDF e stampa MUNBYN restano invariati.
