# CassaIQ RT v1.14.98 — Rinnovo automatico Fisconline

- Versione 1.14.98 / build iOS 129 / Android versionCode 129.
- Attivato il ciclo automatico ogni 30 giorni dall'ultimo rinnovo riuscito.
- Massimo un tentativo automatico al giorno quando il rinnovo è scaduto.
- Il contatore torna a 30 giorni solo dopo l'esito positivo verificato della pagina ufficiale Agenzia Entrate.
- In caso di fallimento il contatore non si resetta e CassaIQ comunica che riproverà il giorno successivo.
- Il rinnovo usa la stessa password Fisconline già salvata e richiede la password iniziale.
- Il modulo rinnovo è separato dal DCO: non disconnette, non ricollega e non modifica la sessione DCO.
- Dopo esito positivo viene chiusa solo la finestra di rinnovo.
- Rafforzato il riconoscimento dell'esito reale: “Ripristino password effettuato con successo.”
- Se il DCO risulta già collegato, il pulsante di collegamento viene disabilitato e mostra “DCO già collegato”, evitando ricollegamenti inutili.
- Resta disponibile il pulsante manuale “Rinnova ora”.
