-- CassaIQ RT v1.5
-- Salva nel prodotto l'immagine scelta dalla libreria interna.

ALTER TABLE public.products
ADD COLUMN IF NOT EXISTS image_library_id TEXT;

COMMENT ON COLUMN public.products.image_library_id IS
'Identificativo della figura generica inclusa nella libreria CassaIQ';
