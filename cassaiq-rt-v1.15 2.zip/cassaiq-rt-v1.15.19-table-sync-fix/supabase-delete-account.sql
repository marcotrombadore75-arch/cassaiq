-- CassaIQ RT - eliminazione account self-service (richiesta da Apple)
-- Crea una funzione che l'utente autenticato può chiamare per eliminare
-- il PROPRIO account. Elimina prima i dati collegati, poi la riga in
-- auth.users (le tabelle con ON DELETE CASCADE si puliscono da sole).
-- SECURITY DEFINER: la funzione gira con privilegi elevati, ma agisce
-- SOLO sull'utente che la chiama (auth.uid()), quindi è sicura.

create or replace function public.delete_own_account()
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  uid uuid := auth.uid();
begin
  if uid is null then
    raise exception 'Non autenticato';
  end if;

  delete from public.sale_items  where user_id = uid;
  delete from public.sales       where user_id = uid;
  delete from public.products    where user_id = uid;
  delete from public.categories  where user_id = uid;
  delete from public.departments where user_id = uid;

  delete from auth.users where id = uid;
end;
$$;

-- Consenti agli utenti autenticati di eseguire la funzione
revoke all on function public.delete_own_account() from public;
grant execute on function public.delete_own_account() to authenticated;
