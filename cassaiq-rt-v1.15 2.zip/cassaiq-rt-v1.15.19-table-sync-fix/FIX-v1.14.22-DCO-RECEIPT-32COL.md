# CassaIQ RT v1.14.22

## Obiettivo

Allineare la copia di cortesia DCO alla larghezza fisica effettiva della MUNBYN usata nei test.

## Modifiche

- `RECEIPT_WIDTH = 32` come costante unica.
- `printerAscii` conserva il carattere LF, evitando che le righe vengano trasformate in una sola riga continua.
- `printerLine` preserva sempre il valore allineato a destra.
- Articoli in formato `qX descrizione` con prezzo totale riga a destra.
- Aliquota IVA indentata sotto ogni articolo.
- Nomi lunghi mandati a capo per parola intera.
- Riepilogo: imponibile, IVA, totale complessivo, pagamento e resto.
- Intestazione e piede ordinati; numero DCO e data/ora centrati.

## Non modificato

- emissione DCO;
- aggancio della stampa immediata;
- guardia anti-doppia-stampa;
- flag stampa automatica;
- recupero PDF opzionale.

Versione 1.14.22, build/versionCode 52.
