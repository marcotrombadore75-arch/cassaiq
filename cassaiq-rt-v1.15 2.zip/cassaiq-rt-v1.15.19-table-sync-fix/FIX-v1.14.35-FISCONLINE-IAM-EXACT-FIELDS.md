# CassaIQ RT v1.14.35 — Fisconline IAM exact fields

Correzione mirata del login Fisconline:
- ingresso diretto sulla pagina IAM;
- apertura automatica della scheda `#tab-4` se i campi non sono visibili;
- uso prioritario dei campi `IDToken1`, `IDToken2`, `IDToken3`;
- focus/blur prima dell'invio;
- credenziali sempre protette dal canale cifrato già presente;
- emissione DCO e stampa MUNBYN non modificate.
