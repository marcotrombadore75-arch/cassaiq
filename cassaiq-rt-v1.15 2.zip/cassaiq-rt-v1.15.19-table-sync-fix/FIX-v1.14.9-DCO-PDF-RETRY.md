# Fix v1.14.9 — Recupero PDF DCO indipendente dal carrello

## Problema
Dopo l’emissione, il carrello viene svuotato. Il comando “Riprova recupero PDF” riattivava anche il laboratorio DCO, che riceveva una bozza non valida (`DRAFT ok:false: carrello vuoto`) e avviava interrogazioni concorrenti del browser.

## Correzione
- recupero PDF completamente separato dal runner della vendita;
- uso dell’ID DCO conservato nel blocco `pdf-pending`;
- nessuna nuova compilazione o emissione fiscale;
- arresto del live poll durante il download;
- attesa dedicata fino a 45 secondi dello stato `ready/error`;
- diagnostica HTTP, content type e URL della risposta;
- trasferimento, salvataggio e stampa MUNBYN invariati dopo il download riuscito;
- messaggi espliciti per impedire una doppia emissione.
