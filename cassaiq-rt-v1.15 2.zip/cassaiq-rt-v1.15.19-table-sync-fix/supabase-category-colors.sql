-- CassaIQ RT v1.4 - colore categorie
alter table public.categories
add column if not exists color text not null default '#4F8FD8';

update public.categories
set color = '#4F8FD8'
where color is null or trim(color) = '';
