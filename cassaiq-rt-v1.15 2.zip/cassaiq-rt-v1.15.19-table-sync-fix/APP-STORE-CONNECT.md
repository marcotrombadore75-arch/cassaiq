# CassaIQ RT — testi per App Store Connect

Testi pronti da incollare. Dove trovi `[…]` sostituisci con i tuoi dati.
Bundle ID: `it.menoova.cassaiq` · Nome: `CassaIQ RT` · Solo iPad.

---

## 1. Informazioni sull'app

**Nome (30 caratteri max)**
```
CassaIQ RT
```

**Sottotitolo (30 caratteri max)**
```
Cassa fiscale per iPad
```

**Categoria principale:** Economia (Business)
**Categoria secondaria:** Produttività (facoltativa)

---

## 2. Descrizione (App Store)

```
CassaIQ RT trasforma il tuo iPad in un registratore di cassa da banco,
pensato per bar, panifici, gastronomie e negozi.

Vendita rapida
• Catalogo prodotti a tasti grandi, organizzati per categoria e colore
• I prodotti si dispongono in automatico per riempire lo schermo, senza scorrere
• Prezzo manuale con tastierino per vendite al volo
• Prodotti a peso: al tocco si apre il tastierino per l'importo

Carrello e incasso
• Carrello chiaro con totale sempre in evidenza
• Sconto, resto, pagamento in contanti o carta
• Ordini in attesa: metti da parte una vendita con un nome e riprendila dopo

Gestione
• Prodotti, categorie e reparti fiscali configurabili
• Libreria di 160 immagini prodotto generiche, senza marchi
• Statistiche di incassi, scontrini e prodotti più venduti

Archiviazione cloud opzionale
• Con un account gratuito, catalogo e vendite si sincronizzano tra dispositivi
• La cassa funziona anche senza account, salvando i dati sul dispositivo

CassaIQ RT dialoga con un registratore telematico Epson (serie FP-81II RT)
collegato alla stessa rete locale, per l'emissione fiscale reale dei documenti
di vendita e la chiusura giornaliera.

Nota: l'emissione dei documenti fiscali richiede un registratore telematico
Epson compatibile, collegato in rete. Senza questo hardware l'app resta
utilizzabile per la gestione del catalogo, del carrello e delle statistiche.
```

**Novità di questa versione** (campo "Cosa c'è di nuovo")
```
Prima versione pubblica di CassaIQ RT.
```

---

## 3. Parole chiave (100 caratteri max, separate da virgola)

```
cassa,registratore,scontrino,fiscale,pos,vendita,negozio,bar,epson,rt,punto vendita
```

---

## 4. URL richiesti

**URL di supporto** (obbligatorio — una pagina o anche una mailto)
```
[https://tuosito.it/supporto  oppure  mailto:supporto@tuosito.it]
```

**URL marketing** (facoltativo)
```
[lascia vuoto se non ne hai uno]
```

**URL Privacy Policy** (obbligatorio)
```
[https://tuosito.it/cassaiq-privacy]
```
→ vedi il file `privacy-policy.html`: pubblicalo e incolla qui il suo indirizzo.

---

## 5. Note per la revisione (App Review Information → Notes)

Questo è il campo PIÙ importante: senza queste note il revisore non riesce a
provare l'app e la respinge. Incolla tutto il blocco:

```
L'app è un registratore di cassa per iPad destinato all'uso da banco in
attività commerciali.

HARDWARE ESTERNO
L'emissione dei documenti fiscali e la chiusura giornaliera avvengono tramite
un registratore telematico Epson FP-81II RT collegato alla stessa rete locale
(protocollo ePOS su HTTP). Il revisore non dispone di questo hardware, quindi
il pulsante "Emetti documento" e il test di connessione alla stampante non
saranno completabili: è il comportamento atteso, non un difetto.

COSA SI PUÒ PROVARE SENZA HARDWARE
Tutte le altre funzioni sono pienamente utilizzabili senza registratore:
navigazione del catalogo, aggiunta di prodotti al carrello, prezzo manuale,
prodotti a peso, sconto e resto, ordini in attesa, gestione di prodotti,
categorie e reparti, statistiche.

ACCOUNT DI PROVA (facoltativo)
La cassa funziona anche senza login. L'accesso serve solo per la
sincronizzazione cloud del catalogo e delle vendite. Credenziali demo:
   email: [demo@tuosito.it]
   password: [PASSWORD_DEMO]

PERMESSO RETE LOCALE
Al primo tentativo di collegamento alla stampante, iOS chiede l'autorizzazione
"Rete locale": è necessaria per raggiungere il registratore Epson sulla LAN.

ACQUISTI IN-APP
Nessun acquisto in-app attivo in questa versione.

DISPOSITIVI
App destinata esclusivamente a iPad (uso da banco).
```

**Contatto per la revisione**
```
Nome:    [il tuo nome]
Cognome: [il tuo cognome]
Telefono:[il tuo telefono]
Email:   [la tua email]
```

---

## 6. Privacy — questionario "App Privacy"

Compila la sezione *App Privacy* così (coerente con la privacy policy):

- **Raccogli dati?** Sì.
- **Contatti → Indirizzo email**
  - Raccolto: Sì (solo se l'utente crea un account)
  - Uso: *App Functionality* (autenticazione e sincronizzazione)
  - Collegato all'identità dell'utente: Sì
  - Usato per tracciamento: No
- **Contenuti generati dall'utente → Altri contenuti** (catalogo e vendite)
  - Uso: *App Functionality*
  - Collegato all'identità: Sì
  - Tracciamento: No
- **Non** vengono raccolti: posizione, contatti della rubrica, dati sanitari,
  finanziari personali, identificatori pubblicitari.

Nota: se un utente usa la cassa senza account, non viene raccolto alcun dato
personale (i dati restano solo sul dispositivo).

---

## 7. Checklist prima di "Invia per la revisione"

- [ ] In Xcode: Supported Destinations = solo iPad
- [ ] Numero build superiore a quello già caricato
- [ ] Icona 1024×1024 PNG senza trasparenza
- [ ] Screenshot iPad 13" (obbligatori) — 3-10 immagini orizzontali
- [ ] Privacy policy pubblicata e URL inserito
- [ ] Note per la revisione incollate + account demo creato
- [ ] Questionario App Privacy compilato
- [ ] Prezzo/disponibilità impostati (gratis o a pagamento)
```
```


## Testo abbonamento da aggiungere alla descrizione App Store

CassaIQ Pro è un abbonamento mensile con rinnovo automatico. Il pagamento viene addebitato all’account Apple alla conferma dell’acquisto. L’abbonamento si rinnova automaticamente salvo disattivazione almeno 24 ore prima della fine del periodo corrente. L’abbonamento può essere gestito o annullato dalle impostazioni dell’account Apple. La prova gratuita iniziale di CassaIQ è gestita tramite l’account dell’app e non attiva automaticamente alcun abbonamento.

Termini di utilizzo (EULA):
https://www.apple.com/legal/internet-services/itunes/dev/stdeula/

Privacy Policy:
https://menoova.it/cassaiq-privacy.html

## Note per la revisione

CassaIQ offre un mese gratuito gestito tramite l’account Supabase. Questa prova non è un’offerta introduttiva dell’App Store e non avvia automaticamente un abbonamento. Al termine del mese gratuito, l’utente può scegliere volontariamente di acquistare CassaIQ Pro Mensile tramite In-App Purchase Apple. Per visualizzare l’abbonamento: accedere o registrarsi, quindi aprire Impostazioni → Abbonamento.
