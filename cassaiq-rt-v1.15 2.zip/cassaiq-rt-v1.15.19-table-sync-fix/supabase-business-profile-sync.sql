-- CassaIQ RT v1.14.27
-- Sincronizzazione dei dati dell'attivita tra dispositivi dello stesso account.

create table if not exists public.business_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  legal_name text not null default '',
  trade_name text,
  vat_number text not null default '',
  tax_code text,
  address text not null default '',
  civic text not null default '',
  zip_code text not null default '',
  city text not null default '',
  province text not null default '',
  phone text,
  email text,
  receipt_logo_data text,
  receipt_logo_enabled boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint business_profiles_vat_check check (vat_number = '' or vat_number ~ '^[0-9]{11}$'),
  constraint business_profiles_zip_check check (zip_code = '' or zip_code ~ '^[0-9]{5}$'),
  constraint business_profiles_province_check check (province = '' or province ~ '^[A-Z]{2}$'),
  constraint business_profiles_receipt_logo_size_check check (receipt_logo_data is null or length(receipt_logo_data) <= 500000)
);

alter table public.business_profiles enable row level security;

drop policy if exists "business_profiles_select_own" on public.business_profiles;
create policy "business_profiles_select_own"
on public.business_profiles for select
to authenticated
using (auth.uid() = user_id);

drop policy if exists "business_profiles_insert_own" on public.business_profiles;
create policy "business_profiles_insert_own"
on public.business_profiles for insert
to authenticated
with check (auth.uid() = user_id);

drop policy if exists "business_profiles_update_own" on public.business_profiles;
create policy "business_profiles_update_own"
on public.business_profiles for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "business_profiles_delete_own" on public.business_profiles;
create policy "business_profiles_delete_own"
on public.business_profiles for delete
to authenticated
using (auth.uid() = user_id);

grant select, insert, update, delete on public.business_profiles to authenticated;
