# CassaIQ RT v1.14.10 — PDF navigation race fix

Versione 1.14.10, build iOS 40, Android versionCode 40.

## Correzione

- annulla i clic differiti del runner DCO quando il documento risulta emesso;
- interrompe completamente timer e waiter della vendita prima del recupero PDF;
- impedisce che `Scarica e stampa file` venga cliccato mentre parte il `fetch` del PDF;
- evita richieste PDF duplicate durante `loadstart`/`loaderror`;
- riusa una richiesta già in stato `loading` invece di riavviarla;
- mantiene separati emissione fiscale e recupero del documento già emesso.

Il documento già emesso non deve essere riemesso. Usare soltanto **Riprova recupero PDF**.
