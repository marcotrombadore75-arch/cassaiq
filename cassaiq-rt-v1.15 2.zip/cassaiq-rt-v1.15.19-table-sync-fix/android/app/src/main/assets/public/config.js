window.CASSAIQ_CONFIG = Object.freeze({
  supabaseUrl: "https://fmwoycukrablixqqatmo.supabase.co",
  supabaseAnonKey: "sb_publishable_cgeNpt6V56Wc95lFZUDYSA_xFcmxTTZ",
  revenueCatAndroidApiKey: "goog_QrMegIukHsgRQEPkIcEVyUukPmR",
  revenueCatIosApiKey: "appl_MqPMpHYwOFKDAJRhvQiRjqnZbpZ",
  revenueCatEntitlement: "pro",
  termsUrlIos: "https://www.apple.com/legal/internet-services/itunes/dev/stdeula/",
  privacyUrlIos: "https://menoova.it/cassaiq-privacy.html",
  termsUrlAndroid: "https://menoova.it/cassaiq-termini-android.html",
  privacyUrlAndroid: "https://menoova.it/cassaiq-privacy-android.html",
  confirmEmailUrl: "https://menoova.it/cassaiq-conferma.html",
  resetPasswordUrl: "https://menoova.it/cassaiq-reset-password.html",
  get platform() {
    try { return window.Capacitor?.getPlatform?.() || 'web'; } catch (e) { return 'web'; }
  },
  get revenueCatApiKey() {
    return this.platform === 'ios' ? this.revenueCatIosApiKey : this.revenueCatAndroidApiKey;
  },
  get termsUrl() {
    return this.platform === 'ios' ? this.termsUrlIos : this.termsUrlAndroid;
  },
  get privacyUrl() {
    return this.platform === 'ios' ? this.privacyUrlIos : this.privacyUrlAndroid;
  }
});
