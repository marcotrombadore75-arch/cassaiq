// CassaIQ RT v1.15.19 — sync tavolo Client + stop riapertura ordine
(()=>{'use strict';
const K={fiscalMode:'cassaiq.fiscal.mode',dcoSession:'cassaiq.dco.session.v1',dcoAuthMode:'cassaiq.dco.authMode.v1',dcoFisconlinePasswordSetAt:'cassaiq.dco.fisconline.passwordSetAt.v1',dcoFisconlinePasswordReminderDay:'cassaiq.dco.fisconline.passwordReminderDay.v1',fisRenewLastSuccessAt:'cassaiq.fisrenew.lastSuccessAt.v1',fisRenewLastAttemptDay:'cassaiq.fisrenew.lastAttemptDay.v1',fisRenewLastResult:'cassaiq.fisrenew.lastResult.v1',fisRenewDcoStabilizeUntil:'cassaiq.fisrenew.dcoStabilizeUntil.v1',fisRenewFreshDcoSession:'cassaiq.fisrenew.freshDcoSession.v1',dcoAutoLock:'cassaiq.dco.autoEmissionLock.v1',dcoVoidLock:'cassaiq.dco.voidLock.v1',dcoRealLock:'cassaiq.dco.realTestLock',dcoPendingSale:'cassaiq.dco.pendingSale.v1',dcoLastDocument:'cassaiq.dco.lastDocument.v1',dcoAutoPrint:'cassaiq.dco.autoPrint',printerTestIp:'cassaiq.printer80.ip',printerTestPort:'cassaiq.printer80.port',kitchenPrinterEnabled:'cassaiq.kitchenPrinter.enabled',kitchenPrinterIp:'cassaiq.kitchenPrinter.ip',kitchenPrinterPort:'cassaiq.kitchenPrinter.port',kitchenPrinter2Enabled:'cassaiq.kitchenPrinter2.enabled',kitchenPrinter2Ip:'cassaiq.kitchenPrinter2.ip',kitchenPrinter2Port:'cassaiq.kitchenPrinter2.port',kitchenPrinter2Scope:'cassaiq.kitchenPrinter2.scope',kitchenPrinter2Routing:'cassaiq.kitchenPrinter2.routing',kitchenPrinter2CategoryIds:'cassaiq.kitchenPrinter2.categoryIds',ip:'cassaiq.epson.fp81ii.ip',closures:'cassaiq.daily.closures.v1',categories:'cassaiq.categories.v1',products:'cassaiq.products.v1',departments:'cassaiq.departments.v1',sales:'cassaiq.sales.v1',subscription:'cassaiq.subscription.v1',session:'cassaiq.supabase.session',lastSync:'cassaiq.cloud.lastSync',hold:'cassaiq.hold.orders.v1',trial:'cassaiq.trial.v1',businessProfile:'cassaiq.business.profile.v1',dcoTimingHistory:'cassaiq.dco.timingHistory.v1',emergencyOps:'cassaiq.emergency.operations.v1',emergencyActive:'cassaiq.emergency.active.v1',restaurantTablesCache:'cassaiq.restaurant.tables.cache.v1',lanOrders:'cassaiq.lan.orders.v1',clientAuthorizedIds:'cassaiq.client.authorized.ids.v1',clientLanPort:'cassaiq.client.lan.port.v1',lanOrderChanges:'cassaiq.lan.orderChanges.v1'};
const DCO_SPID_UI_ENABLED=false; // logica SPID/CIE/CNS mantenuta; riattivare la UI portando questo flag a true
const APP_CONFIG=window.CASSAIQ_CONFIG||{
  supabaseUrl:'https://fmwoycukrablixqqatmo.supabase.co',
  supabaseAnonKey:'sb_publishable_cgeNpt6V56Wc95lFZUDYSA_xFcmxTTZ'
};
const APP_VERSION='1.15.19';
const APP_BUILD='150';
const CONFIRM_EMAIL_URL=(APP_CONFIG.confirmEmailUrl||'https://menoova.it/cassaiq-conferma.html').trim();
const RESET_PASSWORD_URL=(APP_CONFIG.resetPasswordUrl||'https://menoova.it/cassaiq-reset-password.html').trim();
const defaults={categories:[],departments:[{id:'dep1',name:'Reparto 1',number:1,vat:22}],products:[],sales:[]};
const categoryColors=['#4F8FD8','#27A8A0','#44A66B','#86B843','#E1B63B','#ED8D3A','#E35D5D','#D9659E','#9B6AD6','#6D75D8','#667785','#8B6B55'];
const iconGroups={
  'Generiche':['▦','▣','★','●','◆','◼','🏷️','📦','🛍️','🧾'],
  'Bar':['☕','🥐','🍵','🥤','🧃','🍺','🍷','🍹','🧊','🍰'],
  'Panificio':['🥖','🍞','🥨','🥐','🧁','🍪','🥧','🍕','🌾','🫓'],
  'Ristorante':['🍝','🍕','🍔','🥪','🥗','🍲','🍣','🍖','🍟','🍽️'],
  'Negozio':['👕','👟','👜','🧴','🧸','📱','💡','🔧','📚','🎁'],
  'Servizi':['✂️','💇','🧹','🚗','🛠️','🖥️','📷','🧘','🏋️','🩺']
};
const productImageLibrary=[{"id":"caffe","name":"Caffè","category":"Caffetteria","file":"assets/product-library/caffe.svg","tags":["espresso","bar"]},{"id":"cappuccino","name":"Cappuccino","category":"Caffetteria","file":"assets/product-library/cappuccino.svg","tags":["latte","bar"]},{"id":"te","name":"Tè","category":"Caffetteria","file":"assets/product-library/te.svg","tags":["infuso","bar"]},{"id":"cioccolata","name":"Cioccolata calda","category":"Caffetteria","file":"assets/product-library/cioccolata.svg","tags":["cacao","bar"]},{"id":"cornetto","name":"Cornetto","category":"Panificio","file":"assets/product-library/cornetto.svg","tags":["brioche","colazione"]},{"id":"pane","name":"Pane","category":"Panificio","file":"assets/product-library/pane.svg","tags":["panificio","alimentari"]},{"id":"baguette","name":"Baguette","category":"Panificio","file":"assets/product-library/baguette.svg","tags":["pane","panificio"]},{"id":"pizza","name":"Pizza","category":"Ristorante","file":"assets/product-library/pizza.svg","tags":["pizzeria","alimentari"]},{"id":"panino","name":"Panino","category":"Ristorante","file":"assets/product-library/panino.svg","tags":["sandwich","alimentari"]},{"id":"hamburger","name":"Hamburger","category":"Ristorante","file":"assets/product-library/hamburger.svg","tags":["panino","fast food"]},{"id":"pasta","name":"Pasta","category":"Ristorante","file":"assets/product-library/pasta.svg","tags":["primo","alimentari"]},{"id":"insalata","name":"Insalata","category":"Ristorante","file":"assets/product-library/insalata.svg","tags":["verdura","piatto"]},{"id":"carne","name":"Carne","category":"Alimentari","file":"assets/product-library/carne.svg","tags":["macelleria","proteine"]},{"id":"pollo","name":"Pollo","category":"Alimentari","file":"assets/product-library/pollo.svg","tags":["carne","alimentari"]},{"id":"pesce","name":"Pesce","category":"Alimentari","file":"assets/product-library/pesce.svg","tags":["pescheria","alimentari"]},{"id":"formaggio","name":"Formaggio","category":"Alimentari","file":"assets/product-library/formaggio.svg","tags":["latticini","alimentari"]},{"id":"uova","name":"Uova","category":"Alimentari","file":"assets/product-library/uova.svg","tags":["alimentari","colazione"]},{"id":"latte","name":"Latte","category":"Bevande","file":"assets/product-library/latte.svg","tags":["latticini","bevanda"]},{"id":"acqua","name":"Acqua","category":"Bevande","file":"assets/product-library/acqua.svg","tags":["bottiglia","bevanda"]},{"id":"cola","name":"Bibita cola","category":"Bevande","file":"assets/product-library/cola.svg","tags":["lattina","bevanda"]},{"id":"aranciata","name":"Aranciata","category":"Bevande","file":"assets/product-library/aranciata.svg","tags":["bibita","bevanda"]},{"id":"succo","name":"Succo di frutta","category":"Bevande","file":"assets/product-library/succo.svg","tags":["bevanda","frutta"]},{"id":"birra","name":"Birra","category":"Bevande","file":"assets/product-library/birra.svg","tags":["alcolico","bevanda"]},{"id":"vino","name":"Vino","category":"Bevande","file":"assets/product-library/vino.svg","tags":["alcolico","bevanda"]},{"id":"torta","name":"Torta","category":"Dolci","file":"assets/product-library/torta.svg","tags":["dessert","pasticceria"]},{"id":"gelato","name":"Gelato","category":"Dolci","file":"assets/product-library/gelato.svg","tags":["dessert","freddo"]},{"id":"biscotti","name":"Biscotti","category":"Dolci","file":"assets/product-library/biscotti.svg","tags":["dolce","pasticceria"]},{"id":"cioccolato","name":"Cioccolato","category":"Dolci","file":"assets/product-library/cioccolato.svg","tags":["dolce","cacao"]},{"id":"mela","name":"Mela","category":"Frutta e verdura","file":"assets/product-library/mela.svg","tags":["frutta","alimentari"]},{"id":"banana","name":"Banana","category":"Frutta e verdura","file":"assets/product-library/banana.svg","tags":["frutta","alimentari"]},{"id":"arancia","name":"Arancia","category":"Frutta e verdura","file":"assets/product-library/arancia.svg","tags":["frutta","alimentari"]},{"id":"pomodoro","name":"Pomodoro","category":"Frutta e verdura","file":"assets/product-library/pomodoro.svg","tags":["verdura","alimentari"]},{"id":"carota","name":"Carota","category":"Frutta e verdura","file":"assets/product-library/carota.svg","tags":["verdura","alimentari"]},{"id":"patata","name":"Patata","category":"Frutta e verdura","file":"assets/product-library/patata.svg","tags":["verdura","alimentari"]},{"id":"detersivo","name":"Detersivo","category":"Casa","file":"assets/product-library/detersivo.svg","tags":["pulizia","casa"]},{"id":"sapone","name":"Sapone","category":"Casa","file":"assets/product-library/sapone.svg","tags":["igiene","casa"]},{"id":"carta","name":"Carta casa","category":"Casa","file":"assets/product-library/carta.svg","tags":["pulizia","casa"]},{"id":"scatola","name":"Prodotto confezionato","category":"Generico","file":"assets/product-library/scatola.svg","tags":["confezione","negozio"]},{"id":"abbigliamento","name":"Abbigliamento","category":"Generico","file":"assets/product-library/abbigliamento.svg","tags":["negozio","moda"]},{"id":"servizio","name":"Servizio","category":"Generico","file":"assets/product-library/servizio.svg","tags":["prestazione","servizi"]},{"id":"web-caffe-espresso","name":"Caffè espresso","category":"Caffetteria","file":"assets/web-library/caffe-espresso.svg","tags":["espresso","tazzina","bar"]},{"id":"web-cappuccino","name":"Cappuccino","category":"Caffetteria","file":"assets/web-library/cappuccino.svg","tags":["latte","schiuma"]},{"id":"web-caffe-macchiato","name":"Caffè macchiato","category":"Caffetteria","file":"assets/web-library/caffe-macchiato.svg","tags":["macchiato"]},{"id":"web-latte-caldo","name":"Latte caldo","category":"Caffetteria","file":"assets/web-library/latte-caldo.svg","tags":["latte"]},{"id":"web-te-caldo","name":"Tè caldo","category":"Caffetteria","file":"assets/web-library/te-caldo.svg","tags":["te","infuso"]},{"id":"web-cioccolata-calda","name":"Cioccolata calda","category":"Caffetteria","file":"assets/web-library/cioccolata-calda.svg","tags":["cioccolata","tazza"]},{"id":"web-orzo","name":"Orzo","category":"Caffetteria","file":"assets/web-library/orzo.svg","tags":["orzo"]},{"id":"web-ginseng","name":"Ginseng","category":"Caffetteria","file":"assets/web-library/ginseng.svg","tags":["ginseng"]},{"id":"web-granita","name":"Granita","category":"Caffetteria","file":"assets/web-library/granita.svg","tags":["granita","sicilia"]},{"id":"web-frappe","name":"Frappè","category":"Caffetteria","file":"assets/web-library/frappe.svg","tags":["frappe","latte"]},{"id":"web-acqua-naturale","name":"Acqua naturale","category":"Bevande","file":"assets/web-library/acqua-naturale.svg","tags":["acqua","bottiglia"]},{"id":"web-acqua-frizzante","name":"Acqua frizzante","category":"Bevande","file":"assets/web-library/acqua-frizzante.svg","tags":["acqua","gasata"]},{"id":"web-cola-generica","name":"Cola generica","category":"Bevande","file":"assets/web-library/cola-generica.svg","tags":["cola","bibita"]},{"id":"web-aranciata-generica","name":"Aranciata generica","category":"Bevande","file":"assets/web-library/aranciata-generica.svg","tags":["aranciata","bibita"]},{"id":"web-limonata","name":"Limonata","category":"Bevande","file":"assets/web-library/limonata.svg","tags":["limonata"]},{"id":"web-te-freddo","name":"Tè freddo","category":"Bevande","file":"assets/web-library/te-freddo.svg","tags":["te","freddo"]},{"id":"web-succo-arancia","name":"Succo arancia","category":"Bevande","file":"assets/web-library/succo-arancia.svg","tags":["succo","arancia"]},{"id":"web-succo-mela","name":"Succo mela","category":"Bevande","file":"assets/web-library/succo-mela.svg","tags":["succo","mela"]},{"id":"web-energy-drink-generico","name":"Energy drink generico","category":"Bevande","file":"assets/web-library/energy-drink-generico.svg","tags":["energy","lattina"]},{"id":"web-bibita-zero","name":"Bibita zero","category":"Bevande","file":"assets/web-library/bibita-zero.svg","tags":["zero","bibita"]},{"id":"web-pane","name":"Pane","category":"Panificio","file":"assets/web-library/pane.svg","tags":["pane","filone"]},{"id":"web-baguette","name":"Baguette","category":"Panificio","file":"assets/web-library/baguette.svg","tags":["baguette"]},{"id":"web-panino","name":"Panino","category":"Panificio","file":"assets/web-library/panino.svg","tags":["panino"]},{"id":"web-focaccia","name":"Focaccia","category":"Panificio","file":"assets/web-library/focaccia.svg","tags":["focaccia"]},{"id":"web-pizza-al-taglio","name":"Pizza al taglio","category":"Panificio","file":"assets/web-library/pizza-al-taglio.svg","tags":["pizza"]},{"id":"web-cornetto","name":"Cornetto","category":"Panificio","file":"assets/web-library/cornetto.svg","tags":["cornetto"]},{"id":"web-brioche","name":"Brioche","category":"Panificio","file":"assets/web-library/brioche.svg","tags":["brioche"]},{"id":"web-grissini","name":"Grissini","category":"Panificio","file":"assets/web-library/grissini.svg","tags":["grissini"]},{"id":"web-cracker","name":"Cracker","category":"Panificio","file":"assets/web-library/cracker.svg","tags":["cracker"]},{"id":"web-piadina","name":"Piadina","category":"Panificio","file":"assets/web-library/piadina.svg","tags":["piadina"]},{"id":"web-pasta","name":"Pasta","category":"Ristorante","file":"assets/web-library/pasta.svg","tags":["pasta","primo"]},{"id":"web-riso","name":"Riso","category":"Ristorante","file":"assets/web-library/riso.svg","tags":["riso","primo"]},{"id":"web-pizza","name":"Pizza","category":"Ristorante","file":"assets/web-library/pizza.svg","tags":["pizza"]},{"id":"web-hamburger","name":"Hamburger","category":"Ristorante","file":"assets/web-library/hamburger.svg","tags":["hamburger"]},{"id":"web-patatine","name":"Patatine","category":"Ristorante","file":"assets/web-library/patatine.svg","tags":["patatine"]},{"id":"web-pollo","name":"Pollo","category":"Ristorante","file":"assets/web-library/pollo.svg","tags":["pollo"]},{"id":"web-carne","name":"Carne","category":"Ristorante","file":"assets/web-library/carne.svg","tags":["carne","bistecca"]},{"id":"web-pesce","name":"Pesce","category":"Ristorante","file":"assets/web-library/pesce.svg","tags":["pesce"]},{"id":"web-insalata","name":"Insalata","category":"Ristorante","file":"assets/web-library/insalata.svg","tags":["insalata"]},{"id":"web-zuppa","name":"Zuppa","category":"Ristorante","file":"assets/web-library/zuppa.svg","tags":["zuppa"]},{"id":"web-torta","name":"Torta","category":"Dolci","file":"assets/web-library/torta.svg","tags":["torta"]},{"id":"web-gelato","name":"Gelato","category":"Dolci","file":"assets/web-library/gelato.svg","tags":["gelato"]},{"id":"web-biscotti","name":"Biscotti","category":"Dolci","file":"assets/web-library/biscotti.svg","tags":["biscotti"]},{"id":"web-cioccolato","name":"Cioccolato","category":"Dolci","file":"assets/web-library/cioccolato.svg","tags":["cioccolato"]},{"id":"web-cannolo","name":"Cannolo","category":"Dolci","file":"assets/web-library/cannolo.svg","tags":["cannolo","dolce"]},{"id":"web-tiramisu","name":"Tiramisù","category":"Dolci","file":"assets/web-library/tiramisu.svg","tags":["tiramisu"]},{"id":"web-muffin","name":"Muffin","category":"Dolci","file":"assets/web-library/muffin.svg","tags":["muffin"]},{"id":"web-donut","name":"Donut","category":"Dolci","file":"assets/web-library/donut.svg","tags":["ciambella"]},{"id":"web-caramelle","name":"Caramelle","category":"Dolci","file":"assets/web-library/caramelle.svg","tags":["caramelle"]},{"id":"web-dessert","name":"Dessert","category":"Dolci","file":"assets/web-library/dessert.svg","tags":["dessert"]},{"id":"web-pasta-confezionata","name":"Pasta confezionata","category":"Alimentari","file":"assets/web-library/pasta-confezionata.svg","tags":["pasta","pacco"]},{"id":"web-riso-confezionato","name":"Riso confezionato","category":"Alimentari","file":"assets/web-library/riso-confezionato.svg","tags":["riso","pacco"]},{"id":"web-farina","name":"Farina","category":"Alimentari","file":"assets/web-library/farina.svg","tags":["farina"]},{"id":"web-zucchero","name":"Zucchero","category":"Alimentari","file":"assets/web-library/zucchero.svg","tags":["zucchero"]},{"id":"web-sale","name":"Sale","category":"Alimentari","file":"assets/web-library/sale.svg","tags":["sale"]},{"id":"web-olio","name":"Olio","category":"Alimentari","file":"assets/web-library/olio.svg","tags":["olio","bottiglia"]},{"id":"web-salsa-pomodoro","name":"Salsa pomodoro","category":"Alimentari","file":"assets/web-library/salsa-pomodoro.svg","tags":["salsa"]},{"id":"web-tonno","name":"Tonno","category":"Alimentari","file":"assets/web-library/tonno.svg","tags":["tonno","scatola"]},{"id":"web-legumi","name":"Legumi","category":"Alimentari","file":"assets/web-library/legumi.svg","tags":["legumi"]},{"id":"web-uova","name":"Uova","category":"Alimentari","file":"assets/web-library/uova.svg","tags":["uova"]},{"id":"web-mela","name":"Mela","category":"Frutta e verdura","file":"assets/web-library/mela.svg","tags":["mela"]},{"id":"web-banana","name":"Banana","category":"Frutta e verdura","file":"assets/web-library/banana.svg","tags":["banana"]},{"id":"web-arancia","name":"Arancia","category":"Frutta e verdura","file":"assets/web-library/arancia.svg","tags":["arancia"]},{"id":"web-limone","name":"Limone","category":"Frutta e verdura","file":"assets/web-library/limone.svg","tags":["limone"]},{"id":"web-pera","name":"Pera","category":"Frutta e verdura","file":"assets/web-library/pera.svg","tags":["pera"]},{"id":"web-uva","name":"Uva","category":"Frutta e verdura","file":"assets/web-library/uva.svg","tags":["uva"]},{"id":"web-fragola","name":"Fragola","category":"Frutta e verdura","file":"assets/web-library/fragola.svg","tags":["fragola"]},{"id":"web-pomodoro","name":"Pomodoro","category":"Frutta e verdura","file":"assets/web-library/pomodoro.svg","tags":["pomodoro"]},{"id":"web-carota","name":"Carota","category":"Frutta e verdura","file":"assets/web-library/carota.svg","tags":["carota"]},{"id":"web-patata","name":"Patata","category":"Frutta e verdura","file":"assets/web-library/patata.svg","tags":["patata"]},{"id":"web-latte","name":"Latte","category":"Latticini","file":"assets/web-library/latte.svg","tags":["latte"]},{"id":"web-formaggio","name":"Formaggio","category":"Latticini","file":"assets/web-library/formaggio.svg","tags":["formaggio"]},{"id":"web-yogurt","name":"Yogurt","category":"Latticini","file":"assets/web-library/yogurt.svg","tags":["yogurt"]},{"id":"web-burro","name":"Burro","category":"Latticini","file":"assets/web-library/burro.svg","tags":["burro"]},{"id":"web-mozzarella","name":"Mozzarella","category":"Latticini","file":"assets/web-library/mozzarella.svg","tags":["mozzarella"]},{"id":"web-ricotta","name":"Ricotta","category":"Latticini","file":"assets/web-library/ricotta.svg","tags":["ricotta"]},{"id":"web-panna","name":"Panna","category":"Latticini","file":"assets/web-library/panna.svg","tags":["panna"]},{"id":"web-gelato-vaschetta","name":"Gelato vaschetta","category":"Latticini","file":"assets/web-library/gelato-vaschetta.svg","tags":["gelato"]},{"id":"web-dessert-latte","name":"Dessert latte","category":"Latticini","file":"assets/web-library/dessert-latte.svg","tags":["dessert"]},{"id":"web-bevanda-vegetale","name":"Bevanda vegetale","category":"Latticini","file":"assets/web-library/bevanda-vegetale.svg","tags":["vegetale"]},{"id":"web-prosciutto","name":"Prosciutto","category":"Salumi e carne","file":"assets/web-library/prosciutto.svg","tags":["prosciutto"]},{"id":"web-salame","name":"Salame","category":"Salumi e carne","file":"assets/web-library/salame.svg","tags":["salame"]},{"id":"web-mortadella","name":"Mortadella","category":"Salumi e carne","file":"assets/web-library/mortadella.svg","tags":["mortadella"]},{"id":"web-bresaola","name":"Bresaola","category":"Salumi e carne","file":"assets/web-library/bresaola.svg","tags":["bresaola"]},{"id":"web-salsiccia","name":"Salsiccia","category":"Salumi e carne","file":"assets/web-library/salsiccia.svg","tags":["salsiccia"]},{"id":"web-pollo-intero","name":"Pollo intero","category":"Salumi e carne","file":"assets/web-library/pollo-intero.svg","tags":["pollo"]},{"id":"web-bistecca","name":"Bistecca","category":"Salumi e carne","file":"assets/web-library/bistecca.svg","tags":["bistecca"]},{"id":"web-macinato","name":"Macinato","category":"Salumi e carne","file":"assets/web-library/macinato.svg","tags":["macinato"]},{"id":"web-hamburger-carne","name":"Hamburger carne","category":"Salumi e carne","file":"assets/web-library/hamburger-carne.svg","tags":["hamburger"]},{"id":"web-arrosto","name":"Arrosto","category":"Salumi e carne","file":"assets/web-library/arrosto.svg","tags":["arrosto"]},{"id":"web-detersivo-piatti","name":"Detersivo piatti","category":"Casa e pulizia","file":"assets/web-library/detersivo-piatti.svg","tags":["detersivo","piatti"]},{"id":"web-detersivo-bucato","name":"Detersivo bucato","category":"Casa e pulizia","file":"assets/web-library/detersivo-bucato.svg","tags":["bucato"]},{"id":"web-ammorbidente","name":"Ammorbidente","category":"Casa e pulizia","file":"assets/web-library/ammorbidente.svg","tags":["ammorbidente"]},{"id":"web-sapone-mani","name":"Sapone mani","category":"Casa e pulizia","file":"assets/web-library/sapone-mani.svg","tags":["sapone"]},{"id":"web-carta-cucina","name":"Carta cucina","category":"Casa e pulizia","file":"assets/web-library/carta-cucina.svg","tags":["carta","cucina"]},{"id":"web-carta-igienica","name":"Carta igienica","category":"Casa e pulizia","file":"assets/web-library/carta-igienica.svg","tags":["carta","igienica"]},{"id":"web-spugna","name":"Spugna","category":"Casa e pulizia","file":"assets/web-library/spugna.svg","tags":["spugna"]},{"id":"web-sacchi-rifiuti","name":"Sacchi rifiuti","category":"Casa e pulizia","file":"assets/web-library/sacchi-rifiuti.svg","tags":["sacchi"]},{"id":"web-spray-superfici","name":"Spray superfici","category":"Casa e pulizia","file":"assets/web-library/spray-superfici.svg","tags":["spray"]},{"id":"web-guanti-pulizia","name":"Guanti pulizia","category":"Casa e pulizia","file":"assets/web-library/guanti-pulizia.svg","tags":["guanti"]},{"id":"web-maglietta","name":"Maglietta","category":"Abbigliamento","file":"assets/web-library/maglietta.svg","tags":["maglietta"]},{"id":"web-camicia","name":"Camicia","category":"Abbigliamento","file":"assets/web-library/camicia.svg","tags":["camicia"]},{"id":"web-pantaloni","name":"Pantaloni","category":"Abbigliamento","file":"assets/web-library/pantaloni.svg","tags":["pantaloni"]},{"id":"web-vestito","name":"Vestito","category":"Abbigliamento","file":"assets/web-library/vestito.svg","tags":["vestito"]},{"id":"web-giacca","name":"Giacca","category":"Abbigliamento","file":"assets/web-library/giacca.svg","tags":["giacca"]},{"id":"web-scarpe","name":"Scarpe","category":"Abbigliamento","file":"assets/web-library/scarpe.svg","tags":["scarpe"]},{"id":"web-cappello","name":"Cappello","category":"Abbigliamento","file":"assets/web-library/cappello.svg","tags":["cappello"]},{"id":"web-borsa","name":"Borsa","category":"Abbigliamento","file":"assets/web-library/borsa.svg","tags":["borsa"]},{"id":"web-calze","name":"Calze","category":"Abbigliamento","file":"assets/web-library/calze.svg","tags":["calze"]},{"id":"web-accessori","name":"Accessori","category":"Abbigliamento","file":"assets/web-library/accessori.svg","tags":["accessori"]},{"id":"web-consegna","name":"Consegna","category":"Servizi","file":"assets/web-library/consegna.svg","tags":["consegna"]},{"id":"web-asporto","name":"Asporto","category":"Servizi","file":"assets/web-library/asporto.svg","tags":["asporto"]},{"id":"web-coperto","name":"Coperto","category":"Servizi","file":"assets/web-library/coperto.svg","tags":["coperto"]},{"id":"web-riparazione","name":"Riparazione","category":"Servizi","file":"assets/web-library/riparazione.svg","tags":["riparazione"]},{"id":"web-lavaggio","name":"Lavaggio","category":"Servizi","file":"assets/web-library/lavaggio.svg","tags":["lavaggio"]},{"id":"web-consulenza","name":"Consulenza","category":"Servizi","file":"assets/web-library/consulenza.svg","tags":["consulenza"]},{"id":"web-noleggio","name":"Noleggio","category":"Servizi","file":"assets/web-library/noleggio.svg","tags":["noleggio"]},{"id":"web-ingresso","name":"Ingresso","category":"Servizi","file":"assets/web-library/ingresso.svg","tags":["ingresso"]},{"id":"web-ricarica","name":"Ricarica","category":"Servizi","file":"assets/web-library/ricarica.svg","tags":["ricarica"]},{"id":"web-servizio-generico","name":"Servizio generico","category":"Servizi","file":"assets/web-library/servizio-generico.svg","tags":["servizio"]}];

// La libreria storica resta completa per non rompere prodotti già salvati con vecchi ID.
// Nel selettore mostriamo una sola voce per nome, preferendo la versione web più recente.
const productImageLibraryVisible=(()=>{
  const byName=new Map();
  productImageLibrary.forEach(item=>{
    const key=String(item.name||'').trim().toLocaleLowerCase('it-IT');
    const current=byName.get(key);
    if(!current||String(item.id||'').startsWith('web-'))byName.set(key,item);
  });
  return [...byName.values()];
})();
function libraryImageById(id){return productImageLibrary.find(x=>x.id===id)}
function libraryImageSrc(id){return libraryImageById(id)?.file||''}
function productImageSrc(product){return product?.imageLibraryId?libraryImageSrc(product.imageLibraryId):(product?.image||'')}
let categories=load(K.categories,defaults.categories),departments=load(K.departments,defaults.departments),products=load(K.products,defaults.products),sales=load(K.sales,defaults.sales);
let emergencyOperations=load(K.emergencyOps,[]),dcoEmergencyActiveId=localStorage.getItem(K.emergencyActive)||'';
// Migrazione sicura: elimina la vecchia categoria automatica 'Generale' solo se è rimasta vuota e inutilizzata.
if(categories.length===1&&categories[0]?.id==='general'&&!products.some(p=>p.categoryId==='general')){categories=[];save(K.categories,categories)}
let cart={},cartItemNotes={},cartSupplements={},category='all',payment='',lotteryCode='',isIssuing=false,cashReceived=0,changeDue=0,discountAmount=0;
let activeTableCheckout=null;
let tableOrderDraft=null,tableOrderDraftSaving=false;
let dcoRealTestEnabled=localStorage.getItem(K.dcoRealLock)==='1';
let manualItems=[];
let cloudPriceOptionsMissing=false;
let trialState=loadObjectSafe(K.trial,{loaded:false,valid:false,endsAt:null,startedAt:null});
function loadObjectSafe(k,f){try{return JSON.parse(localStorage.getItem(k)||'null')||f}catch{return f}}
function renderSchemaWarning(){const el=$('schemaWarning');if(el)el.hidden=!cloudPriceOptionsMissing}
const CART_LINE_SEP='::';
function cartLineBaseId(id){const raw=String(id||'');const pos=raw.indexOf(CART_LINE_SEP);return pos>0?raw.slice(0,pos):raw}
function findCartProduct(id){const raw=String(id||'');return manualItems.find(x=>String(x.id)===raw)||products.find(x=>String(x.id)===raw)||products.find(x=>String(x.id)===cartLineBaseId(raw))||null}
function cartLineKeyForProduct(productId,preferBase=true){const base=String(productId||'');if(preferBase&&!cart[base])return base;let key='';do{key=`${base}${CART_LINE_SEP}${uid()}`}while(cart[key]);return key}
function cartLineSourceId(lineId){const p=findCartProduct(lineId);return String(p?.sourceProductId||cartLineBaseId(lineId)||p?.id||'')}
function cartLinePersonalized(lineId){return !!String(cartItemNotes[lineId]||'').trim()||lineSupplements(lineId).length>0}
function mergeableNormalCartLine(productId){const base=String(productId||'');return Object.keys(cart).find(lineId=>cart[lineId]>0&&cartLineSourceId(lineId)===base&&!cartLinePersonalized(lineId))||''}
function addCatalogProductToCart(product){const lineId=mergeableNormalCartLine(product.id)||cartLineKeyForProduct(product.id,true),isNew=!cart[lineId];cart[lineId]=(cart[lineId]||0)+1;renderCart(isNew)}
function splitCartLineForSingleModifier(lineId){const qty=Number(cart[lineId]||0);if(qty<=1)return lineId;const p=findCartProduct(lineId);if(!p)return lineId;cart[lineId]=qty-1;let newLineId;if(manualItems.some(x=>String(x.id)===String(p.id))){const clone={...p,id:uid()};manualItems.push(clone);newLineId=clone.id}else newLineId=cartLineKeyForProduct(cartLineSourceId(lineId),false);cart[newLineId]=1;if(cartItemNotes[lineId])cartItemNotes[newLineId]=cartItemNotes[lineId];const extras=lineSupplements(lineId);if(extras.length)cartSupplements[newLineId]=extras.map(x=>({...x}));return newLineId}
function cartLineSignature(lineId){const p=findCartProduct(lineId);if(!p)return'';const extras=lineSupplements(lineId).map(x=>`${x.id}:${supplementKind(x)}:${roundMoney(x.price)}`).sort().join(',');return`${p.sourceProductId||cartLineBaseId(lineId)||p.id}|${roundMoney(p.price)}|${String(cartItemNotes[lineId]||'').trim()}|${extras}`}
function mergeEquivalentCartLines(){const seen=new Map();for(const lineId of Object.keys(cart)){if(!(cart[lineId]>0))continue;const sig=cartLineSignature(lineId);if(!sig)continue;if(!seen.has(sig)){seen.set(sig,lineId);continue}const target=seen.get(sig);cart[target]=(cart[target]||0)+(cart[lineId]||0);delete cart[lineId];delete cartItemNotes[lineId];delete cartSupplements[lineId]}manualItems=manualItems.filter(p=>cart[p.id]>0||!p.manual)}
const $=id=>document.getElementById(id),euro=n=>new Intl.NumberFormat('it-IT',{style:'currency',currency:'EUR'}).format(Number(n)||0),money=n=>Number(n).toFixed(2),uid=()=>crypto.randomUUID();
function load(k,f){try{const v=JSON.parse(localStorage.getItem(k));return Array.isArray(v)?v:f}catch{return f}}
function save(k,v){localStorage.setItem(k,JSON.stringify(v))}
function xmlEscape(s){return String(s).replace(/[<>&"']/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&apos;'}[c]))}
function escapeHtml(s){return String(s==null?'':s).replace(/[&<>\"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]))}
function toast(t,d=2600){const e=$('toast');e.textContent=t;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),d)}
function showView(name){document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));const target=$(`view-${name}`);if(!target)return;target.classList.add('active');document.querySelectorAll('.nav-trigger').forEach(b=>b.classList.toggle('active',b.dataset.view===name));if(name==='categorie')renderCategoryManager();if(name==='prodotti')renderProductManager();if(name==='reparti')renderDepartmentManager();if(name==='statistiche'){renderStats();setTimeout(()=>syncSalesFromCloud(false),0)}if(name==='tavoli')initTablesView();if(name==='stampante80')initPrinterTestView();if(name==='dcolab'){initDcoLabView();renderDcoDraftSummary();}if(name==='stampanti'){initDcoLabView();renderConfigFiscalMode();}if(name==='client')initClientPairingPanel();if(name==='emergenze')initEmergencyView();requestAnimationFrame(()=>{target.scrollTop=0;const main=document.querySelector('main');if(main)main.scrollTop=0;window.scrollTo(0,0)})}
document.querySelectorAll('.nav-trigger,[data-view]').forEach(b=>b.addEventListener('click',()=>b.dataset.view&&showView(b.dataset.view)));
$('desktopSettings').onclick=()=>showView('impostazioni');if($('homeTables'))$('homeTables').onclick=()=>showView('tavoli');$('settingsUser').onclick=openUserDialog;$('settingsSubscription').onclick=openSubscriptionDialog;document.querySelectorAll('.management-view').forEach(section=>{const btn=document.createElement('button');btn.type='button';btn.className='back-button';btn.innerHTML='← Indietro';btn.onclick=()=>showView(section.id==='view-impostazioni'?'cassa':'impostazioni');section.insertBefore(btn,section.firstChild)});
if($('appInstalledVersion'))$('appInstalledVersion').textContent=APP_VERSION;if($('appInstalledBuild'))$('appInstalledBuild').textContent=APP_BUILD;

// ---------------------------------------------------------------------------
// OPERAZIONI DI EMERGENZA DA REGOLARIZZARE
// Non sono documenti DCO emessi: CassaIQ conserva la vendita e consente
// esclusivamente l'invio manuale, una operazione alla volta, quando la rete
// e il portale tornano disponibili.
// ---------------------------------------------------------------------------
let emergencyReconnectOnly=false;
function emergencyInternetOnline(){return navigator.onLine!==false}
function emergencyFind(id){return emergencyOperations.find(x=>String(x?.id||'')===String(id||''))||null}
function emergencySaveOperations(){save(K.emergencyOps,emergencyOperations);emergencyRenderSettingsSummary();if($('view-emergenze')?.classList.contains('active'))renderEmergencyOperations()}
function emergencyStatusInfo(status){
  if(status==='regolarizzata')return{label:'REGOLARIZZATA',cls:'regularized'};
  if(status==='esito_da_verificare')return{label:'ESITO DA VERIFICARE',cls:'uncertain'};
  if(status==='in_invio')return{label:'INVIO IN CORSO',cls:'sending'};
  return{label:'DA REGOLARIZZARE',cls:'pending'}
}
function emergencyPendingRows(){return emergencyOperations.filter(x=>x?.status==='da_regolarizzare')}
function emergencyRenderSettingsSummary(){
  const el=$('emergencySettingsSummary'),card=$('settingsEmergency');
  const pending=emergencyOperations.filter(x=>x?.status==='da_regolarizzare').length,uncertain=emergencyOperations.filter(x=>x?.status==='esito_da_verificare').length,sending=emergencyOperations.filter(x=>x?.status==='in_invio').length;
  const attention=pending+uncertain+sending;
  if(el)el.textContent=uncertain?`${pending} da regolarizzare · ${uncertain} da verificare`:sending?`${pending} da regolarizzare · ${sending} in invio`:pending?`${pending} ${pending===1?'operazione':'operazioni'} da regolarizzare`:'Nessuna operazione da regolarizzare';
  if(card){card.classList.toggle('settings-status-ok',attention===0);card.classList.toggle('settings-status-error',attention>0);card.setAttribute('aria-label',attention?`Operazioni di emergenza: ${attention} da gestire`:'Operazioni di emergenza: nessuna operazione da gestire')}
}
function emergencyRecordSnapshot(snapshot,status='da_regolarizzare',reason='',extra={}){
  if(!snapshot)return null;const sourceSaleId=String(snapshot.id||'');
  let row=sourceSaleId?emergencyOperations.find(x=>String(x?.sourceSaleId||x?.snapshot?.id||'')===sourceSaleId&&x?.status!=='regolarizzata'):null;
  const now=new Date().toISOString();
  if(!row){row={id:uid(),sourceSaleId,createdAt:snapshot.date||now,updatedAt:now,status,reason:String(reason||''),snapshot:JSON.parse(JSON.stringify(snapshot)),attempts:0,...extra};emergencyOperations.unshift(row)}
  else{row.updatedAt=now;row.status=status;row.reason=String(reason||row.reason||'');row.snapshot=row.snapshot||JSON.parse(JSON.stringify(snapshot));Object.assign(row,extra)}
  emergencySaveOperations();return row
}
function emergencyUpdateRow(id,patch={}){const row=emergencyFind(id);if(!row)return null;Object.assign(row,patch,{updatedAt:new Date().toISOString()});emergencySaveOperations();return row}
function emergencyClearActive(){dcoEmergencyActiveId='';localStorage.removeItem(K.emergencyActive)}
function emergencySetActive(id){dcoEmergencyActiveId=String(id||'');if(dcoEmergencyActiveId)localStorage.setItem(K.emergencyActive,dcoEmergencyActiveId);else localStorage.removeItem(K.emergencyActive)}
function emergencyBuildDraftFromSnapshot(snapshot){
  if(!snapshot||!Array.isArray(snapshot.lines)||!snapshot.lines.length)return{ok:false,error:'Operazione di emergenza senza righe prodotto.'};
  const supportedVat=[4,5,10,22],unsupported=[];
  const lines=snapshot.lines.map((line,index)=>{const vat=Number(line.vatRate),matched=supportedVat.find(v=>Math.abs(v-vat)<.001);if(matched===undefined)unsupported.push(`${line.name||'Prodotto'}: IVA ${Number.isFinite(vat)?vat:'non impostata'}`);return{index,quantity:Number(line.quantity||0),description:String(line.name||'Prodotto').trim().slice(0,80),grossPrice:roundMoney(Number(line.unitPrice||0)),vat:matched===undefined?'':String(matched),discount:0,gift:false}});
  if(unsupported.length)return{ok:false,error:`Aliquota non gestita: ${unsupported.join('; ')}.`};
  if(lines.some(x=>!(x.quantity>0)||!(x.grossPrice>=0)))return{ok:false,error:'Quantità o prezzi non validi nell’operazione di emergenza.'};
  const total=roundMoney(snapshot.total),subtotal=roundMoney(snapshot.subtotal||lines.reduce((s,x)=>s+x.grossPrice*x.quantity,0)),discount=roundMoney(snapshot.discount||0),pay=snapshot.payment==='Carta'?'Carta':'Contanti';
  if(!(total>0))return{ok:false,error:'Totale non valido nell’operazione di emergenza.'};
  const normalizedLottery=pay==='Carta'&&total>=1?normalizeLotteryCode(snapshot.lotteryCode||''):'';
  if(normalizedLottery&&!/^[A-Z0-9]{8}$/.test(normalizedLottery))return{ok:false,error:'Codice lotteria non valido nell’operazione di emergenza: servono 8 caratteri alfanumerici.'};
  return{ok:true,operation:'V',lines,payment:pay,subtotal,discount,total,cash:pay==='Contanti'?total:0,electronic:pay==='Carta'?total:0,lotteryCode:normalizedLottery,createdAt:new Date().toISOString(),emergencyOperation:true}
}
function emergencyAfterRecorded(snapshot){
  const matches=dcoCurrentCartMatchesSnapshot(snapshot);if(!matches)return;
  resetSale();renderCart()
}
function emergencyTableContext(){return activeTableCheckout?JSON.parse(JSON.stringify(activeTableCheckout)):null}
async function emergencyFinalizeStoredTable(row){
  const ctx=row?.tableCheckout;if(!ctx?.tableId||!Array.isArray(ctx.orderIds)||!ctx.orderIds.length)return false;
  try{const ids=ctx.orderIds.map(encodeURIComponent).join(',');await cloudRequest('orders',{method:'PATCH',query:`?id=in.(${ids})`,body:{status:'closed',updated_at:new Date().toISOString()},prefer:'return=minimal'});const remaining=await cloudRequest('orders',{query:`?select=id&table_id=eq.${encodeURIComponent(ctx.tableId)}&status=in.(sent,accepted)&limit=1`});if(!Array.isArray(remaining)||!remaining.length)await cloudRequest('restaurant_tables',{method:'PATCH',query:`?id=eq.${encodeURIComponent(ctx.tableId)}`,body:{status:'free',updated_at:new Date().toISOString()},prefer:'return=minimal'});row.tableClosedAt=new Date().toISOString();row.tableCloseError='';emergencySaveOperations();loadRestaurantTables(false).catch(()=>{});return true}catch(e){row.tableCloseError=String(e?.message||e);emergencySaveOperations();toast(`${ctx.tableName||'Tavolo'}: documento regolarizzato, ma stato tavolo da aggiornare`,5000);return false}
}
function emergencySaveCurrentOfflineSale(){
  const snapshot=dcoCreateSaleSnapshot();if(!snapshot)return false;
  const row=emergencyRecordSnapshot(snapshot,'da_regolarizzare','Connessione internet assente al momento dell’emissione.',{detectedOffline:true,tableCheckout:emergencyTableContext()});
  emergencyAfterRecorded(snapshot);status('','Operazione di emergenza salvata');toast(`Operazione ${euro(snapshot.total)} salvata · da regolarizzare`,4500);return !!row
}
function emergencyMarkRegularized(id,meta={}){
  const row=emergencyFind(id);if(!row){emergencyClearActive();return null}
  const documentNumber=String(meta.documentNumber||meta.receiptNumber||'');
  const out=emergencyUpdateRow(id,{status:'regolarizzata',regularizedAt:new Date().toISOString(),dcoDocumentId:String(meta.documentId||''),dcoDocumentNumber:documentNumber,dcoDocumentDate:String(meta.documentDate||''),reason:'Operazione inviata manualmente al Documento Commerciale Online.'});
  if(out?.tableCheckout)emergencyFinalizeStoredTable(out).catch(()=>{});emergencyClearActive();return out
}
function emergencyHandleDcoAbort(snapshot,uncertain,message){
  const activeId=dcoEmergencyActiveId||localStorage.getItem(K.emergencyActive)||'';
  if(activeId&&emergencyFind(activeId)){
    emergencyUpdateRow(activeId,{status:uncertain?'esito_da_verificare':'da_regolarizzare',reason:String(message||''),lastAttemptAt:new Date().toISOString()});
    emergencyClearActive();return{existing:true,status:uncertain?'esito_da_verificare':'da_regolarizzare'}
  }
  if(!snapshot)return null;
  const row=emergencyRecordSnapshot(snapshot,uncertain?'esito_da_verificare':'da_regolarizzare',message,{capturedFromDcoFailure:true,uncertain:!!uncertain,tableCheckout:emergencyTableContext()});
  if(!uncertain)emergencyAfterRecorded(snapshot);
  return row?{existing:false,status:row.status,row}:null
}
function emergencyHandleReconnectFailure(message){
  if(dcoEmergencyActiveId&&emergencyFind(dcoEmergencyActiveId)){emergencyUpdateRow(dcoEmergencyActiveId,{status:'da_regolarizzare',reason:String(message||'Ricollegamento DCO non completato.')});emergencyClearActive();return true}
  const pending=dcoLoadPendingSale();if(!pending)return false;emergencyRecordSnapshot(pending,'da_regolarizzare',String(message||'Ricollegamento DCO non completato.'),{capturedFromReconnectFailure:true,tableCheckout:emergencyTableContext()});emergencyAfterRecorded(pending);localStorage.removeItem(K.dcoPendingSale);return true
}
function emergencyVerifyNotEmitted(id){
  const row=emergencyFind(id);if(!row||row.status!=='esito_da_verificare')return;
  if(!confirm('Usa questa funzione SOLO dopo aver controllato nel DCO che il documento NON risulta emesso. Confermi di aver verificato e che l’operazione deve ancora essere inviata?'))return;
  const pending=dcoLoadPendingSale(),samePending=String(pending?.id||'')===String(row.snapshot?.id||'');
  if(samePending){localStorage.removeItem(K.dcoAutoLock);localStorage.removeItem(K.dcoPendingSale)}
  emergencyUpdateRow(id,{status:'da_regolarizzare',reason:'Verificata manualmente nel DCO: documento non emesso. Operazione nuovamente disponibile per la regolarizzazione.'});
  if(dcoCurrentCartMatchesSnapshot(row.snapshot))resetSale()
  renderDcoConnectionStatus();renderCart();toast('Operazione pronta per la regolarizzazione',3500)
}
async function emergencyRegularize(id){
  const row=emergencyFind(id);if(!row||row.status!=='da_regolarizzare')return;
  if(!emergencyInternetOnline()){toast('Connessione internet assente. Riprova quando torna la linea.',4500);renderEmergencyConnectivity();return}
  if(isIssuing||dcoAutoSale)return toast('Attendi la conclusione dell’emissione in corso.',3500);
  const check=dcoBusinessValidation();if(!check.ok){alert(`Completa prima i dati dell’attività: ${check.missing.join(', ')}.`);showView('dcolab');return}
  const draft=emergencyBuildDraftFromSnapshot(row.snapshot);if(!draft.ok)return alert(draft.error);
  if(!confirm(`Inviare ora al DCO questa singola operazione?\n\n${new Date(row.createdAt).toLocaleString('it-IT')} · ${euro(row.snapshot.total)} · ${row.snapshot.payment||''}\n\nCassaIQ invierà soltanto questa operazione.`))return;
  row.attempts=Number(row.attempts||0)+1;row.status='in_invio';row.lastAttemptAt=new Date().toISOString();row.updatedAt=row.lastAttemptAt;emergencySaveOperations();emergencySetActive(row.id);dcoTimingBegin();
  try{await dcoStartAutomaticSale({emergencyRecord:row})}catch(e){emergencyUpdateRow(row.id,{status:'da_regolarizzare',reason:e?.message||String(e)});emergencyClearActive();throw e}
}
function emergencyRenderConnectivity(message=''){
  const dot=$('emergencyInternetDot'),internet=$('emergencyInternetText'),dco=$('emergencyDcoText');if(!dot||!internet||!dco)return;
  const online=emergencyInternetOnline();dot.className=`emergency-dot ${online?'ok':'error'}`;internet.textContent=online?'Internet disponibile':'Connessione internet assente';
  if(!online)dco.textContent='Il DCO non può essere verificato finché manca la connessione.';
  else if(message)dco.textContent=message;
  else if(dcoHasSessionMarker())dco.textContent='Internet disponibile · verifica della sessione DCO consigliata prima dell’invio.';
  else dco.textContent='Internet disponibile · DCO da ricollegare prima della regolarizzazione.'
}
async function emergencyProbeDco(reconnect=false){
  emergencyRenderConnectivity();if(!emergencyInternetOnline())return false;
  if(dcoBrowserRef){
    try{const info=await dcoExecScript(dcoBrowserRef,"(function(){var body=String(document.body&&document.body.innerText||'').toLowerCase();var href=String(location.href||'').toLowerCase();return{href:href,readyState:document.readyState,logged:!!document.querySelector('#user-info'),home:href.indexOf('/ser/documenticommercialionline/')>=0&&href.indexOf('#/home')>=0,hasGeneration:body.indexOf('generazione')>=0||body.indexOf('genera il tuo documento')>=0}})()",3500);if(info?.readyState==='complete'&&info?.logged&&info?.home&&info?.hasGeneration){dcoMarkConnected();emergencyRenderConnectivity('Documento Commerciale Online disponibile e sessione valida.');if(reconnect)toast('DCO disponibile',3000);return true}}catch(e){}
  }
  if(!reconnect){emergencyRenderConnectivity(dcoHasSessionMarker()?'Internet disponibile · sessione DCO da verificare.':'Internet disponibile · DCO da ricollegare.');return false}
  if(dcoAuthMode()==='fisconline'){
    const credentials=await dcoLoadFisconlineCredentials();if(credentials){emergencyReconnectOnly=true;emergencyRenderConnectivity('Ricollegamento Fisconline al DCO in corso…');const ok=await dcoStartConnection('fisconline',{credentials});if(!ok){emergencyReconnectOnly=false;emergencyRenderConnectivity('Ricollegamento DCO non avviato. Controlla la configurazione.')}return ok}
  }
  emergencyReconnectOnly=false;showView('dcolab');renderDcoConnectionStatus('Internet disponibile. Ricollega il DCO prima di inviare le operazioni di emergenza.','warning');return false
}
function renderEmergencyOperations(){
  const list=$('emergencyList');if(!list)return;
  const pending=emergencyOperations.filter(x=>x?.status==='da_regolarizzare'),uncertain=emergencyOperations.filter(x=>x?.status==='esito_da_verificare'),regularized=emergencyOperations.filter(x=>x?.status==='regolarizzata');
  $('emergencyPendingCount').textContent=String(pending.length);$('emergencyPendingTotal').textContent=euro(pending.reduce((s,x)=>s+Number(x?.snapshot?.total||0),0));$('emergencyUncertainCount').textContent=String(uncertain.length);$('emergencyRegularizedCount').textContent=String(regularized.length);
  emergencyRenderSettingsSummary();emergencyRenderConnectivity();
  if(!emergencyOperations.length){list.innerHTML='<div class="emergency-empty"><strong>Nessuna operazione di emergenza</strong><span>Le vendite non completate dal DCO compariranno qui automaticamente.</span></div>';return}
  const rows=[...emergencyOperations].sort((a,b)=>String(b.createdAt||'').localeCompare(String(a.createdAt||'')));
  list.innerHTML=rows.map(row=>{const st=emergencyStatusInfo(row.status),snap=row.snapshot||{},when=new Date(row.createdAt||snap.date||Date.now()),stamp=Number.isNaN(when.getTime())?'—':when.toLocaleString('it-IT'),lines=Array.isArray(snap.lines)?snap.lines:[],actions=row.status==='da_regolarizzare'?`<button type="button" class="primary compact" data-emergency-send="${escapeHtml(row.id)}">Invia al DCO</button>`:row.status==='esito_da_verificare'?`<button type="button" class="secondary compact" data-emergency-open-dco="1">Apri DCO e verifica</button><button type="button" class="secondary compact" data-emergency-not-emitted="${escapeHtml(row.id)}">Ho verificato: non emessa</button>`:'',doc=row.dcoDocumentNumber||row.dcoDocumentId||'';return`<article class="emergency-operation ${st.cls}"><div class="emergency-operation-head"><div class="emergency-operation-title"><strong>${euro(snap.total)}</strong><small>${escapeHtml(stamp)} · ${escapeHtml(snap.payment||'Pagamento non indicato')}</small></div><span class="emergency-status-badge ${st.cls}">${st.label}</span></div><div class="emergency-operation-meta"><span>${Number(snap.items||0)} articoli</span><span>ID ${escapeHtml(String(row.id||'').slice(0,8).toUpperCase())}</span>${row.attempts?`<span>${Number(row.attempts)} ${Number(row.attempts)===1?'tentativo':'tentativi'} DCO</span>`:''}</div>${row.reason?`<p class="emergency-operation-reason">${escapeHtml(row.reason)}</p>`:''}${doc?`<div class="emergency-doc-ref">Documento DCO: ${escapeHtml(doc)}</div>`:''}<details><summary>Dettagli operazione</summary><div class="emergency-lines">${lines.map(line=>`<div class="emergency-line"><span>${Number(line.quantity||0)} × ${escapeHtml(line.name||'Prodotto')} · IVA ${Number(line.vatRate||0)}%</span><strong>${euro(Number(line.unitPrice||0)*Number(line.quantity||0))}</strong></div>`).join('')||'<span>Nessuna riga disponibile</span>'}</div></details>${actions?`<div class="emergency-operation-actions">${actions}</div>`:''}</article>`}).join('');
  list.querySelectorAll('[data-emergency-send]').forEach(b=>b.onclick=()=>emergencyRegularize(b.dataset.emergencySend));list.querySelectorAll('[data-emergency-open-dco]').forEach(b=>b.onclick=()=>showView('dcolab'));list.querySelectorAll('[data-emergency-not-emitted]').forEach(b=>b.onclick=()=>emergencyVerifyNotEmitted(b.dataset.emergencyNotEmitted))
}
function initEmergencyView(){renderEmergencyOperations();if($('emergencyRefresh'))$('emergencyRefresh').onclick=()=>{renderEmergencyOperations();emergencyProbeDco(false)};if($('emergencyCheckDco'))$('emergencyCheckDco').onclick=()=>emergencyProbeDco(true);emergencyProbeDco(false)}
function dcoRecoverLegacyGlobalLock(){
  const lock=loadObjectSafe(K.dcoAutoLock,null),pending=dcoLoadPendingSale();if(!lock)return;
  if(pending)emergencyRecordSnapshot(pending,'esito_da_verificare','CassaIQ è stato chiuso/interrotto durante una fase DCO potenzialmente fiscale. Verifica l’esito nel portale prima di reinviare.',{capturedFromLegacyLock:true,uncertain:true});
  localStorage.removeItem(K.dcoAutoLock);localStorage.removeItem(K.dcoPendingSale);renderCart();emergencyRenderSettingsSummary()
}
function emergencyRecoverInterruptedAttempt(){
  const id=dcoEmergencyActiveId||localStorage.getItem(K.emergencyActive)||'';if(!id)return;const row=emergencyFind(id);if(!row){emergencyClearActive();return}const lock=loadObjectSafe(K.dcoAutoLock,null);row.status=lock?'esito_da_verificare':'da_regolarizzare';row.reason=lock?'L’app è stata interrotta durante un invio DCO: verifica l’esito prima di ripetere.':'Tentativo interrotto prima dell’invio finale: operazione nuovamente disponibile.';row.updatedAt=new Date().toISOString();emergencyClearActive();emergencySaveOperations()
}
window.addEventListener('online',()=>{emergencyRenderConnectivity('Internet è tornato. Verifica il DCO prima di regolarizzare.');const n=emergencyPendingRows().length;if(n)toast(`Internet disponibile · ${n} ${n===1?'operazione':'operazioni'} da regolarizzare`,5000);setTimeout(()=>emergencyProbeDco(false),500)});
window.addEventListener('offline',()=>{emergencyRenderConnectivity();if(emergencyPendingRows().length)toast('Connessione assente · le operazioni restano salvate',4000)});

// FAQ: ricerca testuale, filtri per argomento e apertura/chiusura rapida.
const faqSearch=$('faqSearch'),faqClear=$('faqClear'),faqNoResults=$('faqNoResults'),faqResultCount=$('faqResultCount');
let activeFaqCategory='all';
function normalizeFaqText(value){return String(value||'').toLocaleLowerCase('it-IT').normalize('NFD').replace(/[\u0300-\u036f]/g,'')}
function filterFaqItems(){
  if(!faqSearch)return;
  const query=normalizeFaqText(faqSearch.value.trim());
  let visible=0;
  document.querySelectorAll('.faq-item').forEach(item=>{
    const category=item.dataset.category||'';
    const categoryMatch=activeFaqCategory==='all'||category===activeFaqCategory;
    const textMatch=!query||normalizeFaqText(item.textContent).includes(query);
    item.hidden=!(categoryMatch&&textMatch);
    if(!item.hidden)visible+=1;
  });
  document.querySelectorAll('.faq-group').forEach(group=>{
    group.hidden=![...group.querySelectorAll('.faq-item')].some(item=>!item.hidden);
  });
  faqClear.hidden=!faqSearch.value;
  faqNoResults.hidden=visible!==0;
  faqResultCount.textContent=visible===1?'1 risposta':`${visible} risposte`;
}
if(faqSearch){
  faqSearch.addEventListener('input',filterFaqItems);
  faqClear.onclick=()=>{faqSearch.value='';faqSearch.focus();filterFaqItems()};
  document.querySelectorAll('.faq-filter').forEach(button=>button.onclick=()=>{
    activeFaqCategory=button.dataset.faqCategory||'all';
    document.querySelectorAll('.faq-filter').forEach(item=>item.classList.toggle('active',item===button));
    filterFaqItems();
  });
  document.querySelectorAll('.faq-external-link[data-faq-url]').forEach(button=>button.onclick=()=>{
    const url=String(button.dataset.faqUrl||'').trim();
    if(!url)return;
    try{window.open(url,'_system')}catch(e){try{location.href=url}catch(_){toast('Impossibile aprire il collegamento esterno',4500)}}
  });
  $('faqOpenAll').onclick=()=>document.querySelectorAll('.faq-item:not([hidden])').forEach(item=>item.open=true);
  $('faqCloseAll').onclick=()=>document.querySelectorAll('.faq-item').forEach(item=>item.open=false);
  filterFaqItems();
}


function categoryById(id){return categories.find(x=>x.id===id)} function departmentById(id){return departments.find(x=>x.id===id)}
function normalizedCatalogName(value){return String(value||'').trim().toLocaleLowerCase('it-IT').normalize('NFD').replace(/[\u0300-\u036f]/g,'')}
function isSupplementCategory(categoryRow){const n=normalizedCatalogName(categoryRow?.name);return n==='supplementi'||n==='supplemento'||n==='supplements'}
function supplementCategoryIds(){return new Set(categories.filter(isSupplementCategory).map(c=>String(c.id)))}
function supplementProducts(){const ids=supplementCategoryIds();return products.filter(p=>ids.has(String(p.categoryId))&&!p.variablePrice)}
function isSupplementProduct(product){return supplementCategoryIds().has(String(product?.categoryId))}
function lineSupplements(id){return Array.isArray(cartSupplements[id])?cartSupplements[id]:[]}
function supplementKind(item){return item?.kind==='remove'?'remove':'add'}
function supplementUnitTotal(list){return roundMoney((list||[]).reduce((sum,x)=>sum+(supplementKind(x)==='add'?Number(x.price||0):0),0))}
function lineUnitTotal(line){return roundMoney(Number(line?.product?.price||0)+supplementUnitTotal(line?.supplements||[]))}
function supplementDisplayNote(list){return (list||[]).map(x=>`${supplementKind(x)==='remove'?'-':'+'} ${x.name}`).join(' | ')}
function composeOrderItemNote(line){const extras=supplementDisplayNote(line?.supplements||[]),note=String(line?.note||'').trim();return [extras,note].filter(Boolean).join(' | ').slice(0,300)}
function expandedCartFiscalLines(){const out=[];for(const line of cartLines()){out.push({product:line.product,quantity:line.quantity,isSupplement:false});for(const extra of (line.supplements||[]).filter(x=>supplementKind(x)==='add')){const product=products.find(p=>String(p.id)===String(extra.id))||{id:extra.id,name:extra.name,price:Number(extra.price||0),categoryId:extra.categoryId||'',departmentId:extra.departmentId||line.product.departmentId,manual:false};out.push({product,quantity:line.quantity,isSupplement:true,baseProduct:line.product})}}return out}

function textColorFor(bg){const h=String(bg||'#4F8FD8').replace('#','');const r=parseInt(h.slice(0,2),16)||0,g=parseInt(h.slice(2,4),16)||0,b=parseInt(h.slice(4,6),16)||0;return (r*299+g*587+b*114)/1000>155?'#17302b':'#ffffff'}
function renderCategoryButtons(){const root=$('categoryButtons');root.innerHTML='';const visibleCategories=categories.filter(c=>!isSupplementCategory(c));if(category!=='all'&&!visibleCategories.some(c=>String(c.id)===String(category)))category='all';const all=document.createElement('button');all.className=`category ${category==='all'?'active':''}`;all.innerHTML='<span>★</span>Tutti';all.onclick=()=>{category='all';renderCategoryButtons();renderProducts()};root.appendChild(all);visibleCategories.forEach(c=>{const b=document.createElement('button');b.className=`category ${category===c.id?'active':''}`;b.innerHTML=`<span>${c.icon||'▦'}</span>${c.name}`;b.onclick=()=>{category=c.id;renderCategoryButtons();renderProducts()};root.appendChild(b)})}
function productNameSize(name,hasImage=false){const n=String(name||'').trim().length;if(n<=12)return hasImage?18:23;if(n<=22)return hasImage?16:20;if(n<=34)return hasImage?14:17;return hasImage?13:14}
function renderProducts(){const root=$('products');root.innerHTML='';const list=products.filter(p=>!isSupplementProduct(p)&&(category==='all'||p.categoryId===category));/* In "Tutti" i prodotti vengono raggruppati per categoria, nello stesso
   ordine della colonna Categorie. L'ordinamento e' stabile, quindi dentro
   ogni categoria resta l'ordine con cui sono stati caricati. */
const catOrder=new Map(categories.map((c,i)=>[c.id,i]));list.sort((a,b)=>{const ia=catOrder.has(a.categoryId)?catOrder.get(a.categoryId):Number.MAX_SAFE_INTEGER;const ib=catOrder.has(b.categoryId)?catOrder.get(b.categoryId):Number.MAX_SAFE_INTEGER;return ia-ib});if(!list.length){root.innerHTML='<p class="empty">Nessun prodotto. Crealo da Prodotti → Nuovo prodotto.</p>';fitProducts();return}list.forEach(p=>{const b=document.createElement('button');const cat=categoryById(p.categoryId),imageSrc=productImageSrc(p),hasImage=!!imageSrc;b.type='button';b.className=`product ${hasImage?'has-photo':'category-colored no-product-image'}${p.variablePrice?' variable-price':''}`;b.style.setProperty('--product-name-size',`${productNameSize(p.name,hasImage)}px`);if(!hasImage){const bg=cat?.color||'#4F8FD8';b.style.background=bg;b.style.color=textColorFor(bg)}const visual=hasImage?`<span class="product-icon"><img class="product-photo" src="${imageSrc}" alt=""></span>`:'';const showPrice=p.showPrice!==false;const priceHtml=p.variablePrice?'':(showPrice?`<span class="price">${euro(p.price)}</span>`:'');b.innerHTML=`${visual}<strong class="product-name">${xmlEscape(p.name)}</strong>${priceHtml}`;b.onclick=()=>{if(p.variablePrice){openKeypad(p);return}addCatalogProductToCart(p)};root.appendChild(b)});fitProducts()}
/* Adatta il numero di colonne e l'altezza dei tasti perche' tutti i prodotti
   stiano in una sola schermata, senza dover scorrere. */
function fitProducts(){const root=$('products');if(!root)return;const tiles=root.querySelectorAll('.product');const n=tiles.length;if(!n){root.style.removeProperty('--cols');root.style.removeProperty('--tile-h');root.style.removeProperty('--tile-scale');return}const W=root.clientWidth,H=root.clientHeight;if(!W||!H)return;const gap=parseFloat(getComputedStyle(root).gap)||12;const MIN_H=66,MIN_W=78;let best=null;for(let cols=1;cols<=Math.min(n,10);cols++){const rows=Math.ceil(n/cols);const tw=(W-gap*(cols-1))/cols,th=(H-gap*(rows-1))/rows;if(tw<MIN_W||th<MIN_H)continue;const score=Math.min(tw,th*1.4);if(!best||score>best.score)best={cols,th,score}}if(!best){const cols=Math.min(n,Math.max(2,Math.floor((W+gap)/(MIN_W+gap))));best={cols,th:MIN_H}}root.style.setProperty('--cols',best.cols);root.style.setProperty('--tile-h',`${Math.floor(best.th)}px`);root.style.setProperty('--tile-scale',Math.max(.5,Math.min(1.15,best.th/150)).toFixed(2))}
let fitTimer=null;function scheduleFit(){clearTimeout(fitTimer);fitTimer=setTimeout(fitProducts,80)}window.addEventListener('resize',scheduleFit);window.addEventListener('orientationchange',scheduleFit);
/* Blocca lo zoom a pizzico. Lo zoom da doppio tocco e' gia' disattivato
   via CSS (touch-action:manipulation), che non interferisce con i tocchi
   ripetuti sullo stesso prodotto. */
['gesturestart','gesturechange','gestureend'].forEach(ev=>document.addEventListener(ev,e=>e.preventDefault(),{passive:false}));
/* --------- Tastierino numerico: importo manuale / prodotti a peso --------- */
let keypadDigits='',keypadProduct=null;
function keypadAmount(){return roundMoney((Number(keypadDigits||'0'))/100)}
function renderKeypad(){const el=$('keypadValue');if(el)el.textContent=euro(keypadAmount()).replace('€','').trim()}
function openKeypad(product=null){keypadProduct=product;keypadDigits='';
  const dlg=$('keypadDialog');if(!dlg)return;
  $('keypadTitle').textContent=product?product.name:'Prezzo manuale';
  const extra=$('keypadExtra'),nameField=$('keypadName'),depSel=$('keypadDepartment');
  const sel=depSel;sel.innerHTML='';departments.forEach(d=>{const o=document.createElement('option');o.value=d.id;o.textContent=`${d.name} (reparto ${d.number})`;sel.appendChild(o)});
  if(product){extra.hidden=true;nameField.value=product.name;if(product.departmentId)sel.value=product.departmentId}
  else{extra.hidden=false;nameField.value='';}
  $('keypadError').textContent='';renderKeypad();
  if(!departments.length){$('keypadError').textContent='Configura prima almeno un reparto fiscale.'}
  dlg.showModal()}
document.querySelectorAll('#keypadDialog [data-k]').forEach(b=>{b.onclick=()=>{const k=b.dataset.k;
  if(k==='clear')keypadDigits='';else if(k==='back')keypadDigits=keypadDigits.slice(0,-1);
  else if(keypadDigits.length<8)keypadDigits=(keypadDigits+k).replace(/^0+(?=\d)/,'');
  renderKeypad()}});
const manualButton=$('manualPriceButton');if(manualButton)manualButton.onclick=()=>{if(tableOrderDraft)return toast('Per un ordine al tavolo usa i prodotti del catalogo');openKeypad(null)};
const keypadForm=$('keypadForm');if(keypadForm)keypadForm.onsubmit=e=>{e.preventDefault();
  const amount=keypadAmount();
  if(!(amount>0)){$('keypadError').textContent='Inserisci un importo maggiore di zero.';return}
  const depId=$('keypadDepartment').value;
  if(!depId){$('keypadError').textContent='Seleziona un reparto fiscale.';return}
  const name=(keypadProduct?keypadProduct.name:($('keypadName').value.trim()||'Vendita banco')).slice(0,60);
  const item={id:uid(),name,price:amount,manual:true,sourceProductId:keypadProduct?.id||null,categoryId:keypadProduct?.categoryId||'',departmentId:depId,icon:'',image:'',imageLibraryId:''};
  manualItems.push(item);cart[item.id]=1;
  $('keypadDialog').close();renderCart(true)};

function cartLines(){return Object.keys(cart).filter(id=>cart[id]>0).map(id=>({lineId:id,product:findCartProduct(id),quantity:cart[id],note:String(cartItemNotes[id]||'').trim(),supplements:lineSupplements(id)})).filter(x=>x.product)}
let cartItemNoteTargetId=null;
function cartItemNote(id){return String(cartItemNotes[id]||'').trim()}
function openCartItemNote(id){
  if(!tableOrderDraft)return;
  const product=findCartProduct(id),dlg=$('cartItemNoteDialog'),input=$('cartItemNoteInput');
  if(!product||!dlg||!input)return;
  cartItemNoteTargetId=id;
  $('cartItemNoteProduct').textContent=product.name||'Prodotto';
  input.value=cartItemNote(id);
  dlg.showModal();setTimeout(()=>{input.focus();input.setSelectionRange(input.value.length,input.value.length)},80)
}
function saveCartItemNote(){
  if(!cartItemNoteTargetId)return;
  const text=String($('cartItemNoteInput')?.value||'').trim().slice(0,300);
  if(text)cartItemNotes[cartItemNoteTargetId]=text;else delete cartItemNotes[cartItemNoteTargetId];
  cartItemNoteTargetId=null;const dlg=$('cartItemNoteDialog');if(dlg?.open)dlg.close();renderCart()
}
function clearCartItemNote(){
  if(cartItemNoteTargetId)delete cartItemNotes[cartItemNoteTargetId];
  cartItemNoteTargetId=null;const dlg=$('cartItemNoteDialog');if(dlg?.open)dlg.close();renderCart()
}
let cartSupplementTargetId=null;
function supplementChoiceHtml(product,current){
  const kind=current?supplementKind(current):'';
  return `<div class="supplement-choice-row ${kind?`selected ${kind}`:''}" data-supplement-row="${escapeHtml(product.id)}"><button type="button" class="supplement-sign minus ${kind==='remove'?'selected':''}" data-supplement-action="remove" data-supplement-id="${escapeHtml(product.id)}" aria-label="Togli ${escapeHtml(product.name)}">−</button><div class="supplement-choice-center"><strong>${escapeHtml(product.name)}</strong><small>${euro(product.price)} se aggiunto · prezzo invariato se tolto</small></div><button type="button" class="supplement-sign plus ${kind==='add'?'selected':''}" data-supplement-action="add" data-supplement-id="${escapeHtml(product.id)}" aria-label="Aggiungi ${escapeHtml(product.name)}">+</button></div>`
}
function renderCartSupplementChoices(){
  const list=$('supplementList');if(!list||!cartSupplementTargetId)return;
  const available=supplementProducts(),current=lineSupplements(cartSupplementTargetId);
  list.innerHTML=available.length?available.map(p=>supplementChoiceHtml(p,current.find(x=>String(x.id)===String(p.id)))).join(''):'<div class="supplement-empty">Nessun ingrediente configurato. Crea una categoria chiamata <strong>Supplementi</strong> e aggiungi gli ingredienti con il relativo prezzo di aggiunta.</div>';
  list.querySelectorAll('[data-supplement-action]').forEach(btn=>btn.onclick=()=>setCartSupplement(btn.dataset.supplementId,btn.dataset.supplementAction))
}
function openCartSupplements(id){
  let targetId=id;const originalQty=Number(cart[id]||0);if(originalQty>1){targetId=splitCartLineForSingleModifier(id);renderCart();toast('1 unità separata: il supplemento verrà applicato solo a questa',3200)}
  const product=findCartProduct(targetId),dlg=$('supplementDialog'),list=$('supplementList');if(!product||!dlg||!list)return;
  cartSupplementTargetId=targetId;if($('supplementProduct'))$('supplementProduct').textContent=product.name||'Prodotto';renderCartSupplementChoices();dlg.showModal()
}
function setCartSupplement(supplementId,kind){
  if(!cartSupplementTargetId)return;const p=products.find(x=>String(x.id)===String(supplementId));if(!p||isSupplementProduct(findCartProduct(cartSupplementTargetId)))return;
  const mode=kind==='remove'?'remove':'add',current=[...lineSupplements(cartSupplementTargetId)],idx=current.findIndex(x=>String(x.id)===String(p.id));
  if(idx>=0&&supplementKind(current[idx])===mode)current.splice(idx,1);
  else{const item={id:p.id,name:p.name,price:mode==='add'?roundMoney(p.price):0,kind:mode,categoryId:p.categoryId||'',departmentId:p.departmentId||''};if(idx>=0)current[idx]=item;else current.push(item)}
  if(current.length)cartSupplements[cartSupplementTargetId]=current;else delete cartSupplements[cartSupplementTargetId];
  renderCartSupplementChoices();renderCart()
}
function openCartSupplementsRefresh(){renderCartSupplementChoices()}
function closeCartSupplements(){cartSupplementTargetId=null;const dlg=$('supplementDialog');if(dlg?.open)dlg.close();mergeEquivalentCartLines();renderCart()}
function roundMoney(n){return Math.round((Number(n)||0)*100)/100}
function parseMoneyInput(v){const n=Number(String(v||'').trim().replace(',','.'));return Number.isFinite(n)?roundMoney(n):NaN}
function cartSubtotal(){return roundMoney(cartLines().reduce((s,l)=>s+lineUnitTotal(l)*l.quantity,0))}
function normalizeDiscount(){const subtotal=cartSubtotal();if(!subtotal){discountAmount=0;return}const maximum=roundMoney(Math.max(0,subtotal-.01));discountAmount=roundMoney(Math.max(0,Math.min(Number(discountAmount)||0,maximum)))}
function cartTotal(){normalizeDiscount();return roundMoney(Math.max(0,cartSubtotal()-discountAmount))}
/* --------- Ordini in attesa (standby) ---------
   Il carrello puo' essere messo da parte con un nome e ripreso piu' tardi,
   liberando la cassa per il cliente successivo. Vengono salvati sul
   dispositivo, quindi sopravvivono anche alla chiusura dell'app. */
let holdOrders=load(K.hold,[]);
function saveHolds(){save(K.hold,holdOrders)}
function holdTotal(o){return roundMoney((o.lines||[]).reduce((t,l)=>(t+(Number(l.price||0)+supplementUnitTotal(l.supplements||[]))*Number(l.quantity||0)),0))}
function holdItemCount(o){return (o.lines||[]).reduce((t,l)=>t+l.quantity,0)}
function renderHoldButton(){const b=$('holdButton'),c=$('holdCount');if(!b||!c)return;
 const n=holdOrders.length;
 b.classList.toggle('is-empty',n===0);b.classList.toggle('has-orders',n>0);
 c.textContent=n===0?'vuoto':`${n} in attesa`}
function renderHoldList(){const box=$('holdList');if(!box)return;box.innerHTML='';
 const hasCart=cartLines().length>0;
 $('holdSaveBox').hidden=!hasCart;$('holdCartEmpty').hidden=hasCart;
 if(!holdOrders.length){box.innerHTML='<p class="empty hold-empty">Nessun ordine in attesa.</p>';return}
 holdOrders.forEach(o=>{const row=document.createElement('div');row.className='hold-row';
  const when=new Date(o.createdAt);
  const time=isNaN(when)?'':when.toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit'});
  row.innerHTML=`<div class="hold-info"><strong>${xmlEscape(o.name)}</strong><small>${holdItemCount(o)} pezzi · ${euro(holdTotal(o))}${time?` · ${time}`:''}</small></div>`;
  const actions=document.createElement('div');actions.className='hold-actions';
  const resume=document.createElement('button');resume.type='button';resume.className='edit';resume.textContent='Riprendi';
  resume.onclick=()=>resumeHold(o.id);
  const del=document.createElement('button');del.type='button';del.className='delete';del.textContent='Elimina';
  del.onclick=()=>{if(!confirm(`Eliminare l’ordine «${o.name}»?`))return;holdOrders=holdOrders.filter(x=>x.id!==o.id);saveHolds();renderHoldButton();renderHoldList();toast('Ordine eliminato')};
  actions.appendChild(resume);actions.appendChild(del);row.appendChild(actions);box.appendChild(row)})}
function openHoldDialog(){const dlg=$('holdDialog');if(!dlg)return;
 $('holdName').value='';renderHoldList();dlg.showModal()}
function parkCurrentOrder(){const lines=cartLines();
 if(!lines.length)return toast('Il carrello è vuoto');
 const typed=$('holdName').value.trim();
 const name=(typed||`Ordine ${holdOrders.length+1}`).slice(0,40);
 holdOrders.push({id:uid(),name,createdAt:new Date().toISOString(),discountAmount,
  lines:lines.map(l=>({productId:l.product.manual?null:l.product.id,name:l.product.name,price:l.product.price,
   quantity:l.quantity,categoryId:l.product.categoryId||'',departmentId:l.product.departmentId||'',note:l.note||'',supplements:(l.supplements||[]).map(x=>({...x}))}))});
 saveHolds();resetSale();renderHoldButton();renderHoldList();$('holdDialog').close();
 toast(`«${name}» messo in attesa`)}
function resumeHold(id){const o=holdOrders.find(x=>x.id===id);if(!o)return;
 if(cartLines().length&&!confirm('Il carrello attuale verrà sostituito. Continuare?'))return;
 resetSale();
 (o.lines||[]).forEach(l=>{const existing=l.productId?products.find(p=>p.id===l.productId):null;
  if(existing&&!existing.variablePrice&&roundMoney(existing.price)===roundMoney(l.price)){
    const personalized=!!String(l.note||'').trim()||(Array.isArray(l.supplements)&&l.supplements.length>0),key=personalized?cartLineKeyForProduct(existing.id,false):(mergeableNormalCartLine(existing.id)||cartLineKeyForProduct(existing.id,true));
    cart[key]=(cart[key]||0)+Number(l.quantity||0);if(String(l.note||'').trim())cartItemNotes[key]=String(l.note).trim();if(Array.isArray(l.supplements)&&l.supplements.length)cartSupplements[key]=l.supplements.map(x=>({...x}));return}
  const item={id:uid(),name:l.name,price:l.price,manual:true,sourceProductId:l.productId||null,categoryId:l.categoryId||'',departmentId:l.departmentId||'',icon:'',image:'',imageLibraryId:''};
  manualItems.push(item);cart[item.id]=Number(l.quantity||0);if(String(l.note||'').trim())cartItemNotes[item.id]=String(l.note).trim();if(Array.isArray(l.supplements)&&l.supplements.length)cartSupplements[item.id]=l.supplements.map(x=>({...x}))});
 discountAmount=Number(o.discountAmount)||0;
 holdOrders=holdOrders.filter(x=>x.id!==id);saveHolds();renderHoldButton();
 $('holdDialog').close();renderCart(true);toast(`«${o.name}» ripreso`)}
function showPay(on){const c=$('cartPane'),p=$('payPane');if(!c||!p)return;c.hidden=!!on;p.hidden=!on}
function isPayOpen(){return $('payPane')&&!$('payPane').hidden}
function normalizeLotteryCode(value){return String(value||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,8)}
function lotteryEligible(){return payment==='Carta'&&cartTotal()>=1}
function lotteryCodeValid(){return !lotteryCode||/^[A-Z0-9]{8}$/.test(lotteryCode)}
function renderLotteryUi(){
  const box=$('lotteryBox'),input=$('lotteryCode'),hint=$('lotteryHint');if(!box||!input||!hint)return;
  const eligible=lotteryEligible();box.hidden=!eligible;
  if(!eligible){lotteryCode='';input.value='';input.classList.remove('invalid');hint.className='lottery-hint';hint.textContent='Inserisci il codice mostrato dal cliente prima dell’emissione.';return}
  if(input.value!==lotteryCode)input.value=lotteryCode;
  const invalid=!!lotteryCode&&!lotteryCodeValid();input.classList.toggle('invalid',invalid);hint.className=`lottery-hint${invalid?' error':''}`;hint.textContent=invalid?'Il codice lotteria deve contenere esattamente 8 caratteri alfanumerici.':(lotteryCode?'Codice lotteria pronto per il documento.':'Inserisci il codice mostrato dal cliente prima dell’emissione.');
}
function requireValidLotteryCode(){if(!lotteryEligible())return true;if(lotteryCodeValid())return true;renderLotteryUi();$('lotteryCode')?.focus();toast('Controlla il codice lotteria: servono 8 caratteri.',4200);return false}
if($('lotteryCode'))$('lotteryCode').addEventListener('input',e=>{lotteryCode=normalizeLotteryCode(e.target.value);e.target.value=lotteryCode;renderLotteryUi()});
function renderCart(scrollToLatest=false){normalizeDiscount();const root=$('cartItems'),lines=cartLines(),subtotal=cartSubtotal(),total=cartTotal();const tableBanner=$('tableCheckoutBanner'),tableContext=tableOrderDraft||activeTableCheckout;if(tableBanner){tableBanner.hidden=!tableContext;if(tableContext&&$('tableCheckoutName'))$('tableCheckoutName').textContent=tableContext.tableName||'Tavolo';const label=$('tableCheckoutLabel');if(label)label.textContent=tableOrderDraft?'Ordine da cassa':'Comanda tavolo'}root.innerHTML='';if(!lines.length)root.innerHTML='<p class="empty">Tocca un prodotto per aggiungerlo.</p>';lines.forEach(({lineId,product:p,quantity:q,note,supplements})=>{const r=document.createElement('div');r.className='cart-row';const extras=supplements||[],extraTotal=supplementUnitTotal(extras),unitTotal=roundMoney(Number(p.price||0)+extraTotal),extraUi=extras.length?`<div class="cart-supplement-preview">${extras.map(x=>supplementKind(x)==='remove'?`<span class="removed"><em>− ${escapeHtml(x.name)}</em><b>prezzo invariato</b></span>`:`<span class="added"><em>+ ${escapeHtml(x.name)}</em><b>${euro(x.price)}</b></span>`).join('')}</div>`:'',noteUi=tableOrderDraft?`<div class="cart-item-note-box"><button type="button" class="item-note-btn ${note?'has-note':''}" data-a="note">${note?'📝 Nota':'+ Nota'}</button>${note?`<div class="item-note-preview">${escapeHtml(note)}</div>`:''}</div>`:'';r.innerHTML=`<div class="cart-row-main"><strong>${xmlEscape(p.name)}</strong><div class="line-sub">${q} × ${euro(unitTotal)}${extraTotal>0?` · base ${euro(p.price)}`:''}</div>${extraUi}<div class="cart-row-controls"><div class="qty"><button data-a="minus">−</button><span>${q}</span><button data-a="plus">+</button></div><button type="button" class="supplement-btn ${extras.length?'active':''}" data-a="supplements">SUPPL.${extras.length?` <b>${extras.length}</b>`:''}</button>${noteUi}</div></div><strong class="line-total">${euro(unitTotal*q)}</strong>`;r.querySelector('[data-a=minus]').onclick=()=>{cart[lineId]--;if(cart[lineId]<=0){delete cart[lineId];delete cartItemNotes[lineId];delete cartSupplements[lineId]}renderCart()};r.querySelector('[data-a=plus]').onclick=()=>{cart[lineId]++;renderCart()};r.querySelector('[data-a=supplements]').onclick=()=>openCartSupplements(lineId);const noteBtn=r.querySelector('[data-a=note]');if(noteBtn)noteBtn.onclick=()=>openCartItemNote(lineId);root.appendChild(r)});if(scrollToLatest&&lines.length){requestAnimationFrame(()=>{root.scrollTo({top:root.scrollHeight,behavior:'smooth'})})}$('subtotal').textContent=euro(subtotal);$('discountLine').hidden=discountAmount<=0;$('discountValue').textContent=`− ${euro(discountAmount)}`;$('discountButton').classList.toggle('active',discountAmount>0);$('total').textContent=euro(total);$('cartTotalDisplay').textContent=euro(total);const pieces=lines.reduce((n,{quantity})=>n+quantity,0);if($('cartItemCount'))$('cartItemCount').textContent=pieces;if($('cartTotalLabel'))$('cartTotalLabel').textContent=tableOrderDraft?'Totale ordine':'Totale da pagare';if(payment==='Contanti'&&cashReceived>0)changeDue=Math.max(0,roundMoney(cashReceived-total));const payBtn=$('payButton');if(payBtn){payBtn.disabled=!lines.length||tableOrderDraftSaving;payBtn.innerHTML=tableOrderDraft?(tableOrderDraftSaving?'<span>…</span> SALVATAGGIO…':'<span>＋</span> AGGIUNGI AL TAVOLO'):'<span>▸</span> PAGA'}$('payCount').textContent=lines.length?`${lines.length} ${lines.length===1?'riga':'righe'}`:'';const showChange=payment==='Contanti'&&cashReceived>0;$('changeBanner').hidden=!showChange;if(showChange){$('changeBannerValue').textContent=euro(changeDue);$('changeBannerSub').textContent=`Ricevuti ${euro(cashReceived)} su ${euro(total)}`}if(isPayOpen()&&!lines.length)showPay(false);const mode=fiscalMode();const businessReady=mode!=='dco'||dcoBusinessValidation().ok;$('issueButton').disabled=!lines.length||!payment||isIssuing||!businessReady||(mode==='epson'&&dcoRealTestEnabled);$('issueButton').title=!businessReady?'Completa i dati dell’attività in Documento Commerciale Online.':(mode==='epson'&&dcoRealTestEnabled?'Emissione Epson bloccata durante la prova DCO reale.':'');renderLotteryUi();if(!isIssuing)$('issueButton').innerHTML=mode==='dco'?'<span>▧</span> EMETTI E STAMPA':'<span>▧</span> EMETTI DOCUMENTO';const safety=$('issueSafety');if(safety)safety.textContent=mode==='dco'?'Documento commerciale online e stampa immediata ESC/POS sulla stampante di rete.':'Emissione fiscale reale tramite Epson FP-81II RT.';if($('dcoDraftSummary'))renderDcoDraftSummary()}
document.querySelectorAll('[data-pay]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-pay]').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');payment=b.dataset.pay;if(payment!=='Carta')lotteryCode='';renderCart()});$('trashCart').onclick=()=>{const wasTableDraft=!!tableOrderDraft;resetSale();if(wasTableDraft){showView('tavoli');toast('Ordine tavolo annullato')}};$('holdButton').onclick=()=>{if(tableOrderDraft)return toast('Completa o annulla prima l’ordine del tavolo');openHoldDialog()};$('holdSave').onclick=parkCurrentOrder;$('closeHold').onclick=()=>$('holdDialog').close();$('payButton').onclick=()=>{if(!cartLines().length)return toast('Aggiungi almeno un prodotto');if(tableOrderDraft){saveTableOrderFromCart();return}showPay(true)};$('backToCart').onclick=()=>showPay(false);
function resetSale(){cart={};cartItemNotes={};cartSupplements={};manualItems=[];payment='';lotteryCode='';cashReceived=0;changeDue=0;discountAmount=0;activeTableCheckout=null;tableOrderDraft=null;tableOrderDraftSaving=false;showPay(false);document.querySelectorAll('[data-pay]').forEach(x=>x.classList.remove('selected'));renderCart()}

function row(icon,title,sub,id,type){return `<div class="data-row"><div class="row-icon">${icon}</div><div><strong>${title}</strong><small>${sub}</small></div><div class="row-actions"><button class="edit" data-edit="${type}" data-id="${id}">Modifica</button><button class="delete" data-delete="${type}" data-id="${id}">Elimina</button></div></div>`}
function bindRows(){document.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>({category:openCategory,product:openProduct,department:openDepartment}[b.dataset.edit](b.dataset.id)));document.querySelectorAll('[data-delete]').forEach(b=>b.onclick=()=>removeItem(b.dataset.delete,b.dataset.id))}
async function removeItem(type,id){if(type==='category'&&products.some(p=>p.categoryId===id))return alert('Questa categoria contiene prodotti. Sposta o elimina prima i prodotti collegati.');if(type==='department'&&products.some(p=>p.departmentId===id))return alert('Questo reparto è utilizzato da uno o più prodotti.');if(!confirm('Eliminare definitivamente?'))return;try{if(getSession())await cloudDelete(type,id);if(type==='category'){categories=categories.filter(x=>x.id!==id);save(K.categories,categories);renderCategoryManager();renderCategoryButtons()}if(type==='product'){products=products.filter(x=>x.id!==id);save(K.products,products);renderProductManager();renderProducts()}if(type==='department'){departments=departments.filter(x=>x.id!==id);save(K.departments,departments);renderDepartmentManager()}toast(getSession()?'Elemento eliminato e sincronizzato':'Elemento eliminato localmente')}catch(e){alert(`Impossibile eliminare dal cloud: ${e.message}`)}}
function renderCategoryManager(){const root=$('categoriesTable');root.innerHTML=categories.length?categories.map(c=>row(`<span class="category-color-dot" style="background:${c.color||'#4F8FD8'}"></span>${c.icon}`,c.name,`${products.filter(p=>p.categoryId===c.id).length} prodotti`,c.id,'category')).join(''):'<div class="stats-empty">Nessuna categoria.</div>';bindRows()}
function renderProductManager(){const root=$('productsTable');root.innerHTML=products.length?products.map(p=>{const c=categoryById(p.categoryId),d=departmentById(p.departmentId),src=productImageSrc(p),visual=src?`<img class="row-photo" src="${src}" alt="">`:`<span class="row-color-swatch" style="background:${c?.color||'#4F8FD8'}" aria-hidden="true"></span>`;return row(visual,p.name,`${euro(p.price)} · ${c?.name||'Senza categoria'} · Reparto ${d?.number||'—'} IVA ${d?.vat??'—'}%`,p.id,'product')}).join(''):'<div class="stats-empty">Nessun prodotto. Premi “Nuovo prodotto”.</div>';bindRows()}
function renderDepartmentManager(){const root=$('departmentsTable');root.innerHTML=departments.length?departments.map(d=>row('%',d.name,`Reparto Epson ${d.number} · IVA ${d.vat}%`,d.id,'department')).join(''):'<div class="stats-empty">Nessun reparto configurato.</div>';bindRows()}

// Gestione finestre e moduli catalogo
const categoryDialog=$('categoryDialog'),productDialog=$('productDialog'),departmentDialog=$('departmentDialog');let pendingProductImage='',pendingLibraryImageId='';
function renderIconLibrary(selected=''){const root=$('iconLibrary');root.innerHTML=Object.entries(iconGroups).map(([g,icons])=>`<div class="icon-group"><h3>${g}</h3><div class="icon-grid">${icons.map(i=>`<button type="button" class="icon-option ${i===selected?'selected':''}" data-icon="${i}">${i}</button>`).join('')}</div></div>`).join('');root.querySelectorAll('[data-icon]').forEach(b=>b.onclick=()=>{$('categoryIcon').value=b.dataset.icon;$('selectedIcon').textContent=`${b.dataset.icon} Icona selezionata`;root.querySelectorAll('.icon-option').forEach(x=>x.classList.remove('selected'));b.classList.add('selected')})}
function renderColorPalette(selected='#4F8FD8'){const root=$('categoryColorPalette');root.innerHTML=categoryColors.map(c=>`<button type="button" class="color-option ${c===selected?'selected':''}" data-color="${c}" style="background:${c}" aria-label="Colore ${c}"></button>`).join('');$('categoryColor').value=selected;$('selectedColor').textContent=`Colore selezionato: ${selected}`;root.querySelectorAll('[data-color]').forEach(b=>b.onclick=()=>{$('categoryColor').value=b.dataset.color;$('selectedColor').textContent=`Colore selezionato: ${b.dataset.color}`;root.querySelectorAll('.color-option').forEach(x=>x.classList.remove('selected'));b.classList.add('selected')})}
function openCategory(id=''){const c=categories.find(x=>x.id===id),color=c?.color||categoryColors[categories.length%categoryColors.length];$('categoryDialogTitle').textContent=c?'Modifica categoria':'Nuova categoria';$('categoryId').value=c?.id||'';$('categoryName').value=c?.name||'';$('categoryIcon').value=c?.icon||'▦';$('selectedIcon').textContent=`${c?.icon||'▦'} Icona selezionata`;renderColorPalette(color);renderIconLibrary(c?.icon||'▦');categoryDialog.showModal()}
$('addCategory').onclick=()=>openCategory();$('categoryForm').onsubmit=async e=>{e.preventDefault();let obj={id:$('categoryId').value||uid(),name:$('categoryName').value.trim(),icon:$('categoryIcon').value||'▦',color:$('categoryColor').value||'#4F8FD8'};try{if(getSession())obj=await cloudSaveCategory(obj);const i=categories.findIndex(x=>x.id===obj.id);if(i>=0)categories[i]=obj;else categories.push(obj);save(K.categories,categories);categoryDialog.close();renderCategoryManager();renderCategoryButtons();renderProducts();toast(getSession()?'Categoria salvata nel cloud':'Categoria salvata sul dispositivo')}catch(err){alert(`Categoria non salvata: ${err.message}`)}};
function fillSelects(){const cs=$('productCategory'),ds=$('productDepartment');cs.innerHTML=categories.map(c=>`<option value="${c.id}">${c.name}</option>`).join('');ds.innerHTML=departments.map(d=>`<option value="${d.id}">Reparto ${d.number} · ${d.name} · IVA ${d.vat}%</option>`).join('')}
function renderProductImagePreview(){const root=$('productImagePreview'),src=pendingLibraryImageId?libraryImageSrc(pendingLibraryImageId):pendingProductImage,item=libraryImageById(pendingLibraryImageId);root.innerHTML=src?`<img src="${src}" alt="Anteprima prodotto">${item?`<small class="library-selection-label">Libreria: ${item.name}</small>`:''}`:'Nessuna immagine'}
function fillProductLibraryCategories(){const select=$('productLibraryCategory');const cats=[...new Set(productImageLibraryVisible.map(x=>x.category))].sort((a,b)=>a.localeCompare(b,'it'));select.innerHTML='<option value="all">Tutte le categorie</option>'+cats.map(c=>`<option value="${c}">${c}</option>`).join('')}
function renderProductImageLibrary(){const root=$('productLibraryGrid'),q=($('productLibrarySearch').value||'').trim().toLowerCase(),cat=$('productLibraryCategory').value||'all';const list=productImageLibraryVisible.filter(item=>(cat==='all'||item.category===cat)&&(!q||`${item.name} ${item.category} ${(item.tags||[]).join(' ')}`.toLowerCase().includes(q)));root.innerHTML=list.length?list.map(item=>`<button type="button" class="library-image-card ${item.id===pendingLibraryImageId?'selected':''}" data-library-image="${item.id}"><img src="${item.file}" alt=""><strong>${item.name}</strong><small>${item.category}</small></button>`).join(''):'<div class="stats-empty">Nessuna immagine trovata.</div>';root.querySelectorAll('[data-library-image]').forEach(b=>b.onclick=()=>{pendingLibraryImageId=b.dataset.libraryImage;pendingProductImage='';$('productImageInput').value='';renderProductImagePreview();$('productImageLibraryPanel').hidden=true})}
function openProductImageLibrary(){fillProductLibraryCategories();$('productLibrarySearch').value='';$('productLibraryCategory').value='all';$('productImageLibraryPanel').hidden=false;renderProductImageLibrary()}
function openProduct(id=''){if(!categories.length||!departments.length)return alert('Crea prima almeno una categoria e un reparto.');fillSelects();const p=products.find(x=>x.id===id);$('productDialogTitle').textContent=p?'Modifica prodotto':'Nuovo prodotto';$('productId').value=p?.id||'';$('productName').value=p?.name||'';$('productPrice').value=p?String(p.price).replace('.',','):'';$('productCategory').value=p?.categoryId||categories[0].id;$('productDepartment').value=p?.departmentId||departments[0].id;pendingProductImage=p?.image||'';pendingLibraryImageId=p?.imageLibraryId||'';$('productImageInput').value='';$('productImageLibraryPanel').hidden=true;$('productShowPrice').checked=p?p.showPrice!==false:true;$('productVariablePrice').checked=!!p?.variablePrice;syncVariablePriceUi();renderProductImagePreview();productDialog.showModal()}
function syncVariablePriceUi(){const v=$('productVariablePrice')?.checked;const price=$('productPrice');if(!price)return;price.disabled=!!v;price.placeholder=v?'definito al momento della vendita':'0,00';if(v)price.value=''}
$('productVariablePrice')?.addEventListener('change',syncVariablePriceUi);
$('addProduct').onclick=()=>openProduct();const addProductBottom=$('addProductBottom');if(addProductBottom)addProductBottom.onclick=()=>openProduct();$('chooseProductLibrary').onclick=openProductImageLibrary;$('closeProductLibrary').onclick=()=>{$('productImageLibraryPanel').hidden=true};$('productLibrarySearch').oninput=renderProductImageLibrary;$('productLibraryCategory').onchange=renderProductImageLibrary;$('productImageInput').onchange=async e=>{const file=e.target.files?.[0];if(!file)return;if(!file.type.startsWith('image/'))return alert('Seleziona un file immagine.');try{pendingProductImage=await compressProductImage(file);pendingLibraryImageId='';$('productImageLibraryPanel').hidden=true;renderProductImagePreview()}catch(err){alert(err.message)}};$('removeProductImage').onclick=()=>{pendingProductImage='';pendingLibraryImageId='';$('productImageInput').value='';$('productImageLibraryPanel').hidden=true;renderProductImagePreview()};
async function compressProductImage(file){return new Promise((resolve,reject)=>{const img=new Image(),url=URL.createObjectURL(file);img.onload=()=>{const size=420,canvas=document.createElement('canvas');canvas.width=size;canvas.height=size;const ctx=canvas.getContext('2d'),scale=Math.max(size/img.width,size/img.height),w=img.width*scale,h=img.height*scale;ctx.drawImage(img,(size-w)/2,(size-h)/2,w,h);URL.revokeObjectURL(url);resolve(canvas.toDataURL('image/jpeg',.72))};img.onerror=()=>{URL.revokeObjectURL(url);reject(new Error('Impossibile leggere l’immagine.'))};img.src=url})}
$('productForm').onsubmit=async e=>{e.preventDefault();const variablePrice=$('productVariablePrice').checked;const raw=$('productPrice').value.trim();const price=variablePrice?0:Number(raw.replace(',','.'));if(!variablePrice&&(!raw||!Number.isFinite(price)||price<0))return alert('Inserisci un prezzo valido.');let obj={id:$('productId').value||uid(),name:$('productName').value.trim(),price,icon:'',image:pendingProductImage,imageLibraryId:pendingLibraryImageId,categoryId:$('productCategory').value,departmentId:$('productDepartment').value,showPrice:$('productShowPrice').checked,variablePrice};try{if(getSession())obj=await cloudSaveProduct(obj);const i=products.findIndex(x=>x.id===obj.id);if(i>=0)products[i]=obj;else products.push(obj);save(K.products,products);productDialog.close();renderProductManager();renderProducts();toast(getSession()?'Prodotto salvato nel cloud':'Prodotto salvato sul dispositivo')}catch(err){alert(`Prodotto non salvato: ${err.message}`)}};
function openDepartment(id=''){const d=departments.find(x=>x.id===id);$('departmentDialogTitle').textContent=d?'Modifica reparto':'Nuovo reparto';$('departmentId').value=d?.id||'';$('departmentName').value=d?.name||'';$('departmentNumber').value=d?.number||'';$('departmentVat').value=d?String(d.vat).replace('.',','):'';departmentDialog.showModal()}
$('addDepartment').onclick=()=>openDepartment();$('departmentForm').onsubmit=async e=>{e.preventDefault();const number=Number($('departmentNumber').value),vat=Number($('departmentVat').value.replace(',','.'));if(departments.some(d=>d.number===number&&d.id!==$('departmentId').value))return alert('Esiste già un reparto con questo numero Epson.');let obj={id:$('departmentId').value||uid(),name:$('departmentName').value.trim(),number,vat};try{if(getSession())obj=await cloudSaveDepartment(obj);const i=departments.findIndex(x=>x.id===obj.id);if(i>=0)departments[i]=obj;else departments.push(obj);save(K.departments,departments);departmentDialog.close();renderDepartmentManager();renderProducts();toast(getSession()?'Reparto salvato nel cloud':'Reparto salvato sul dispositivo')}catch(err){alert(`Reparto non salvato: ${err.message}`)}};
const cartItemNoteForm=$('cartItemNoteForm');if(cartItemNoteForm)cartItemNoteForm.onsubmit=e=>{e.preventDefault();saveCartItemNote()};
if($('cartItemNoteRemove'))$('cartItemNoteRemove').onclick=clearCartItemNote;
if($('supplementDone'))$('supplementDone').onclick=closeCartSupplements;if($('supplementClose'))$('supplementClose').onclick=closeCartSupplements;if($('dcoCredentialsGuide'))$('dcoCredentialsGuide').onclick=()=>{const url='https://www.youtube.com/watch?v=E8mnc1HtqRg';try{window.open(url,'_system')}catch(e){try{location.href=url}catch(_){toast('Impossibile aprire la guida',4500)}}};
document.querySelectorAll('.dialog-close').forEach(b=>b.onclick=()=>{const d=b.closest('dialog');if(d?.open)d.close()});
document.querySelectorAll('dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d)d.close()}));
function loadObject(k,f){try{return JSON.parse(localStorage.getItem(k)||'null')||f}catch{return f}}
function statsDateRange(){const mode=$('statsPeriod')?.value||'30',now=new Date(),end=new Date(now);end.setHours(23,59,59,999);let start=new Date(0);if(mode==='today'){start=new Date(now);start.setHours(0,0,0,0)}else if(mode==='7'||mode==='30'){start=new Date(now);start.setDate(start.getDate()-Number(mode)+1);start.setHours(0,0,0,0)}else if(mode==='month'){start=new Date(now.getFullYear(),now.getMonth(),1)}else if(mode==='custom'){start=$('statsFrom').value?new Date($('statsFrom').value+'T00:00:00'):new Date(0);if($('statsTo').value)end.setTime(new Date($('statsTo').value+'T23:59:59').getTime())}return{start,end}}
function normalizeStatsProductName(value){return String(value||'').trim().replace(/\s+/g,' ').toLocaleLowerCase('it-IT')}
function statsProductNameIndex(){const idx=new Map();for(const p of products){const key=normalizeStatsProductName(p?.name);if(!key)continue;if(!idx.has(key))idx.set(key,String(p.id||''));else if(idx.get(key)!==String(p.id||''))idx.set(key,'')}return idx}
function statsLineGroupKey(line,nameIndex){const productId=String(line?.productId||'').trim();if(productId)return `id:${productId}`;const nameKey=normalizeStatsProductName(line?.name);const catalogId=nameKey?String(nameIndex?.get(nameKey)||''):'';return catalogId?`id:${catalogId}`:`name:${nameKey||'prodotto-senza-nome'}`}
function dcoVoidStatus(sale){return String(sale?.voidStatus||'').trim()}
function dcoSaleIsVoided(sale){return dcoVoidStatus(sale)==='annullata'}
function dcoVoidSetSale(saleId,patch={}){
  const sale=sales.find(x=>String(x?.id||'')===String(saleId||''));if(!sale)return null;
  Object.assign(sale,patch);save(K.sales,sales);renderStats();return sale
}
function dcoVoidClearPendingState(saleId){
  const sale=sales.find(x=>String(x?.id||'')===String(saleId||''));if(!sale)return null;
  if(sale.voidStatus==='in_corso'){delete sale.voidStatus;delete sale.voidStartedAt;delete sale.voidReason;delete sale.voidOriginalNumber;save(K.sales,sales);renderStats()}
  return sale
}
function filteredSales(includeVoided=false){const {start,end}=statsDateRange(),pid=$('statsProduct')?.value||'all',selected=pid==='all'?null:products.find(p=>String(p.id)===String(pid)),selectedName=normalizeStatsProductName(selected?.name);return sales.filter(x=>{const d=new Date(x.date);if(!(d>=start&&d<=end))return false;if(!includeVoided&&dcoSaleIsVoided(x))return false;return pid==='all'||(x.lines||[]).some(l=>String(l.productId||'')===String(pid)||(!l.productId&&selectedName&&normalizeStatsProductName(l.name)===selectedName))})}
function populateStatsProducts(){const x=$('statsProduct');if(!x)return;const v=x.value;x.innerHTML='<option value="all">Tutti i prodotti</option>'+products.map(p=>`<option value="${p.id}">${p.name}</option>`).join('');x.value=[...x.options].some(o=>o.value===v)?v:'all'}
function drawChart(c,labels,values,type='bar'){if(!c)return;const ctx=c.getContext('2d'),w=c.clientWidth||500,h=220,dpr=window.devicePixelRatio||1;c.width=w*dpr;c.height=h*dpr;ctx.scale(dpr,dpr);ctx.clearRect(0,0,w,h);ctx.font='11px system-ui';ctx.fillStyle='#71827f';if(!values.length||Math.max(...values)<=0){ctx.textAlign='center';ctx.fillText('Nessun dato nel periodo selezionato',w/2,h/2);return}const max=Math.max(...values)*1.12,p={l:42,r:12,t:15,b:42},cw=w-p.l-p.r,ch=h-p.t-p.b;ctx.strokeStyle='#dfe7e5';ctx.beginPath();ctx.moveTo(p.l,p.t);ctx.lineTo(p.l,p.t+ch);ctx.lineTo(p.l+cw,p.t+ch);ctx.stroke();ctx.strokeStyle='#1687B5';ctx.fillStyle='#2FA8D7';if(type==='line'){ctx.beginPath();values.forEach((v,i)=>{const x=p.l+(values.length===1?cw/2:i*cw/(values.length-1)),y=p.t+ch-(v/max)*ch;i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.lineWidth=2.5;ctx.stroke();values.forEach((v,i)=>{const x=p.l+(values.length===1?cw/2:i*cw/(values.length-1)),y=p.t+ch-(v/max)*ch;ctx.beginPath();ctx.arc(x,y,3,0,Math.PI*2);ctx.fill()})}else{const bw=Math.max(8,cw/values.length*.58);values.forEach((v,i)=>{const x=p.l+(i+.5)*cw/values.length-bw/2,y=p.t+ch-(v/max)*ch;ctx.fillRect(x,y,bw,p.t+ch-y)})}ctx.fillStyle='#71827f';ctx.textAlign='center';labels.forEach((l,i)=>{if(labels.length>8&&i%Math.ceil(labels.length/8))return;const x=p.l+(type==='line'?(labels.length===1?cw/2:i*cw/(labels.length-1)):(i+.5)*cw/labels.length);ctx.fillText(String(l).slice(0,12),x,h-16)})}
function isCardPayment(value){const method=String(value||'').trim().toLowerCase().replace(/[_-]+/g,' ');return method==='carta'||method==='card'||method==='credit card'||method==='debit card'||method==='elettronico'||method==='electronic'||method==='pagamento elettronico'||method.includes('carta')||method.includes('card')}
function dcoSaleOriginalNumber(sale){return String(sale?.dcoDocumentNumber||sale?.receiptNumber||'').trim()}
function dcoSaleLooksLikeDco(sale){const n=dcoSaleOriginalNumber(sale);return !!n&&(sale?.fiscalSource==='DCO'||!!sale?.dcoDocumentId||!!sale?.dcoDocumentNumber||/^DC[A-Z0-9]/i.test(n))}
function dcoSaleIsToday(sale){const d=new Date(sale?.date||0),now=new Date();return !Number.isNaN(d.getTime())&&d.getFullYear()===now.getFullYear()&&d.getMonth()===now.getMonth()&&d.getDate()===now.getDate()}
function dcoSaleCanVoid(sale){return dcoSaleLooksLikeDco(sale)&&dcoSaleIsToday(sale)&&!!dcoSaleOriginalNumber(sale)&&!['annullata','in_corso','esito_da_verificare'].includes(dcoVoidStatus(sale))}
function renderStats(){
  populateStatsProducts();
  const list=filteredSales(false),history=filteredSales(true),total=list.reduce((sum,x)=>sum+Number(x.total||0),0),items=list.reduce((sum,x)=>sum+Number(x.items||0),0),avg=list.length?total/list.length:0,cardSales=list.filter(x=>isCardPayment(x.payment)),cardTotal=cardSales.reduce((sum,x)=>sum+Number(x.total||0),0),cardShare=total?Math.round(cardTotal/total*100):0;
  $('statsCards').innerHTML=`<div class="stat-card"><small>Incasso</small><strong>${euro(total)}</strong></div><div class="stat-card stat-card-payment"><small>Pagamenti con carta</small><strong>${euro(cardTotal)}</strong><span class="stat-card-meta">${cardSales.length} ${cardSales.length===1?'scontrino':'scontrini'} · ${cardShare}% dell’incasso</span></div><div class="stat-card"><small>Scontrini</small><strong>${list.length}</strong></div><div class="stat-card"><small>Scontrino medio</small><strong>${euro(avg)}</strong></div><div class="stat-card"><small>Prodotti venduti</small><strong>${items}</strong></div>`;
  const by=new Map(),nameIndex=statsProductNameIndex();
  list.forEach(sale=>{const lines=sale.lines||[],gross=Number(sale.subtotal)||lines.reduce((sum,line)=>sum+Number(line.lineTotal||0),0),ratio=gross>0?Math.max(0,Math.min(1,Number(sale.total||0)/gross)):1;lines.forEach(line=>{const key=statsLineGroupKey(line,nameIndex),catalogId=key.startsWith('id:')?key.slice(3):'',catalogProduct=catalogId?products.find(p=>String(p.id)===catalogId):null,displayName=String(catalogProduct?.name||line.name||'Prodotto senza nome').trim()||'Prodotto senza nome',row=by.get(key)||{name:displayName,quantity:0,revenue:0};row.quantity+=Number(line.quantity||0);row.revenue+=Number(line.lineTotal||0)*ratio;by.set(key,row)})});
  const sort=$('statsSort')?.value||'revenue',rank=[...by.values()].sort((a,b)=>b[sort]-a[sort]);
  $('productStatsTable').innerHTML=rank.length?rank.map((x,i)=>`<div class="data-row product-stat-row"><div class="row-icon">${i+1}</div><div><strong>${x.name}</strong><small>${x.quantity} unità vendute</small></div><div class="metric"><small>Incasso</small><strong>${euro(x.revenue)}</strong></div><div class="metric"><small>Quota</small><strong>${total?Math.round(x.revenue/total*100):0}%</strong></div></div>`).join(''):'<div class="stats-empty">Nessuna vendita con dettaglio prodotti.</div>';
  $('salesTable').innerHTML=history.length?[...history].reverse().slice(0,30).map(sale=>{
    const state=dcoVoidStatus(sale),voidRef=String(sale.voidDocumentNumber||sale.voidDocumentId||'').trim();
    let action='';
    if(state==='annullata')action=`<span class="sale-void-status ok">ANNULLATO</span>${voidRef?`<small class="sale-void-ref">Annullo N. ${escapeHtml(voidRef)}</small>`:''}`;
    else if(state==='esito_da_verificare')action='<span class="sale-void-status warning">ANNULLAMENTO DA VERIFICARE</span>';
    else if(state==='in_corso')action='<span class="sale-void-status progress">ANNULLAMENTO IN CORSO</span>';
    else if(dcoSaleCanVoid(sale))action=`<button type="button" class="sale-void-lab" data-sale-void="${escapeHtml(sale.id)}">Annulla DCO</button>`;
    return `<div class="data-row sale-history-row ${state==='annullata'?'sale-history-voided':''}"><div class="row-icon">${state==='annullata'?'↩':'🧾'}</div><div><strong>${euro(sale.total)}</strong><small>${new Date(sale.date).toLocaleString('it-IT')} · ${sale.payment}${Number(sale.discount)>0?` · Sconto ${euro(sale.discount)}`:''}${sale.receiptNumber?` · N. ${sale.receiptNumber}`:''}${state==='annullata'?' · ANNULLATO':''}</small></div><div class="sale-history-actions"><strong>${sale.items} articoli</strong>${action}</div></div>`
  }).join(''):'<div class="stats-empty">Nessuna vendita nel periodo selezionato.</div>';
  document.querySelectorAll('[data-sale-void]').forEach(btn=>btn.onclick=()=>dcoStartVoidForSale(btn.dataset.saleVoid));
  const days={};list.forEach(sale=>{const key=new Date(sale.date).toLocaleDateString('it-IT',{day:'2-digit',month:'2-digit'});days[key]=(days[key]||0)+Number(sale.total)});
  drawChart($('salesTrendChart'),Object.keys(days),Object.values(days),'line');drawChart($('productsChart'),rank.slice(0,8).map(x=>x.name),rank.slice(0,8).map(x=>x[sort]),'bar')
}
['statsPeriod','statsFrom','statsTo','statsProduct','statsSort'].forEach(id=>$(id)?.addEventListener('change',renderStats));$('refreshStatsCloud')?.addEventListener('click',()=>syncSalesFromCloud(true));$('jumpLatestSales')?.addEventListener('click',()=>{$('latestSalesSection')?.scrollIntoView({behavior:'smooth',block:'start'})});window.addEventListener('resize',()=>{if($('view-statistiche').classList.contains('active'))renderStats()});document.addEventListener('visibilitychange',()=>{if(!document.hidden&&getSession())syncSalesFromCloud(false)});
// v1.15.0: nessun rinnovo Fisconline al semplice ritorno in primo piano; il controllo automatico avviene all'avvio.

function norm(v){return String(v||'').trim().replace(/^https?:\/\//i,'').replace(/\/.*$/,'')}
function valid(v){return /^(25[0-5]|2[0-4]\d|1?\d?\d)(\.(25[0-5]|2[0-4]\d|1?\d?\d)){3}$/.test(norm(v))}
function endpoint(v){return `http://${norm(v)||'—'}/cgi-bin/fpmate.cgi`}
function status(type,text){$('headerDot').className=type;$('headerRt').textContent=text}
function soapEnvelope(request){return `<?xml version="1.0" encoding="utf-8"?>\n<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">\n<s:Body>\n${request}\n</s:Body>\n</s:Envelope>\n`}
function parseEpsonResponse(text){const doc=new DOMParser().parseFromString(text,'text/xml');if(doc.querySelector('parsererror'))throw new Error('Risposta XML Epson non valida');const response=doc.getElementsByTagName('response')[0];if(!response)throw new Error('Risposta Epson priva del nodo response');const info={},addInfo=response.getElementsByTagName('addInfo')[0];if(addInfo)Array.from(addInfo.children).forEach(el=>{if(el.tagName!=='elementList')info[el.tagName]=el.textContent||''});return{success:/^(1|true)$/i.test(response.getAttribute('success')||''),code:response.getAttribute('code')||'',status:response.getAttribute('status')||'',info,raw:text}}
async function sendEpson(request,timeoutMs=20000){const ip=localStorage.getItem(K.ip)||'';if(!valid(ip))throw new Error('Configura prima un indirizzo IP Epson valido');const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeoutMs);try{const response=await fetch(endpoint(ip),{method:'POST',headers:{'Content-Type':'text/xml; charset=UTF-8','If-Modified-Since':'Thu, 01 Jan 1970 00:00:00 GMT','SOAPAction':'""'},body:soapEnvelope(request),signal:controller.signal});const text=await response.text();if(!response.ok)throw new Error(`Errore HTTP ${response.status}`);return parseEpsonResponse(text)}catch(err){if(err.name==='AbortError')throw new Error('Nessuna risposta Epson entro il tempo previsto');throw err}finally{clearTimeout(timer)}}
function buildFiscalReceipt(){const subtotal=cartSubtotal();if(discountAmount<0||discountAmount>=subtotal)throw new Error('Lo sconto deve essere inferiore al subtotale.');const rows=expandedCartFiscalLines().map(({product:p,quantity:q,isSupplement})=>{const dep=departmentById(p.departmentId);if(!dep)throw new Error(`Reparto non configurato per ${p.name}`);const description=isSupplement?`SUPPL. ${p.name}`:p.name;return `<printRecItem operator="1" description="${xmlEscape(description)}" quantity="${q}" unitPrice="${money(p.price)}" department="${dep.number}" justification="1" />`}).join('\n');const discountLine=discountAmount>0?`<printRecSubtotalAdjustment operator="1" adjustmentType="2" description="SCONTO" amount="${money(discountAmount)}" justification="1" />`:'';const isElectronic=payment==='Carta',type=isElectronic?2:0,index=isElectronic?2:0,description=isElectronic?'PAGAMENTO ELETTRONICO':'CONTANTI',total=money(cartTotal()),lotteryLine=isElectronic&&cartTotal()>=1&&lotteryCode?`<printRecLotteryID operator="1" code="${xmlEscape(lotteryCode)}" />`:'';return `<printerFiscalReceipt>\n<beginFiscalReceipt operator="1" />\n${rows}\n${discountLine}\n${lotteryLine}\n<printRecTotal operator="1" description="${description}" payment="${total}" paymentType="${type}" index="${index}" justification="1" />\n<endFiscalReceipt operator="1" />\n</printerFiscalReceipt>`}


// ---------------------------------------------------------------------------
// TEST HARDWARE STAMPANTE 80 MM (ESC/POS)
// Questa sezione e' indipendente dal driver fiscale Epson FP-Mate.
// ---------------------------------------------------------------------------
let printerTestInitialized=false;
function printerNativePlugin(){return window.Capacitor?.Plugins?.CassaIQPrinter||null}
function printerPlatform(){try{return window.Capacitor?.getPlatform?.()||'web'}catch{return'web'}}
let dcoPendingEmissionTiming=null;
function dcoTimingBegin(){
  const now=Date.now();
  dcoPendingEmissionTiming={version:'1.14.82 lottery-logo-error-flow',platform:printerPlatform(),runner:{prepPollMs:350,finalPollMs:1100,metaWatchMs:1200,metadataRequiresDate:false,iosWebViewVisibleDuringEmission:true,operationIsolation:true,evidenceMode:'visible-current-document',androidVerifyFallback:true,androidActiveWebView:true,androidPortalMasked:true,dynamicDcoRows:true,sessionPreflight:false},inputAt:now,marks:[{key:'input',label:'Input emissione',at:now}]};
  dcoRenderQuickTiming(null);return dcoPendingEmissionTiming
}
function dcoTimingMark(target,key,label,at=Date.now()){
  const timing=target?.timing||target;if(!timing||!key)return timing||null;
  if(!Array.isArray(timing.marks))timing.marks=[];
  if(!timing.marks.some(x=>x&&x.key===key))timing.marks.push({key,label:label||key,at:Number(at)||Date.now()});
  return timing
}
function dcoTimingLoadHistory(){const value=loadObjectSafe(K.dcoTimingHistory,[]);return Array.isArray(value)?value:[]}
function dcoTimingMsText(value){const ms=Number(value);if(!Number.isFinite(ms)||ms<0)return'—';return`${(ms/1000).toFixed(2).replace('.',',')} s`}
function dcoTimingResult(timing,extra={}){
  if(!timing)return null;const marks=Array.isArray(timing.marks)?timing.marks:[],inputAt=Number(timing.inputAt||marks.find(x=>x?.key==='input')?.at||0),find=key=>Number(marks.find(x=>x?.key===key)?.at||0),emittedAt=find('emitted-detected'),printAt=find('print-end'),abortedAt=find('aborted');
  return{version:timing.version||'1.14.82 lottery-logo-error-flow',platform:timing.platform||printerPlatform(),runner:timing.runner||{prepPollMs:350,finalPollMs:1100,metaWatchMs:1200,metadataRequiresDate:false,iosWebViewVisibleDuringEmission:true,operationIsolation:true,evidenceMode:'visible-current-document',androidVerifyFallback:true,androidActiveWebView:true,androidPortalMasked:true,dynamicDcoRows:true,sessionPreflight:false},capturedAt:new Date().toISOString(),outcome:extra.outcome||'unknown',documentNumber:extra.documentNumber||'',printed:!!extra.printed,printError:extra.printError||'',totalToEmissionMs:inputAt&&emittedAt?emittedAt-inputAt:null,totalToPrintMs:inputAt&&printAt?printAt-inputAt:null,totalToStopMs:inputAt&&abortedAt?abortedAt-inputAt:null,stages:marks.map(x=>({key:x.key,label:x.label,elapsedMs:inputAt?Number(x.at)-inputAt:null}))}
}
function dcoTimingSummaryText(result){
  if(!result)return'';const lines=[];
  if(Number.isFinite(result.totalToEmissionMs))lines.push(`Input → emissione: ${dcoTimingMsText(result.totalToEmissionMs)}`);
  else if(Number.isFinite(result.totalToStopMs))lines.push(`Input → blocco/interruzione: ${dcoTimingMsText(result.totalToStopMs)}`);
  const wanted=['automation-start','wizard-open','cart-filled','verify-clicked','final-page','final-armed','confirm-clicked','proceed-clicked','emitted-detected','metadata-ready','print-end'];
  const stageNames={'automation-start':'avvio DCO','wizard-open':'apertura documento','cart-filled':'carrello','verify-clicked':'verifica','final-page':'pagina finale','final-armed':'invio pronto','confirm-clicked':'conferma','proceed-clicked':'richiesta AdE','emitted-detected':'emesso','metadata-ready':'numero ufficiale','print-end':'stampa'};
  const details=(result.stages||[]).filter(x=>wanted.includes(x.key)&&Number.isFinite(x.elapsedMs)).map(x=>`${stageNames[x.key]||x.label}: ${dcoTimingMsText(x.elapsedMs)}`);
  if(details.length)lines.push(details.join(' · '));
  if(Number.isFinite(result.totalToPrintMs))lines.push(`Input → fine stampa: ${dcoTimingMsText(result.totalToPrintMs)}`);
  return lines.join('\n')
}
function dcoRenderQuickTiming(result){const el=$('dcoQuickTiming');if(!el)return;if(!result){el.hidden=true;el.textContent='';return}el.hidden=false;el.textContent=dcoTimingSummaryText(result)}
function dcoRenderTimingHistory(){
  const el=$('dcoTimingHistory');if(!el)return;const rows=dcoTimingLoadHistory().slice(0,10);if(!rows.length){el.textContent='Nessuna misurazione emissione registrata.';return}
  el.textContent=rows.map((r,i)=>{const when=new Date(r.capturedAt);const stamp=Number.isNaN(when.getTime())?'':when.toLocaleString('it-IT');const total=Number.isFinite(r.totalToEmissionMs)?dcoTimingMsText(r.totalToEmissionMs):`interrotta a ${dcoTimingMsText(r.totalToStopMs)}`;return`${i+1}. ${String(r.platform||'').toUpperCase()} · ${stamp} · ${total}${r.documentNumber?` · ${r.documentNumber}`:''}`}).join('\n')
}
function dcoPersistEmissionTiming(timing,extra={}){
  const result=dcoTimingResult(timing,extra);if(!result)return null;const history=dcoTimingLoadHistory();history.unshift(result);localStorage.setItem(K.dcoTimingHistory,JSON.stringify(history.slice(0,20)));dcoPendingEmissionTiming=null;dcoRenderQuickTiming(result);dcoRenderTimingHistory();
  dcoLastDiagnostic={capturedAt:new Date().toISOString(),routes:dcoRouteHistory.slice(),page:dcoLastDiagnostic?.page||null,emissionTimings:dcoTimingLoadHistory()};const out=$('dcoDiagnostic');if(out)out.textContent=JSON.stringify(dcoLastDiagnostic,null,2);return result
}
function printerSetResult(id,type,message){const el=$(id);if(!el)return;el.hidden=false;el.className=`test-result ${type||''}`.trim();el.textContent=message}
function printerSetBusy(button,busy,label){if(!button)return;if(!button.dataset.defaultLabel)button.dataset.defaultLabel=button.textContent;button.disabled=!!busy;button.textContent=busy?(label||'Attendere…'):button.dataset.defaultLabel}
function printerBytesToBase64(bytes){let binary='';const chunk=0x8000;for(let i=0;i<bytes.length;i+=chunk)binary+=String.fromCharCode(...bytes.slice(i,i+chunk));return btoa(binary)}
function printerAscii(text){return Array.from(String(text),c=>{const n=c.charCodeAt(0);if(n===10)return 10;if(n===13)return 13;return n>=32&&n<=126?n:32})}
function printerConcat(...parts){const out=[];for(const p of parts)out.push(...p);return out}
function printerLine(left,right,width=48){left=printerPlainText(left||'').replace(/\s+/g,' ').trim();right=printerPlainText(right||'').replace(/\s+/g,' ').trim();const maxLeft=Math.max(0,width-right.length-(right?1:0));if(left.length>maxLeft)left=left.slice(0,maxLeft);const gap=Math.max(right?1:0,width-left.length-right.length);return(left+' '.repeat(gap)+right).padEnd(width).slice(0,width)+'\n'}
function printerInit(){return[0x1b,0x40]}
function printerCutPayload(){return printerConcat(printerInit(),[0x0a,0x0a,0x0a,0x1d,0x56,0x00])}
function printerDrawerPayload(){return printerConcat(printerInit(),[0x1b,0x70,0x00,0x32,0xfa])}
function printerTestPayload(connectionLabel){
  const now=new Date().toLocaleString('it-IT',{dateStyle:'short',timeStyle:'short'}).replace(/[^\x20-\x7E]/g,' ');
  const divider='------------------------------------------------\n';
  return printerConcat(
    printerInit(),
    [0x1b,0x61,0x01,0x1b,0x45,0x01,0x1d,0x21,0x11],printerAscii('CASSAIQ\n'),
    [0x1d,0x21,0x00],printerAscii('TEST STAMPANTE 80 MM\n'),[0x1b,0x45,0x00],
    printerAscii('STAMPANTE DI RETE / ESC-POS\n\n'),
    [0x1b,0x61,0x00],printerAscii(divider),
    printerAscii(printerLine('Prodotto prova','EUR 10,00')),
    printerAscii(printerLine('Prodotto prova 2','EUR 5,50')),
    printerAscii(divider),
    [0x1b,0x45,0x01],printerAscii(printerLine('TOTALE','EUR 15,50')),[0x1b,0x45,0x00],
    printerAscii(divider),
    printerAscii(`Collegamento: ${connectionLabel}\n`),
    printerAscii(`Data test: ${now}\n`),
    printerAscii('Protocollo ESC/POS: OK\n'),
    printerAscii('Larghezza stampa: 72 mm\n'),
    [0x1b,0x61,0x01],printerAscii('\n*** STAMPA NON FISCALE ***\n'),
    printerAscii('Test hardware CassaIQ completato\n'),
    [0x0a,0x0a,0x0a,0x1d,0x56,0x00]
  )
}
function printerPlainText(value){
  return String(value==null?'':value).replace(/[−–—]/g,'-').replace(/·/g,'|').replace(/[“”]/g,'\"').replace(/[‘’]/g,"'").normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^\x20-\x7E\n]/g,'?')
}
function printerWrapText(value,width=48){
  const text=printerPlainText(value).replace(/\s+/g,' ').trim();if(!text)return[];
  const words=text.split(' '),lines=[];let line='';
  for(const word of words){
    if(word.length>width){if(line){lines.push(line);line=''};for(let i=0;i<word.length;i+=width)lines.push(word.slice(i,i+width));continue}
    const candidate=line?`${line} ${word}`:word;
    if(candidate.length>width){lines.push(line);line=word}else line=candidate;
  }
  if(line)lines.push(line);return lines
}
function printerMoneyText(value){return `EUR ${Number(value||0).toFixed(2).replace('.',',')}`}
function printerCenterText(value,width=48){const text=printerPlainText(value).trim().slice(0,width),left=Math.max(0,Math.floor((width-text.length)/2));return' '.repeat(left)+text+'\n'}
function printerItemRow(description,vat,price,width=48){const descWidth=29,vatWidth=5,priceWidth=12,desc=printerPlainText(description).slice(0,descWidth),vatText=printerPlainText(vat).slice(0,vatWidth),priceText=printerPlainText(price).slice(0,priceWidth);return desc.padEnd(descWidth)+' '+vatText.padStart(vatWidth)+' '+priceText.padStart(priceWidth)+'\n'}
const RECEIPT_WIDTH=32;
const RECEIPT_FEED_LINES=6;
const RECEIPT_LOGO_PRINT_WIDTH=576; // 72 mm @ 203 dpi sulla stampante di rete ESC/POS di riferimento
const RECEIPT_LOGO_MAX_WIDTH=448;
const RECEIPT_LOGO_MAX_HEIGHT=190;
function dcoReceiptLogoLoadImage(dataUrl){
  return new Promise((resolve,reject)=>{
    const img=new Image();
    img.onload=()=>resolve(img);
    img.onerror=()=>reject(new Error('Impossibile leggere il logo.'));
    img.src=dataUrl;
  })
}
async function dcoReceiptLogoPrepareFile(file){
  if(!file||!String(file.type||'').startsWith('image/'))throw new Error('Seleziona un file immagine.');
  if(Number(file.size||0)>8*1024*1024)throw new Error('Il logo è troppo grande. Usa un file inferiore a 8 MB.');
  const url=URL.createObjectURL(file);
  try{
    const img=await dcoReceiptLogoLoadImage(url);
    const maxWork=1400,workScale=Math.min(1,maxWork/Math.max(img.naturalWidth||img.width||1,img.naturalHeight||img.height||1));
    const sw=Math.max(1,Math.round((img.naturalWidth||img.width||1)*workScale)),sh=Math.max(1,Math.round((img.naturalHeight||img.height||1)*workScale));
    const src=document.createElement('canvas');src.width=sw;src.height=sh;
    const sctx=src.getContext('2d',{willReadFrequently:true});sctx.fillStyle='#fff';sctx.fillRect(0,0,sw,sh);sctx.drawImage(img,0,0,sw,sh);
    const data=sctx.getImageData(0,0,sw,sh),px=data.data;
    let minX=sw,minY=sh,maxX=-1,maxY=-1;
    for(let y=0;y<sh;y++)for(let x=0;x<sw;x++){
      const i=(y*sw+x)*4,darkest=Math.min(px[i],px[i+1],px[i+2]);
      if(darkest<245){if(x<minX)minX=x;if(x>maxX)maxX=x;if(y<minY)minY=y;if(y>maxY)maxY=y}
    }
    if(maxX<minX||maxY<minY)throw new Error('Il logo risulta vuoto o completamente bianco.');
    const margin=Math.max(4,Math.round(Math.max(sw,sh)*.012));
    minX=Math.max(0,minX-margin);minY=Math.max(0,minY-margin);maxX=Math.min(sw-1,maxX+margin);maxY=Math.min(sh-1,maxY+margin);
    const cropW=maxX-minX+1,cropH=maxY-minY+1,scale=Math.min(RECEIPT_LOGO_MAX_WIDTH/cropW,RECEIPT_LOGO_MAX_HEIGHT/cropH);
    const outW=Math.max(1,Math.round(cropW*scale)),outH=Math.max(1,Math.round(cropH*scale));
    const out=document.createElement('canvas');out.width=outW;out.height=outH;
    const ctx=out.getContext('2d',{willReadFrequently:true});ctx.fillStyle='#fff';ctx.fillRect(0,0,outW,outH);ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';ctx.drawImage(src,minX,minY,cropW,cropH,0,0,outW,outH);
    const outData=ctx.getImageData(0,0,outW,outH),opx=outData.data;
    for(let i=0;i<opx.length;i+=4){
      const darkest=Math.min(opx[i],opx[i+1],opx[i+2]),v=darkest<215?0:255;
      opx[i]=v;opx[i+1]=v;opx[i+2]=v;opx[i+3]=255;
    }
    ctx.putImageData(outData,0,0);
    return out.toDataURL('image/png');
  }finally{URL.revokeObjectURL(url)}
}
async function dcoReceiptLogoEscPos(dataUrl){
  if(!dataUrl)return[];
  const img=await dcoReceiptLogoLoadImage(dataUrl),height=Math.max(1,Math.min(RECEIPT_LOGO_MAX_HEIGHT,Math.round(img.naturalHeight||img.height||1)));
  const canvas=document.createElement('canvas');canvas.width=RECEIPT_LOGO_PRINT_WIDTH;canvas.height=height;
  const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);
  const drawW=Math.min(RECEIPT_LOGO_MAX_WIDTH,Math.round((img.naturalWidth||img.width||1)*(height/(img.naturalHeight||img.height||height)))),drawH=Math.min(height,Math.round((img.naturalHeight||img.height||1)*(drawW/(img.naturalWidth||img.width||drawW))));
  const x=Math.max(0,Math.floor((canvas.width-drawW)/2)),y=Math.max(0,Math.floor((canvas.height-drawH)/2));
  ctx.drawImage(img,x,y,drawW,drawH);
  const px=ctx.getImageData(0,0,canvas.width,canvas.height).data,bytesPerRow=Math.ceil(canvas.width/8),raster=new Array(bytesPerRow*canvas.height).fill(0);
  for(let yy=0;yy<canvas.height;yy++)for(let xx=0;xx<canvas.width;xx++){
    const i=(yy*canvas.width+xx)*4,luma=.2126*px[i]+.7152*px[i+1]+.0722*px[i+2];
    if(luma<128)raster[yy*bytesPerRow+(xx>>3)]|=(0x80>>(xx&7));
  }
  const xL=bytesPerRow&0xff,xH=(bytesPerRow>>8)&0xff,yL=canvas.height&0xff,yH=(canvas.height>>8)&0xff;
  return[0x1d,0x76,0x30,0x00,xL,xH,yL,yH,...raster]
}
const EPSON_RECEIPT_LOGO_INDEX=9;
function writeLe16(bytes,offset,value){bytes[offset]=value&255;bytes[offset+1]=(value>>8)&255}
function writeLe32(bytes,offset,value){bytes[offset]=value&255;bytes[offset+1]=(value>>8)&255;bytes[offset+2]=(value>>16)&255;bytes[offset+3]=(value>>24)&255}
async function dcoReceiptLogoEpsonBmpBase64(dataUrl){
  if(!dataUrl)throw new Error('Carica prima un logo.');
  const img=await dcoReceiptLogoLoadImage(dataUrl),width=576,srcW=Math.max(1,img.naturalWidth||img.width||1),srcH=Math.max(1,img.naturalHeight||img.height||1),drawW=Math.min(RECEIPT_LOGO_MAX_WIDTH,srcW),scale=drawW/srcW,drawH=Math.max(1,Math.min(RECEIPT_LOGO_MAX_HEIGHT,Math.round(srcH*scale))),height=drawH;
  const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.fillStyle='#fff';ctx.fillRect(0,0,width,height);const x=Math.max(0,Math.floor((width-drawW)/2));ctx.drawImage(img,x,0,drawW,drawH);
  const px=ctx.getImageData(0,0,width,height).data,rowDataBytes=Math.ceil(width/8),rowSize=(rowDataBytes+3)&~3,pixelBytes=rowSize*height,offset=14+40+8,fileSize=offset+pixelBytes,bytes=new Array(fileSize).fill(0);
  bytes[0]=0x42;bytes[1]=0x4d;writeLe32(bytes,2,fileSize);writeLe32(bytes,10,offset);writeLe32(bytes,14,40);writeLe32(bytes,18,width);writeLe32(bytes,22,height);writeLe16(bytes,26,1);writeLe16(bytes,28,1);writeLe32(bytes,34,pixelBytes);writeLe32(bytes,38,203*39.3701);writeLe32(bytes,42,203*39.3701);writeLe32(bytes,46,2);writeLe32(bytes,50,2);
  // Tavolozza 1 bit: indice 0 nero, indice 1 bianco.
  bytes[54]=0;bytes[55]=0;bytes[56]=0;bytes[57]=0;bytes[58]=255;bytes[59]=255;bytes[60]=255;bytes[61]=0;
  for(let y=0;y<height;y++){
    const dstRow=offset+(height-1-y)*rowSize;for(let b=0;b<rowDataBytes;b++)bytes[dstRow+b]=255;
    for(let x2=0;x2<width;x2++){const i=(y*width+x2)*4,luma=.2126*px[i]+.7152*px[i+1]+.0722*px[i+2];if(luma<128)bytes[dstRow+(x2>>3)]&=~(0x80>>(x2&7))}
  }
  if(bytes.length>20000)throw new Error(`Logo Epson troppo grande (${bytes.length} byte). Riduci l’altezza del logo.`);
  return printerBytesToBase64(bytes)
}
function dcoEpsonLogoStatus(type,message){const el=$('businessReceiptLogoEpsonStatus');if(!el)return;el.hidden=false;el.className=`config-status-line ${type||''}`.trim();el.textContent=message}
async function dcoSendReceiptLogoToEpson(){
  const button=$('businessReceiptLogoEpsonSend'),data=dcoReceiptLogoDraftData||dcoBusinessProfile().receiptLogoData;if(!data)return toast('Carica prima un logo.');
  if(!valid(localStorage.getItem(K.ip)||'')){toast('Configura prima l’indirizzo IP Epson');openPrinter();return}
  printerSetBusy(button,true,'Invio…');dcoEpsonLogoStatus('loading','Conversione BMP e caricamento nella Epson RT…');
  try{const base64=await dcoReceiptLogoEpsonBmpBase64(data),request=`<printerNonFiscal>\n<beginNonFiscal operator="1" />\n<setLogo operator="1" location="1" index="${EPSON_RECEIPT_LOGO_INDEX}" option="0" graphicFormat="B">${base64}</setLogo>\n<endNonFiscal operator="1" />\n</printerNonFiscal>`,res=await sendEpson(request,45000);if(!res.success)throw new Error(`${res.code||'operazione rifiutata'}${res.status?` (stato ${res.status})`:''}`);dcoEpsonLogoStatus('ok',`Logo caricato nello slot ${EPSON_RECEIPT_LOGO_INDEX} e impostato come intestazione Epson RT.`);toast('Logo Epson RT configurato',4000)}catch(e){dcoEpsonLogoStatus('error',`Logo Epson non configurato: ${e.message||e}`);alert(`Logo Epson RT non configurato:\n\n${e.message||e}`)}finally{printerSetBusy(button,false)}
}
async function dcoDisableReceiptLogoOnEpson(){
  const button=$('businessReceiptLogoEpsonDisable');if(!valid(localStorage.getItem(K.ip)||'')){toast('Configura prima l’indirizzo IP Epson');openPrinter();return}
  printerSetBusy(button,true,'Disattivo…');dcoEpsonLogoStatus('loading','Disattivazione HEADER grafico Epson…');
  try{const res=await sendEpson('<printerCommand><setLogo location="1" index="0" option="2" /></printerCommand>',20000);if(!res.success)throw new Error(`${res.code||'operazione rifiutata'}${res.status?` (stato ${res.status})`:''}`);dcoEpsonLogoStatus('ok','Logo Epson disattivato. Il file resta in NVRAM ma non viene stampato in testa.');toast('Logo Epson disattivato',3500)}catch(e){dcoEpsonLogoStatus('error',`Disattivazione non riuscita: ${e.message||e}`);alert(`Disattivazione logo Epson non riuscita:\n\n${e.message||e}`)}finally{printerSetBusy(button,false)}
}
function dcoReceiptAmount(value){return Number(value||0).toFixed(2).replace('.',',')}
function dcoReceiptQuantity(value){const n=Number(value||0);return Number.isInteger(n)?String(n):n.toFixed(2).replace('.',',')}
function dcoReceiptPaymentDescription(value){const p=String(value||'').trim().toLowerCase();if(p.includes('carta')||p.includes('card')||p.includes('elettron'))return'Pagamento Carta';if(p.includes('contant')||p.includes('cash'))return'Pagamento Contanti';return`Pagamento ${printerPlainText(value||'')}`.trim()}
function dcoReceiptDateTime(value=new Date(),withSeconds=false){
  const d=value instanceof Date?value:new Date(value),pad=n=>String(n).padStart(2,'0');
  if(Number.isNaN(d.getTime()))return'';
  return`${pad(d.getDate())}/${pad(d.getMonth()+1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}${withSeconds?`:${pad(d.getSeconds())}`:''}`
}
function dcoNormalizeOfficialDate(value){
  const raw=String(value||'').replace(/\s+/g,' ').trim();if(!raw)return'';
  const italian=raw.match(/(\d{2}\/\d{2}\/\d{4})\s+(\d{2}:\d{2}(?::\d{2})?)/);if(italian)return`${italian[1]} ${italian[2]}`;
  const parsed=new Date(raw);return Number.isNaN(parsed.getTime())?raw.slice(0,32):dcoReceiptDateTime(parsed,true)
}
function dcoNormalizeDocumentMeta(value,fallbackId=''){
  const input=value&&typeof value==='object'?value:{documentId:value};
  const id=String(input.documentId||input.idtrx||fallbackId||'').replace(/[^0-9]/g,'');
  let documentNumber=printerPlainText(input.documentNumber||input.numeroProgressivo||input.receiptNumber||'').replace(/\s+/g,' ').trim();
  if(/^DCO-?\d+$/i.test(documentNumber))documentNumber='';
  const documentDate=dcoNormalizeOfficialDate(input.documentDate||input.dataOra||input.formattedDate||'');
  return{documentId:id,documentNumber,documentDate}
}
function dcoDocumentMetaScript(fallbackId=''){
  const safeId=String(fallbackId||'').replace(/[^0-9]/g,'');
  return `(function(){
    function clean(v){return String(v==null?'':v).replace(/\\s+/g,' ').trim()}
    function idOf(invio){return String(invio&&invio.idtrx!=null?invio.idtrx:'').replace(/[^0-9]/g,'')}
    var expected=${JSON.stringify(safeId)},matched=false,out={documentId:expected,documentNumber:'',documentDate:''};
    function merge(invio){
      if(!invio||typeof invio!=='object')return false;
      var invioId=idOf(invio);
      if(expected&&invioId!==expected)return false;
      if(!expected&&!invioId)return false;
      if(!out.documentId&&invioId)out.documentId=invioId;
      var transmission=invio.datiTrasmissione||{},doc=invio.documentoCommerciale||{};
      if(!out.documentNumber)out.documentNumber=clean(transmission.numeroProgressivo||doc.numeroProgressivo||invio.numeroProgressivo||invio.documentNumber||'');
      if(!out.documentDate)out.documentDate=clean(doc.dataOra||transmission.dataOra||invio.dataOra||invio.formattedDate||'');
      matched=true;return true
    }
    function scanScope(scope,seen){
      if(!scope||seen.indexOf(scope)>=0||seen.length>700)return;seen.push(scope);
      try{if(scope.vm&&scope.vm.invio)merge(scope.vm.invio)}catch(e){}
      if(matched&&out.documentNumber&&out.documentDate)return;
      scanScope(scope.$$childHead,seen);scanScope(scope.$$nextSibling,seen)
    }
    try{
      var buttons=Array.prototype.slice.call(document.querySelectorAll('button,a,input[type=button],input[type=submit]'));
      var target=buttons.find(function(el){var st=getComputedStyle(el),r=el.getBoundingClientRect(),visible=st.display!=='none'&&st.visibility!=='hidden'&&r.width>0&&r.height>0;return visible&&clean(el.textContent||el.value).toLowerCase().indexOf('scarica e stampa file')===0});
      if(window.angular&&target){var scope=angular.element(target).scope()||angular.element(target).isolateScope();while(scope){if(scope.vm&&scope.vm.invio&&merge(scope.vm.invio))break;scope=scope.$parent}}
      if(window.angular&&(!matched||!out.documentNumber||!out.documentDate)){var injector=angular.element(document.body).injector&&angular.element(document.body).injector(),root=injector&&injector.get('$rootScope');scanScope(root,[])}
    }catch(e){}
    try{
      var current=String(location.href||''),m=current.match(/documenti\\/(\\d+)\\/stampa/i);
      if(expected&&m&&String(m[1])===expected)matched=true;
      if(!expected&&m){out.documentId=String(m[1]);matched=true}
    }catch(e){}
    // Il testo libero della pagina viene usato soltanto se abbiamo gia' provato
    // che lo scope/URL appartiene allo stesso ID documento. In questo modo un
    // numero rimasto nel $rootScope della vendita precedente non puo' essere
    // associato al nuovo documento.
    if(matched){
      try{var body=clean(document.body&&document.body.innerText||''),numberMatch=body.match(/\\b[A-Z]{2,5}\\d{4}\\/\\d+-\\d+\\b/i),dateMatch=body.match(/\\b\\d{2}\\/\\d{2}\\/\\d{4}\\s+\\d{2}:\\d{2}(?::\\d{2})?\\b/);if(!out.documentNumber&&numberMatch)out.documentNumber=numberMatch[0];if(!out.documentDate&&dateMatch)out.documentDate=dateMatch[0]}catch(e){}
    }
    out.matchedExpected=matched;return out
  })()`
}
function dcoDocumentMetaWatcherScript(fallbackId='',watchMs=1200){
  const safeId=String(fallbackId||'').replace(/[^0-9]/g,''),duration=Math.max(250,Math.min(3000,Number(watchMs)||1200));
  return `(function(){
    try{
      if(window.__cassaiqMetaWatchTimer){clearInterval(window.__cassaiqMetaWatchTimer);window.__cassaiqMetaWatchTimer=null}
      var send=function(payload){try{var encoded=JSON.stringify(payload);if(window.webkit&&window.webkit.messageHandlers&&window.webkit.messageHandlers.cordova_iab){window.webkit.messageHandlers.cordova_iab.postMessage(encoded);return true}if(window.cordova_iab&&typeof window.cordova_iab.postMessage==='function'){window.cordova_iab.postMessage(encoded);return true}}catch(e){}return false};
      function clean(v){return String(v==null?'':v).replace(/\\s+/g,' ').trim()}
      function idOf(invio){return String(invio&&invio.idtrx!=null?invio.idtrx:'').replace(/[^0-9]/g,'')}
      var expected=${JSON.stringify(safeId)};
      function read(){
        var matched=false,out={documentId:expected,documentNumber:'',documentDate:''};
        function merge(invio){if(!invio||typeof invio!=='object')return false;var invioId=idOf(invio);if(expected&&invioId!==expected)return false;if(!expected&&!invioId)return false;if(!out.documentId&&invioId)out.documentId=invioId;var transmission=invio.datiTrasmissione||{},doc=invio.documentoCommerciale||{};if(!out.documentNumber)out.documentNumber=clean(transmission.numeroProgressivo||doc.numeroProgressivo||invio.numeroProgressivo||invio.documentNumber||'');if(!out.documentDate)out.documentDate=clean(doc.dataOra||transmission.dataOra||invio.dataOra||invio.formattedDate||'');matched=true;return true}
        function scan(scope,seen){if(!scope||seen.indexOf(scope)>=0||seen.length>700)return;seen.push(scope);try{if(scope.vm&&scope.vm.invio)merge(scope.vm.invio)}catch(e){}if(matched&&out.documentNumber)return;scan(scope.$$childHead,seen);scan(scope.$$nextSibling,seen)}
        try{var buttons=Array.prototype.slice.call(document.querySelectorAll('button,a,input[type=button],input[type=submit]')),target=buttons.find(function(el){var st=getComputedStyle(el),r=el.getBoundingClientRect(),visible=st.display!=='none'&&st.visibility!=='hidden'&&r.width>0&&r.height>0;return visible&&clean(el.textContent||el.value).toLowerCase().indexOf('scarica e stampa file')===0});if(window.angular&&target){var sc=angular.element(target).scope()||angular.element(target).isolateScope();while(sc){if(sc.vm&&sc.vm.invio&&merge(sc.vm.invio))break;sc=sc.$parent}}if(window.angular&&(!matched||!out.documentNumber)){var injector=angular.element(document.body).injector&&angular.element(document.body).injector(),root=injector&&injector.get('$rootScope');scan(root,[])}}catch(e){}
        try{var current=String(location.href||''),m=current.match(/documenti\\/(\\d+)\\/stampa/i);if(expected&&m&&String(m[1])===expected)matched=true;if(!expected&&m){out.documentId=String(m[1]);matched=true}}catch(e){}
        if(matched){try{var body=clean(document.body&&document.body.innerText||''),numberMatch=body.match(/\\b[A-Z]{2,5}\\d{4}\\/\\d+-\\d+\\b/i),dateMatch=body.match(/\\b\\d{2}\\/\\d{2}\\/\\d{4}\\s+\\d{2}:\\d{2}(?::\\d{2})?\\b/);if(!out.documentNumber&&numberMatch)out.documentNumber=numberMatch[0];if(!out.documentDate&&dateMatch)out.documentDate=dateMatch[0]}catch(e){}}
        out.matchedExpected=matched;return out
      }
      var started=Date.now(),done=false;
      function check(){if(done)return;var out=read();if(out.matchedExpected&&out.documentNumber){done=true;if(window.__cassaiqMetaWatchTimer){clearInterval(window.__cassaiqMetaWatchTimer);window.__cassaiqMetaWatchTimer=null}send({source:'cassaiq-dco',type:'document-meta',meta:out,at:Date.now()});return}if(Date.now()-started>=${duration}){done=true;if(window.__cassaiqMetaWatchTimer){clearInterval(window.__cassaiqMetaWatchTimer);window.__cassaiqMetaWatchTimer=null}}}
      check();if(!done)window.__cassaiqMetaWatchTimer=setInterval(check,60);return true
    }catch(e){return false}
  })()`
}
function dcoWaitDocumentMetaEvent(ref,value,watchMs=1200){
  let meta=dcoNormalizeDocumentMeta(value);if(meta.documentNumber)return meta;
  if(!ref)return meta;
  return new Promise(async resolve=>{
    let settled=false;const finish=(error,found)=>{if(settled)return;settled=true;clearTimeout(timer);if(dcoDocumentMetaWaiter?.finish===finish)dcoDocumentMetaWaiter=null;if(!error&&found)meta=dcoNormalizeDocumentMeta({documentId:found.documentId||meta.documentId,documentNumber:found.documentNumber||meta.documentNumber,documentDate:found.documentDate||meta.documentDate},meta.documentId);resolve(meta)};
    const timer=setTimeout(()=>finish(null,null),Math.max(300,Number(watchMs)||1200)+180);
    dcoDocumentMetaWaiter={finish,documentId:meta.documentId};
    try{await dcoExecScript(ref,dcoDocumentMetaWatcherScript(meta.documentId,watchMs),2500)}catch{finish(null,null)}
  })
}
async function dcoResolveDocumentMeta(ref,value,attempts=10){
  let meta=dcoNormalizeDocumentMeta(value);
  // Per stampare il documento commerciale serve il numero ufficiale. La data non deve
  // bloccare la stampa: se non e' ancora esposta dal portale, usiamo l'ora locale
  // della vendita e la aggiorniamo in seguito quando disponibile.
  if(meta.documentNumber)return meta;
  meta=await dcoWaitDocumentMetaEvent(ref,meta,1200);
  if(meta.documentNumber)return meta;
  for(let i=0;i<attempts;i++){
    try{
      const found=await dcoExecScript(ref,dcoDocumentMetaScript(meta.documentId),6000);
      meta=dcoNormalizeDocumentMeta({documentId:found?.documentId||meta.documentId,documentNumber:found?.documentNumber||meta.documentNumber,documentDate:found?.documentDate||meta.documentDate},meta.documentId);
      if(meta.documentNumber)return meta
    }catch{}
    if(i<attempts-1)await new Promise(resolve=>setTimeout(resolve,250))
  }
  return meta
}
function dcoReceiptVatTotals(snapshot){
  const lines=Array.isArray(snapshot?.lines)?snapshot.lines:[],subtotal=lines.reduce((sum,line)=>sum+Number(line.lineTotal||Number(line.quantity||0)*Number(line.unitPrice||0)),0),discount=Math.max(0,Number(snapshot?.discount||0)),groups=new Map();
  lines.forEach(line=>{const rawGross=Number(line.lineTotal||Number(line.quantity||0)*Number(line.unitPrice||0)),discountShare=subtotal>0?discount*(rawGross/subtotal):0,gross=Math.max(0,rawGross-discountShare),rate=Math.max(0,Number(line.vatRate||0)),key=String(rate),group=groups.get(key)||{rate,gross:0};group.gross+=gross;groups.set(key,group)});
  let taxable=0,vat=0;groups.forEach(group=>{const base=group.rate>0?group.gross/(1+group.rate/100):group.gross,tax=group.gross-base;taxable+=Math.round((base+Number.EPSILON)*100)/100;vat+=Math.round((tax+Number.EPSILON)*100)/100});
  const total=Math.max(0,Number(snapshot?.total||subtotal-discount)),roundedVat=Math.round((vat+Number.EPSILON)*100)/100,roundedTaxable=Math.round((taxable+Number.EPSILON)*100)/100,diff=Math.round((total-roundedTaxable-roundedVat)*100)/100;
  return{taxable:Math.round((roundedTaxable+diff+Number.EPSILON)*100)/100,vat:roundedVat}
}
function dcoReceiptProductLines(line,width=RECEIPT_WIDTH){
  const quantity=`${dcoReceiptQuantity(line?.quantity||0)}X`,name=printerPlainText(line?.name||'Prodotto').replace(/\s+/g,' ').trim()||'Prodotto',price=dcoReceiptAmount(line?.lineTotal||Number(line?.quantity||0)*Number(line?.unitPrice||0)),prefix=`${quantity} `,firstWidth=Math.max(1,width-price.length-1),nameWidth=Math.max(1,firstWidth-prefix.length),wrapped=printerWrapText(name,nameWidth),out=[];
  const firstName=wrapped.shift()||'';out.push(printerLine(`${prefix}${firstName}`,price,width));
  const continuationWidth=Math.max(1,width-3);for(const chunk of wrapped)for(const row of printerWrapText(chunk,continuationWidth))out.push(`   ${row}\n`);
  const rate=Number(line?.vatRate||0);out.push(`   Aliquota IVA ${dcoReceiptQuantity(rate)}%\n`);return out
}
async function dcoCourtesyReceiptPayload(snapshot,documentMeta){
  if(!snapshot)throw new Error('Dati della vendita non disponibili per la stampa.');
  const meta=dcoNormalizeDocumentMeta(documentMeta),width=RECEIPT_WIDTH,divider='-'.repeat(width)+'\n',parts=[printerInit()],currentProfile=dcoBusinessProfile(),storedProfile=snapshot.businessProfile||{},hasStoredLogoFlag=Object.prototype.hasOwnProperty.call(storedProfile,'receiptLogoEnabled'),profile={...currentProfile,...storedProfile,receiptLogoData:storedProfile.receiptLogoData||currentProfile.receiptLogoData||'',receiptLogoEnabled:(hasStoredLogoFlag?!!storedProfile.receiptLogoEnabled:!!currentProfile.receiptLogoEnabled)&&!!(storedProfile.receiptLogoData||currentProfile.receiptLogoData)},add=text=>parts.push(printerAscii(printerPlainText(text)));
  /* Il logo e' un elemento grafico della stampa locale: non entra nel payload
     fiscale inviato all'Agenzia delle Entrate. Se il file non e' leggibile,
     la vendita non viene mai bloccata: stampiamo semplicemente senza logo. */
  let logoPrinted=false;
  if(profile.receiptLogoEnabled&&profile.receiptLogoData){
    try{
      const logo=await dcoReceiptLogoEscPos(profile.receiptLogoData);
      if(logo.length){parts.push([0x1b,0x61,0x01]);parts.push(logo);parts.push([0x0a]);logoPrinted=true}
    }catch(e){console.warn('Logo documento commerciale non stampato',e)}
  }
  /* Intestazione: usa la centratura hardware ESC/POS sull'intera area di stampa.
     Senza logo manteniamo la riga di inizializzazione necessaria su alcune stampanti ESC/POS
     subito dopo ESC @. Se il logo e' gia' stato stampato, il raster ha gia'
     inizializzato il flusso e possiamo evitare una riga vuota aggiuntiva. */
  parts.push(logoPrinted?[0x1b,0x61,0x01,0x1b,0x45,0x01,0x1d,0x21,0x00]:[0x1b,0x61,0x01,0x0a,0x1b,0x61,0x01,0x1b,0x45,0x01,0x1d,0x21,0x00]);
  for(const row of printerWrapText(profile.legalName||'ATTIVITA',width))add(`${row}\n`);
  if(profile.tradeName&&profile.tradeName.toLowerCase()!==String(profile.legalName||'').toLowerCase())for(const row of printerWrapText(profile.tradeName,width))add(`${row}\n`);
  parts.push([0x1b,0x45,0x00]);
  add(`P.IVA ${profile.vat||''}\n`);
  const street=[profile.address,profile.civic].filter(Boolean).join(' ');for(const row of printerWrapText(street,width))add(`${row}\n`);
  const city=[profile.zip,profile.city,profile.province?`(${profile.province})`:'' ].filter(Boolean).join(' ');for(const row of printerWrapText(city,width))add(`${row}\n`);
  add('\n');parts.push([0x1b,0x45,0x01]);add('DOCUMENTO COMMERCIALE\n');parts.push([0x1b,0x45,0x00]);add('\n');
  parts.push([0x1b,0x61,0x00]);
  for(const line of snapshot.lines||[])for(const row of dcoReceiptProductLines(line,width))add(row);
  add(divider);
  const fiscal=dcoReceiptVatTotals(snapshot);add(printerLine('Totale imponibile',dcoReceiptAmount(fiscal.taxable),width));add(printerLine('Totale IVA',dcoReceiptAmount(fiscal.vat),width));
  parts.push([0x1b,0x45,0x01,0x1d,0x21,0x01]);add(printerLine('Totale complessivo',dcoReceiptAmount(snapshot.total),width));parts.push([0x1d,0x21,0x00,0x1b,0x45,0x00]);
  add(printerLine(dcoReceiptPaymentDescription(snapshot.payment),dcoReceiptAmount(snapshot.total),width));
  if(String(snapshot.payment||'').toLowerCase().includes('contant')&&Number(snapshot.changeDue||0)>0)add(printerLine('Resto',dcoReceiptAmount(snapshot.changeDue),width));
  add('\n'+divider);parts.push([0x1b,0x61,0x01]);
  const officialLabel=meta.documentNumber?`Doc. N. ${meta.documentNumber}`:(meta.documentId?`Rif. tecnico DCO ${meta.documentId}`:'Documento emesso tramite DCO');
  for(const row of printerWrapText(officialLabel,width))add(`${row}\n`);
  for(const row of printerWrapText('Emesso tramite DCO Agenzia Entrate',width))add(`${row}\n`);
  add(`${meta.documentDate||dcoReceiptDateTime(new Date(),true)}\n`);
  parts.push([0x1b,0x64,RECEIPT_FEED_LINES,0x1d,0x56,0x00]);return printerConcat(...parts)
}
async function dcoPrintCourtesyReceipt(snapshot,documentMeta){
  const plugin=printerNativePlugin();if(!plugin)throw new Error('Modulo stampante di rete non disponibile.');
  const opt=dcoPrinterOptions(),bytes=await dcoCourtesyReceiptPayload(snapshot,documentMeta),data=printerBytesToBase64(bytes);
  localStorage.setItem(K.printerTestIp,opt.host);localStorage.setItem(K.printerTestPort,String(opt.port));
  if(!/^(?:\d{1,3}\.){3}\d{1,3}$/.test(opt.host))throw new Error('Indirizzo IP stampante di rete non valido.');
  return plugin.printNetwork({host:opt.host,port:opt.port,data,timeoutMs:12000})
}
async function printerSendNetwork(bytes){
  const plugin=printerNativePlugin();if(!plugin)throw new Error('Modulo nativo stampante non disponibile. Esegui npm install e npm run ios:sync oppure npm run sync.');
  const host=$('printerNetworkIp').value.trim();const port=Number($('printerNetworkPort').value||9100);
  if(!/^(?:\d{1,3}\.){3}\d{1,3}$/.test(host))throw new Error('Inserisci un indirizzo IP valido, per esempio 192.168.1.201.');
  if(!Number.isInteger(port)||port<1||port>65535)throw new Error('Inserisci una porta valida. Per ESC/POS normalmente e 9100.');
  localStorage.setItem(K.printerTestIp,host);localStorage.setItem(K.printerTestPort,String(port));
  return plugin.printNetwork({host,port,data:printerBytesToBase64(bytes),timeoutMs:8000})
}
function initPrinterTestView(){
  const ip=$('printerNetworkIp'),port=$('printerNetworkPort'),status=$('printerPluginStatus');if(!ip||!port)return;
  ip.value=localStorage.getItem(K.printerTestIp)||'192.168.1.201';port.value=localStorage.getItem(K.printerTestPort)||'9100';
  const plugin=printerNativePlugin(),platform=printerPlatform();
  status.className=`printer-plugin-status ${plugin?'ok':'error'}`;
  status.textContent=plugin?`Modulo ESC/POS di rete attivo su ${platform==='ios'?'iPhone/iPad':platform==='android'?'Android':platform}. Puoi iniziare il test.`:'Modulo nativo non caricato. Questa funzione non opera nel browser: sincronizza e avvia il progetto nativo.';
  if(printerTestInitialized)return;printerTestInitialized=true;

  $('printerNetworkTest').onclick=async()=>{const b=$('printerNetworkTest');printerSetBusy(b,true,'Invio stampa…');printerSetResult('printerNetworkResult','loading','Connessione alla stampante in corso…');try{const host=$('printerNetworkIp').value.trim(),port=Number($('printerNetworkPort').value||9100);const out=await printerSendNetwork(printerTestPayload(`LAN ${host}:${port}`));printerSetResult('printerNetworkResult','ok',`Test inviato: ${out.bytes||0} byte. Controlla stampa e taglio.`)}catch(e){printerSetResult('printerNetworkResult','error',e.message||String(e))}finally{printerSetBusy(b,false)}};
  $('printerNetworkCut').onclick=async()=>{const b=$('printerNetworkCut');printerSetBusy(b,true);try{await printerSendNetwork(printerCutPayload());printerSetResult('printerNetworkResult','ok','Comando taglio inviato.')}catch(e){printerSetResult('printerNetworkResult','error',e.message||String(e))}finally{printerSetBusy(b,false)}};
  $('printerNetworkDrawer').onclick=async()=>{const b=$('printerNetworkDrawer');printerSetBusy(b,true);try{await printerSendNetwork(printerDrawerPayload());printerSetResult('printerNetworkResult','ok','Impulso apertura cassetto inviato.')}catch(e){printerSetResult('printerNetworkResult','error',e.message||String(e))}finally{printerSetBusy(b,false)}};
}

/* --------- Laboratorio Documento Commerciale Online ---------
   Compila una BOZZA del Documento Commerciale Online usando il carrello
   corrente. Consente di raggiungere anche la schermata conclusiva per
   mapparne i controlli e, solo dopo un'abilitazione esplicita, consente una singola prova fiscale reale protetta. Dopo l'emissione recupera il PDF ufficiale, registra la vendita e può stamparla sulla stampante di rete.
   La diagnostica non raccoglie password, PIN o valori digitati. In modalita Fisconline,
   CassaIQ legge le credenziali solo dal secure storage nativo per compilare il login ufficiale. */
let dcoBrowserRef=null;
let dcoLabInitialized=false;
let dcoLastDiagnostic=null;
let dcoRouteHistory=[];
let dcoCaptureTimers=[];
let dcoLivePollTimer=null;
let dcoPdfPulling=false;
let dcoPdfRetryBusy=false;
let dcoAutoPdfRecoveryBusy=false;
let dcoLastPdfBase64='';
const dcoProcessedDocumentIds=new Set();
const dcoNativePdfDownloads=new Map();
let dcoConnectionPending=false;
let dcoConnectionStartBusy=false;
let dcoConnectionPhase='';
let dcoConnectionTickBusy=false;
let dcoConnectionAttempt=0;
let dcoConnectionReadyChecks=0;
let dcoConnectionLastReadyAt=0;
let dcoConnectionRouteAttempts=0;
let dcoConnectionLastRouteAt=0;
let dcoLastServiceNav=0;let dcoLastServiceNavHref='';let dcoWizardEntered=0;
let dcoConnectionAuthenticatedAt=0;
let dcoConnectionPortalReadyChecks=0;
let dcoConnectionWizardStartedAt=0;
let dcoAutoSale=null;
let dcoAutoTimer=null;
let dcoAutoTickBusy=false;
// v1.15.10 annullo DCO: percorso separato dalla vendita normale, basato sul flusso v1.15.7 già verificato.
// Arriva soltanto a Verifica dati e blocca qualsiasi passaggio finale.
let dcoVoidLab=null;
let dcoVoidLabTimer=null;
let dcoVoidLabTickBusy=false;
let dcoEmissionFinalizeBusy=false;
const dcoCourtesyFinalizedIds=new Set();
let dcoBrowserLoading=false;
let dcoBrowserLoadGuardTimer=null;
const dcoAutomationWaiters=new Map();
let dcoDocumentMetaWaiter=null;
const DCO_URLS={
  login:'https://iampe.agenziaentrate.gov.it/sam/UI/Login?realm=/agenziaentrate',
  entry:'https://ivaservizi.agenziaentrate.gov.it/instr/InstradamentofcWeb/wizard',
  loggedHome:'https://ivaservizi.agenziaentrate.gov.it/instr/InstradamentofcWeb/home',
  service:'https://ivaservizi.agenziaentrate.gov.it/ser/documenticommercialionline/#/home'
};

const DCO_SECURE_CREDENTIALS_KEY='dco.fisconline.credentials.v1';
let dcoFisconlineConfigured=false;
let dcoConnectionMethod='fisconline';
let dcoConnectionCredentials=null;
let dcoResumeSaleAfterConnect=false;
let dcoFisconlineActionBusy=false;
let dcoFisconlineLastActionAt=0;
let dcoFisconlineLoginSubmittedAt=0;
let dcoFisconlineLoginSubmitUrl='';
let dcoFisconlineLoginStage='idle';
let dcoFisconlineWorkUserConfirmed=false;
let dcoFisconlineWorkUserSelectionAttempted=false;
const DCO_PASSWORD_RENEW_URL='https://telematici.agenziaentrate.gov.it/';
const DCO_PASSWORD_VALIDITY_DAYS=90;
const DCO_PASSWORD_WARNING_DAYS=7;
const DCO_DAY_MS=24*60*60*1000;

// v1.14.98 — Modulo rinnovo Fisconline SEPARATO dal DCO.
// Il ciclo automatico parte ogni 30 giorni dall'ultimo rinnovo riuscito.
// Il DCO non viene aperto, disconnesso, ricollegato o modificato dal rinnovo.
const FIS_RENEW_URL='https://telematici.agenziaentrate.gov.it/Abilitazione/RipristinaPassword/IRipristinaPassword.jsp';
const FIS_RENEW_CYCLE_DAYS=30;
const FIS_RENEW_MANUAL_COOLDOWN_MS=24*60*60*1000;
const FIS_RENEW_DCO_STABILIZE_MS=60*1000;
let fisRenewBrowserRef=null;
let fisRenewBusy=false;
let fisRenewSubmitted=false;
let fisRenewTerminal=false;
let fisRenewInitialPasswordSaved=false;
let fisRenewAutomaticRun=false;
let fisRenewUiCooldownTimer=null;
let dcoCredentialIssueType='';
let dcoVisualHealth='error';
let dcoVisualHealthCheckedAt=0;
// v1.14.81: nessun polling o preflight temporale della sessione DCO.
// La sessione resta intatta finché il portale non segnala davvero AUTH_REQUIRED
// o SESSION_EXPIRED durante l'emissione; in quel caso il runner ricollega Fisconline.
window.addEventListener('online',()=>{dcoVisualHealth=dcoHasSessionMarker()?'ok':'error';dcoVisualHealthCheckedAt=Date.now();renderDcoSettingsCardStatus()});
window.addEventListener('offline',()=>{dcoVisualHealth='error';dcoVisualHealthCheckedAt=Date.now();renderDcoSettingsCardStatus()});

function dcoLocalDayKey(date=new Date()){
  const y=date.getFullYear(),m=String(date.getMonth()+1).padStart(2,'0'),d=String(date.getDate()).padStart(2,'0');
  return `${y}-${m}-${d}`
}
function dcoFisconlinePasswordSetAtMs(){
  const raw=Number(localStorage.getItem(K.dcoFisconlinePasswordSetAt)||0);
  return Number.isFinite(raw)&&raw>0?raw:0
}
function dcoMarkFisconlinePasswordRenewed(at=Date.now()){
  const ms=Number(at)||Date.now();
  localStorage.setItem(K.dcoFisconlinePasswordSetAt,String(ms));
  localStorage.removeItem(K.dcoFisconlinePasswordReminderDay);
  renderDcoFisconlinePasswordCounter();
  return ms
}
function dcoEnsureFisconlinePasswordCounter(){
  let ms=dcoFisconlinePasswordSetAtMs();
  if(!ms&&dcoFisconlineConfigured){
    // Le versioni precedenti non registravano la data del cambio password.
    // Per le credenziali gia' presenti il primo ciclo parte dall'aggiornamento
    // dell'app; dai rinnovi successivi la data viene aggiornata automaticamente.
    ms=dcoMarkFisconlinePasswordRenewed(Date.now())
  }
  return ms
}
function dcoFisconlinePasswordExpiryInfo(){
  const setAt=dcoFisconlinePasswordSetAtMs();if(!setAt)return null;
  const expiresAt=setAt+DCO_PASSWORD_VALIDITY_DAYS*DCO_DAY_MS;
  const remainingMs=expiresAt-Date.now();
  const daysRemaining=Math.ceil(remainingMs/DCO_DAY_MS);
  return{setAt,expiresAt,daysRemaining,warning:daysRemaining<=DCO_PASSWORD_WARNING_DAYS}
}
function dcoFormatDate(ms){
  try{return new Date(ms).toLocaleDateString('it-IT',{day:'2-digit',month:'2-digit',year:'numeric'})}catch{return''}
}


function fisRenewStartUiCooldown(){
  if(fisRenewUiCooldownTimer)clearInterval(fisRenewUiCooldownTimer);
  if(fisRenewDcoStabilizeRemainingMs()<=0){fisRenewUiCooldownTimer=null;renderDcoAuthUi();return}
  fisRenewUiCooldownTimer=setInterval(()=>{
    renderDcoAuthUi();
    const msg=fisRenewPostRenewalMessage();
    if(msg)renderDcoConnectionStatus(msg,'warning');
    if(fisRenewDcoStabilizeRemainingMs()<=0){
      clearInterval(fisRenewUiCooldownTimer);fisRenewUiCooldownTimer=null;
      renderDcoAuthUi();
      if(!dcoHasSessionMarker())renderDcoConnectionStatus('Stabilizzazione completata. Ora puoi collegare il DCO con una sessione pulita.','ok')
    }
  },1000)
}
function fisRenewDcoStabilizeRemainingMs(){
  const until=Number(localStorage.getItem(K.fisRenewDcoStabilizeUntil)||0);
  return Number.isFinite(until)&&until>Date.now()?until-Date.now():0
}
function fisRenewDcoStabilizeSeconds(){
  return Math.max(0,Math.ceil(fisRenewDcoStabilizeRemainingMs()/1000))
}
function fisRenewPostRenewalMessage(){
  const sec=fisRenewDcoStabilizeSeconds();
  return sec>0
    ?`Password rinnovata. L'Agenzia delle Entrate sta stabilizzando la nuova sessione: collegamento DCO disponibile tra circa ${sec} secondi.`
    :''
}
function fisRenewLastSuccessMs(){
  const raw=Number(localStorage.getItem(K.fisRenewLastSuccessAt)||0);
  return Number.isFinite(raw)&&raw>0?raw:0
}
function fisRenewCycleInfo(){
  const lastSuccess=fisRenewLastSuccessMs();if(!lastSuccess)return null;
  const nextAt=lastSuccess+FIS_RENEW_CYCLE_DAYS*DCO_DAY_MS;
  const daysRemaining=Math.ceil((nextAt-Date.now())/DCO_DAY_MS);
  return{lastSuccess,nextAt,daysRemaining}
}
function renderDcoFisconlinePasswordCounter(){
  const el=$('dcoFisconlinePasswordCounter');if(!el)return;
  if(!dcoFisconlineConfigured){el.hidden=true;return}
  el.hidden=false;
  const info=fisRenewCycleInfo();
  if(!info){
    el.className='config-status-line warning';
    el.textContent=fisRenewInitialPasswordSaved
      ?'Rinnovo Fisconline: ciclo automatico non ancora inizializzato. Usa “Rinnova ora” una volta.'
      :'Rinnovo Fisconline: salva anche la password iniziale per abilitare il rinnovo automatico.';
    return
  }
  const next=dcoFormatDate(info.nextAt),last=dcoFormatDate(info.lastSuccess),days=info.daysRemaining;
  if(days>1){el.className='config-status-line ok';el.textContent=`Rinnovo Fisconline: prossimo controllo tra ${days} giorni (${next}) · ultimo rinnovo riuscito ${last}.`;return}
  if(days===1){el.className='config-status-line warning';el.textContent=`Rinnovo Fisconline: prossimo controllo domani (${next}) · ultimo rinnovo riuscito ${last}.`;return}
  el.className='config-status-line warning';
  el.textContent=`Rinnovo Fisconline: rinnovo previsto ${days===0?'oggi':`da ${Math.abs(days)} giorni`}. CassaIQ eseguirà al massimo un tentativo automatico al giorno, solo con DCO non collegato.`
}
async function dcoMaybeShowFisconlinePasswordReminder(){
  // v1.14.98: il vecchio popup di scadenza non viene più usato.
  // Controlliamo esclusivamente il modulo rinnovo, separato dal DCO.
  renderDcoFisconlinePasswordCounter();
  setTimeout(()=>{fisRenewMaybeAuto().catch(()=>{})},700);
  return false
}


function fisRenewSetStatus(message,type=''){
  const el=$('dcoFisconlineRenewalStatus');if(!el)return;
  el.hidden=!message;
  el.className=`test-result ${type}`.trim();
  el.textContent=message||''
}
function fisRenewSetBusy(value,label='Rinnova ora'){
  fisRenewBusy=!!value;
  const b=$('dcoFisconlineRenewNow');
  if(b){b.disabled=!!value;b.textContent=value?'Rinnovo in corso…':label}
}
function fisRenewWipeCredentials(c){
  if(!c)return;
  try{c.username='';c.password='';c.pin='';c.initialPassword=''}catch{}
}
function fisRenewInspectScript(){
  return `(function(){
    try{
      function clean(v){return String(v==null?'':v).replace(/\\s+/g,' ').trim()}
      var host=String(location.hostname||'').toLowerCase(),path=String(location.pathname||'');
      if(host!=='telematici.agenziaentrate.gov.it')return{state:'other',url:location.href,reason:'host'};
      var success=document.querySelector('#esito_positivo p, #esito_positivo, .esito_positivo, .alert-success, .success');
      var successText=clean(success&&success.textContent||'');
      var bodyText=clean(document.body&&document.body.innerText||'');
      if(successText&&successText.toLowerCase().indexOf('ripristino password effettuato con successo')>=0)return{state:'success',message:successText.slice(0,500)};
      if(bodyText.toLowerCase().indexOf('ripristino password effettuato con successo')>=0)return{state:'success',message:'Ripristino password effettuato con successo.'};
      var err1=document.querySelector('span.errore_txt ul'),err2=document.querySelector('#errore p, .alert-danger, .error');
      var errText=clean((err1&&err1.textContent)||(err2&&err2.textContent)||'');
      if(errText)return{state:'error',message:errText.slice(0,700)};
      var forms=Array.prototype.slice.call(document.forms||[]);
      var form=forms.find(function(f){var t=clean(f.innerText||f.textContent).toLowerCase();return t.indexOf('codice fiscale')>=0&&t.indexOf('codice pin')>=0&&t.indexOf('password iniziale')>=0&&t.indexOf('nuova password')>=0});
      if(form)return{state:'form',url:location.href};
      var body=clean(document.body&&document.body.innerText||'').toLowerCase();
      if(body.indexOf('ripristina password')>=0&&body.indexOf('password iniziale')>=0)return{state:'form',url:location.href};
      return{state:'other',url:location.href,path:path};
    }catch(e){return{state:'error',message:String(e&&e.message||e)}}
  })()`
}
async function fisRenewInspect(ref){
  return dcoExecScript(ref,fisRenewInspectScript(),5000)
}
async function fisRenewEncryptPayload(publicJwk,credentials){
  if(!globalThis.crypto?.subtle)throw new Error('Cifratura WebCrypto non disponibile.');
  const key=await crypto.subtle.importKey('jwk',publicJwk,{name:'RSA-OAEP',hash:'SHA-256'},false,['encrypt']);
  const clear=new TextEncoder().encode(JSON.stringify({
    username:String(credentials?.username||''),
    pin:String(credentials?.pin||''),
    initialPassword:String(credentials?.initialPassword||''),
    newPassword:String(credentials?.password||'')
  }));
  const encrypted=await crypto.subtle.encrypt({name:'RSA-OAEP'},key,clear);
  clear.fill(0);
  const bytes=new Uint8Array(encrypted);let binary='';for(let i=0;i<bytes.length;i++)binary+=String.fromCharCode(bytes[i]);
  return btoa(binary)
}
async function fisRenewSecureFillAndSubmit(ref,credentials){
  const probeKey=`__cassaiqRenewProbe_${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
  const privateStorageKey=`cassaiq:fisrenew:private:${probeKey}`;
  const resultStorage=`cassaiq:fis:result:${probeKey}`;
  const probeCode=`(function(){
    var RESULT_KEY=${JSON.stringify(probeKey)},RESULT_STORAGE=${JSON.stringify(resultStorage)},PRIVATE_STORAGE=${JSON.stringify(privateStorageKey)};
    function publish(state,value){var packet={state:state,value:value};try{window[RESULT_KEY]=packet}catch(e){}try{sessionStorage.setItem(RESULT_STORAGE,JSON.stringify(packet))}catch(e){}}
    function done(value){publish('done',value)}
    try{
      publish('pending',null);
      var host=String(location.hostname||'').toLowerCase();
      if(host!=='telematici.agenziaentrate.gov.it'){done({ok:false,reason:'pagina non ufficiale'});return{ok:true}}
      if(!globalThis.crypto||!crypto.subtle){done({ok:false,error:'SECURE_CHANNEL_UNAVAILABLE'});return{ok:true}}
      var forms=Array.prototype.slice.call(document.forms||[]);
      var form=forms.find(function(f){var t=String(f.innerText||f.textContent||'').toLowerCase();return t.indexOf('codice fiscale')>=0&&t.indexOf('password iniziale')>=0&&t.indexOf('nuova password')>=0});
      if(!form){done({ok:false,reason:'modulo ripristino non riconosciuto'});return{ok:true}}
      crypto.subtle.generateKey({name:'RSA-OAEP',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['encrypt','decrypt'])
        .then(function(pair){window.__cassaiqFisRenewPrivateKey=pair.privateKey;return Promise.all([crypto.subtle.exportKey('jwk',pair.publicKey),crypto.subtle.exportKey('jwk',pair.privateKey)])})
        .then(function(keys){try{sessionStorage.setItem(PRIVATE_STORAGE,JSON.stringify(keys[1]))}catch(e){}done({ok:true,publicJwk:keys[0],privateStorageKey:PRIVATE_STORAGE})})
        .catch(function(e){done({ok:false,error:'SECURE_CHANNEL_FAILED',reason:String(e&&e.message||e)})});
    }catch(e){done({ok:false,reason:String(e&&e.message||e)})}
    return{ok:true,action:'probe-started'}
  })()`;
  await dcoExecScript(ref,probeCode,5000);
  const probe=await dcoFisconlineWaitPageResult(ref,probeKey,18000);
  if(!probe?.ok||!probe.publicJwk)return probe||{ok:false,reason:'canale sicuro non disponibile'};

  const cipher=await fisRenewEncryptPayload(probe.publicJwk,credentials);
  const fillKey=`__cassaiqRenewFill_${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
  const fillStorage=`cassaiq:fis:result:${fillKey}`;
  const fillCode=`(function(){
    var RESULT_KEY=${JSON.stringify(fillKey)},RESULT_STORAGE=${JSON.stringify(fillStorage)},PRIVATE_STORAGE=${JSON.stringify(String(probe.privateStorageKey||privateStorageKey))},CIPHER=${JSON.stringify(cipher)};
    function publish(state,value){var packet={state:state,value:value};try{window[RESULT_KEY]=packet}catch(e){}try{sessionStorage.setItem(RESULT_STORAGE,JSON.stringify(packet))}catch(e){}}
    function done(value){publish('done',value)}
    function clean(v){return String(v==null?'':v).replace(/\\s+/g,' ').trim().toLowerCase()}
    function visible(el){if(!el||el.disabled)return false;try{var st=getComputedStyle(el),r=el.getBoundingClientRect();return st.display!=='none'&&st.visibility!=='hidden'&&r.width>0&&r.height>0}catch(e){return true}}
    function setValue(el,value){
      if(!el)return;
      var desc=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');
      if(desc&&desc.set)desc.set.call(el,value);else el.value=value;
      ['input','change','keyup','blur'].forEach(function(n){try{el.dispatchEvent(new Event(n,{bubbles:true}))}catch(e){}})
    }
    function context(el){
      try{
        if(el.id){var lab=document.querySelector('label[for="'+CSS.escape(el.id)+'"]');if(lab)return clean(lab.textContent)}
      }catch(e){}
      var row=el.closest&&el.closest('tr');if(row)return clean(row.textContent);
      var label=el.closest&&el.closest('label');if(label)return clean(label.textContent);
      var p=el.parentElement;return clean(p&&p.textContent||'')
    }
    function selectFields(form){
      var fields=Array.prototype.slice.call(form.querySelectorAll('input')).filter(function(el){
        var type=String(el.type||'text').toLowerCase();
        return visible(el)&&['hidden','submit','button','image','reset','checkbox','radio','search'].indexOf(type)<0
      });
      var out={};
      fields.forEach(function(el){
        var c=context(el),name=clean((el.name||'')+' '+(el.id||'')+' '+(el.placeholder||''));
        var all=c+' '+name;
        if(!out.username&&all.indexOf('codice fiscale')>=0)out.username=el;
        else if(!out.pin&&(all.indexOf('codice pin')>=0||(/\\bpin\\b/.test(all)&&all.indexOf('password')<0)))out.pin=el;
        else if(!out.initialPassword&&all.indexOf('password iniziale')>=0)out.initialPassword=el;
        else if(!out.confirmPassword&&all.indexOf('conferma')>=0&&all.indexOf('password')>=0)out.confirmPassword=el;
        else if(!out.newPassword&&all.indexOf('nuova password')>=0&&all.indexOf('conferma')<0)out.newPassword=el;
      });
      if((!out.username||!out.pin||!out.initialPassword||!out.newPassword||!out.confirmPassword)&&fields.length>=5){
        out.username=out.username||fields[0];out.pin=out.pin||fields[1];out.initialPassword=out.initialPassword||fields[2];out.newPassword=out.newPassword||fields[3];out.confirmPassword=out.confirmPassword||fields[4]
      }
      return out
    }
    try{
      publish('pending',null);
      if(!globalThis.crypto||!crypto.subtle){done({ok:false,error:'SECURE_CHANNEL_UNAVAILABLE'});return{ok:true}}
      var forms=Array.prototype.slice.call(document.forms||[]);
      var form=forms.find(function(f){var t=clean(f.innerText||f.textContent);return t.indexOf('codice fiscale')>=0&&t.indexOf('password iniziale')>=0&&t.indexOf('nuova password')>=0});
      if(!form){done({ok:false,reason:'modulo ripristino non riconosciuto'});return{ok:true}}
      var f=selectFields(form);
      if(!f.username||!f.pin||!f.initialPassword||!f.newPassword||!f.confirmPassword){done({ok:false,reason:'campi del modulo non riconosciuti'});return{ok:true}}
      var memoryKey=window.__cassaiqFisRenewPrivateKey;window.__cassaiqFisRenewPrivateKey=null;
      var stored='';try{stored=sessionStorage.getItem(PRIVATE_STORAGE)||'';sessionStorage.removeItem(PRIVATE_STORAGE)}catch(e){}
      var keyPromise;
      if(stored){try{var privateJwk=JSON.parse(stored);stored='';keyPromise=crypto.subtle.importKey('jwk',privateJwk,{name:'RSA-OAEP',hash:'SHA-256'},false,['decrypt']);privateJwk=null}catch(e){keyPromise=Promise.reject(e)}}
      else if(memoryKey)keyPromise=Promise.resolve(memoryKey);
      else{done({ok:false,error:'SECURE_CHANNEL_EXPIRED'});return{ok:true}}
      var raw=atob(CIPHER),bytes=new Uint8Array(raw.length);for(var i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);CIPHER='';raw='';
      keyPromise.then(function(privateKey){return crypto.subtle.decrypt({name:'RSA-OAEP'},privateKey,bytes)}).then(function(clear){
        bytes.fill(0);var clearBytes=new Uint8Array(clear),text=new TextDecoder().decode(clearBytes),creds;
        try{creds=JSON.parse(text)}finally{clearBytes.fill(0);text=''}
        setValue(f.username,String(creds.username||''));
        setValue(f.pin,String(creds.pin||''));
        setValue(f.initialPassword,String(creds.initialPassword||''));
        setValue(f.newPassword,String(creds.newPassword||''));
        setValue(f.confirmPassword,String(creds.newPassword||''));
        creds.username='';creds.pin='';creds.initialPassword='';creds.newPassword='';creds=null;
        var actions=Array.prototype.slice.call(form.querySelectorAll('button,input[type=submit],input[type=image],input[type=button]'));
        var submit=actions.find(function(el){var t=clean(el.textContent||el.value||el.alt||'');return t.indexOf('invia')>=0})||form.querySelector('[type=submit],[type=image]');
        if(submit){try{submit.scrollIntoView({block:'center'})}catch(e){}setTimeout(function(){try{submit.click()}catch(e){try{form.requestSubmit?form.requestSubmit():form.submit()}catch(_){}}},180)}
        else setTimeout(function(){try{form.requestSubmit?form.requestSubmit():form.submit()}catch(e){}},180);
        done({ok:true,action:'submitted'});
      }).catch(function(e){try{bytes.fill(0)}catch(_){}done({ok:false,error:'SECURE_CHANNEL_FAILED',reason:String(e&&e.message||e)})});
    }catch(e){done({ok:false,reason:String(e&&e.message||e)})}
    return{ok:true,action:'fill-started'}
  })()`;
  await dcoExecScript(ref,fillCode,5000);
  const result=await dcoFisconlineWaitPageResult(ref,fillKey,18000);
  return result
}
function fisRenewRecordSuccess(message=''){
  const now=Date.now();
  localStorage.setItem(K.fisRenewLastSuccessAt,String(now));
  localStorage.setItem(K.fisRenewLastResult,JSON.stringify({ok:true,at:now,message:String(message||'')}));
  // Il reset password può invalidare token IAM già esistenti sul server AdE.
  // Attesa breve + prossima sessione DCO pulita evitano rimbalzi nonauth/wizard.
  localStorage.setItem(K.fisRenewDcoStabilizeUntil,String(now+FIS_RENEW_DCO_STABILIZE_MS));
  localStorage.setItem(K.fisRenewFreshDcoSession,'1');
  fisRenewStartUiCooldown();
  renderDcoFisconlinePasswordCounter();
  renderDcoAuthUi();
}
async function fisRenewHandleLoad(ref,url,credentials){
  if(ref!==fisRenewBrowserRef||fisRenewTerminal)return;
  const state=await fisRenewInspect(ref).catch(e=>({state:'error',message:String(e&&e.message||e)}));
  if(state?.state==='success'){
    fisRenewTerminal=true;fisRenewRecordSuccess(state.message);
    fisRenewSetBusy(false,'Rinnova ora');
    fisRenewSetStatus(`Rinnovo riuscito e verificato dall'Agenzia delle Entrate. Il contatore è ripartito da 30 giorni. Per sicurezza il DCO attenderà circa 60 secondi prima di creare una nuova sessione.${state.message?` Esito: ${state.message}`:''}`,'ok');
    toast('Rinnovo Fisconline riuscito · nuovo ciclo 30 giorni',5000);
    fisRenewWipeCredentials(credentials);
    // Modulo separato: chiudiamo solo la finestra di rinnovo.
    // Nessun logout/login o ricollegamento DCO viene eseguito.
    fisRenewAutomaticRun=false;
    setTimeout(()=>{try{if(ref===fisRenewBrowserRef)ref.close?.()}catch{}},900);
    return
  }
  if(state?.state==='error'){
    fisRenewTerminal=true;fisRenewSetBusy(false);
    localStorage.setItem(K.fisRenewLastResult,JSON.stringify({ok:false,at:Date.now(),message:String(state.message||'')}));
    fisRenewSetStatus(`Rinnovo non riuscito: ${state.message||'errore restituito dal portale Agenzia Entrate'}. CassaIQ riproverà automaticamente domani; il DCO resta invariato.`,'error');
    if(fisRenewAutomaticRun)alert('Rinnovo automatico Fisconline non riuscito. CassaIQ riproverà automaticamente domani. Il Documento Commerciale Online resta operativo.');
    fisRenewAutomaticRun=false;
    fisRenewWipeCredentials(credentials);
    return
  }
  if(state?.state==='form'&&!fisRenewSubmitted){
    fisRenewSubmitted=true;
    fisRenewSetStatus('Pagina ufficiale Agenzia Entrate riconosciuta. Compilazione sicura e invio del test…','loading');
    const result=await fisRenewSecureFillAndSubmit(ref,credentials).catch(e=>({ok:false,reason:String(e&&e.message||e)}));
    if(!result?.ok){
      fisRenewTerminal=true;fisRenewSetBusy(false);fisRenewSubmitted=false;
      fisRenewSetStatus(`Test non inviato: ${result?.reason||result?.error||'modulo ufficiale non riconosciuto'}`,'error');
      fisRenewWipeCredentials(credentials);
    }else{
      fisRenewSetStatus('Dati inviati alla pagina ufficiale. Attendo l’esito dell’Agenzia delle Entrate…','loading')
    }
  }
}
async function fisRenewStart({automatic=false}={}){
  if(fisRenewBusy)return false;

  // Sicurezza fiscale: il ripristino password non viene eseguito mentre
  // esiste una sessione DCO attiva. In questo modo un reset credenziali
  // non può disturbare una vendita o una sessione del portale già pronta.
  if(dcoHasSessionMarker()){
    const msg='Rinnovo Fisconline rimandato: la sessione DCO è attiva. Per sicurezza CassaIQ rinnoverà la password solo quando il DCO non è collegato.';
    fisRenewSetStatus(msg,'warning');
    if(!automatic)toast('DCO attivo · rinnovo rimandato',3500);
    return false
  }
  if(isIssuing||dcoAutoSale||dcoConnectionPending)return false;

  const credentials=await dcoLoadFisconlineCredentials();
  if(!credentials){
    if(!automatic)fisRenewSetStatus('Prima salva le credenziali Fisconline su questo dispositivo.','error');
    return false
  }
  if(!credentials.initialPassword){
    fisRenewInitialPasswordSaved=false;renderDcoFisconlinePasswordCounter();
    if(!automatic)fisRenewSetStatus('Manca la password iniziale Fisconline. Inseriscila e premi “Salva credenziali”, poi riprova.','error');
    fisRenewWipeCredentials(credentials);
    return false
  }

  // Evita ripristini ripetuti a distanza di pochi minuti: il primo test reale
  // ha dimostrato che il reset è valido; ripeterlo può rendere instabile la
  // sessione server dell'Agenzia.
  const lastSuccess=fisRenewLastSuccessMs();
  if(!automatic&&lastSuccess&&Date.now()-lastSuccess<FIS_RENEW_MANUAL_COOLDOWN_MS){
    const at=dcoFormatDate(lastSuccess);
    fisRenewSetStatus(`Password Fisconline già rinnovata recentemente${at?` (${at})`:''}. Per sicurezza il rinnovo manuale è disponibile una sola volta ogni 24 ore.`,'warning');
    fisRenewWipeCredentials(credentials);
    return false
  }

  if(!automatic){
    if(!confirm('Avviare ora il rinnovo Fisconline? CassaIQ userà una connessione di rete separata dal browser DCO e reimposterà LA STESSA password attuale. Nessuna sessione DCO verrà aperta o modificata.')){
      fisRenewWipeCredentials(credentials);return false
    }
  }

  const plugin=printerNativePlugin();
  if(!plugin||typeof plugin.renewFisconlinePassword!=='function'){
    fisRenewSetStatus('Modulo nativo di rinnovo Fisconline non disponibile. Esegui npm install e la sincronizzazione nativa.','error');
    fisRenewWipeCredentials(credentials);
    return false
  }

  fisRenewAutomaticRun=!!automatic;
  fisRenewSetBusy(true,automatic?'Rinnovo automatico…':'Rinnova ora');
  fisRenewSetStatus(
    automatic?'Rinnovo automatico Fisconline in corso su connessione separata…':'Rinnovo Fisconline in corso su connessione separata dal DCO…',
    'loading'
  );
  localStorage.setItem(K.fisRenewLastAttemptDay,dcoLocalDayKey());

  try{
    const result=await plugin.renewFisconlinePassword({
      username:String(credentials.username||''),
      pin:String(credentials.pin||''),
      initialPassword:String(credentials.initialPassword||''),
      password:String(credentials.password||''),
      timeoutMs:30000
    });

    if(result?.ok===true){
      fisRenewRecordSuccess(result.message||'Ripristino password effettuato con successo.');
      fisRenewSetStatus(`Rinnovo riuscito e verificato dall'Agenzia delle Entrate. Il contatore è ripartito da 30 giorni. ${result.message||''}`.trim(),'ok');
      toast('Rinnovo Fisconline riuscito · nuovo ciclo 30 giorni',5000);
      fisRenewAutomaticRun=false;
      return true
    }

    const message=String(result?.message||'Esito del ripristino non riconosciuto.');
    localStorage.setItem(K.fisRenewLastResult,JSON.stringify({ok:false,at:Date.now(),message}));
    fisRenewSetStatus(`Rinnovo non riuscito: ${message} CassaIQ riproverà il giorno successivo; il DCO resta invariato.`,'error');
    if(automatic)alert('Rinnovo automatico Fisconline non riuscito. CassaIQ riproverà il giorno successivo. Il Documento Commerciale Online non è stato toccato.');
    fisRenewAutomaticRun=false;
    return false
  }catch(e){
    const message=String(e?.message||e||'Errore di rete');
    localStorage.setItem(K.fisRenewLastResult,JSON.stringify({ok:false,at:Date.now(),message}));
    fisRenewSetStatus(`Rinnovo non riuscito: ${message}. CassaIQ riproverà il giorno successivo; il DCO resta invariato.`,'error');
    if(automatic)alert('Rinnovo automatico Fisconline non riuscito. CassaIQ riproverà il giorno successivo. Il Documento Commerciale Online non è stato toccato.');
    fisRenewAutomaticRun=false;
    return false
  }finally{
    fisRenewSetBusy(false,'Rinnova ora');
    fisRenewWipeCredentials(credentials)
  }
}
async function fisRenewManualTest(){return fisRenewStart({automatic:false})}

async function fisRenewMaybeAuto(){
  if(fisRenewBusy||isIssuing||dcoAutoSale||dcoConnectionPending)return false;
  const info=fisRenewCycleInfo();
  if(!info||info.daysRemaining>0)return false; // automatico solo dopo almeno un rinnovo reale riuscito
  const today=dcoLocalDayKey();
  if(localStorage.getItem(K.fisRenewLastAttemptDay)===today)return false; // max 1 tentativo/giorno
  if(dcoHasSessionMarker()){
    fisRenewSetStatus('Rinnovo Fisconline previsto, ma rimandato perché il DCO è collegato. Verrà eseguito quando la sessione DCO non sarà attiva.','warning');
    return false
  }

  const credentials=await dcoLoadFisconlineCredentials();
  const canRenew=!!(credentials&&credentials.initialPassword);
  fisRenewWipeCredentials(credentials);
  if(!canRenew)return false;

  return fisRenewStart({automatic:true})
}

function dcoResetFisconlineLoginState(){dcoFisconlineLoginSubmittedAt=0;dcoFisconlineLoginSubmitUrl='';dcoFisconlineLoginStage='idle'}

function dcoAuthMode(){return 'fisconline'}
function dcoSecurePlugin(){const plugin=printerNativePlugin();return plugin&&typeof plugin.secureGet==='function'&&typeof plugin.secureSet==='function'&&typeof plugin.secureRemove==='function'?plugin:null}
function dcoFisconlineCredentialsFromForm(){return{username:String($('dcoFisconlineUser')?.value||'').trim(),password:String($('dcoFisconlinePassword')?.value||''),pin:String($('dcoFisconlinePin')?.value||'').replace(/\s+/g,''),initialPassword:String($('dcoFisconlineInitialPassword')?.value||'').trim()}}
function dcoFisconlineCredentialsValidation(value){const c=value||{};const missing=[];if(!String(c.username||'').trim())missing.push('codice fiscale / nome utente');if(!String(c.password||''))missing.push('password');if(!/^\d{10}$/.test(String(c.pin||'')))missing.push('PIN Fisconline di 10 cifre');return{ok:missing.length===0,missing}}
async function dcoLoadFisconlineCredentials(){
  const plugin=dcoSecurePlugin();if(!plugin)return null;
  try{
    const out=await plugin.secureGet({key:DCO_SECURE_CREDENTIALS_KEY}),raw=String(out?.value||'');if(!raw)return null;
    const value=JSON.parse(raw),check=dcoFisconlineCredentialsValidation(value);return check.ok?{username:String(value.username).trim(),password:String(value.password),pin:String(value.pin),initialPassword:String(value.initialPassword||'')}:null
  }catch(e){console.warn('Credenziali Fisconline non leggibili',e);return null}
}
async function dcoSaveFisconlineCredentials(showMessage=true){
  const plugin=dcoSecurePlugin();if(!plugin){renderDcoFisconlineStatus('Archivio sicuro non disponibile. Sincronizza nuovamente il progetto nativo.','error');return false}
  const value=dcoFisconlineCredentialsFromForm(),check=dcoFisconlineCredentialsValidation(value);
  if(!check.ok){renderDcoFisconlineStatus(`Completa ${check.missing.join(', ')}.`,'error');return false}
  try{
    const previous=await dcoLoadFisconlineCredentials();
    if(!value.initialPassword&&previous?.initialPassword)value.initialPassword=previous.initialPassword;
    await plugin.secureSet({key:DCO_SECURE_CREDENTIALS_KEY,value:JSON.stringify(value)});
    dcoFisconlineConfigured=true;fisRenewInitialPasswordSaved=!!value.initialPassword;localStorage.setItem(K.dcoAuthMode,'fisconline');setFiscalMode('dco');
    if(!previous||previous.password!==value.password||!dcoFisconlinePasswordSetAtMs())dcoMarkFisconlinePasswordRenewed();
    ['dcoFisconlineUser','dcoFisconlinePassword','dcoFisconlinePin','dcoFisconlineInitialPassword'].forEach(id=>{const el=$(id);if(el)el.value=''});
    renderDcoAuthUi();renderDcoFisconlineStatus('Credenziali salvate in modo sicuro solo su questo dispositivo.','ok');
    if(showMessage)toast('Credenziali Fisconline salvate sul dispositivo');
    return true
  }catch(e){renderDcoFisconlineStatus(`Salvataggio sicuro non riuscito: ${e.message||e}`,'error');return false}
}
async function dcoClearFisconlineCredentials(){
  const plugin=dcoSecurePlugin();try{if(plugin)await plugin.secureRemove({key:DCO_SECURE_CREDENTIALS_KEY})}catch{}
  dcoFisconlineConfigured=false;fisRenewInitialPasswordSaved=false;dcoConnectionCredentials=null;localStorage.removeItem(K.dcoFisconlinePasswordSetAt);localStorage.removeItem(K.dcoFisconlinePasswordReminderDay);localStorage.removeItem(K.fisRenewLastSuccessAt);localStorage.removeItem(K.fisRenewLastAttemptDay);localStorage.removeItem(K.fisRenewLastResult);
  ['dcoFisconlineUser','dcoFisconlinePassword','dcoFisconlinePin','dcoFisconlineInitialPassword'].forEach(id=>{const el=$(id);if(el)el.value=''});
  renderDcoAuthUi();renderDcoFisconlineStatus('Credenziali eliminate da questo dispositivo.','warning');toast('Credenziali Fisconline eliminate')
}
function renderDcoFisconlineStatus(message,type){
  const el=$('dcoFisconlineStatus');if(!el)return;
  el.className=`config-status-line ${type||(dcoFisconlineConfigured?'ok':'')}`.trim();
  el.textContent=message||(dcoFisconlineConfigured?'Credenziali Fisconline salvate in modo sicuro su questo dispositivo.':'Credenziali non ancora configurate su questo dispositivo.');
  renderDcoFisconlinePasswordCounter()
}
function dcoShowCredentialIssue(type,message){
  dcoCredentialIssueType=String(type||'error');
  const dlg=$('dcoCredentialIssueDialog'),title=$('dcoCredentialIssueTitle'),text=$('dcoCredentialIssueText'),expired=$('dcoExpiredPasswordBox'),edit=$('dcoCredentialEdit'),save=$('dcoSaveRenewedPassword'),input=$('dcoRenewedPassword'),result=$('dcoRenewedPasswordResult');
  if(!dlg)return;
  const isExpired=dcoCredentialIssueType==='PASSWORD_EXPIRED';
  const isExpiring=dcoCredentialIssueType==='PASSWORD_EXPIRING';
  const isDisabled=dcoCredentialIssueType==='ACCOUNT_DISABLED';
  dlg.classList.toggle('password-warning',isExpiring);
  if(title)title.textContent=isExpired?'Password Fisconline scaduta':isExpiring?'Password Fisconline in scadenza':isDisabled?'Utenza Fisconline temporaneamente disabilitata':'Accesso Fisconline non riuscito';
  if(text)text.textContent=message||(isExpired?'La password dei Servizi Telematici deve essere rinnovata sul sito ufficiale dell’Agenzia delle Entrate.':isExpiring?'La password Fisconline è vicina alla scadenza. Rinnovala prima della data indicata per evitare interruzioni del DCO.':isDisabled?'L’Agenzia delle Entrate ha temporaneamente disabilitato l’utenza. CassaIQ non effettuerà altri tentativi automatici.':'Le credenziali sono state rifiutate dall’Agenzia delle Entrate. Controlla codice fiscale/nome utente, password e PIN prima di riprovare.');
  if(expired)expired.hidden=!(isExpired||isExpiring);
  const instructions=$('dcoPasswordRenewalInstructions');if(instructions)instructions.textContent=(isExpired||isExpiring)?'1. Apri il sito ufficiale dei Servizi Telematici dell’Agenzia delle Entrate. 2. Accedi con le credenziali Fisconline e completa il cambio password richiesto dal portale. 3. Torna in CassaIQ e inserisci qui soltanto la nuova password: codice fiscale/nome utente e PIN restano invariati.':'Il cambio password va eseguito sul sito ufficiale dell’Agenzia delle Entrate.';
  if(edit)edit.hidden=isExpired||isExpiring||isDisabled;
  if(save)save.hidden=!(isExpired||isExpiring);
  if(input){input.value='';if(isExpired)setTimeout(()=>input.focus(),250)}
  if(result){result.hidden=true;result.textContent='';result.className='test-result'}
  const openBtn=$('dcoOpenPasswordRenewal'),closeBtn=$('dcoCredentialIssueClose'),editBtn=$('dcoCredentialEdit'),saveBtn=$('dcoSaveRenewedPassword');
  if(openBtn)openBtn.onclick=dcoOpenPasswordRenewalExternal;
  if(closeBtn)closeBtn.onclick=()=>{if(dlg.open)dlg.close()};
  if(editBtn)editBtn.onclick=()=>{if(dlg.open)dlg.close();showView('dcolab');setTimeout(()=>{const panel=$('dcoFisconlinePanel');panel?.scrollIntoView?.({behavior:'smooth',block:'center'});const pass=$('dcoFisconlinePassword');pass?.focus?.()},150)};
  if(saveBtn)saveBtn.onclick=()=>dcoUpdateFisconlinePasswordOnly();
  if(!dlg.open)dlg.showModal();
}
function dcoOpenPasswordRenewalExternal(){
  try{window.open(DCO_PASSWORD_RENEW_URL,'_system')}catch(e){try{location.href=DCO_PASSWORD_RENEW_URL}catch(_){toast('Apri telematici.agenziaentrate.gov.it nel browser',5000)}}
}
async function dcoUpdateFisconlinePasswordOnly(){
  const input=$('dcoRenewedPassword'),result=$('dcoRenewedPasswordResult'),value=String(input?.value||'');
  const show=(type,msg)=>{if(result){result.hidden=false;result.className=`test-result ${type}`;result.textContent=msg}};
  if(value.length<8||value.length>15){show('error','La nuova password deve contenere da 8 a 15 caratteri.');return false}
  const plugin=dcoSecurePlugin();if(!plugin){show('error','Archivio sicuro non disponibile. Sincronizza nuovamente il progetto nativo.');return false}
  const current=await dcoLoadFisconlineCredentials();if(!current){show('error','Credenziali Fisconline non trovate sul dispositivo. Chiudi questa finestra e reinserisci codice fiscale, password e PIN.');return false}
  try{
    current.password=value;
    await plugin.secureSet({key:DCO_SECURE_CREDENTIALS_KEY,value:JSON.stringify(current)});
    dcoMarkFisconlinePasswordRenewed();
    if(input)input.value='';
    dcoFisconlineConfigured=true;dcoConnectionCredentials=null;dcoConnectionPending=false;dcoResetFisconlineLoginState();dcoClearConnected();
    renderDcoAuthUi();renderDcoFisconlineStatus('Nuova password Fisconline salvata. CF/nome utente e PIN sono rimasti invariati.','ok');renderDcoConnectionStatus('Nuova password salvata. CassaIQ potrà ricollegarsi automaticamente alla prossima emissione.','ok');
    show('ok','Nuova password salvata in modo sicuro sul dispositivo.');toast('Nuova password Fisconline salvata',4000);
    setTimeout(()=>{const dlg=$('dcoCredentialIssueDialog');if(dlg?.open)dlg.close()},850);
    return true
  }catch(e){show('error',`Salvataggio non riuscito: ${e.message||e}`);return false}
}
async function dcoRefreshFisconlineConfigured(){
  const loaded=await dcoLoadFisconlineCredentials();
  dcoFisconlineConfigured=!!loaded;
  fisRenewInitialPasswordSaved=!!loaded?.initialPassword;
  if(dcoFisconlineConfigured)dcoEnsureFisconlinePasswordCounter();
  renderDcoAuthUi();renderDcoFisconlineStatus();renderDcoConnectionStatus();renderDcoFisconlinePasswordCounter()
}
function dcoSetAuthMode(mode){
  // Fisconline resta sempre il metodo preferito. SPID/CIE/CNS apre soltanto
  // una sessione alternativa e non modifica la preferenza persistente.
  if(mode==='fisconline'){localStorage.setItem(K.dcoAuthMode,'fisconline');dcoConnectionMethod='fisconline'}
  else dcoConnectionMethod='spid';
  renderDcoAuthUi();renderDcoConnectionStatus()
}
function dcoConnectionOverlayMessage(message){
  const raw=String(message||'').trim();
  if(!raw)return'Connessione al DCO in corso…';
  return raw
    .replace(/^Collegamento Fisconline automatico in corso…?$/i,'Accesso Fisconline in corso…')
    .replace(/^Collegamento in corso…?/i,'Connessione al DCO in corso…');
}
function dcoShowConnectionOverlay(message='Connessione al DCO in corso…'){
  const overlay=$('dcoConnectionOverlay'),statusEl=$('dcoConnectionOverlayStatus');if(!overlay||!statusEl)return;
  statusEl.textContent=dcoConnectionOverlayMessage(message);
  overlay.hidden=false;overlay.setAttribute('aria-busy','true');
}
function dcoHideConnectionOverlay(){
  const overlay=$('dcoConnectionOverlay');if(!overlay)return;
  overlay.hidden=true;overlay.setAttribute('aria-busy','false');
}

function renderDcoAuthUi(){
  const fisPanel=$('dcoFisconlinePanel'),spidPanel=$('dcoSpidPanel'),alternative=$('dcoSpidAlternative');
  if(fisPanel)fisPanel.hidden=false;
  if(spidPanel)spidPanel.hidden=!DCO_SPID_UI_ENABLED;
  if(alternative){alternative.hidden=!DCO_SPID_UI_ENABLED;alternative.setAttribute('aria-hidden',DCO_SPID_UI_ENABLED?'false':'true');alternative.classList.toggle('session-active',DCO_SPID_UI_ENABLED&&dcoSessionInfo()?.authMode==='spid'&&dcoHasSessionMarker())}
  const quick=$('dcoConnectQuick');
  if(quick){
    const alreadyConnected=dcoHasSessionMarker(),businessOk=dcoBusinessValidation().ok,wait=fisRenewDcoStabilizeSeconds(),connecting=dcoConnectionPending||dcoConnectionStartBusy;
    quick.textContent=alreadyConnected?'DCO già collegato':connecting?'Connessione in corso…':wait>0?`Attendi ${wait}s`:dcoFisconlineConfigured?'Collega automaticamente':'Salva e collega';
    quick.disabled=alreadyConnected||connecting||!businessOk||wait>0;
  }
}
async function dcoFisconlineEncryptPayload(publicJwk,credentials){
  if(!globalThis.crypto?.subtle)throw new Error('Cifratura WebCrypto non disponibile.');
  const key=await crypto.subtle.importKey('jwk',publicJwk,{name:'RSA-OAEP',hash:'SHA-256'},false,['encrypt']);
  const clear=new TextEncoder().encode(JSON.stringify({username:String(credentials?.username||''),password:String(credentials?.password||''),pin:String(credentials?.pin||'')}));
  const encrypted=await crypto.subtle.encrypt({name:'RSA-OAEP'},key,clear);
  const bytes=new Uint8Array(encrypted);let binary='';for(let i=0;i<bytes.length;i++)binary+=String.fromCharCode(bytes[i]);
  return btoa(binary)
}
async function dcoFisconlineWaitPageResult(ref,resultKey,timeoutMs=18000){
  const deadline=Date.now()+timeoutMs,keyLiteral=JSON.stringify(String(resultKey||''));
  const storageLiteral=JSON.stringify(`cassaiq:fis:result:${String(resultKey||'')}`);
  // Lascia qualche millisecondo a WebCrypto prima del primo poll: su WKWebView
  // un polling immediato puo sovrapporsi alla callback di evaluateJavaScript.
  await new Promise(resolve=>setTimeout(resolve,260));
  let consecutiveErrors=0;
  while(Date.now()<deadline){
    let value=null;
    try{
      value=await dcoExecScript(ref,`(function(){try{var k=${keyLiteral},sk=${storageLiteral},slot=window[k],raw='';if(slot&&slot.state==='done'){var out=slot.value;try{delete window[k]}catch(e){window[k]=null}try{sessionStorage.removeItem(sk)}catch(e){}return out}try{raw=sessionStorage.getItem(sk)||''}catch(e){}if(raw){var parsed=JSON.parse(raw);if(parsed&&parsed.state==='done'){try{sessionStorage.removeItem(sk)}catch(e){}try{delete window[k]}catch(e){window[k]=null}return parsed.value}if(parsed&&parsed.state==='pending')return{pending:true}}if(slot&&slot.state!=='done')return{pending:true};return null}catch(e){return{ok:false,reason:String(e&&e.message||e)}}})()`,2500);
      consecutiveErrors=0;
    }catch(e){
      consecutiveErrors++;
      if(Date.now()>=deadline||consecutiveErrors>=4)throw e;
    }
    if(value&&!value.pending)return value;
    await new Promise(resolve=>setTimeout(resolve,220));
  }
  // Pulizia best-effort dei soli marker temporanei, mai delle credenziali salvate.
  await dcoExecScript(ref,`(function(){try{var k=${keyLiteral},sk=${storageLiteral};try{delete window[k]}catch(e){window[k]=null}try{sessionStorage.removeItem(sk)}catch(e){}return true}catch(e){return false}})()`,1800).catch(()=>{});
  throw new Error('Risposta sicura Fisconline scaduta.');
}
async function dcoFisconlineLoginAction(ref,credentials){
  if(dcoFisconlineActionBusy||Date.now()-dcoFisconlineLastActionAt<450)return{ok:true,action:'cooldown'};
  dcoFisconlineActionBusy=true;dcoFisconlineLastActionAt=Date.now();
  let privateStorageKey='';
  try{
    // Stato IAM preciso, come il flusso osservato nell'app di riferimento:
    // tab Fisconline/Entratel (#tab-4), tre IDToken e submit del solo pannello tab-4.
    // Dopo il primo submit NON ritentiamo le credenziali: attendiamo navigazione/#user-info.
    const state=await dcoExecScript(ref,`(function(){
      try{
        function clean(v){return String(v==null?'':v).replace(/\\s+/g,' ').trim().toLowerCase()}
        function visible(el){if(!el||el.disabled)return false;try{var st=getComputedStyle(el),r=el.getBoundingClientRect();return st.display!=='none'&&st.visibility!=='hidden'&&r.width>0&&r.height>0}catch(e){return true}}
        var host=String(location.hostname||'').toLowerCase(),path=String(location.pathname||'').toLowerCase();
        var body=clean(document.body&&document.body.innerText||''),errorEl=document.querySelector('#error-msg');
        var errorText=clean(errorEl&&errorEl.textContent||'');
        if(document.querySelector('#user-info'))return{ok:true,action:'iam-authenticated'};
        if(body.indexOf('la tua password è scaduta')>=0||body.indexOf('la tua password e scaduta')>=0||body.indexOf('password scaduta')>=0||body.indexOf('password risulta scaduta')>=0||(body.indexOf('password')>=0&&body.indexOf('scadut')>=0)||(body.indexOf('vecchia password')>=0&&body.indexOf('nuova password')>=0&&body.indexOf('conferma')>=0))return{ok:false,error:'PASSWORD_EXPIRED'};
        if(body.indexOf('utente temporaneamente disabilitato')>=0)return{ok:false,error:'ACCOUNT_DISABLED'};
        if(errorText||body.indexOf('autenticazione fallita')>=0||body.indexOf('credenziali non valide')>=0||body.indexOf('credenziali errate')>=0||(body.indexOf('utente o password')>=0&&body.indexOf('errat')>=0))return{ok:false,error:'CREDENTIALS_REJECTED'};
        if(host.indexOf('iampe.agenziaentrate.gov.it')<0||path.indexOf('/sam/ui/login')<0)return{ok:false,reason:'not-iam-login'};
        var panel=document.querySelector('#tab-4');
        var tabLink=document.querySelector('a[href="#tab-4"],[aria-controls="tab-4"],[data-target="#tab-4"],[data-bs-target="#tab-4"]');
        var user=(panel&&panel.querySelector('#username-fo-ent,[name="IDToken1"]'))||document.querySelector('#username-fo-ent');
        var pass=(panel&&panel.querySelector('#password-fo-ent-1,[name="IDToken2"]'))||document.querySelector('#password-fo-ent-1');
        var pin=(panel&&panel.querySelector('#pin-fo-ent,[name="IDToken3"]'))||document.querySelector('#pin-fo-ent');
        var submit=(panel&&panel.querySelector('[type="submit"]'))||document.querySelector('#tab-4 [type="submit"]');
        var fieldsReady=visible(user)&&visible(pass)&&visible(pin),submitReady=visible(submit);
        if(!fieldsReady||!submitReady){
          if(tabLink&&visible(tabLink)){try{tabLink.click()}catch(e){}return{ok:true,action:'iam-credentials-tab-opened',fieldsReady:fieldsReady,submitReady:submitReady}}
          return{ok:false,reason:'iam-fields-not-ready',fieldsReady:fieldsReady,submitReady:submitReady,hasPanel:!!panel,hasUser:!!user,hasPassword:!!pass,hasPin:!!pin,hasSubmit:!!submit};
        }
        return{ok:true,action:'iam-credentials-ready'};
      }catch(e){return{ok:false,reason:String(e&&e.message||e)}}
    })()`,5000);

    if(state?.error)return state;
    if(state?.action==='iam-authenticated')return state;

    // Un solo invio credenziali per tentativo. Se la pagina IAM è ancora presente,
    // aspettiamo il redirect invece di premere nuovamente Accedi (protezione anti lockout).
    if(dcoFisconlineLoginSubmittedAt){
      const elapsed=Date.now()-dcoFisconlineLoginSubmittedAt;
      if(elapsed<12000)return{ok:true,action:'iam-login-awaiting-result',elapsed};
      return{ok:false,error:'LOGIN_NOT_COMPLETED',reason:'iam-login-still-visible-after-submit'};
    }
    if(state?.action==='iam-credentials-tab-opened'){dcoFisconlineLoginStage='tab-opened';return state}
    if(state?.action!=='iam-credentials-ready')return state||{ok:false,reason:'iam-not-ready'};

    dcoFisconlineLoginStage='secure-channel';
    const probeKey=`__cassaiqFisProbe_${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
    privateStorageKey=`cassaiq:fis:private:${probeKey}`;
    const probeKeyLiteral=JSON.stringify(probeKey),probeStorageLiteral=JSON.stringify(`cassaiq:fis:result:${probeKey}`),privateStorageLiteral=JSON.stringify(privateStorageKey);
    const probeCode=`(function(){
      var RESULT_KEY=${probeKeyLiteral},RESULT_STORAGE=${probeStorageLiteral},PRIVATE_STORAGE=${privateStorageLiteral};
      function publish(state,value){var packet={state:state,value:value};try{window[RESULT_KEY]=packet}catch(e){}try{sessionStorage.setItem(RESULT_STORAGE,JSON.stringify(packet))}catch(e){}}
      function done(value){publish('done',value)}
      try{
        publish('pending',null);
        var host=String(location.hostname||'').toLowerCase(),path=String(location.pathname||'').toLowerCase();
        if(host.indexOf('iampe.agenziaentrate.gov.it')<0||path.indexOf('/sam/ui/login')<0){done({ok:false,reason:'not-iam-login'});return{ok:true,action:'probe-started'}}
        function visible(el){if(!el||el.disabled)return false;try{var st=getComputedStyle(el),r=el.getBoundingClientRect();return st.display!=='none'&&st.visibility!=='hidden'&&r.width>0&&r.height>0}catch(e){return true}}
        var panel=document.querySelector('#tab-4');
        var user=(panel&&panel.querySelector('#username-fo-ent,[name="IDToken1"]'))||document.querySelector('#username-fo-ent');
        var pass=(panel&&panel.querySelector('#password-fo-ent-1,[name="IDToken2"]'))||document.querySelector('#password-fo-ent-1');
        var pin=(panel&&panel.querySelector('#pin-fo-ent,[name="IDToken3"]'))||document.querySelector('#pin-fo-ent');
        var submit=(panel&&panel.querySelector('[type="submit"]'))||document.querySelector('#tab-4 [type="submit"]');
        if(!visible(user)||!visible(pass)||!visible(pin)||!visible(submit)){done({ok:false,reason:'iam-exact-controls-not-ready'});return{ok:true,action:'probe-started'}}
        if(!globalThis.crypto||!crypto.subtle){done({ok:false,error:'SECURE_CHANNEL_UNAVAILABLE'});return{ok:true,action:'probe-started'}}
        crypto.subtle.generateKey({name:'RSA-OAEP',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['encrypt','decrypt'])
          .then(function(pair){window.__cassaiqFisconlinePrivateKey=pair.privateKey;return Promise.all([crypto.subtle.exportKey('jwk',pair.publicKey),crypto.subtle.exportKey('jwk',pair.privateKey)])})
          .then(function(keys){try{sessionStorage.setItem(PRIVATE_STORAGE,JSON.stringify(keys[1]))}catch(e){}done({ok:true,action:'secure-channel-ready',publicJwk:keys[0],privateStorageKey:PRIVATE_STORAGE})})
          .catch(function(e){try{window.__cassaiqFisconlinePrivateKey=null}catch(_){}try{sessionStorage.removeItem(PRIVATE_STORAGE)}catch(_){}done({ok:false,error:'SECURE_CHANNEL_FAILED',reason:String(e&&e.message||e)})});
      }catch(e){done({ok:false,reason:String(e&&e.message||e)})}
      return{ok:true,action:'probe-started'}
    })()`;
    await dcoExecScript(ref,probeCode,5000);
    const probe=await dcoFisconlineWaitPageResult(ref,probeKey,18000);
    if(!probe?.ok||probe.action!=='secure-channel-ready')return probe;

    const cipher=await dcoFisconlineEncryptPayload(probe.publicJwk,credentials||{});
    privateStorageKey=String(probe.privateStorageKey||privateStorageKey);
    const fillKey=`__cassaiqFisFill_${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
    const fillKeyLiteral=JSON.stringify(fillKey),fillStorageLiteral=JSON.stringify(`cassaiq:fis:result:${fillKey}`),cipherLiteral=JSON.stringify(cipher),privateStorageLiteral2=JSON.stringify(privateStorageKey);
    const fillCode=`(function(){
      var RESULT_KEY=${fillKeyLiteral},RESULT_STORAGE=${fillStorageLiteral},PRIVATE_STORAGE=${privateStorageLiteral2},CIPHER=${cipherLiteral};
      function publish(state,value){var packet={state:state,value:value};try{window[RESULT_KEY]=packet}catch(e){}try{sessionStorage.setItem(RESULT_STORAGE,JSON.stringify(packet))}catch(e){}}
      function done(value){publish('done',value)}
      try{
        publish('pending',null);
        if(!globalThis.crypto||!crypto.subtle){done({ok:false,error:'SECURE_CHANNEL_UNAVAILABLE'});return{ok:true,action:'fill-started'}}
        function visible(el){if(!el||el.disabled)return false;try{var st=getComputedStyle(el),r=el.getBoundingClientRect();return st.display!=='none'&&st.visibility!=='hidden'&&r.width>0&&r.height>0}catch(e){return true}}
        function setValue(el,value){if(!el)return;var proto=HTMLInputElement.prototype,desc=Object.getOwnPropertyDescriptor(proto,'value');if(desc&&desc.set)desc.set.call(el,value);else el.value=value;['input','change','keyup'].forEach(function(n){try{el.dispatchEvent(new Event(n,{bubbles:true}))}catch(e){}})}
        var panel=document.querySelector('#tab-4');
        var user=(panel&&panel.querySelector('#username-fo-ent,[name="IDToken1"]'))||document.querySelector('#username-fo-ent');
        var pass=(panel&&panel.querySelector('#password-fo-ent-1,[name="IDToken2"]'))||document.querySelector('#password-fo-ent-1');
        var pin=(panel&&panel.querySelector('#pin-fo-ent,[name="IDToken3"]'))||document.querySelector('#pin-fo-ent');
        var submit=(panel&&panel.querySelector('[type="submit"]'))||document.querySelector('#tab-4 [type="submit"]');
        if(!visible(user)||!visible(pass)||!visible(pin)||!visible(submit)){done({ok:false,reason:'iam-exact-controls-changed'});return{ok:true,action:'fill-started'}}
        var memoryKey=window.__cassaiqFisconlinePrivateKey;window.__cassaiqFisconlinePrivateKey=null;
        var stored='';try{stored=sessionStorage.getItem(PRIVATE_STORAGE)||'';sessionStorage.removeItem(PRIVATE_STORAGE)}catch(e){}
        var keyPromise;if(stored){try{var privateJwk=JSON.parse(stored);stored='';keyPromise=crypto.subtle.importKey('jwk',privateJwk,{name:'RSA-OAEP',hash:'SHA-256'},false,['decrypt']);privateJwk=null}catch(e){keyPromise=Promise.reject(e)}}else if(memoryKey){keyPromise=Promise.resolve(memoryKey)}else{done({ok:false,error:'SECURE_CHANNEL_EXPIRED'});return{ok:true,action:'fill-started'}}
        var raw=atob(CIPHER),bytes=new Uint8Array(raw.length);for(var i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);CIPHER='';raw='';
        keyPromise.then(function(privateKey){return crypto.subtle.decrypt({name:'RSA-OAEP'},privateKey,bytes)}).then(function(clear){
          bytes.fill(0);memoryKey=null;var clearBytes=new Uint8Array(clear),text=new TextDecoder().decode(clearBytes),creds;
          try{creds=JSON.parse(text)}finally{clearBytes.fill(0);text=''}
          setValue(user,String(creds.username||''));setValue(pass,String(creds.password||''));setValue(pin,String(creds.pin||''));
          creds.username='';creds.password='';creds.pin='';creds=null;
          try{user.focus();user.blur();pass.focus();pass.blur();pin.focus();pin.blur()}catch(e){}
          done({ok:true,action:'secure-credentials-filled',submitReady:visible(submit)});
        }).catch(function(e){try{bytes.fill(0)}catch(_){}done({ok:false,error:'SECURE_CHANNEL_FAILED',reason:String(e&&e.message||e)})});
      }catch(e){try{window.__cassaiqFisconlinePrivateKey=null}catch(_){}try{sessionStorage.removeItem(PRIVATE_STORAGE)}catch(_){}done({ok:false,error:'SECURE_CHANNEL_FAILED',reason:String(e&&e.message||e)})}
      return{ok:true,action:'fill-started'}
    })()`;
    await dcoExecScript(ref,fillCode,5000);
    const filled=await dcoFisconlineWaitPageResult(ref,fillKey,18000);
    if(!filled?.ok)return filled;

    // Submit ESATTO del pannello Fisconline, senza ricerca generica di altri "Accedi".
    const submitOut=await dcoExecScript(ref,`(function(){
      try{
        function visible(el){if(!el||el.disabled)return false;try{var st=getComputedStyle(el),r=el.getBoundingClientRect();return st.display!=='none'&&st.visibility!=='hidden'&&r.width>0&&r.height>0}catch(e){return true}}
        var panel=document.querySelector('#tab-4'),submit=(panel&&panel.querySelector('[type="submit"]'))||document.querySelector('#tab-4 [type="submit"]');
        if(!visible(submit))return{ok:false,reason:'fisconline-submit-not-found'};
        try{submit.scrollIntoView({block:'center',inline:'center'})}catch(e){}
        setTimeout(function(){try{submit.click()}catch(e){}},120);
        return{ok:true,action:'secure-credentials-submit'};
      }catch(e){return{ok:false,reason:String(e&&e.message||e)}}
    })()`,5000);
    if(submitOut?.ok){dcoFisconlineLoginSubmittedAt=Date.now();dcoFisconlineLoginSubmitUrl=DCO_URLS.login;dcoFisconlineLoginStage='submitted'}
    return submitOut;
  }finally{
    if(privateStorageKey&&ref){const cleanup=JSON.stringify(privateStorageKey);dcoExecScript(ref,`(function(){try{sessionStorage.removeItem(${cleanup});window.__cassaiqFisconlinePrivateKey=null;return true}catch(e){return false}})()`,1800).catch(()=>{})}
    dcoFisconlineActionBusy=false;
  }
}

function fiscalMode(){return localStorage.getItem(K.fiscalMode)||'epson'}
const DCO_BUSINESS_FIELDS={legalName:'businessLegalName',tradeName:'businessTradeName',vat:'businessVat',taxCode:'businessTaxCode',address:'businessAddress',civic:'businessCivic',zip:'businessZip',city:'businessCity',province:'businessProvince',phone:'businessPhone',email:'businessEmail'};
let dcoReceiptLogoDraftData='',dcoReceiptLogoDraftEnabled=false,dcoReceiptLogoDraftInitialized=false,dcoReceiptLogoCloudSchemaMissing=false;
function dcoBusinessProfileStorageKey(){return `${K.businessProfile}.${getSession()?.user?.id||'local'}`}
function dcoBusinessProfile(){
  const saved=loadObjectSafe(dcoBusinessProfileStorageKey(),{}),logoData=String(saved?.receiptLogoData||'');
  return{legalName:String(saved?.legalName||'').trim(),tradeName:String(saved?.tradeName||'').trim(),vat:String(saved?.vat||'').replace(/\D/g,'').slice(0,11),taxCode:String(saved?.taxCode||'').trim().toUpperCase().slice(0,16),address:String(saved?.address||'').trim(),civic:String(saved?.civic||'').trim(),zip:String(saved?.zip||'').replace(/\D/g,'').slice(0,5),city:String(saved?.city||'').trim(),province:String(saved?.province||'').trim().toUpperCase().slice(0,2),phone:String(saved?.phone||'').trim(),email:String(saved?.email||'').trim(),receiptLogoData:logoData,receiptLogoEnabled:!!logoData&&saved?.receiptLogoEnabled!==false}
}
function dcoReceiptLogoRender(){
  const preview=$('businessReceiptLogoPreview'),remove=$('businessReceiptLogoRemove'),test=$('businessReceiptLogoTest'),enabled=$('businessReceiptLogoEnabled');
  if(preview)preview.innerHTML=dcoReceiptLogoDraftData?`<img src="${dcoReceiptLogoDraftData}" alt="Anteprima logo documento commerciale">`:'<span>Nessun logo</span>';
  if(remove)remove.disabled=false;if(test)test.disabled=false;
  if(enabled){enabled.disabled=!dcoReceiptLogoDraftData;enabled.checked=!!dcoReceiptLogoDraftData&&dcoReceiptLogoDraftEnabled}
}
function dcoReceiptLogoLoadDraft(profile=dcoBusinessProfile()){
  dcoReceiptLogoDraftData=String(profile?.receiptLogoData||'');dcoReceiptLogoDraftEnabled=!!dcoReceiptLogoDraftData&&profile?.receiptLogoEnabled!==false;dcoReceiptLogoDraftInitialized=true;dcoReceiptLogoRender()
}
function dcoBusinessProfileFromForm(){
  const get=key=>String($(DCO_BUSINESS_FIELDS[key])?.value||'').trim(),base=dcoBusinessProfile();
  if(!dcoReceiptLogoDraftInitialized)dcoReceiptLogoLoadDraft(base);
  return{legalName:get('legalName'),tradeName:get('tradeName'),vat:get('vat').replace(/\D/g,'').slice(0,11),taxCode:get('taxCode').toUpperCase().slice(0,16),address:get('address'),civic:get('civic'),zip:get('zip').replace(/\D/g,'').slice(0,5),city:get('city'),province:get('province').toUpperCase().slice(0,2),phone:get('phone'),email:get('email'),receiptLogoData:dcoReceiptLogoDraftData||'',receiptLogoEnabled:!!dcoReceiptLogoDraftData&&!!dcoReceiptLogoDraftEnabled}
}
async function dcoTestReceiptLogo(){
  const button=$('businessReceiptLogoTest'),data=dcoReceiptLogoDraftData;if(!data)return toast('Carica prima un logo.');
  const plugin=printerNativePlugin();if(!plugin)return alert('Modulo stampante di rete non disponibile.');
  const opt=dcoPrinterOptions();if(!/^(?:\d{1,3}\.){3}\d{1,3}$/.test(opt.host))return alert('Configura prima un indirizzo IP valido per la stampante di rete.');
  printerSetBusy(button,true,'Stampa…');
  try{
    const logo=await dcoReceiptLogoEscPos(data),payload=printerConcat(printerInit(),[0x1b,0x61,0x01],logo,[0x0a,0x1b,0x45,0x01],printerAscii('TEST LOGO CASSAIQ\n'),[0x1b,0x45,0x00],printerAscii('STAMPA NON FISCALE\n'),[0x1b,0x64,0x04,0x1d,0x56,0x00]);
    await plugin.printNetwork({host:opt.host,port:opt.port,data:printerBytesToBase64(payload),timeoutMs:10000});toast('Test logo inviato alla stampante di rete',3500)
  }catch(e){alert(`Test logo non riuscito: ${e.message||e}`)}finally{printerSetBusy(button,false)}
}
function dcoBusinessValidation(profile=dcoBusinessProfile()){const missing=[];if(!profile.legalName)missing.push('Ragione sociale');if(!/^\d{11}$/.test(profile.vat))missing.push('Partita IVA di 11 cifre');if(!profile.address)missing.push('Indirizzo');if(!profile.civic)missing.push('Numero civico');if(!/^\d{5}$/.test(profile.zip))missing.push('CAP di 5 cifre');if(!profile.city)missing.push('Comune');if(!/^[A-Z]{2}$/.test(profile.province))missing.push('Provincia di 2 lettere');return{ok:missing.length===0,missing}}
function dcoFillBusinessForm(){
  const profile=dcoBusinessProfile();for(const [key,id] of Object.entries(DCO_BUSINESS_FIELDS)){const el=$(id);if(el&&document.activeElement!==el)el.value=profile[key]||''}
  dcoReceiptLogoLoadDraft(profile);renderDcoBusinessStatus()
}
function renderDcoBusinessStatus(message,type){
  const profile=dcoBusinessProfile(),check=dcoBusinessValidation(profile),statusEl=$('configBusinessStatus'),dot=$('configBusinessDot'),connect=$('dcoConnectQuick'),spid=$('dcoSpidConnect'),saveDco=$('configUseDcoAndSave');
  if(dot)dot.className=`mini-status-dot ${check.ok?'ok':'error'}`;
  if(connect)connect.disabled=!check.ok||dcoHasSessionMarker();if(spid)spid.disabled=!check.ok;if(saveDco)saveDco.disabled=!check.ok;
  if(statusEl){statusEl.className=`config-status-line ${type||(check.ok?'ok':'error')}`.trim();statusEl.textContent=message||(check.ok?`Dati completi · ${profile.legalName} · P. IVA ${profile.vat}`:`Completa prima: ${check.missing.join(', ')}.`)}
  return check
}
async function dcoSaveBusinessProfile(showMessage=true){
  const profile=dcoBusinessProfileFromForm(),check=dcoBusinessValidation(profile);for(const [key,id] of Object.entries(DCO_BUSINESS_FIELDS)){const el=$(id);if(el)el.classList.toggle('invalid',check.missing.some(item=>({legalName:'Ragione sociale',vat:'Partita IVA di 11 cifre',address:'Indirizzo',civic:'Numero civico',zip:'CAP di 5 cifre',city:'Comune',province:'Provincia di 2 lettere'}[key]===item)))}
  if(!check.ok){renderDcoBusinessStatus(`Mancano dati obbligatori: ${check.missing.join(', ')}.`,'error');$(DCO_BUSINESS_FIELDS.legalName)?.scrollIntoView({behavior:'smooth',block:'center'});return false}
  localStorage.setItem(dcoBusinessProfileStorageKey(),JSON.stringify(profile));dcoReceiptLogoLoadDraft(profile);renderCart();const session=getSession();
  if(!session?.user?.id){renderDcoBusinessStatus('Dati salvati su questo dispositivo. Accedi per sincronizzarli sugli altri dispositivi.','warning');if(showMessage)toast('Dati attività salvati sul dispositivo');return true}
  renderDcoBusinessStatus('Dati salvati sul dispositivo · sincronizzazione cloud…','loading');
  try{
    dcoReceiptLogoCloudSchemaMissing=false;await cloudSaveBusinessProfile(profile);
    if(dcoReceiptLogoCloudSchemaMissing&&profile.receiptLogoData){
      renderDcoBusinessStatus('Dati attività sincronizzati. Il logo è già attivo su questo dispositivo; esegui supabase-receipt-logo-v1.14.78.sql per sincronizzarlo anche nel cloud.','warning');
      if(showMessage)toast('Logo salvato sul dispositivo · SQL cloud da eseguire',5000)
    }else{
      renderDcoBusinessStatus('Dati dell’attività salvati e sincronizzati con l’account.','ok');if(showMessage)toast('Dati attività sincronizzati')
    }
    return true
  }catch(e){console.warn('Profilo attività non sincronizzato',e);renderDcoBusinessStatus(`Dati salvati sul dispositivo, ma non nel cloud: ${e.message||e}`,'warning');if(showMessage)toast('Dati locali salvati; sincronizzazione cloud non riuscita',5000);return true}
}
function dcoRequireBusinessProfile(){const check=dcoBusinessValidation();if(check.ok)return true;showView('dcolab');dcoFillBusinessForm();renderDcoBusinessStatus(`Completa i dati dell’attività prima di usare il DCO: ${check.missing.join(', ')}.`,'error');setTimeout(()=>$(DCO_BUSINESS_FIELDS.legalName)?.focus(),250);return false}
function renderDcoSettingsCardStatus(){
  const card=$('settingsDco');if(!card)return;
  // Indicatore passivo: nessuna interrogazione periodica del portale.
  const ready=dcoHasSessionMarker()&&emergencyInternetOnline();
  card.classList.toggle('settings-status-ok',ready);
  card.classList.toggle('settings-status-error',!ready);
  card.setAttribute('aria-label',ready?'Documento Commerciale Online: sessione memorizzata e Internet disponibile':'Documento Commerciale Online: non collegato o Internet non disponibile');
}
function dcoSessionInfo(){return loadObjectSafe(K.dcoSession,null)}
function dcoHasSessionMarker(){return !!dcoSessionInfo()?.connectedAt}
function dcoMarkConnected(){
  const authMode=dcoConnectionMethod==='fisconline'?'fisconline':dcoConnectionMethod==='spid'?'spid':dcoAuthMode();
  const data={connectedAt:new Date().toISOString(),workProfile:true,authMode};
  localStorage.setItem(K.dcoSession,JSON.stringify(data));
  localStorage.setItem(K.fiscalMode,'dco');localStorage.setItem(K.dcoAuthMode,'fisconline');
  dcoConnectionCredentials=null;
  dcoVisualHealth='ok';dcoVisualHealthCheckedAt=Date.now();
  renderDcoAuthUi();renderDcoConnectionStatus();renderDcoSettingsCardStatus();renderCart();
  return data;
}
function dcoClearConnected(){localStorage.removeItem(K.dcoSession);dcoVisualHealth='error';dcoVisualHealthCheckedAt=Date.now();renderDcoConnectionStatus();renderDcoSettingsCardStatus();renderCart()}
function setFiscalMode(mode){
  const value=mode==='dco'?'dco':'epson';localStorage.setItem(K.fiscalMode,value);
  const select=$('dcoFiscalMode');if(select)select.value=value;
  renderConfigFiscalMode();renderDcoConnectionStatus();renderCart();
}
function renderDcoConnectionStatus(message,type){
  const el=$('dcoQuickConnectionStatus'),select=$('dcoFiscalMode'),disconnect=$('dcoDisconnectQuick'),clearLock=$('dcoClearPendingLock'),dot=$('configDcoDot');
  const connected=dcoHasSessionMarker(),mode=fiscalMode(),lock=loadObjectSafe(K.dcoAutoLock,null),auth=dcoAuthMode(),sessionAuth=dcoSessionInfo()?.authMode||auth;
  if(select)select.value=mode;
  if(disconnect)disconnect.hidden=!connected;
  if(clearLock)clearLock.hidden=!lock;
  if(dot)dot.className=`mini-status-dot ${lock?'error':connected?'ok':auth==='fisconline'&&dcoFisconlineConfigured?'ok':'error'}`;
  renderConfigFiscalMode();renderDcoAuthUi();renderDcoSettingsCardStatus();
  if(dcoConnectionPending||dcoConnectionStartBusy)dcoShowConnectionOverlay(message||'Connessione al DCO in corso…');
  else dcoHideConnectionOverlay();
  if(el){
    el.hidden=false;
    if(message){el.className=`test-result ${type||''}`.trim();el.textContent=message}
    else if(lock){el.className='test-result error';el.textContent=`Emissione DCO da verificare (${lock.total||'totale non disponibile'}). Nuove emissioni bloccate finché non controlli il portale.`}
    else if(connected){const at=new Date(dcoSessionInfo().connectedAt),label=sessionAuth==='fisconline'?'Fisconline':'SPID/CIE/CNS';el.className='test-result ok';el.textContent=`DCO collegato con ${label} · ${Number.isNaN(at.getTime())?'':at.toLocaleString('it-IT')}. Dopo il pagamento CassaIQ emette e stampa sulla stampante di rete.`}
    else if(auth==='fisconline'&&dcoFisconlineConfigured){el.className='test-result ok';el.textContent='Fisconline configurato. CassaIQ può autenticarsi automaticamente quando serve.'}
    else if(auth==='fisconline'){el.className='test-result warning';el.textContent='Fisconline selezionato: salva codice fiscale/nome utente, password e PIN su questo dispositivo.'}
    else{el.className='test-result warning';el.textContent='DCO non collegato. Configura Fisconline per attivare il collegamento automatico.'}
  }
  if(mode==='dco'){
    $('headerRt').textContent=connected?'DCO collegato':auth==='fisconline'&&dcoFisconlineConfigured?'DCO automatico':'Collega DCO';
    $('headerIp').textContent=connected||auth==='fisconline'&&dcoFisconlineConfigured?`Rete ${localStorage.getItem(K.printerTestIp)||'192.168.1.201'}`:'Fisconline da configurare';
    $('headerDot').className=connected||auth==='fisconline'&&dcoFisconlineConfigured?'ok':'error';
  }else if(localStorage.getItem(K.ip)){
    $('headerRt').textContent='Epson configurato';$('headerIp').textContent=localStorage.getItem(K.ip);$('headerDot').className='';
  }else{
    $('headerRt').textContent='Configura stampante';$('headerIp').textContent='IP Epson richiesto';$('headerDot').className='error';
  }
}
function renderConfigFiscalMode(){
  const mode=fiscalMode(),epsonButton=$('configUseEpson'),dcoButton=$('configUseDco'),rt=$('configRtArea'),network=$('configNetworkPrinterArea'),dco=$('configDcoArea'),badge=$('configModeBadge'),epsonStatus=$('configEpsonStatus'),epsonIp=$('configEpsonIp'),closureBox=$('configEpsonClosure');
  if(epsonButton)epsonButton.classList.toggle('active',mode==='epson');
  if(dcoButton)dcoButton.classList.toggle('active',mode==='dco');
  if(rt){rt.classList.toggle('active',mode==='epson');rt.classList.toggle('inactive',mode!=='epson')}
  if(network){network.classList.toggle('active',mode==='dco');network.classList.toggle('inactive',mode!=='dco')}
  if(dco){dco.classList.remove('inactive');dco.classList.toggle('active',mode==='dco')}
  if(closureBox)closureBox.hidden=mode!=='epson';
  if(badge){badge.className=`config-mode-badge ${mode}`;badge.textContent=mode==='dco'?'STAMPANTE DI RETE ATTIVA':'EPSON RT ATTIVO'}
  const savedIp=localStorage.getItem(K.ip)||'';
  if(epsonIp&&document.activeElement!==epsonIp)epsonIp.value=savedIp;
  if(epsonStatus){epsonStatus.className=`config-status-line ${savedIp?'ok':''}`.trim();epsonStatus.textContent=savedIp?`Epson configurato all’indirizzo ${savedIp}.`:'Indirizzo Epson non configurato.'}
}
async function configTestEpson(){
  const button=$('configEpsonTest'),field=$('configEpsonIp'),statusEl=$('configEpsonStatus'),ip=field?.value||'';
  if(!valid(ip)){if(statusEl){statusEl.className='config-status-line error';statusEl.textContent='Inserisci un indirizzo IP Epson valido.'}return}
  localStorage.setItem(K.ip,norm(ip));printerSetBusy(button,true,'Verifica…');if(statusEl){statusEl.className='config-status-line loading';statusEl.textContent='Lettura stato Epson…'}
  try{const res=await sendEpson('<printerCommand><queryPrinterStatus operator="1" /></printerCommand>',10000);if(!res.success)throw new Error(`${res.code||'stato non disponibile'}${res.status?` (${res.status})`:''}`);if(statusEl){statusEl.className='config-status-line ok';statusEl.textContent='Epson FP-81II RT collegato e operativo.'};status('ok','Epson connesso');$('headerIp').textContent=norm(ip)}catch(e){if(statusEl){statusEl.className='config-status-line error';statusEl.textContent=`Epson non raggiungibile: ${e.message||e}`};status('error','Epson offline')}finally{printerSetBusy(button,false)}
}
function configSaveEpson(){
  const field=$('configEpsonIp'),statusEl=$('configEpsonStatus'),ip=field?.value||'';
  if(!valid(ip)){if(statusEl){statusEl.className='config-status-line error';statusEl.textContent='Inserisci un indirizzo IP Epson valido.'}return}
  localStorage.setItem(K.ip,norm(ip));setFiscalMode('epson');status('','Epson configurato');$('headerIp').textContent=norm(ip);if(statusEl){statusEl.className='config-status-line ok';statusEl.textContent=`Epson salvato all’indirizzo ${norm(ip)}.`};toast('Epson RT configurato')
}
async function configTestNetworkPrinter(){
  const button=$('configNetworkPrinterTest'),out=$('configNetworkPrinterStatus'),opt=dcoPrinterOptions();
  localStorage.setItem(K.printerTestIp,opt.host);localStorage.setItem(K.printerTestPort,String(opt.port));
  printerSetBusy(button,true,'Invio test…');if(out){out.className='config-status-line loading';out.textContent='Connessione alla stampante di rete…'}
  try{const plugin=printerNativePlugin();if(!plugin)throw new Error('Modulo nativo stampante non disponibile.');if(!/^(?:\d{1,3}\.){3}\d{1,3}$/.test(opt.host))throw new Error('Indirizzo IP stampante di rete non valido.');const result=await plugin.printNetwork({host:opt.host,port:opt.port,data:printerBytesToBase64(printerTestPayload(`LAN ${opt.host}:${opt.port}`)),timeoutMs:8000});if(out){out.className='config-status-line ok';out.textContent=`Test stampante di rete inviato${result?.bytes?` · ${result.bytes} byte`:''}. Controlla stampa e taglio.`}}catch(e){if(out){out.className='config-status-line error';out.textContent=e.message||String(e)}}finally{printerSetBusy(button,false)}
}
async function configSaveDco(){
  if(!await dcoSaveBusinessProfile(false))return;
  const opt=dcoPrinterOptions();localStorage.setItem(K.printerTestIp,opt.host);localStorage.setItem(K.printerTestPort,String(opt.port));setFiscalMode('dco');
  toast(dcoHasSessionMarker()?'DCO e stampante di rete configurati':'Stampante di rete salvata. Configura o collega Fisconline.',4500)
}
function dcoQuickSetStatus(message,type='loading'){
  const el=$('dcoQuickProgressStatus');if(el){el.className=`test-result ${type}`;el.textContent=message}
  status(type==='ok'?'ok':type==='error'?'error':'',message);
}
function dcoQuickOpenProgress(){
  const dlg=$('dcoQuickProgressDialog'),close=$('dcoQuickProgressClose');if(close)close.hidden=true;dcoRenderQuickTiming(null);
  if(dlg&&!dlg.open)dlg.showModal();
}
function dcoQuickFinishProgress(message,type='ok'){
  dcoQuickSetStatus(message,type);const close=$('dcoQuickProgressClose');if(close)close.hidden=false;
}
function dcoEmissionOverlayCode(message,type='loading'){
  const bg=type==='error'?'#fff0f0':type==='ok'?'#eefbf7':'#ffffff';
  const accent=type==='error'?'#b42318':type==='ok'?'#087f5b':'#2FA8D7';
  const msg=JSON.stringify(String(message||'Emissione automatica in corso…'));
  return `(function(){
    var old=document.getElementById('cassaiq-emission-overlay');if(old)old.remove();
    var el=document.createElement('div');el.id='cassaiq-emission-overlay';
    el.style.cssText='position:fixed;inset:0;z-index:2147483646;background:rgba(9,35,43,.94);display:flex;align-items:center;justify-content:center;padding:24px;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;color:white;text-align:center;pointer-events:auto';
    var box=document.createElement('div');box.style.cssText='max-width:520px;background:${bg};color:#17333a;border-radius:18px;padding:28px;box-shadow:0 18px 70px rgba(0,0,0,.35)';
    var brand=document.createElement('div');brand.style.cssText='font-size:12px;font-weight:800;letter-spacing:.12em;color:${accent};margin-bottom:12px';brand.textContent='CASSAIQ · OPERAZIONE DCO';
    var title=document.createElement('div');title.style.cssText='font-size:22px;font-weight:800;margin-bottom:10px';title.textContent=${msg};
    var note=document.createElement('div');note.style.cssText='font-size:15px;line-height:1.45;color:#52666b';note.textContent='Non toccare i comandi del portale e non chiudere la finestra. CassaIQ tornerà alla cassa soltanto dopo l’esito fiscale e il recupero del PDF.';
    box.appendChild(brand);box.appendChild(title);box.appendChild(note);el.appendChild(box);document.documentElement.appendChild(el);return true
  })()`;
}
async function dcoShowEmissionOverlay(ref,message,type='loading'){
  if(!ref||dcoBrowserRef!==ref)return;
  // Non rendere visibile il portale durante il flusso automatico: l'overlay resta
  // nel documento del browser come protezione, mentre l'utente vede il progresso CassaIQ.
  await dcoExecScript(ref,dcoEmissionOverlayCode(message,type),5000).catch(()=>{});
}
async function dcoRemoveEmissionOverlay(ref){
  if(!ref)return;
  await dcoExecScript(ref,"(function(){var el=document.getElementById('cassaiq-emission-overlay');if(el)el.remove();return true})()",4000).catch(()=>{});
}
const DCO_RUNNER_PREP_MS=350;
const DCO_RUNNER_FINAL_MS=1100;
function dcoStopAutoTimer(){if(dcoAutoTimer){clearTimeout(dcoAutoTimer);clearInterval(dcoAutoTimer);dcoAutoTimer=null}}
function dcoRunnerDelay(state=dcoAutoSale){return state&&(state.finalArmed||state.proceedClicked)?DCO_RUNNER_FINAL_MS:DCO_RUNNER_PREP_MS}
function dcoScheduleAutoTick(ref,delayMs=null){
  if(!dcoAutoSale||!ref||dcoBrowserRef!==ref)return;
  if(dcoAutoTimer){clearTimeout(dcoAutoTimer);clearInterval(dcoAutoTimer)}
  const wait=Math.max(80,Number.isFinite(Number(delayMs))?Number(delayMs):dcoRunnerDelay(dcoAutoSale));
  dcoAutoTimer=setTimeout(async()=>{
    dcoAutoTimer=null;
    if(!dcoAutoSale||dcoBrowserRef!==ref)return;
    await dcoAutoTick(ref);
    if(dcoAutoSale&&dcoBrowserRef===ref)dcoScheduleAutoTick(ref);
  },wait)
}
function dcoDisposeBrowser(reason='Sessione DCO sostituita.'){
  const ref=dcoBrowserRef;
  if(dcoPdfRetryBusy){dcoLogPdfMeta('chiusura browser bloccata durante recupero PDF',{reason,hasBrowser:!!ref});return ref}
  dcoBrowserRef=null;dcoBrowserLoading=false;dcoVisualHealth='error';dcoVisualHealthCheckedAt=Date.now();renderDcoSettingsCardStatus();
  dcoClearBrowserLoadGuard();dcoClearAutomationWaiters(reason);dcoClearCaptureTimers();dcoStopLivePoll();dcoStopVoidLabTimer();if(dcoVoidLab)dcoVoidLab=null;
  if(ref){try{ref.close?.()}catch{}}
  return ref;
}
function dcoNavigate(ref,url){
  if(!ref||dcoBrowserRef!==ref)return false;
  const code=`(function(){setTimeout(function(){location.href=${JSON.stringify(String(url||''))}},80);return true})()`;
  try{ref.executeScript({code},()=>{});return true}catch{return false}
}
function dcoOfficialUrl(value){
  try{const u=new URL(value);return u.protocol==='https:'&&(u.hostname==='agenziaentrate.gov.it'||u.hostname.endsWith('.agenziaentrate.gov.it'))}catch{return false}
}
function dcoSafeUrl(value){try{const u=new URL(value);return `${u.origin}${u.pathname}${u.hash||''}`}catch{return String(value||'')}}
function dcoSetResult(type,message){const el=$('dcoResult');if(!el)return;el.hidden=false;el.className=`test-result ${type||''}`.trim();el.textContent=message}
function dcoPlugin(){return window.cordova?.InAppBrowser||null}
function setDcoRealTestEnabled(value){
  dcoRealTestEnabled=!!value;
  if(dcoRealTestEnabled)localStorage.setItem(K.dcoRealLock,'1');else localStorage.removeItem(K.dcoRealLock);
  renderDcoRealTestStatus();renderCart();
  if(dcoBrowserRef)dcoInjectLabBar(dcoBrowserRef);
}
function renderDcoRealTestStatus(){
  const status=$('dcoRealTestStatus'),enable=$('dcoEnableRealTest'),disable=$('dcoDisableRealTest');
  if(!status)return;
  const draft=dcoBuildDraftPayload();
  if(dcoRealTestEnabled){
    status.className='test-result warning';
    status.textContent=`PROVA REALE ABILITATA · Epson bloccata · ${draft.ok?euro(draft.total):'carrello da verificare'}. Disabilitala solo dopo aver controllato l'esito nel DCO.`;
  }else{
    status.className='test-result';
    status.textContent='Prova reale disabilitata. La schermata finale resta completamente bloccata.';
  }
  if(enable)enable.hidden=dcoRealTestEnabled;
  if(disable)disable.hidden=!dcoRealTestEnabled;
}
function dcoBuildDraftPayload(){
  const rows=expandedCartFiscalLines();
  if(!rows.length)return{ok:false,error:'Il carrello è vuoto. Aggiungi una vendita prima di aprire il laboratorio DCO.'};
  if(payment!=='Contanti'&&payment!=='Carta')return{ok:false,error:'Seleziona prima il pagamento Contanti oppure Carta nella schermata cassa.'};
  const supportedVat=[4,5,10,22],unsupported=[];
  const lines=rows.map(({product:p,quantity:q},index)=>{
    const department=departmentById(p.departmentId),vat=Number(department?.vat);
    const matched=supportedVat.find(value=>Math.abs(value-vat)<0.001);
    if(matched===undefined)unsupported.push(`${p.name}: IVA ${Number.isFinite(vat)?vat:'non impostata'}`);
    return{index,quantity:Number(q),description:String(p.name||'Prodotto').trim().slice(0,80),grossPrice:roundMoney(Number(p.price)),vat:matched===undefined?'':String(matched),discount:0,gift:false};
  });
  if(unsupported.length)return{ok:false,error:`Aliquota non gestita in questa prova: ${unsupported.join('; ')}. Sono ammesse 4%, 5%, 10% e 22%.`};
  if(lines.some(line=>!(line.quantity>0)||!(line.grossPrice>=0)))return{ok:false,error:'Nel carrello sono presenti quantità o prezzi non validi.'};
  const total=cartTotal();
  if(!(total>0))return{ok:false,error:'Il totale della vendita deve essere maggiore di zero.'};
  const normalizedLottery=payment==='Carta'&&total>=1?normalizeLotteryCode(lotteryCode):'';
  if(normalizedLottery&&!/^[A-Z0-9]{8}$/.test(normalizedLottery))return{ok:false,error:'Codice lotteria non valido: servono 8 caratteri alfanumerici.'};
  return{ok:true,operation:'V',lines,payment,subtotal:cartSubtotal(),discount:roundMoney(discountAmount),total,cash:payment==='Contanti'?total:0,electronic:payment==='Carta'?total:0,lotteryCode:normalizedLottery,createdAt:new Date().toISOString()};
}
function renderDcoDraftSummary(){
  const el=$('dcoDraftSummary');if(!el)return;
  const draft=dcoBuildDraftPayload();
  el.hidden=false;
  if(!draft.ok){el.className='test-result error';el.textContent=draft.error;return}
  const vats=[...new Set(draft.lines.map(line=>line.vat))].join('%, ');
  el.className='test-result ok';
  el.textContent=`Bozza pronta: ${draft.lines.length} ${draft.lines.length===1?'riga':'righe'} · ${euro(draft.total)} · ${draft.payment} · IVA ${vats}%.`;
}
function dcoCreateSaleSnapshot(){
  const rows=cartLines();
  if(!rows.length)return null;
  const subtotal=cartSubtotal(),discount=discountAmount,total=cartTotal(),fullProfile=dcoBusinessProfile(),businessProfile={...fullProfile,receiptLogoData:''};
  /* Non duplichiamo l'immagine del logo dentro ogni vendita: il flag resta
     nello snapshot, mentre i byte grafici vivono una sola volta nel profilo attività. */
  const fiscalRows=expandedCartFiscalLines();
  return{id:uid(),userId:getSession()?.user?.id||null,date:new Date().toISOString(),subtotal,discount,total,payment,lotteryCode:payment==='Carta'&&total>=1?normalizeLotteryCode(lotteryCode):'',businessProfile,items:fiscalRows.reduce((n,x)=>n+Number(x.quantity||0),0),lines:fiscalRows.map(({product:p,quantity:q,isSupplement})=>{const c=categoryById(p.categoryId),d=departmentById(p.departmentId);return{id:uid(),productId:p.manual?null:p.id,name:isSupplement?`SUPPL. ${p.name}`:p.name,quantity:q,unitPrice:Number(p.price),lineTotal:Number(p.price)*q,categoryName:c?.name||'',departmentName:d?.name||'',vatRate:Number(d?.vat||0)}}),cashReceived:payment==='Contanti'?cashReceived||total:0,changeDue:payment==='Contanti'?changeDue:0,fiscalSource:'DCO'};
}
function dcoStorePendingSale(){const snapshot=dcoCreateSaleSnapshot();if(snapshot)localStorage.setItem(K.dcoPendingSale,JSON.stringify(snapshot));return snapshot}
function dcoLoadPendingSale(){return loadObjectSafe(K.dcoPendingSale,null)}
function dcoLoadLastDocument(){return loadObjectSafe(K.dcoLastDocument,null)}
function dcoPrinterOptions(){
  const host=($('dcoPrinterIp')?.value||localStorage.getItem(K.printerTestIp)||'192.168.1.201').trim();
  const port=Number($('dcoPrinterPort')?.value||localStorage.getItem(K.printerTestPort)||9100);
  return{mode:'network',host,port:Number.isInteger(port)&&port>0&&port<65536?port:9100,width:576,threshold:185};
}

function kitchenPrinterOptions(){
  const fieldHost=String($('kitchenPrinterIp')?.value||'').trim(),storedHost=String(localStorage.getItem(K.kitchenPrinterIp)||'').trim();
  const fieldPort=String($('kitchenPrinterPort')?.value||'').trim(),storedPort=String(localStorage.getItem(K.kitchenPrinterPort)||'9100').trim();
  const host=fieldHost||storedHost,rawPort=Number(fieldPort||storedPort||9100),enabled=localStorage.getItem(K.kitchenPrinterEnabled)==='1';
  return{enabled,host,port:Number.isInteger(rawPort)&&rawPort>0&&rawPort<65536?rawPort:9100};
}
function kitchenSecondCategoryIds(){try{const v=JSON.parse(localStorage.getItem(K.kitchenPrinter2CategoryIds)||'[]');return Array.isArray(v)?v.map(String):[]}catch{return[]}}
function kitchenSecondPrinterOptions(){
  const fieldHost=String($('kitchenPrinter2Ip')?.value||'').trim(),storedHost=String(localStorage.getItem(K.kitchenPrinter2Ip)||'').trim();
  const fieldPort=String($('kitchenPrinter2Port')?.value||'').trim(),storedPort=String(localStorage.getItem(K.kitchenPrinter2Port)||'9100').trim();
  const host=fieldHost||storedHost,rawPort=Number(fieldPort||storedPort||9100),enabled=localStorage.getItem(K.kitchenPrinter2Enabled)==='1';
  const scope=['all','categories'].includes(localStorage.getItem(K.kitchenPrinter2Scope))?localStorage.getItem(K.kitchenPrinter2Scope):'categories';
  const routing=['duplicate','split'].includes(localStorage.getItem(K.kitchenPrinter2Routing))?localStorage.getItem(K.kitchenPrinter2Routing):'split';
  return{enabled,host,port:Number.isInteger(rawPort)&&rawPort>0&&rawPort<65536?rawPort:9100,scope,routing,categoryIds:kitchenSecondCategoryIds()};
}
function kitchenPrinterValidHost(host){return /^(?:\d{1,3}\.){3}\d{1,3}$/.test(String(host||'').trim())}
function kitchenLineCategoryId(line){
  const explicit=line?.categoryId??line?.category_id;if(explicit!=null&&String(explicit))return String(explicit);
  const productId=line?.productId??line?.product_id;if(productId==null)return'';
  const p=products.find(x=>String(x.id)===String(productId));return String(p?.categoryId??p?.category_id??'');
}
function kitchenRouteJob(job={}){
  const second=kitchenSecondPrinterOptions(),lines=Array.isArray(job.lines)?job.lines:[];
  if(!second.enabled)return{primary:{...job,lines},secondary:{...job,lines:[]},second};
  const selectedIds=new Set(second.categoryIds.map(String));
  const isSelected=line=>second.scope==='all'||selectedIds.has(kitchenLineCategoryId(line));
  const secondaryLines=lines.filter(isSelected);
  const primaryLines=second.routing==='split'?lines.filter(line=>!isSelected(line)):lines;
  return{primary:{...job,lines:primaryLines},secondary:{...job,lines:secondaryLines},second};
}
function kitchenOrderPayload({tableName='Tavolo',lines=[],notes='',source='CassaIQ',orderId='',isUpdate=false,replacesOrderId=''}={}){
  const width=42,divider='-'.repeat(width)+'\n',parts=[printerInit()],add=t=>parts.push(printerAscii(printerPlainText(t)));
  parts.push([0x1b,0x61,0x01,0x1b,0x45,0x01,0x1d,0x21,0x11]);add(isUpdate?'AGGIORNAMENTO\n':'COMANDA CUCINA\n');
  // v1.15.5: tavolo grande e in grassetto per riconoscerlo subito in cucina.
  parts.push([0x1d,0x21,0x11,0x1b,0x45,0x01]);add(`${String(tableName||'Tavolo').toUpperCase()}\n`);parts.push([0x1d,0x21,0x00,0x1b,0x45,0x00]);
  if(isUpdate){parts.push([0x1b,0x45,0x01]);add('SOSTITUISCE TUTTE LE COMANDE PRECEDENTI\n');add('QUESTO E L ORDINE COMPLETO DEL TAVOLO\n');parts.push([0x1b,0x45,0x00])}
  parts.push([0x1b,0x45,0x00]);add(`${new Date().toLocaleString('it-IT',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}\n`);parts.push([0x1b,0x61,0x00]);add('\n'+divider);
  for(const line of lines||[]){const qty=Number(line.quantity||0),name=String(line.name||line.product_name||'Prodotto'),itemNote=String(line.note||line.notes||'').trim();parts.push([0x1b,0x45,0x01,0x1d,0x21,0x01]);for(const row of printerWrapText(`${qty} x ${name}`,Math.max(10,width-2)))add(`${row}\n`);parts.push([0x1d,0x21,0x00,0x1b,0x45,0x00]);if(itemNote){parts.push([0x1b,0x45,0x01]);for(const row of printerWrapText(`> ${itemNote}`,Math.max(10,width-2)))add(`${row}\n`);parts.push([0x1b,0x45,0x00])}}
  if(notes){add(divider);parts.push([0x1b,0x45,0x01]);add('NOTE\n');parts.push([0x1b,0x45,0x00]);for(const row of printerWrapText(notes,width))add(`${row}\n`)}
  add(divider);parts.push([0x1b,0x61,0x01]);add(`${source||'CassaIQ'}${orderId?` · ${String(orderId).slice(0,8)}`:''}\n`);parts.push([0x1b,0x64,0x05,0x1d,0x56,0x00]);return printerConcat(...parts)
}
async function kitchenPrintOne(opt,payload,label,force=false){
  if(!force&&!opt.enabled)return{skipped:true,reason:'disabled'};
  if(!kitchenPrinterValidHost(opt.host))throw new Error(`${label}: indirizzo IP non valido.`);
  const plugin=printerNativePlugin();if(!plugin)throw new Error(`${label}: modulo nativo stampante non disponibile.`);
  return plugin.printNetwork({host:opt.host,port:opt.port,data:printerBytesToBase64(payload),timeoutMs:8000})
}
async function kitchenPrintOrder(job,{force=false,target='routed'}={}){
  const primary=kitchenPrinterOptions(),second=kitchenSecondPrinterOptions();
  if(target==='primary')return kitchenPrintOne(primary,kitchenOrderPayload(job),'Stampante cucina 1',force);
  if(target==='secondary')return kitchenPrintOne(second,kitchenOrderPayload(job),'Stampante cucina 2',force);
  const routed=kitchenRouteJob(job),errors=[];let primaryPrinted=false,secondaryPrinted=false,bytes=0,attempted=0;
  if(routed.primary.lines.length&&(primary.enabled||(force&&!second.enabled))){attempted++;try{const r=await kitchenPrintOne(primary,kitchenOrderPayload(routed.primary),'Stampante cucina 1',force&&!second.enabled);primaryPrinted=!r?.skipped;bytes+=Number(r?.bytes||0)}catch(e){errors.push(String(e?.message||e))}}
  if(routed.secondary.lines.length&&second.enabled){attempted++;try{const r=await kitchenPrintOne(second,kitchenOrderPayload(routed.secondary),'Stampante cucina 2',false);secondaryPrinted=!r?.skipped;bytes+=Number(r?.bytes||0)}catch(e){errors.push(String(e?.message||e))}}
  if(errors.length)throw new Error(errors.join(' · '));
  if(!attempted)return{skipped:true,reason:'disabled-or-no-lines'};
  return{skipped:false,primaryPrinted,secondaryPrinted,bytes};
}
function kitchenCancellationPayload({tableName='Tavolo',lines=[],reason='',source='CassaIQ',orderId=''}={}){
  const width=42,divider='='.repeat(width)+'\n',parts=[printerInit()],add=t=>parts.push(printerAscii(printerPlainText(t)));
  parts.push([0x1b,0x61,0x01,0x1b,0x45,0x01,0x1d,0x21,0x11]);add('*** ANNULLAMENTO ***\n');parts.push([0x1d,0x21,0x00]);
  add(`${String(tableName||'Tavolo').toUpperCase()}\n`);add(`${new Date().toLocaleString('it-IT',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}\n`);
  parts.push([0x1b,0x61,0x00]);add('\n'+divider);parts.push([0x1b,0x45,0x01]);add('ANNULLA:\n');parts.push([0x1b,0x45,0x00]);
  for(const line of lines||[]){const qty=Number(line.quantity||0),name=String(line.name||line.product_name||'Prodotto'),itemNote=String(line.note||line.notes||'').trim();for(const row of printerWrapText(`${qty} x ${name}`,Math.max(10,width-2)))add(`${row}\n`);if(itemNote)for(const row of printerWrapText(`> ${itemNote}`,Math.max(10,width-2)))add(`${row}\n`)}
  if(reason){add(divider);parts.push([0x1b,0x45,0x01]);add('MOTIVO\n');parts.push([0x1b,0x45,0x00]);for(const row of printerWrapText(reason,width))add(`${row}\n`)}
  add(divider);parts.push([0x1b,0x61,0x01,0x1b,0x45,0x01]);add('NON PREPARARE\n');parts.push([0x1b,0x45,0x00]);add(`${source||'CassaIQ'}${orderId?` · ${String(orderId).slice(0,8)}`:''}\n`);parts.push([0x1b,0x64,0x05,0x1d,0x56,0x00]);return printerConcat(...parts)
}
async function kitchenPrintCancellation(job,{force=false,target='routed'}={}){
  const primary=kitchenPrinterOptions(),second=kitchenSecondPrinterOptions();
  if(target==='primary')return kitchenPrintOne(primary,kitchenCancellationPayload(job),'Stampante cucina 1',force);
  if(target==='secondary')return kitchenPrintOne(second,kitchenCancellationPayload(job),'Stampante cucina 2',force);
  const routed=kitchenRouteJob(job),errors=[];let primaryPrinted=false,secondaryPrinted=false,bytes=0,attempted=0;
  if(routed.primary.lines.length&&(primary.enabled||(force&&!second.enabled))){attempted++;try{const r=await kitchenPrintOne(primary,kitchenCancellationPayload(routed.primary),'Stampante cucina 1',force&&!second.enabled);primaryPrinted=!r?.skipped;bytes+=Number(r?.bytes||0)}catch(e){errors.push(String(e?.message||e))}}
  if(routed.secondary.lines.length&&second.enabled){attempted++;try{const r=await kitchenPrintOne(second,kitchenCancellationPayload(routed.secondary),'Stampante cucina 2',false);secondaryPrinted=!r?.skipped;bytes+=Number(r?.bytes||0)}catch(e){errors.push(String(e?.message||e))}}
  if(errors.length)throw new Error(errors.join(' · '));if(!attempted)return{skipped:true,reason:'disabled-or-no-lines'};return{skipped:false,primaryPrinted,secondaryPrinted,bytes};
}
function kitchenPrinterStatus(type,message){const el=$('configKitchenPrinterStatus');if(!el)return;el.className=`config-status-line ${type||''}`.trim();el.textContent=message||''}
function kitchenRenderSecondCategories(){
  const root=$('kitchenPrinter2Categories'),wrap=$('kitchenPrinter2CategoryWrap'),scope=$('kitchenPrinter2Scope');if(!root)return;
  const selected=new Set(kitchenSecondCategoryIds()),show=(scope?.value||localStorage.getItem(K.kitchenPrinter2Scope)||'categories')==='categories';if(wrap)wrap.hidden=!show;
  root.innerHTML=categories.length?categories.map(c=>`<label class="kitchen-category-option"><input type="checkbox" value="${escapeHtml(String(c.id))}" ${selected.has(String(c.id))?'checked':''}><span>${escapeHtml(c.name||'Categoria')}</span></label>`).join(''):'<span class="config-help">Crea prima almeno una categoria prodotti.</span>';
  root.querySelectorAll('input[type="checkbox"]').forEach(input=>input.onchange=()=>{const ids=[...root.querySelectorAll('input[type="checkbox"]:checked')].map(x=>String(x.value));localStorage.setItem(K.kitchenPrinter2CategoryIds,JSON.stringify(ids))})
}
function kitchenApplyConfig(config={}){
  if(config.host!=null)localStorage.setItem(K.kitchenPrinterIp,String(config.host||''));if(config.port!=null)localStorage.setItem(K.kitchenPrinterPort,String(config.port||9100));if(config.enabled!=null)localStorage.setItem(K.kitchenPrinterEnabled,config.enabled?'1':'0');
  if(config.second){const s=config.second;if(s.host!=null)localStorage.setItem(K.kitchenPrinter2Ip,String(s.host||''));if(s.port!=null)localStorage.setItem(K.kitchenPrinter2Port,String(s.port||9100));if(s.enabled!=null)localStorage.setItem(K.kitchenPrinter2Enabled,s.enabled?'1':'0');if(s.scope)localStorage.setItem(K.kitchenPrinter2Scope,String(s.scope));if(s.routing)localStorage.setItem(K.kitchenPrinter2Routing,String(s.routing));if(Array.isArray(s.categoryIds))localStorage.setItem(K.kitchenPrinter2CategoryIds,JSON.stringify(s.categoryIds.map(String)))}
  const enabled=$('kitchenPrinterEnabled'),ip=$('kitchenPrinterIp'),port=$('kitchenPrinterPort'),enabled2=$('kitchenPrinter2Enabled'),ip2=$('kitchenPrinter2Ip'),port2=$('kitchenPrinter2Port'),scope2=$('kitchenPrinter2Scope'),routing2=$('kitchenPrinter2Routing');
  if(enabled)enabled.checked=localStorage.getItem(K.kitchenPrinterEnabled)==='1';if(ip&&document.activeElement!==ip)ip.value=localStorage.getItem(K.kitchenPrinterIp)||'';if(port&&document.activeElement!==port)port.value=localStorage.getItem(K.kitchenPrinterPort)||'9100';
  if(enabled2)enabled2.checked=localStorage.getItem(K.kitchenPrinter2Enabled)==='1';if(ip2&&document.activeElement!==ip2)ip2.value=localStorage.getItem(K.kitchenPrinter2Ip)||'';if(port2&&document.activeElement!==port2)port2.value=localStorage.getItem(K.kitchenPrinter2Port)||'9100';if(scope2)scope2.value=localStorage.getItem(K.kitchenPrinter2Scope)||'categories';if(routing2)routing2.value=localStorage.getItem(K.kitchenPrinter2Routing)||'split';kitchenRenderSecondCategories();
}
async function kitchenLoadConfigFromCloud(showStatus=false){
  const ownerId=getSession()?.user?.id||'';kitchenApplyConfig({});if(!ownerId){if(showStatus)kitchenPrinterStatus('warning','Configurazione locale. Accedi/attiva la cassa per sincronizzarla con CassaIQ Client.');return false}
  let primaryLoaded=false;
  try{const rows=await cloudRequest('business_profiles',{query:`?user_id=eq.${encodeURIComponent(ownerId)}&select=kitchen_printer_enabled,kitchen_printer_ip,kitchen_printer_port&limit=1`});const row=rows?.[0];if(row){primaryLoaded=true;kitchenApplyConfig({enabled:!!row.kitchen_printer_enabled,host:row.kitchen_printer_ip||'',port:Number(row.kitchen_printer_port)||9100})}}catch(e){if(showStatus)kitchenPrinterStatus('warning',`Cloud stampante 1 non disponibile: ${e.message||e}`);return false}
  let secondReady=true;
  try{const rows2=await cloudRequest('business_profiles',{query:`?user_id=eq.${encodeURIComponent(ownerId)}&select=kitchen_printer2_enabled,kitchen_printer2_ip,kitchen_printer2_port,kitchen_printer2_scope,kitchen_printer2_routing,kitchen_printer2_category_ids&limit=1`});const r=rows2?.[0];if(r)kitchenApplyConfig({second:{enabled:!!r.kitchen_printer2_enabled,host:r.kitchen_printer2_ip||'',port:Number(r.kitchen_printer2_port)||9100,scope:r.kitchen_printer2_scope||'categories',routing:r.kitchen_printer2_routing||'split',categoryIds:Array.isArray(r.kitchen_printer2_category_ids)?r.kitchen_printer2_category_ids:[]}})}catch(e){secondReady=false}
  if(showStatus){const p=kitchenPrinterOptions(),s=kitchenSecondPrinterOptions();kitchenPrinterStatus(secondReady?(p.enabled||s.enabled?'ok':''):'warning',secondReady?(s.enabled?`Cucina 1 ${p.enabled?'attiva':'spenta'} · Cucina 2 attiva · ${s.routing==='split'?'ordine splittato':'copia su principale'}`:(p.enabled?`Stampante cucina 1 sincronizzata · ${p.host||'IP da impostare'}:${p.port}`:'Stampanti cucina disattivate.')):`Stampante 1 caricata. Per la stampante 2 esegui la migrazione Supabase dedicata.`)}
  return primaryLoaded;
}
function kitchenReadFormToLocal(){
  const pairs=[[K.kitchenPrinterEnabled,$('kitchenPrinterEnabled')?.checked?'1':'0'],[K.kitchenPrinterIp,$('kitchenPrinterIp')?.value.trim()||''],[K.kitchenPrinterPort,$('kitchenPrinterPort')?.value||'9100'],[K.kitchenPrinter2Enabled,$('kitchenPrinter2Enabled')?.checked?'1':'0'],[K.kitchenPrinter2Ip,$('kitchenPrinter2Ip')?.value.trim()||''],[K.kitchenPrinter2Port,$('kitchenPrinter2Port')?.value||'9100'],[K.kitchenPrinter2Scope,$('kitchenPrinter2Scope')?.value||'categories'],[K.kitchenPrinter2Routing,$('kitchenPrinter2Routing')?.value||'split']];pairs.forEach(([k,v])=>localStorage.setItem(k,v));
}
async function kitchenSaveConfig(){
  kitchenReadFormToLocal();const opt=kitchenPrinterOptions(),second=kitchenSecondPrinterOptions();
  if(opt.enabled&&!kitchenPrinterValidHost(opt.host)){kitchenPrinterStatus('error','Inserisci un IP valido per la stampante cucina 1.');return}if(second.enabled&&!kitchenPrinterValidHost(second.host)){kitchenPrinterStatus('error','Inserisci un IP valido per la stampante cucina 2.');return}if(second.enabled&&second.scope==='categories'&&!second.categoryIds.length){kitchenPrinterStatus('error','Seleziona almeno una categoria per la stampante 2 oppure scegli “Tutta la comanda”.');return}
  const ownerId=getSession()?.user?.id||'';if(!ownerId){kitchenPrinterStatus('warning','Configurazione salvata solo su questo dispositivo.');return}
  const button=$('configKitchenPrinterSave');printerSetBusy(button,true,'Salvataggio…');kitchenPrinterStatus('loading','Sincronizzazione configurazione stampanti…');
  try{
    await cloudRequest('business_profiles',{method:'POST',body:{user_id:ownerId,kitchen_printer_enabled:opt.enabled,kitchen_printer_ip:opt.host,kitchen_printer_port:opt.port},prefer:'resolution=merge-duplicates,return=minimal'});
    try{await cloudRequest('business_profiles',{method:'POST',body:{user_id:ownerId,kitchen_printer2_enabled:second.enabled,kitchen_printer2_ip:second.host,kitchen_printer2_port:second.port,kitchen_printer2_scope:second.scope,kitchen_printer2_routing:second.routing,kitchen_printer2_category_ids:second.categoryIds},prefer:'resolution=merge-duplicates,return=minimal'})}catch(secondErr){kitchenPrinterStatus('warning','Stampante 1 salvata. La stampante 2 richiede la nuova migrazione Supabase.');return}
    kitchenPrinterStatus(opt.enabled||second.enabled?'ok':'',second.enabled?`Configurazione salvata · stampante 2 ${second.scope==='all'?'tutta la comanda':`${second.categoryIds.length} categorie`} · ${second.routing==='split'?'ordine splittato':'anche sulla principale'}`:'Configurazione stampante cucina salvata.');toast('Stampanti cucina salvate',3000)
  }catch(e){kitchenPrinterStatus('error',`Configurazione non sincronizzata: ${e.message||e}`)}finally{printerSetBusy(button,false)}
}
async function kitchenTestPrinter(){
  kitchenReadFormToLocal();const button=$('configKitchenPrinterTest'),opt=kitchenPrinterOptions();printerSetBusy(button,true,'Invio test…');kitchenPrinterStatus('loading','Invio prova alla stampante cucina 1…');
  try{const result=await kitchenPrintOrder({tableName:'TAVOLO TEST',lines:[{name:'Spaghetti alle vongole',quantity:2},{name:'Insalata mista',quantity:1}],notes:'Senza cipolla',source:'TEST CassaIQ'},{force:true,target:'primary'});kitchenPrinterStatus('ok',`Test cucina 1 inviato${result?.bytes?` · ${result.bytes} byte`:''}. Controlla stampa e taglio.`)}catch(e){kitchenPrinterStatus('error',e.message||String(e))}finally{printerSetBusy(button,false)}
}
async function kitchenTestSecondPrinter(){
  kitchenReadFormToLocal();const button=$('configKitchenPrinter2Test'),opt=kitchenSecondPrinterOptions();printerSetBusy(button,true,'Invio test…');kitchenPrinterStatus('loading','Invio prova alla stampante cucina 2…');
  try{const result=await kitchenPrintOrder({tableName:'TAVOLO TEST',lines:[{name:'Bibita test',quantity:1}],notes:'Seconda stampante',source:'TEST CassaIQ'},{force:true,target:'secondary'});kitchenPrinterStatus('ok',`Test cucina 2 inviato${result?.bytes?` · ${result.bytes} byte`:''}. Controlla stampa e taglio.`)}catch(e){kitchenPrinterStatus('error',e.message||String(e))}finally{printerSetBusy(button,false)}
}
function renderDcoDocumentStatus(message,type){
  const el=$('dcoDocumentStatus');if(!el)return;
  const last=dcoLoadLastDocument();el.hidden=false;
  if(message){el.className=`test-result ${type||''}`.trim();el.textContent=message}
  else if(last?.documentId){el.className=`test-result ${last.printed?'ok':'warning'}`;el.textContent=`Ultimo DCO: ${last.receiptNumber||last.documentId} · ${euro(last.total)} · ${last.printed?'documento commerciale stampato':'stampa da verificare'} · PDF ${last.path?'salvato':'opzionale non archiviato'}.`}
  else{el.className='test-result';el.textContent='Nessun documento DCO acquisito da questa versione.'}
  const reprint=$('dcoPrintLast');if(reprint)reprint.disabled=!(last?.courtesySnapshot||last?.path||dcoLastPdfBase64);
}
function dcoExecScript(ref,code,timeoutMs=12000){return new Promise((resolve,reject)=>{if(!ref)return reject(new Error('Browser DCO non aperto.'));let done=false;const timer=setTimeout(()=>{if(done)return;done=true;reject(new Error('Risposta del browser DCO scaduta.'))},timeoutMs);try{ref.executeScript({code},results=>{if(done)return;done=true;clearTimeout(timer);resolve(Array.isArray(results)?results[0]:results)})}catch(e){clearTimeout(timer);reject(e)}})}
function dcoClearBrowserLoadGuard(){if(dcoBrowserLoadGuardTimer){clearTimeout(dcoBrowserLoadGuardTimer);dcoBrowserLoadGuardTimer=null}}
function dcoClearAutomationWaiters(message='Operazione DCO interrotta.'){
  for(const waiter of dcoAutomationWaiters.values()){try{waiter.finish(new Error(message))}catch{}}
  dcoAutomationWaiters.clear();
  if(dcoDocumentMetaWaiter){try{dcoDocumentMetaWaiter.finish(new Error(message))}catch{}dcoDocumentMetaWaiter=null}
}
function dcoParseBrowserMessage(event){
  let data=event?.data;
  if(typeof data==='string'){try{data=JSON.parse(data)}catch{return null}}
  if(data&&typeof data==='object'&&data.message==='cassaiq-dco'&&data.content!==undefined)data=data.content;
  if(typeof data==='string'){try{data=JSON.parse(data)}catch{return null}}
  return data&&typeof data==='object'?data:null;
}
function dcoHandleBrowserMessage(event){
  const data=dcoParseBrowserMessage(event);if(!data||data.source!=='cassaiq-dco')return;
  if(data.type==='route'){
    if(dcoAutoSale&&data.token&&String(data.token)!==String(dcoAutoSale.token))return;
    dcoClearBrowserLoadGuard();dcoBrowserLoading=false;
    if(dcoAutoSale){dcoAutoSale.lastNavigationAt=Date.now();dcoAutoSale.lastProgress=Date.now()}
    dcoHandlePage(data.url||'', 'message-route');
    return;
  }
  if(data.type==='document-meta'){
    const waiter=dcoDocumentMetaWaiter;
    if(waiter){
      const incoming=dcoNormalizeDocumentMeta(data.meta||{}),expected=String(waiter.documentId||'').replace(/[^0-9]/g,'');
      // Un watcher avviato per una vendita precedente puo' consegnare il suo
      // messaggio in ritardo. Accettiamo i metadati solo se portano lo stesso
      // ID documento atteso dalla finalizzazione corrente.
      if(expected&&(!incoming.documentId||incoming.documentId!==expected))return;
      const meta=dcoNormalizeDocumentMeta(incoming,expected);if(meta.documentNumber)waiter.finish(null,meta)
    }
    return;
  }
  const callId=String(data.callId||data.result?.callId||'');
  if(!callId)return;
  const waiter=dcoAutomationWaiters.get(callId);
  if(waiter)waiter.finish(null,data.result!==undefined?data.result:data);
}
function dcoRunAutomation(ref,code,callId,timeoutMs=14000){
  return new Promise((resolve,reject)=>{
    if(!ref)return reject(new Error('Browser DCO non aperto.'));
    let settled=false;
    const finish=(error,value)=>{
      if(settled)return;settled=true;
      clearTimeout(timer);dcoAutomationWaiters.delete(callId);
      if(error)reject(error);else resolve(value);
    };
    const timer=setTimeout(()=>finish(new Error('Risposta del browser DCO scaduta.')),timeoutMs);
    dcoAutomationWaiters.set(callId,{finish});
    try{
      ref.executeScript({code},results=>{
        const value=Array.isArray(results)?results[0]:results;
        if(value!==undefined&&value!==null)finish(null,value);
      });
    }catch(e){finish(e)}
  });
}
function dcoExtractDocumentId(value){const m=String(value||'').match(/\/documenti\/(\d+)\/stampa\/?/i);return m?m[1]:''}
function dcoEmissionEvidenceScript(){
  return `(function(){
    function clean(v){return String(v==null?'':v).replace(/\\s+/g,' ').trim()}
    function text(el){return clean(el&&((el.textContent||el.value)||'')).toLowerCase()}
    function visible(el){if(!el||el.disabled)return false;try{var st=getComputedStyle(el),r=el.getBoundingClientRect();return st.display!=='none'&&st.visibility!=='hidden'&&r.width>0&&r.height>0}catch(e){return false}}
    function actions(){return Array.prototype.slice.call(document.querySelectorAll('button,a,input[type=button],input[type=submit],[role=button]'))}
    var out={emitted:false,documentId:'',source:''};
    try{
      var current=String(location.href||''),urlMatch=current.match(/documenti\\/(\\d+)\\/stampa\\/?/i);
      if(urlMatch){out.emitted=true;out.documentId=String(urlMatch[1]);out.source='current-url';return out}
    }catch(e){}
    try{
      var target=actions().find(function(el){return visible(el)&&text(el).indexOf('scarica e stampa file')===0});
      if(!target)return out;
      out.emitted=true;out.source='visible-download-control';
      try{var href=String(target.href||target.getAttribute&&target.getAttribute('href')||''),hm=href.match(/documenti\\/(\\d+)\\/stampa\\/?/i);if(hm)out.documentId=String(hm[1])}catch(e){}
      if(!out.documentId&&window.angular){
        try{var sc=angular.element(target).scope()||angular.element(target).isolateScope();while(sc){if(sc.vm&&sc.vm.invio&&sc.vm.invio.idtrx!=null){out.documentId=String(sc.vm.invio.idtrx).replace(/[^0-9]/g,'');if(out.documentId)break}sc=sc.$parent}}catch(e){}
      }
      return out
    }catch(e){return out}
  })()`
}
function dcoOperationContextResetScript(token='',active=false){
  const tok=JSON.stringify(String(token||'')),isActive=JSON.stringify(!!active);
  return `(function(){
    try{if(window.__cassaiqMetaWatchTimer){clearInterval(window.__cassaiqMetaWatchTimer);window.__cassaiqMetaWatchTimer=null}}catch(e){}
    try{window.__cassaiqCancelDeferredClicks=!${isActive}}catch(e){}
    try{if(window.__cassaiqQuick)window.__cassaiqQuick.cancelled=true}catch(e){}
    try{window.__cassaiqQuick=null}catch(e){}
    try{window.__cassaiqDcoPdf=null}catch(e){}
    try{window.__cassaiqOfficialDownload=null}catch(e){}
    try{var voidBanner=document.getElementById('cassaiq-void-progress-banner');if(voidBanner)voidBanner.remove()}catch(e){}
    try{window.__cassaiqActiveQuickToken=${tok}}catch(e){}
    try{window.__cassaiqAutoSaleActive=${isActive};if(${isActive})['cassaiq-dco-labbar','cassaiq-dco-arm-overlay','cassaiq-dco-safety'].forEach(function(id){var el=document.getElementById(id);if(el)el.remove()})}catch(e){}
    var href=String(location.href||''),ready=String(document.readyState||''),logged=!!document.querySelector('#user-info'),home=location.pathname.indexOf('/ser/documenticommercialionline/')>=0&&String(location.hash||'').indexOf('/home')>=0;
    return{url:href,readyState:ready,logged:logged,home:home}
  })()`
}
async function dcoResetOperationContext(ref,token='',active=false){
  if(!ref)return null;
  if(active)dcoClearAutomationWaiters('Nuova operazione DCO: contesto precedente chiuso.');
  try{return await dcoExecScript(ref,dcoOperationContextResetScript(token,active),4500)}catch{return null}
}
function dcoLogIgnoredDocumentEvidence(state,id,source,reason){
  if(!state)return;
  const cleanId=String(id||'').replace(/[^0-9]/g,''),key=`${reason}:${source}:${cleanId||'-'}`;
  state.ignoredEvidence=state.ignoredEvidence||{};if(state.ignoredEvidence[key])return;state.ignoredEvidence[key]=true;
  dcoRememberRoute(DCO_URLS.service,`diagnostic:${reason}:${source}${cleanId?`:${cleanId}`:''}`)
}
function dcoAcceptAutoDocumentId(state,value,source='unknown'){
  const id=String(value||'').replace(/[^0-9]/g,'');if(!state||!id)return'';
  if(!state.proceedClicked){dcoLogIgnoredDocumentEvidence(state,id,source,'pre-proceed-document-ignored');return''}
  const previous=String(state.previousDocumentId||'').replace(/[^0-9]/g,'');
  if(previous&&id===previous){dcoLogIgnoredDocumentEvidence(state,id,source,'previous-document-ignored');return''}
  if(dcoCourtesyFinalizedIds.has(id)&&String(state.documentId||'')!==id){dcoLogIgnoredDocumentEvidence(state,id,source,'already-finalized-document-ignored');return''}
  if(state.acceptedEvidenceId!==id){state.acceptedEvidenceId=id;dcoRememberRoute(DCO_URLS.service,`diagnostic:new-document-accepted:${source}:${id}`)}
  return id
}
function dcoLogPdfMeta(label,meta){
  const payload={at:new Date().toISOString(),label:String(label||''),meta:meta??null};
  try{console.log(`[CassaIQ DCO PDF] ${payload.label}`,meta);console.log(`[CassaIQ DCO PDF JSON] ${JSON.stringify(payload)}`)}catch(e){try{console.log('[CassaIQ DCO PDF]',String(label||''),String(e?.message||e))}catch{}}
  return meta;
}
function dcoDocumentDetailUrl(documentId){
  const id=String(documentId||'').replace(/[^0-9]/g,'');
  return id?`https://ivaservizi.agenziaentrate.gov.it/ser/documenticommercialionline/?v=1729523483132#/visualizzazione/dettaglio/${id}`:'';
}
async function dcoOpenDocumentDetail(ref,documentId,timeoutMs=35000){
  if(!ref)throw new Error('Browser DCO non aperto.');
  const id=String(documentId||'').replace(/[^0-9]/g,'');if(!id)throw new Error('Identificativo documento DCO non disponibile.');
  const target=dcoDocumentDetailUrl(id),deadline=Date.now()+Math.max(8000,Number(timeoutMs||35000));
  const inspectCode=`(function(){
    function clean(v){return String(v||'').replace(/\\s+/g,' ').trim().toLowerCase()}
    var actions=Array.prototype.slice.call(document.querySelectorAll('button,a,input[type=button],input[type=submit],[role=button]'));
    function isNormalDownload(el){
      var t=clean(el.textContent||el.value),ng=clean(el.getAttribute('ng-click')||el.getAttribute('data-ng-click'));
      if(t.indexOf('regalo')>=0||ng.indexOf('regalo')>=0||ng.indexOf(',true')>=0||ng.indexOf(', true')>=0)return false;
      return t==='scarica e stampa file'||(t.indexOf('scarica e stampa file')===0&&t.indexOf('per regalo')<0)||(ng.indexOf('stampa(')>=0&&ng.indexOf('true')<0);
    }
    var button=actions.find(isNormalDownload);
    return{href:String(location.href||''),hash:String(location.hash||''),readyState:String(document.readyState||''),title:String(document.title||''),hasButton:!!button,buttonText:button?String(button.textContent||button.value||'').replace(/\\s+/g,' ').trim():'',buttonNgClick:button?String(button.getAttribute('ng-click')||button.getAttribute('data-ng-click')||''):''}
  })()`;
  let current=await dcoExecScript(ref,inspectCode,8000).catch(()=>null);
  const onCorrectDetail=meta=>String(meta?.href||'').includes(`#/visualizzazione/dettaglio/${id}`);
  if(!onCorrectDetail(current)){
    dcoSetResult('loading',`Apertura del dettaglio ufficiale DCO-${id}…`);
    await dcoExecScript(ref,`(function(){location.href=${JSON.stringify(target)};return true})()`,6000).catch(()=>{});
  }
  let last=current;
  while(Date.now()<deadline){
    await new Promise(resolve=>setTimeout(resolve,700));
    last=await dcoExecScript(ref,inspectCode,9000).catch(()=>last);
    dcoLogPdfMeta(`attesa dettaglio DCO-${id}`,last);
    const href=String(last?.href||'').toLowerCase();
    if(href.includes('iampe.agenziaentrate.gov.it')||href.includes('/sam/ui/login'))throw new Error('Sessione DCO scaduta. Ricollega con SPID e riprova il solo recupero PDF.');
    if(onCorrectDetail(last)&&last?.readyState==='complete'&&last?.hasButton)return last;
  }
  const where=String(last?.href||target);
  throw new Error(`Pagina di dettaglio DCO-${id} aperta, ma il comando di download non è comparso entro il tempo previsto · ${where}`);
}
async function dcoRequestOfficialPdf(ref,documentId='',force=false){
  if(!ref)throw new Error('Browser DCO non aperto.');
  const safeId=String(documentId||'').replace(/[^0-9]/g,'');
  if(!safeId)throw new Error('Identificativo documento DCO non disponibile.');
  const forceFlag=force?'true':'false';
  const code=`(function(){
    try{
      window.__cassaiqCancelDeferredClicks=true;
      window.__cassaiqActiveQuickToken='';
      var id=${JSON.stringify(safeId)},force=${forceFlag};
      function snapshot(p){return p?{state:String(p.state||''),documentId:String(p.documentId||''),bytes:Number(p.bytes||0),base64Length:String(p.base64||'').length,error:String(p.error||''),status:Number(p.status||0),contentType:String(p.contentType||''),responseUrl:String(p.responseUrl||''),transport:String(p.transport||''),attempt:Number(p.attempt||0),attempts:Array.isArray(p.attempts)?p.attempts.slice(-8):[],startedAt:Number(p.startedAt||0),headersAt:Number(p.headersAt||0),readyAt:Number(p.readyAt||0),failedAt:Number(p.failedAt||0),officialTriggeredAt:Number(p.officialTriggeredAt||0),navigationUrl:String(p.navigationUrl||''),href:String(location.href||''),host:String(location.hostname||''),visibility:String(document.visibilityState||''),hasFocus:document.hasFocus?document.hasFocus():true}:null}
      function setError(message,transport,status,url,type){var old=window.__cassaiqDcoPdf||{};window.__cassaiqDcoPdf={state:'error',documentId:id,startedAt:Number(old.startedAt||Date.now()),bytes:0,base64:'',error:String(message||'Errore recupero PDF ufficiale'),status:Number(status||0),contentType:String(type||''),responseUrl:String(url||old.responseUrl||''),transport:String(transport||old.transport||'official-button'),attempt:Number(old.attempt||1),attempts:Array.isArray(old.attempts)?old.attempts:[],headersAt:Number(old.headersAt||0),readyAt:0,failedAt:Date.now(),officialTriggeredAt:Number(old.officialTriggeredAt||Date.now()),navigationUrl:String(old.navigationUrl||'')};return snapshot(window.__cassaiqDcoPdf)}
      function encode(buffer,transport,type,status,url){try{var bytes=new Uint8Array(buffer),binary='',size=32768;for(var i=0;i<bytes.length;i+=size)binary+=String.fromCharCode.apply(null,bytes.subarray(i,Math.min(i+size,bytes.length)));var base64=btoa(binary);if(base64.slice(0,5)!=='JVBER')throw new Error('Il contenuto ricevuto non è un PDF valido');var old=window.__cassaiqDcoPdf||{};window.__cassaiqDcoPdf={state:'ready',documentId:id,startedAt:Number(old.startedAt||Date.now()),bytes:bytes.length,base64:base64,error:'',status:Number(status||200),contentType:String(type||'application/pdf'),responseUrl:String(url||old.responseUrl||''),transport:String(transport||'official-blob'),attempt:Number(old.attempt||1),attempts:Array.isArray(old.attempts)?old.attempts:[],headersAt:Number(old.headersAt||Date.now()),readyAt:Date.now(),failedAt:0,officialTriggeredAt:Number(old.officialTriggeredAt||Date.now()),navigationUrl:String(old.navigationUrl||'')};return snapshot(window.__cassaiqDcoPdf)}catch(e){return setError(e&&e.message||e,transport,status,url,type)}}
      function captureBlob(blob,transport,url,status){if(!blob||typeof blob.arrayBuffer!=='function')return;var type=String(blob.type||'');blob.arrayBuffer().then(function(buffer){encode(buffer,transport,type,status,url)}).catch(function(e){setError(e&&e.message||e,transport,status,url,type)})}
      function officialUrl(value){
        var compact=String(value||'').replace(/\\s+/g,'');
        try{var parsed=new URL(compact,location.origin);parsed.searchParams.delete('regalo');return parsed.href}catch(e){return compact}
      }
      var previous=window.__cassaiqDcoPdf;
      if(!force&&previous&&String(previous.documentId||'')===id&&['loading','ready','consumed'].indexOf(String(previous.state||''))>=0)return Object.assign({ok:true,reused:true},snapshot(previous));
      window.__cassaiqDcoPdf={state:'loading',documentId:id,startedAt:Date.now(),bytes:0,base64:'',error:'',status:0,contentType:'',responseUrl:'',transport:'official-button',attempt:1,attempts:[],headersAt:0,readyAt:0,failedAt:0,officialTriggeredAt:0,navigationUrl:''};
      if(!window.__cassaiqOfficialPdfHooks){
        window.__cassaiqOfficialPdfHooks=true;
        try{var originalCreate=URL.createObjectURL.bind(URL);URL.createObjectURL=function(value){var out=originalCreate(value);try{if(value instanceof Blob){var current=window.__cassaiqDcoPdf;if(current&&current.state==='loading')captureBlob(value,'official-object-url',out,200)}}catch(e){}return out}}catch(e){}
        try{var originalFetch=window.fetch.bind(window);window.fetch=function(input,init){var url=String(typeof input==='string'?input:(input&&input.url)||'');var promise=originalFetch(input,init);if(url.indexOf('/stampa/')>=0)promise.then(function(response){try{var current=window.__cassaiqDcoPdf;if(!current||current.state!=='loading')return;current.headersAt=Date.now();current.status=Number(response.status||0);current.contentType=String(response.headers.get('content-type')||'');current.responseUrl=String(response.url||url);current.transport='official-fetch';if(response.ok)response.clone().arrayBuffer().then(function(buffer){encode(buffer,'official-fetch',current.contentType,current.status,current.responseUrl)});else setError('HTTP '+response.status,'official-fetch',response.status,response.url,current.contentType)}catch(e){}});return promise}}catch(e){}
        try{var originalOpen=XMLHttpRequest.prototype.open,originalSend=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(method,url){this.__cassaiqUrl=String(url||'');this.__cassaiqMethod=String(method||'');return originalOpen.apply(this,arguments)};XMLHttpRequest.prototype.send=function(){var xhr=this,url=String(xhr.__cassaiqUrl||'');if(url.indexOf('/stampa/')>=0){xhr.addEventListener('loadend',function(){try{var current=window.__cassaiqDcoPdf;if(!current||current.state!=='loading')return;var status=Number(xhr.status||0),type=String(xhr.getResponseHeader('content-type')||''),responseUrl=String(xhr.responseURL||url);current.headersAt=Date.now();current.status=status;current.contentType=type;current.responseUrl=responseUrl;current.transport='official-xhr';if(status<200||status>=300)return setError('HTTP '+status,'official-xhr',status,responseUrl,type);var response=xhr.response;if(response instanceof Blob)return captureBlob(response,'official-xhr',responseUrl,status);if(response instanceof ArrayBuffer)return encode(response,'official-xhr',type,status,responseUrl);if(ArrayBuffer.isView&&ArrayBuffer.isView(response))return encode(response.buffer.slice(response.byteOffset,response.byteOffset+response.byteLength),'official-xhr',type,status,responseUrl)}catch(e){setError(e&&e.message||e,'official-xhr',Number(xhr.status||0),url,'')}})}return originalSend.apply(this,arguments)}}catch(e){}
        try{var originalWindowOpen=window.open;window.open=function(url,name,features){
          var value=officialUrl(url),current=window.__cassaiqDcoPdf;
          if(current&&current.state==='loading'&&value.indexOf('/stampa/')>=0){
            current.navigationUrl=value;current.responseUrl=value;current.transport='official-window-open-intercepted';
            Promise.resolve().then(function(){
              window.fetch(value,{method:'GET',credentials:'include',cache:'no-store'}).catch(function(error){setError(error&&error.message||error,'official-window-open-fetch',0,value,'')});
            });
            return{closed:false,close:function(){this.closed=true},focus:function(){},blur:function(){}};
          }
          return originalWindowOpen.apply(window,arguments)
        }}catch(e){}
      }
      var actions=Array.prototype.slice.call(document.querySelectorAll('button,a,input[type=button],input[type=submit]'));
      function normalButton(el){
        var t=String(el.textContent||el.value||'').replace(/\\s+/g,' ').trim().toLowerCase(),ng=String(el.getAttribute('ng-click')||el.getAttribute('data-ng-click')||'').replace(/\\s+/g,'').toLowerCase();
        if(t.indexOf('regalo')>=0||ng.indexOf('regalo')>=0||ng.indexOf(',true')>=0)return false;
        return t==='scarica e stampa file'||(t.indexOf('scarica e stampa file')===0&&t.indexOf('per regalo')<0)||(ng.indexOf('stampa(')>=0&&ng.indexOf('true')<0);
      }
      var button=actions.find(normalButton);
      if(!button)return setError('Pulsante ufficiale “Scarica e stampa file” non trovato','official-button',0,location.href,'');
      var p=window.__cassaiqDcoPdf;p.officialTriggeredAt=Date.now();p.responseUrl=location.href;
      try{
        var invoked=false;
        if(window.angular){var scope=angular.element(button).scope()||angular.element(button).isolateScope();while(scope){if(scope.vm&&typeof scope.vm.stampa==='function'){invoked=true;scope.vm.stampa(id);break}scope=scope.$parent}}
        if(!invoked){button.scrollIntoView({block:'center'});button.click()}
      }catch(e){return setError(e&&e.message||e,'official-button',0,location.href,'')}
      return Object.assign({ok:true,official:true},snapshot(window.__cassaiqDcoPdf))
    }catch(e){return{ok:false,error:String(e&&e.message||e)}}
  })()`;
  const out=await dcoExecScript(ref,code,15000);
  dcoLogPdfMeta(`avvio pulsante ufficiale DCO-${safeId}`,out);
  if(out?.ok===false)throw new Error(out.error||'Recupero ufficiale non disponibile');
  dcoSetResult('loading',`Documento DCO-${safeId} emesso: download tramite il pulsante ufficiale in corso…`);
  return out;
}
async function dcoDownloadOfficialPdfNatively(ref,documentId,url=''){
  const id=String(documentId||'').replace(/[^0-9]/g,'');if(!id)throw new Error('Identificativo documento DCO non disponibile.');
  if(dcoProcessedDocumentIds.has(id))return dcoLoadLastDocument();
  if(dcoNativePdfDownloads.has(id))return dcoNativePdfDownloads.get(id);
  const task=(async()=>{
    const plugin=printerNativePlugin();if(!plugin?.downloadPdfWithWebCookies)throw new Error('Download PDF con sessione WebKit non disponibile. Esegui npm install e npm run ios:sync.');
    const raw=String(url||'').replace(/\s+/g,'');
    let endpoint=`https://ivaservizi.agenziaentrate.gov.it/ser/api/documenti/v1/doc/documenti/${id}/stampa/`;
    if(raw&&raw.includes('/stampa/')){try{const parsed=new URL(raw,'https://ivaservizi.agenziaentrate.gov.it');parsed.searchParams.delete('regalo');endpoint=parsed.href}catch{endpoint=raw}}
    const referer=dcoDocumentDetailUrl(id);
    dcoLogPdfMeta(`fallback nativo DCO-${id}`,{endpoint,referer});
    const out=await plugin.downloadPdfWithWebCookies({url:endpoint,referer,timeoutMs:60000});
    const base64=String(out?.data||'');if(!base64.startsWith('JVBER'))throw new Error(`Il download ufficiale non ha restituito un PDF valido${out?.status?` · HTTP ${out.status}`:''}`);
    dcoLogPdfMeta(`PDF nativo acquisito DCO-${id}`,{status:Number(out?.status||0),contentType:String(out?.contentType||''),bytes:Number(out?.bytes||0),transport:String(out?.transport||'native-web-cookies')});
    await dcoFinalizeOfficialPdf({documentId:id,base64,bytes:Number(out?.bytes||0),total:dcoBuildDraftPayload().total});
    if(ref)await dcoExecScript(ref,`(function(){window.__cassaiqDcoPdf={state:'consumed',documentId:${JSON.stringify(id)},bytes:${Number(out?.bytes||0)},base64:'',error:'',status:${Number(out?.status||200)},contentType:${JSON.stringify(String(out?.contentType||'application/pdf'))},responseUrl:${JSON.stringify(String(out?.responseUrl||endpoint))},transport:'native-web-cookies',readyAt:Date.now(),startedAt:Date.now()};return true})()`,5000).catch(()=>{});
    return out;
  })().finally(()=>dcoNativePdfDownloads.delete(id));
  dcoNativePdfDownloads.set(id,task);return task;
}

function dcoPendingPdfDocumentId(){
  const lock=loadObjectSafe(K.dcoAutoLock,null),last=dcoLoadLastDocument();
  return String(lock?.documentId||dcoAutoSale?.documentId||last?.documentId||'').replace(/[^0-9]/g,'');
}
async function dcoReadPdfMeta(ref){
  return dcoExecScript(ref,"(function(){var p=window.__cassaiqDcoPdf;return p?{state:String(p.state||''),documentId:String(p.documentId||''),bytes:Number(p.bytes||0),base64Length:String(p.base64||'').length,error:String(p.error||''),status:Number(p.status||0),contentType:String(p.contentType||''),responseUrl:String(p.responseUrl||''),transport:String(p.transport||''),attempt:Number(p.attempt||0),attempts:Array.isArray(p.attempts)?p.attempts.slice(-8):[],startedAt:Number(p.startedAt||0),headersAt:Number(p.headersAt||0),readyAt:Number(p.readyAt||0),failedAt:Number(p.failedAt||0),officialTriggeredAt:Number(p.officialTriggeredAt||0),navigationUrl:String(p.navigationUrl||''),timedOutAt:Number(p.timedOutAt||0),abortedAt:Number(p.abortedAt||0),elapsedMs:p.startedAt?Math.max(0,Date.now()-Number(p.startedAt||0)):0,href:String(location.href||''),host:String(location.hostname||''),visibility:String(document.visibilityState||''),hasFocus:document.hasFocus?document.hasFocus():true}:null})()",10000);
}
async function dcoForcePdfTerminalError(ref,documentId,reason){
  const safeId=String(documentId||'').replace(/[^0-9]/g,''),message=String(reason||'Recupero PDF interrotto prima del completamento.');
  const code=`(function(){
    var id=${JSON.stringify(safeId)},reason=${JSON.stringify(message)},p=window.__cassaiqDcoPdf||{state:'loading',documentId:id,startedAt:Date.now(),bytes:0,base64:'',error:'',status:0,contentType:'',responseUrl:''};
    try{if(window.__cassaiqDcoPdfAbort)window.__cassaiqDcoPdfAbort.abort()}catch(e){}
    if(String(p.state||'')==='loading'){
      p.state='error';p.error=reason;p.failedAt=Date.now();p.timedOutAt=Date.now();p.abortedAt=Date.now();p.bytes=Number(p.bytes||0);p.base64='';
      window.__cassaiqDcoPdf=p;
    }
    return{state:String(p.state||''),documentId:String(p.documentId||id),bytes:Number(p.bytes||0),base64Length:String(p.base64||'').length,error:String(p.error||''),status:Number(p.status||0),contentType:String(p.contentType||''),responseUrl:String(p.responseUrl||''),transport:String(p.transport||''),attempt:Number(p.attempt||0),attempts:Array.isArray(p.attempts)?p.attempts.slice(-8):[],startedAt:Number(p.startedAt||0),headersAt:Number(p.headersAt||0),readyAt:Number(p.readyAt||0),failedAt:Number(p.failedAt||0),officialTriggeredAt:Number(p.officialTriggeredAt||0),navigationUrl:String(p.navigationUrl||''),timedOutAt:Number(p.timedOutAt||0),abortedAt:Number(p.abortedAt||0),elapsedMs:p.startedAt?Math.max(0,Date.now()-Number(p.startedAt||0)):0,href:String(location.href||''),host:String(location.hostname||''),visibility:String(document.visibilityState||''),hasFocus:document.hasFocus?document.hasFocus():true}
  })()`;
  return dcoExecScript(ref,code,10000);
}
async function dcoRetryPendingPdf(options={}){
  const automatic=!!options?.automatic;
  if(dcoPdfRetryBusy)return automatic?false:renderDcoDocumentStatus('Recupero PDF già in corso…','loading');
  const ref=dcoBrowserRef,id=String(options?.documentId||dcoPendingPdfDocumentId()).replace(/[^0-9]/g,'');
  if(!id)return renderDcoDocumentStatus('Identificativo dell’ultimo documento DCO non disponibile. Non ripetere la vendita: verifica il documento in Visualizzazione.','error');
  if(!ref)return renderDcoDocumentStatus(`Documento DCO-${id} già emesso, ma la sessione DCO non è più aperta. Ricollega con SPID e riprova il solo recupero PDF.`,'error');
  dcoPdfRetryBusy=true;if(automatic)dcoAutoPdfRecoveryBusy=true;
  dcoStopAutoTimer();dcoClearBrowserLoadGuard();dcoClearAutomationWaiters(automatic?'Recupero PDF automatico dopo emissione.':'Recupero PDF separato dalla vendita.');
  if(!automatic){dcoAutoSale=null;dcoAutoTickBusy=false;isIssuing=false}
  dcoStopLivePoll();dcoClearCaptureTimers();
  await dcoExecScript(ref,"(function(){window.__cassaiqCancelDeferredClicks=true;window.__cassaiqActiveQuickToken='';if(window.__cassaiqQuick)window.__cassaiqQuick.cancelled=true;return true})()",5000).catch(()=>{});
  renderDcoDocumentStatus(`${automatic?'Recupero automatico':'Preparazione recupero'} PDF ufficiale DCO-${id}…`,'loading');
  dcoSetResult('loading',`${automatic?'Recupero automatico':'Recupero'} PDF DCO-${id} senza ripetere l’emissione…`);
  let browserShown=false,terminalMeta=null,lastMeta=null,keepBrowserOpen=false,pollNumber=0,failureMessage='';
  const terminal=meta=>meta&&['ready','error'].includes(String(meta.state||''));
  const removeOverlay=async()=>{await dcoExecScript(ref,"(function(){var el=document.getElementById('cassaiq-pdf-recovery-overlay');if(el)el.remove();return true})()",4000).catch(()=>{})};
  const updateOverlay=async(message)=>{await dcoExecScript(ref,`(function(){var el=document.getElementById('cassaiq-pdf-recovery-overlay');if(el){var box=el.querySelector('[data-cassaiq-pdf-message]');if(box)box.textContent=${JSON.stringify(String(message||''))}}return true})()`,4000).catch(()=>{})};
  try{
    // Il browser resta visibile e vivo finché il fetch non raggiunge uno stato terminale reale.
    try{ref.show?.();browserShown=true}catch{}
    await new Promise(resolve=>setTimeout(resolve,900));
    const ctx=await dcoExecScript(ref,`(function(){
      var old=document.getElementById('cassaiq-pdf-recovery-overlay');if(old)old.remove();
      var el=document.createElement('div');el.id='cassaiq-pdf-recovery-overlay';
      el.style.cssText='position:fixed;inset:0;z-index:2147483647;background:rgba(9,35,43,.94);display:flex;align-items:center;justify-content:center;padding:24px;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;color:white;text-align:center';
      el.innerHTML='<div style="max-width:520px;background:white;color:#17333a;border-radius:18px;padding:28px;box-shadow:0 18px 70px rgba(0,0,0,.35)"><div style="font-size:12px;font-weight:800;letter-spacing:.12em;color:#2FA8D7;margin-bottom:12px">CASSAIQ · DOCUMENTO GIÀ EMESSO</div><div style="font-size:22px;font-weight:800;margin-bottom:10px">Recupero PDF DCO-${id}</div><div data-cassaiq-pdf-message style="font-size:15px;line-height:1.45;color:#52666b">Attendi senza chiudere questa pagina. Non verrà effettuata una nuova vendita.</div></div>';
      document.documentElement.appendChild(el);
      return{host:String(location.hostname||''),href:String(location.href||''),visibility:String(document.visibilityState||''),hasFocus:document.hasFocus?document.hasFocus():true}
    })()`,8000);
    dcoLogPdfMeta(`contesto DCO-${id}`,ctx);
    if(String(ctx?.host||'').toLowerCase()!=='ivaservizi.agenziaentrate.gov.it')throw new Error('La sessione DCO non è posizionata sul servizio Documento commerciale. Ricollega con SPID e riprova.');
    const detail=await dcoOpenDocumentDetail(ref,id,35000);
    dcoLogPdfMeta(`dettaglio ufficiale pronto DCO-${id}`,detail);
    await dcoExecScript(ref,`(function(){
      var old=document.getElementById('cassaiq-pdf-recovery-overlay');if(old)old.remove();
      var el=document.createElement('div');el.id='cassaiq-pdf-recovery-overlay';
      el.style.cssText='position:fixed;inset:0;z-index:2147483647;background:rgba(9,35,43,.94);display:flex;align-items:center;justify-content:center;padding:24px;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;color:white;text-align:center';
      el.innerHTML='<div style="max-width:520px;background:white;color:#17333a;border-radius:18px;padding:28px;box-shadow:0 18px 70px rgba(0,0,0,.35)"><div style="font-size:12px;font-weight:800;letter-spacing:.12em;color:#2FA8D7;margin-bottom:12px">CASSAIQ · DOCUMENTO GIÀ EMESSO</div><div style="font-size:22px;font-weight:800;margin-bottom:10px">Recupero PDF DCO-${id}</div><div data-cassaiq-pdf-message style="font-size:15px;line-height:1.45;color:#52666b">Dettaglio ufficiale aperto. Acquisizione del PDF in corso; non verrà effettuata una nuova vendita.</div></div>';
      document.documentElement.appendChild(el);return true
    })()`,8000).catch(()=>{});
    await dcoRequestOfficialPdf(ref,id,true);
    const deadline=Date.now()+75000;
    let readFailures=0,restarts=0,nativeFallbackTried=false;
    while(Date.now()<deadline){
      await new Promise(resolve=>setTimeout(resolve,900));pollNumber+=1;
      let meta=null;
      try{meta=await dcoReadPdfMeta(ref);readFailures=0;lastMeta=meta;dcoLogPdfMeta(`poll ${pollNumber} DCO-${id}`,meta)}
      catch(error){
        readFailures+=1;dcoLogPdfMeta(`poll ${pollNumber} non leggibile DCO-${id}`,{error:String(error?.message||error),readFailures});
        if(readFailures<5)continue;
        throw new Error(`Il browser DCO non risponde durante il recupero PDF: ${error?.message||error}`);
      }
      if(!meta){
        if(restarts<1){restarts+=1;dcoLogPdfMeta(`riavvio fetch DCO-${id}`,{reason:'meta assente'});await dcoRequestOfficialPdf(ref,id,true);continue}
        continue;
      }
      const savedNow=dcoLoadLastDocument();if(String(savedNow?.documentId||'')===id&&(savedNow?.path||Number(savedNow?.bytes||0)>0)){terminalMeta={...meta,state:'ready',transport:'native-web-cookies',documentId:id};return}
      if(meta.state==='loading'&&pollNumber===4&&!nativeFallbackTried){
        nativeFallbackTried=true;
        try{
          await dcoDownloadOfficialPdfNatively(ref,id,meta.navigationUrl||meta.responseUrl||'');
          const nativeSaved=dcoLoadLastDocument();
          if(String(nativeSaved?.documentId||'')===id&&(nativeSaved?.path||Number(nativeSaved?.bytes||0)>0)){terminalMeta={...meta,state:'ready',transport:'native-web-cookies',documentId:id};return}
        }catch(error){dcoLogPdfMeta(`fallback nativo fallito DCO-${id}`,{error:String(error?.message||error),url:meta.navigationUrl||meta.responseUrl||''})}
      }
      if(meta.state==='ready'){
        terminalMeta=meta;
        await dcoMaybePullOfficialPdf(ref,meta);
        const saved=dcoLoadLastDocument();
        if(String(saved?.documentId||'')===id&&(saved?.path||Number(saved?.bytes||0)>0))renderDcoDocumentStatus(`PDF ufficiale DCO-${id} recuperato${saved.printed?' e inviato alla stampante di rete':''}.`,saved.printed?'ok':'warning');
        return;
      }
      if(meta.state==='error'){
        if(!nativeFallbackTried&&(meta.navigationUrl||meta.responseUrl||'').includes('/stampa/')){
          nativeFallbackTried=true;
          try{
            await dcoDownloadOfficialPdfNatively(ref,id,meta.navigationUrl||meta.responseUrl||'');
            const nativeSaved=dcoLoadLastDocument();
            if(String(nativeSaved?.documentId||'')===id&&(nativeSaved?.path||Number(nativeSaved?.bytes||0)>0)){terminalMeta={...meta,state:'ready',transport:'native-web-cookies',documentId:id};return}
          }catch(error){dcoLogPdfMeta(`fallback nativo dopo errore DCO-${id}`,{error:String(error?.message||error),url:meta.navigationUrl||meta.responseUrl||''})}
        }
        terminalMeta=meta;
        const details=[meta.error,meta.status?`HTTP ${meta.status}`:'',meta.contentType,meta.responseUrl].filter(Boolean).join(' · ');
        throw new Error(details||'Errore sconosciuto nel recupero PDF');
      }
    }
    // Prima di arrenderci leggiamo e logghiamo ancora lo stato completo.
    try{lastMeta=await dcoReadPdfMeta(ref);dcoLogPdfMeta(`timeout: ultimo stato DCO-${id}`,lastMeta)}catch(error){dcoLogPdfMeta(`timeout: lettura finale fallita DCO-${id}`,{error:String(error?.message||error)})}
    if(lastMeta?.state==='ready'){terminalMeta=lastMeta;await dcoMaybePullOfficialPdf(ref,lastMeta);return}
    if(lastMeta?.state==='error'){terminalMeta=lastMeta;throw new Error([lastMeta.error,lastMeta.status?`HTTP ${lastMeta.status}`:'',lastMeta.contentType,lastMeta.responseUrl].filter(Boolean).join(' · ')||'Errore sconosciuto nel recupero PDF')}
    terminalMeta=await dcoForcePdfTerminalError(ref,id,`Timeout locale dopo 75 secondi: ultimo stato ${lastMeta?.state||'non disponibile'} · HTTP ${Number(lastMeta?.status||0)} · ${lastMeta?.contentType||'content-type non disponibile'}`);
    dcoLogPdfMeta(`timeout: stato terminale forzato DCO-${id}`,terminalMeta);
    throw new Error([terminalMeta?.error,terminalMeta?.status?`HTTP ${terminalMeta.status}`:'',terminalMeta?.contentType,terminalMeta?.responseUrl].filter(Boolean).join(' · ')||'Tempo massimo di recupero superato.');
  }catch(e){
    let msg=String(e?.message||e||'errore sconosciuto');
    if(!terminal(terminalMeta)){
      try{terminalMeta=await dcoForcePdfTerminalError(ref,id,`Recupero interrotto: ${msg}`);dcoLogPdfMeta(`catch: stato terminale DCO-${id}`,terminalMeta)}
      catch(forceError){dcoLogPdfMeta(`catch: impossibile impostare stato terminale DCO-${id}`,{error:String(forceError?.message||forceError),lastMeta});keepBrowserOpen=true}
    }
    if(!terminal(terminalMeta)){
      keepBrowserOpen=true;
      msg+=` · Stato finale non leggibile. Il browser DCO resta aperto e non viene nascosto automaticamente.`;
    }
    failureMessage=msg;
    renderDcoDocumentStatus(`Documento DCO-${id} già emesso. Recupero PDF non riuscito: ${msg}`,'error');
    dcoSetResult('error',`NON ripetere la vendita. DCO-${id} risulta emesso; il problema riguarda solo il PDF: ${msg}`);
  }finally{
    const hasTerminalState=terminal(terminalMeta);
    if(hasTerminalState){
      await removeOverlay();
      const automaticSucceeded=automatic&&String(terminalMeta?.state||'')==='ready';
      if(browserShown&&!automaticSucceeded){try{ref.hide?.()}catch{}}
    }else{
      keepBrowserOpen=true;
      await updateOverlay('Il recupero non ha restituito uno stato finale. La pagina resta aperta per non interrompere la WebView. Non ripetere la vendita.');
    }
    dcoLogPdfMeta(`fine recupero DCO-${id}`,{terminal:hasTerminalState,keepBrowserOpen,browserShown,automatic,lastMeta,terminalMeta});
    dcoPdfRetryBusy=false;if(automatic)dcoAutoPdfRecoveryBusy=false;
    if(automatic&&failureMessage)dcoMarkPdfPending(id,failureMessage);
  }
  return !failureMessage;
}
async function dcoPrintOfficialPdf(source,documentId){
  const plugin=printerNativePlugin();if(!plugin)throw new Error('Modulo stampante non disponibile. Esegui npm install e npm run ios:sync oppure npm run sync.');
  const opt=dcoPrinterOptions();
  localStorage.setItem(K.printerTestIp,opt.host);localStorage.setItem(K.printerTestPort,String(opt.port));
  const payload=source.path?{path:source.path}:{data:source.data};
  if(!/^(?:\d{1,3}\.){3}\d{1,3}$/.test(opt.host))throw new Error('Indirizzo IP stampante di rete non valido.');
  return plugin.printPdfNetwork({...payload,host:opt.host,port:opt.port,width:opt.width,threshold:opt.threshold,timeoutMs:30000});
}
function dcoCurrentCartMatchesSnapshot(snapshot){
  if(!snapshot)return false;
  const current=dcoCreateSaleSnapshot();if(!current)return false;
  if(roundMoney(current.total)!==roundMoney(snapshot.total)||current.payment!==snapshot.payment||current.lines.length!==(snapshot.lines||[]).length)return false;
  return current.lines.every((line,index)=>{const saved=(snapshot.lines||[])[index];return !!saved&&String(line.name)===String(saved.name)&&Number(line.quantity)===Number(saved.quantity)&&roundMoney(line.unitPrice)===roundMoney(saved.unitPrice)});
}
async function dcoFinalizeEmittedSale(documentMeta){
  const initial=dcoNormalizeDocumentMeta(documentMeta),id=initial.documentId;if(!id)throw new Error('Identificativo documento DCO non disponibile.');
  const state=dcoAutoSale;
  if(state&&!dcoAcceptAutoDocumentId(state,id,'finalize'))return null;
  if(dcoEmissionFinalizeBusy)return dcoLoadLastDocument();
  if(dcoCourtesyFinalizedIds.has(id)){
    if(state){dcoLogIgnoredDocumentEvidence(state,id,'finalize','already-finalized-document-ignored');return null}
    return dcoLoadLastDocument()
  }
  dcoEmissionFinalizeBusy=true;dcoCourtesyFinalizedIds.add(id);
  const pending=state?.snapshot||dcoLoadPendingSale();dcoTimingMark(state||dcoPendingEmissionTiming,'emitted-detected','Emissione rilevata');
  try{
    if(!pending)throw new Error('Documento emesso, ma i dati locali della vendita non sono disponibili.');
    const meta=await dcoResolveDocumentMeta(dcoBrowserRef,initial,12),receiptNumber=meta.documentNumber||`DCO-${id}`,officialNumberAvailable=!!meta.documentNumber;dcoTimingMark(state||dcoPendingEmissionTiming,'metadata-ready','Numero ufficiale pronto');
    dcoStopAutoTimer();dcoClearBrowserLoadGuard();dcoClearAutomationWaiters('Documento emesso: stampa immediata su rete.');dcoStopLivePoll();dcoClearCaptureTimers();
    if(state){state.documentId=id;state.documentNumber=meta.documentNumber;state.documentDate=meta.documentDate;state.stage='printing-courtesy';state.lastProgress=Date.now()}
    await dcoShowEmissionOverlay(dcoBrowserRef,`Documento ${receiptNumber} emesso. Stampa immediata sulla stampante di rete…`,'loading').catch(()=>{});
    let snapshot=sales.find(x=>String(x.dcoDocumentId||'')===id||String(x.receiptNumber||'')===receiptNumber)||null,createdNew=false;
    if(!snapshot){
      snapshot={...pending,date:new Date().toISOString(),receiptNumber,dcoDocumentId:id,dcoDocumentNumber:meta.documentNumber||'',dcoDocumentDate:meta.documentDate||'',fiscalSource:'DCO'};
      sales.push(snapshot);save(K.sales,sales);createdNew=true
    }else{
      snapshot.receiptNumber=receiptNumber;snapshot.dcoDocumentId=id;snapshot.dcoDocumentNumber=meta.documentNumber||snapshot.dcoDocumentNumber||'';snapshot.dcoDocumentDate=meta.documentDate||snapshot.dcoDocumentDate||'';
      save(K.sales,sales)
    }
    const previous=dcoLoadLastDocument(),samePrevious=String(previous?.documentId||'')===id;
    let printed=false,printError='',printBytes=0;const autoPrint=localStorage.getItem(K.dcoAutoPrint)!=='0';
    if(autoPrint){
      dcoTimingMark(state||dcoPendingEmissionTiming,'print-start','Avvio stampa di rete');
      try{
        console.log('[CassaIQ DCO ESC/POS]',JSON.stringify({documentId:id,documentNumber:meta.documentNumber,documentDate:meta.documentDate,stage:'printing',lines:(snapshot.lines||[]).length,total:snapshot.total}));
        const out=await dcoPrintCourtesyReceipt(snapshot,meta);printed=true;printBytes=Number(out?.bytes||0);
        console.log('[CassaIQ DCO ESC/POS]',JSON.stringify({documentId:id,documentNumber:meta.documentNumber,stage:'printed',bytes:printBytes}))
      }catch(e){printError=e.message||String(e);console.error('[CassaIQ DCO ESC/POS]',JSON.stringify({documentId:id,documentNumber:meta.documentNumber,stage:'error',error:printError}))}
      finally{dcoTimingMark(state||dcoPendingEmissionTiming,'print-end','Fine stampa di rete')}
    }
    const emissionTiming=dcoPersistEmissionTiming(state?.timing||dcoPendingEmissionTiming,{outcome:'emitted',documentNumber:receiptNumber,printed,printError});
    if(createdNew)cloudSaveSale(snapshot).catch(e=>{console.warn('Vendita DCO salvata solo localmente',e);toast(`Documento emesso; sincronizzazione cloud in attesa: ${e.message||e}`,6000)}).finally(()=>scheduleSalesSyncAfterSale());
    const last={...(samePrevious?previous:{}),documentId:id,documentNumber:meta.documentNumber||'',documentDate:meta.documentDate||'',receiptNumber,total:Number(snapshot.total||0),payment:snapshot.payment||'',date:new Date().toISOString(),courtesySnapshot:snapshot,printed,printedAt:printed?new Date().toISOString():'',printBytes,printError,printKind:'escpos-courtesy',pdfOptional:true,pdfStatus:samePrevious&&previous?.path?'saved':'not-requested',officialNumberAvailable,emissionTiming};
    localStorage.setItem(K.dcoLastDocument,JSON.stringify(last));
    if(dcoEmergencyActiveId||localStorage.getItem(K.emergencyActive))emergencyMarkRegularized(dcoEmergencyActiveId||localStorage.getItem(K.emergencyActive),{documentId:id,documentNumber:meta.documentNumber||receiptNumber,documentDate:meta.documentDate||'',receiptNumber});
    const mayClearCurrentCart=dcoCurrentCartMatchesSnapshot(pending);localStorage.removeItem(K.dcoPendingSale);localStorage.removeItem(K.dcoAutoLock);if(mayClearCurrentCart&&activeTableCheckout)finalizeActiveTableCheckout().catch(()=>{});if(mayClearCurrentCart)resetSale();
    if(createdNew||snapshot)renderStats();setDcoRealTestEnabled(false);
    // Chiudiamo soltanto il contesto dell'operazione CassaIQ, non la sessione
    // Fisconline. Timer, callback, quick state e metadata watcher della vendita
    // appena conclusa non possono cosi' contaminare la vendita successiva.
    dcoStopAutoTimer();dcoClearBrowserLoadGuard();dcoBrowserLoading=false;dcoClearAutomationWaiters('Operazione DCO conclusa.');
    await dcoResetOperationContext(dcoBrowserRef,'',false).catch(()=>{});
    dcoAutoSale=null;dcoAutoTickBusy=false;isIssuing=false;await dcoRemoveEmissionOverlay(dcoBrowserRef).catch(()=>{});try{dcoBrowserRef?.hide?.()}catch{}dcoMarkConnected();renderCart();
    const numberNote=officialNumberAvailable?'':' Numero ufficiale non disponibile nella pagina: sulla stampa è indicato soltanto il riferimento tecnico DCO.';
    if(printed){
      renderDcoDocumentStatus(`Documento ${receiptNumber} emesso e stampato subito sulla stampante di rete.${numberNote} Il PDF ufficiale è opzionale.`,'ok');
      dcoSetResult(officialNumberAvailable?'ok':'warning',`Documento fiscale ${receiptNumber} emesso, registrato e stampato.${numberNote} PDF ufficiale disponibile come archivio opzionale.`);
      dcoQuickFinishProgress(`Documento ${receiptNumber} emesso`,officialNumberAvailable?'ok':'warning');dcoRenderQuickTiming(emissionTiming);toast(`${receiptNumber} emesso`,5000)
    }else{
      renderDcoDocumentStatus(`Documento ${receiptNumber} emesso. Stampa immediata non riuscita: ${printError||'stampa automatica disattivata'}. Usa “Ristampa ultimo documento”.${numberNote}`,'warning');
      dcoSetResult('warning',`Documento fiscale ${receiptNumber} emesso e registrato. Stampa di rete da riprovare: ${printError||'stampa automatica disattivata'}.${numberNote}`);
      dcoQuickFinishProgress(`Documento ${receiptNumber} emesso. Stampa di rete da riprovare.`,'warning');dcoRenderQuickTiming(emissionTiming);toast(`${receiptNumber} emesso; stampa da verificare`,6000)
    }
    return last
  }catch(e){dcoCourtesyFinalizedIds.delete(id);throw e}finally{dcoEmissionFinalizeBusy=false}
}

async function dcoFinalizeOfficialPdf(info){
  const documentId=String(info.documentId||'').replace(/[^0-9]/g,'');if(!documentId)throw new Error('Identificativo documento DCO non disponibile.');
  if(dcoProcessedDocumentIds.has(documentId))return;
  dcoProcessedDocumentIds.add(documentId);dcoLastPdfBase64=info.base64||'';
  const pending=dcoLoadPendingSale(),previousLast=dcoLoadLastDocument(),samePrevious=String(previousLast?.documentId||'')===documentId;
  const meta=dcoNormalizeDocumentMeta({documentId,documentNumber:info.documentNumber||previousLast?.documentNumber||'',documentDate:info.documentDate||previousLast?.documentDate||''});
  const receiptNumber=meta.documentNumber||previousLast?.receiptNumber||`DCO-${documentId}`;
  let snapshot=sales.find(x=>String(x.dcoDocumentId||'')===documentId||String(x.receiptNumber||'')===receiptNumber)||null,createdNew=false;
  if(!snapshot&&pending){snapshot={...pending,date:new Date().toISOString(),receiptNumber,dcoDocumentId:documentId,dcoDocumentNumber:meta.documentNumber||'',dcoDocumentDate:meta.documentDate||'',fiscalSource:'DCO'};sales.push(snapshot);save(K.sales,sales);createdNew=true;try{await cloudSaveSale(snapshot)}catch(e){console.warn('Vendita DCO salvata solo localmente',e);toast(`Documento DCO emesso; sincronizzazione cloud in attesa: ${e.message||e}`,6000)}finally{scheduleSalesSyncAfterSale()}}
  let saved=null,saveError='';const plugin=printerNativePlugin(),safeFileLabel=printerPlainText(receiptNumber).replace(/[^A-Za-z0-9._-]+/g,'-').replace(/^-+|-+$/g,'')||documentId;
  try{if(!plugin?.savePdf)throw new Error('Metodo salvataggio PDF non disponibile.');saved=await plugin.savePdf({data:info.base64,fileName:`Documento-commerciale-${safeFileLabel}.pdf`})}catch(e){saveError=e.message||String(e)}
  const courtesyAlreadyPrinted=samePrevious&&previousLast?.printKind==='escpos-courtesy'&&previousLast?.printed;
  const last={...(samePrevious?previousLast:{}),documentId,documentNumber:meta.documentNumber||previousLast?.documentNumber||'',documentDate:meta.documentDate||previousLast?.documentDate||'',receiptNumber,total:Number(snapshot?.total||pending?.total||info.total||0),payment:snapshot?.payment||pending?.payment||'',date:new Date().toISOString(),path:saved?.path||'',uri:saved?.uri||'',fileName:saved?.fileName||'',bytes:Number(saved?.bytes||info.bytes||0),printed:courtesyAlreadyPrinted?true:false,printedAt:courtesyAlreadyPrinted?previousLast.printedAt:'',printBytes:courtesyAlreadyPrinted?Number(previousLast.printBytes||0):0,printKind:courtesyAlreadyPrinted?'escpos-courtesy':'pdf',courtesySnapshot:previousLast?.courtesySnapshot||snapshot||pending||null,printError:'',saveError,pdfStatus:saved?.path?'saved':'error'};
  localStorage.setItem(K.dcoLastDocument,JSON.stringify(last));
  let printMessage=courtesyAlreadyPrinted?' Il documento commerciale era già stato stampato subito dopo l’emissione.':'';const autoPrint=localStorage.getItem(K.dcoAutoPrint)!=='0'&&!courtesyAlreadyPrinted;
  if(autoPrint){try{const out=await dcoPrintOfficialPdf(saved?.path?{path:saved.path}:{data:info.base64},documentId);last.printed=true;last.printedAt=new Date().toISOString();last.printBytes=Number(out?.bytes||0);last.printKind='pdf';printMessage=' Stampa di rete inviata.'}catch(e){last.printError=e.message||String(e);printMessage=` Stampa non riuscita: ${last.printError}`}}
  localStorage.setItem(K.dcoLastDocument,JSON.stringify(last));
  const mayClearCurrentCart=!!pending&&dcoCurrentCartMatchesSnapshot(pending);
  localStorage.removeItem(K.dcoPendingSale);
  if(mayClearCurrentCart&&activeTableCheckout)finalizeActiveTableCheckout().catch(()=>{});
  if(mayClearCurrentCart)resetSale();
  if(createdNew||snapshot)renderStats();
  setDcoRealTestEnabled(false);renderDcoDocumentStatus(`Documento ${receiptNumber} acquisito. ${saved?.path?'PDF salvato.':`PDF non salvato: ${saveError||'errore sconosciuto'}.`}${printMessage}`,last.printed?'ok':'warning');
  const registration=snapshot?' e registrato in CassaIQ':' acquisito; la vendita non è stata aggiunta alle statistiche perché mancava la bozza locale';
  dcoSetResult(last.printed?'ok':'warning',`Documento fiscale ${receiptNumber} emesso${registration}.${saved?.path?' PDF ufficiale salvato.':''}${printMessage}`);toast(`Documento DCO ${receiptNumber} acquisito`,5000);
  localStorage.removeItem(K.dcoAutoLock);
  if(dcoAutoSale){
    dcoStopAutoTimer();dcoStopLivePoll();dcoClearCaptureTimers();dcoClearBrowserLoadGuard();dcoClearAutomationWaiters('Documento DCO acquisito.');dcoAutoSale=null;dcoAutoTickBusy=false;isIssuing=false;await dcoRemoveEmissionOverlay(dcoBrowserRef);try{dcoBrowserRef?.hide?.()}catch{}dcoMarkConnected();renderCart();
    dcoQuickFinishProgress(`Documento ${receiptNumber} emesso`,last.printed?'ok':'warning');
  }
}
async function dcoMaybePullOfficialPdf(ref,pdfMeta){
  if(!pdfMeta||pdfMeta.state!=='ready'||!pdfMeta.documentId||dcoPdfPulling||dcoProcessedDocumentIds.has(String(pdfMeta.documentId)))return;
  dcoPdfPulling=true;renderDcoDocumentStatus(`Recupero PDF ufficiale DCO-${pdfMeta.documentId}…`,'loading');
  try{
    const length=Number(pdfMeta.base64Length||0);if(!length)throw new Error('Il PDF ufficiale risulta vuoto.');
    let base64='';const chunkSize=120000;
    for(let offset=0;offset<length;offset+=chunkSize){const end=Math.min(length,offset+chunkSize);const chunk=await dcoExecScript(ref,`(function(){var p=window.__cassaiqDcoPdf;return p&&p.base64?p.base64.slice(${offset},${end}):''})()`,15000);if(typeof chunk!=='string'||!chunk.length)throw new Error('Trasferimento PDF interrotto.');base64+=chunk}
    if(!base64.startsWith('JVBER'))throw new Error('Il file ricevuto non sembra un PDF valido.');
    await dcoFinalizeOfficialPdf({documentId:String(pdfMeta.documentId),base64,bytes:Number(pdfMeta.bytes||0),total:dcoBuildDraftPayload().total});
    await dcoExecScript(ref,"(function(){if(window.__cassaiqDcoPdf){window.__cassaiqDcoPdf.base64='';window.__cassaiqDcoPdf.state='consumed'}return true})()",5000).catch(()=>{});
  }catch(e){dcoProcessedDocumentIds.delete(String(pdfMeta.documentId));renderDcoDocumentStatus(`Documento emesso, ma recupero PDF non completato: ${e.message||e}`,'error');dcoSetResult('error',`Non ripetere l'emissione. Il documento risulta emesso; il PDF ufficiale non è stato archiviato. Puoi usare “Ristampa ultimo documento” per ristamparlo. Dettaglio: ${e.message||e}`)}finally{dcoPdfPulling=false}
}
async function dcoReprintLastDocument(){
  const last=dcoLoadLastDocument();if(!last?.courtesySnapshot&&!last?.path&&!dcoLastPdfBase64)return renderDcoDocumentStatus('Nessun documento DCO disponibile per la ristampa.','error');
  renderDcoDocumentStatus('Invio dell’ultimo documento alla stampante di rete…','loading');
  try{const documentMeta={documentId:last.documentId||'',documentNumber:last.documentNumber||last.courtesySnapshot?.dcoDocumentNumber||'',documentDate:last.documentDate||last.courtesySnapshot?.dcoDocumentDate||''};const out=last?.courtesySnapshot?await dcoPrintCourtesyReceipt(last.courtesySnapshot,documentMeta):await dcoPrintOfficialPdf(last?.path?{path:last.path}:{data:dcoLastPdfBase64},last?.documentId||'');const updated={...last,printed:true,printedAt:new Date().toISOString(),printBytes:Number(out?.bytes||0),printKind:last?.courtesySnapshot?'escpos-courtesy':'pdf',printError:''};localStorage.setItem(K.dcoLastDocument,JSON.stringify(updated));renderDcoDocumentStatus(`Ristampa ${updated.receiptNumber||updated.documentId} inviata alla stampante di rete.`,'ok')}catch(e){const updated={...last,printed:false,printError:e.message||String(e)};localStorage.setItem(K.dcoLastDocument,JSON.stringify(updated));renderDcoDocumentStatus(`Ristampa non riuscita: ${updated.printError}`,'error')}
}
function dcoRememberRoute(url,event){
  const safe=dcoSafeUrl(url);
  if(!safe)return;
  const last=dcoRouteHistory[dcoRouteHistory.length-1];
  if(last&&last.url===safe&&last.event===event)return;
  dcoRouteHistory.push({at:new Date().toISOString(),event:event||'page',url:safe});
  if(dcoRouteHistory.length>50)dcoRouteHistory=dcoRouteHistory.slice(-50);
}
function dcoRenderDiagnostic(page){
  dcoLastDiagnostic={capturedAt:new Date().toISOString(),routes:dcoRouteHistory.slice(),page:page||null,emissionTimings:dcoTimingLoadHistory()};
  const out=$('dcoDiagnostic');if(!out)return;
  out.textContent=JSON.stringify(dcoLastDiagnostic,null,2);
}
function dcoClearCaptureTimers(){dcoCaptureTimers.forEach(clearTimeout);dcoCaptureTimers=[]}
function dcoStopLivePoll(){if(dcoLivePollTimer){clearInterval(dcoLivePollTimer);dcoLivePollTimer=null}}
function dcoStartLivePoll(ref){
  dcoStopLivePoll();
  dcoLivePollTimer=setInterval(()=>{
    if(dcoBrowserRef!==ref)return dcoStopLivePoll();

    // La vendita automatica usa il proprio runner dedicato.
    // Non eseguiamo diagnostica parallela durante l'emissione.
    if(dcoAutoSale)return;

    // Il polling continuo serve SOLO mentre CassaIQ sta completando
    // il collegamento Fisconline/SPID. Appena il collegamento termina,
    // fermiamo il timer: niente executeScript diagnostici ogni secondo
    // sulla sessione DCO già pronta.
    if(dcoConnectionPending){
      dcoConnectionTick(ref);
      return;
    }

    dcoStopLivePoll();
  },1000);
}
function dcoInjectLabBar(ref){
  if(!ref)return;
  const urls=JSON.stringify(DCO_URLS),draft=JSON.stringify(dcoBuildDraftPayload()),realTest=JSON.stringify(!!dcoRealTestEnabled);
  const code=`(function(){
    try{
      var U=${urls},DRAFT=${draft},REAL_TEST=${realTest},ARM_KEY='cassaiq_dco_real_arm_v2';
      function clean(v){return String(v==null?'':v).replace(/\\s+/g,' ').trim()}
      function money(v){var n=Number(v||0);return Number.isFinite(n)?n.toFixed(2).replace('.',','):'0,00'}
      function quantity(v){var n=Number(v||0);return Number.isInteger(n)?String(n):n.toFixed(2).replace('.',',')}
      function fire(el){['input','change','blur'].forEach(function(name){try{el.dispatchEvent(new Event(name,{bubbles:true}))}catch(e){}});try{if(window.angular){var scope=angular.element(el).scope();if(scope&&!scope.$$phase)scope.$applyAsync()}}catch(e){}}
      function setValue(id,value){var el=document.getElementById(id);if(!el)return false;if(el.type==='checkbox'){el.checked=!!value;fire(el);return true}el.value=value==null?'':String(value);fire(el);return true}
      function setSelect(id,value){var el=document.getElementById(id);if(!el)return false;el.value=String(value);if(el.value!==String(value)){var option=Array.prototype.slice.call(el.options||[]).find(function(o){return clean(o.textContent)===String(value)||String(o.value)===String(value)});if(option)el.selectedIndex=option.index}fire(el);return true}
      function actionText(el){return clean(el&&((el.textContent||el.value)||'')).toLowerCase()}
      function actionVisible(el){if(!el||el.disabled)return false;try{var st=getComputedStyle(el),r=el.getBoundingClientRect();return st.display!=='none'&&st.visibility!=='hidden'&&r.width>0&&r.height>0}catch(e){return false}}
      function allActions(){return Array.prototype.slice.call(document.querySelectorAll('button,a,input[type=submit],input[type=button],[role=button]'))}
      function downloadButton(){return allActions().find(function(el){return actionVisible(el)&&actionText(el).indexOf('scarica e stampa file')===0})}
      function documentEmitted(){var id=findTransactionId(),p=window.__cassaiqDcoPdf;return !!downloadButton()||!!(id&&p&&String(p.documentId||'')===String(id)&&['loading','ready','consumed','error'].indexOf(String(p.state||''))>=0)}
      function findTransactionId(){
        try{var el=downloadButton();if(window.angular&&el){function scanScope(scope,seen){if(!scope||seen.indexOf(scope)>=0||seen.length>600)return'';seen.push(scope);if(scope.vm&&scope.vm.invio&&scope.vm.invio.idtrx)return String(scope.vm.invio.idtrx);var found=scanScope(scope.$$childHead,seen);if(found)return found;return scanScope(scope.$$nextSibling,seen)}var ae=angular.element(el),scope=ae.scope()||ae.isolateScope();while(scope){if(scope.vm&&scope.vm.invio&&scope.vm.invio.idtrx)return String(scope.vm.invio.idtrx);scope=scope.$parent}var injector=angular.element(document.body).injector&&angular.element(document.body).injector();var root=injector&&injector.get('$rootScope');var deep=scanScope(root,[]);if(deep)return deep}}catch(e){}
        try{var html=document.documentElement.innerHTML,m=html.match(/documenti\\/(\\d+)\\/stampa/i);if(m)return m[1]}catch(e){}return ''
      }
      function startPdfFetch(forcedId,force){
        var id=String(forcedId||findTransactionId()||'').replace(/[^0-9]/g,'');if(!id)return{ok:false,error:'Identificativo documento non ancora disponibile'};
        if(typeof window.__cassaiqStartPdfFetch==='function'&&window.__cassaiqStartPdfFetch.__cassaiqRobust)return window.__cassaiqStartPdfFetch(id,!!force);
        return{ok:false,state:'pending',documentId:id,error:'Recupero PDF gestito dal motore CassaIQ con fallback HTTP'}
      }
      if(typeof window.__cassaiqStartPdfFetch!=='function')window.__cassaiqStartPdfFetch=startPdfFetch;
      function clearDraft(){setSelect('operazione','V');setValue('i2.0','');var rowIds=Array.prototype.slice.call(document.querySelectorAll('[id^=\"i2_2_1_r\"]')).map(function(el){var m=String(el.id||'').match(/^i2_2_1_r(\\d+)$/);return m?Number(m[1]):-1}).filter(function(i){return i>=0});rowIds.forEach(function(i){setValue('i2_2_1_r'+i,'');setValue('i2_2_2_r'+i,'');setValue('i2_2_3_r'+i,'');var vat=document.getElementById('i2_2_4_r'+i);if(vat){vat.selectedIndex=0;fire(vat)}setValue('i2_2_5_r'+i,'');setValue('i2_2_6_r'+i,false)});setValue('i2_4_4',false);setValue('i2_4_5','');setValue('i2_4_6','');setValue('i2_4_1','');setValue('i2_4_2','');setValue('i2_4_3','');setValue('i2_4_3_3','');setValue('i2_5','');setValue('i2_4_7','');state.textContent='Campi della bozza puliti.';window.scrollTo(0,0)}
      function applyDraft(){if(!DRAFT.ok){state.textContent=DRAFT.error;alert('CassaIQ: '+DRAFT.error);return false}if(location.hash.indexOf('/generazione/wizard2')<0){state.textContent='Apri prima Genera il tuo documento.';return false}clearDraft();setSelect('operazione',DRAFT.operation||'V');DRAFT.lines.forEach(function(line,i){setValue('i2_2_1_r'+i,quantity(line.quantity));setValue('i2_2_2_r'+i,line.description);setValue('i2_2_3_r'+i,money(line.grossPrice));setSelect('i2_2_4_r'+i,line.vat);if(line.discount)setValue('i2_2_5_r'+i,money(line.discount));setValue('i2_2_6_r'+i,!!line.gift)});setValue('i2_4_1',DRAFT.cash?money(DRAFT.cash):'');setValue('i2_4_2',DRAFT.electronic?money(DRAFT.electronic):'');setValue('i2_5',DRAFT.discount?money(DRAFT.discount):'');state.textContent='Bozza compilata: '+DRAFT.lines.length+' righe · € '+money(DRAFT.total)+' · '+DRAFT.payment+'. Controlla tutto, poi usa “Vai a Verifica dati”.';window.scrollTo(0,0);setTimeout(function(){fire(document.getElementById('i2_2_1_r0')||document.body)},250);return true}
      function finalAction(el){var t=actionText(el),h=String(location.hash||'').toLowerCase();if(!t)return false;var safeNavigation=['vai a verifica dati','vai a conferma e stampa','ho capito','torna a verifica dati','torna a dati documento commerciale','torna a i miei dati','annulla','scarica e stampa file','scarica e stampa file per regalo'];if(safeNavigation.some(function(v){return t===v||t.indexOf(v)>=0}))return false;if(h.indexOf('/generazione/wizard4')>=0&&(t==='procedi'||t==='conferma'))return true;return /(^conferma$|^procedi$|^stampa$|^emetti$|^conferma e stampa$|conferma.*documento|genera.*documento|emetti|emissione definitiva|conferma e invia|invia.*documento|memorizza|trasmetti|stampa.*documento)/i.test(t)}
      function readArm(){try{var x=JSON.parse(sessionStorage.getItem(ARM_KEY)||'null');if(!x||Number(x.expiresAt)<=Date.now()||String(x.total)!==money(DRAFT.total)||Number(x.lines)!==Number((DRAFT.lines||[]).length)){sessionStorage.removeItem(ARM_KEY);return null}return x}catch(e){sessionStorage.removeItem(ARM_KEY);return null}}
      function canUseFinal(el){if(documentEmitted())return false;if(!REAL_TEST||location.hash.indexOf('/generazione/wizard4')<0)return false;var t=actionText(el);return !!readArm()&&(t==='procedi'||t==='conferma')}
      function writeArm(patch){var arm=readArm();if(!arm)return null;Object.keys(patch||{}).forEach(function(k){arm[k]=patch[k]});sessionStorage.setItem(ARM_KEY,JSON.stringify(arm));return arm}
      function showArmDialog(){if(!REAL_TEST){alert('Abilita prima la prova reale nella schermata CassaIQ.');return}if(!DRAFT.ok){alert('CassaIQ: '+DRAFT.error);return}if(documentEmitted()){alert('Documento già emesso. Non premere nuovamente Procedi.');return}var old=document.getElementById('cassaiq-dco-arm-overlay');if(old)old.remove();var overlay=document.createElement('div');overlay.id='cassaiq-dco-arm-overlay';overlay.style.cssText='position:fixed;z-index:2147483647;inset:0;background:rgba(4,18,16,.78);display:flex;align-items:center;justify-content:center;padding:20px;font-family:-apple-system,BlinkMacSystemFont,sans-serif';var card=document.createElement('div');card.style.cssText='width:min(560px,96vw);max-height:90vh;overflow:auto;background:white;color:#142b27;border-radius:18px;padding:22px;box-shadow:0 20px 70px rgba(0,0,0,.45)';card.innerHTML='<h2 style="margin:0 0 8px">Abilita una emissione fiscale reale</h2><p style="line-height:1.45">Il documento verrà realmente memorizzato presso l’Agenzia delle Entrate. Dopo l’esito CassaIQ recupererà il PDF ufficiale, registrerà la vendita e proverà a stamparla sulla stampante di rete.</p><div style="background:#fff4dc;border:1px solid #e2b759;border-radius:12px;padding:12px;margin:12px 0"><b>'+clean(DRAFT.lines.length)+' righe · € '+money(DRAFT.total)+' · '+clean(DRAFT.payment)+'</b><br><small>Controlla nuovamente dati, IVA e pagamento nella pagina ufficiale.</small></div><label style="display:block;margin:12px 0"><input id="cassaiq-real-check" type="checkbox"> Confermo che si tratta di una vendita reale della mia attività.</label><label style="display:block;margin:12px 0">Digita il totale esatto <b>'+money(DRAFT.total)+'</b><input id="cassaiq-real-total" inputmode="decimal" autocomplete="off" style="display:block;width:100%;box-sizing:border-box;margin-top:6px;padding:12px;border:1px solid #9bb2ad;border-radius:9px;font-size:18px"></label><label style="display:block;margin:12px 0">Digita <b>EMETTI</b><input id="cassaiq-real-word" autocomplete="off" autocapitalize="characters" style="display:block;width:100%;box-sizing:border-box;margin-top:6px;padding:12px;border:1px solid #9bb2ad;border-radius:9px;font-size:18px;text-transform:uppercase"></label><div id="cassaiq-real-error" style="color:#9b2020;font-weight:700;min-height:20px"></div>';var actions=document.createElement('div');actions.style.cssText='display:flex;gap:10px;justify-content:flex-end;margin-top:14px';var cancel=b('Annulla',function(){overlay.remove()},'#e9efed');var unlock=b('Sblocca per 5 minuti',function(){var ok=card.querySelector('#cassaiq-real-check').checked,total=clean(card.querySelector('#cassaiq-real-total').value),word=clean(card.querySelector('#cassaiq-real-word').value).toUpperCase(),err=card.querySelector('#cassaiq-real-error');if(!ok){err.textContent='Conferma che la vendita è reale.';return}if(total!==money(DRAFT.total)){err.textContent='Il totale non corrisponde.';return}if(word!=='EMETTI'){err.textContent='Digita esattamente EMETTI.';return}sessionStorage.setItem(ARM_KEY,JSON.stringify({expiresAt:Date.now()+300000,stage:'armed',armedAt:Date.now(),total:money(DRAFT.total),lines:(DRAFT.lines||[]).length}));overlay.remove();state.textContent='EMISSIONE ARMATA per 5 minuti · usa il pulsante ufficiale “Conferma” e poi “Procedi”.';installSafetyGuard()},'#f4c95d');actions.appendChild(cancel);actions.appendChild(unlock);card.appendChild(actions);overlay.appendChild(card);document.documentElement.appendChild(overlay)}
      function installSafetyGuard(){window.__cassaiqDcoCanUseFinal=canUseFinal;if(!document.__cassaiqDcoSafety){document.__cassaiqDcoSafety=true;document.addEventListener('click',function(e){var el=e.target&&e.target.closest?e.target.closest('button,a,input[type=submit],input[type=button]'):null;if(!el||el.closest('#cassaiq-dco-labbar')||el.closest('#cassaiq-dco-arm-overlay'))return;if(window.__cassaiqAutoSaleActive===true)return;if(finalAction(el)){if(documentEmitted()){e.preventDefault();e.stopImmediatePropagation();alert('CassaIQ: il documento risulta già emesso. Non premere nuovamente Procedi.');return}if(window.__cassaiqDcoCanUseFinal&&window.__cassaiqDcoCanUseFinal(el)){var t=actionText(el),now=Date.now();if(t==='conferma')writeArm({stage:'confirm-opened',confirmClickedAt:now,expiresAt:now+300000});else if(t==='procedi'){writeArm({stage:'proceed-clicked',proceedClickedAt:now,expiresAt:now+120000});window.__cassaiqDcoEmissionClickedAt=now}return}e.preventDefault();e.stopImmediatePropagation();alert(REAL_TEST?'CassaIQ: emissione bloccata. Usa “Arma emissione reale” e completa le conferme.':'CassaIQ LAB: emissione fiscale finale bloccata.');}},true);document.addEventListener('submit',function(e){if(window.__cassaiqAutoSaleActive===true)return;var h=String(location.hash||'').toLowerCase();if(h.indexOf('/generazione/')>=0&&(!readArm()||documentEmitted())){e.preventDefault();e.stopImmediatePropagation();alert(documentEmitted()?'CassaIQ: documento già emesso. Invio ripetuto bloccato.':'CassaIQ: invio fiscale bloccato perché la prova non è armata.');}},true)}Array.prototype.slice.call(document.querySelectorAll('button,a,input[type=submit],input[type=button]')).forEach(function(el){if(el.closest('#cassaiq-dco-labbar')||el.closest('#cassaiq-dco-arm-overlay')||!finalAction(el))return;el.setAttribute('data-cassaiq-final-action','1');if(canUseFinal(el)){el.removeAttribute('aria-disabled');el.title='Emissione armata: verifica prima di continuare';el.style.outline='3px solid #15805a'}else{el.setAttribute('aria-disabled','true');el.title=documentEmitted()?'Documento già emesso: ripetizione bloccata':'Bloccato da CassaIQ';el.style.outline='3px solid #a32323'}el.style.outlineOffset='2px'});var warning=document.getElementById('cassaiq-dco-safety');if(!warning){warning=document.createElement('div');warning.id='cassaiq-dco-safety';warning.style.cssText='position:fixed;z-index:2147483646;top:6px;left:50%;transform:translateX(-50%);color:white;padding:7px 12px;border-radius:9px;font:700 12px -apple-system,BlinkMacSystemFont,sans-serif;box-shadow:0 3px 15px rgba(0,0,0,.25)';document.documentElement.appendChild(warning)}var emitted=documentEmitted(),arm=readArm();warning.style.background=emitted?'#146b45':arm?'#146b45':'#8d1b1b';warning.textContent=emitted?'CassaIQ · DOCUMENTO EMESSO · RIPETIZIONE BLOCCATA':arm?'CassaIQ · EMISSIONE REALE ARMATA':'CassaIQ · emissione fiscale bloccata'}
      var old=document.getElementById('cassaiq-dco-labbar');if(old)old.remove();var bar=document.createElement('div');bar.id='cassaiq-dco-labbar';bar.style.cssText='position:fixed;z-index:2147483647;left:8px;right:8px;bottom:8px;background:#102f2b;color:white;border-radius:12px;padding:8px;box-shadow:0 5px 25px rgba(0,0,0,.35);font:600 13px -apple-system,BlinkMacSystemFont,sans-serif;display:flex;gap:6px;align-items:center;flex-wrap:wrap';function b(label,action,accent){var x=document.createElement('button');x.type='button';x.textContent=label;x.style.cssText='border:0;border-radius:8px;padding:9px 11px;background:'+(accent||'white')+';color:#173e39;font-weight:700';x.onclick=action;return x}function go(url){return function(){location.href=url}}function clickByText(labels){var wanted=labels.map(function(v){return String(v).toLowerCase()});var primary=allActions();var found=primary.find(function(el){var t=actionText(el);return wanted.some(function(w){return t===w})})||primary.find(function(el){var t=actionText(el);return wanted.some(function(w){return t.indexOf(w)>=0})});if(found){state.textContent='Apertura schermata…';found.click();setTimeout(function(){window.scrollTo(0,0)},300);return true}state.textContent='Comando non trovato: aprilo dal menu ufficiale.';return false}var state=document.createElement('span');state.style.cssText='padding:0 6px;flex:1 1 240px';state.textContent=(document.querySelector('#user-info')?'Sessione rilevata · ':'')+(DRAFT.ok?DRAFT.lines.length+' righe · € '+money(DRAFT.total)+' · '+DRAFT.payment:DRAFT.error);bar.appendChild(state);bar.appendChild(b('Accesso',go(U.login)));bar.appendChild(b('Verifica',go(U.loggedHome)));bar.appendChild(b('Utenza',go(U.entry)));bar.appendChild(b('DCO',go(U.service)));
      if(location.pathname.indexOf('/ser/documenticommercialionline/')>=0&&location.hash.indexOf('/generazione/wizard2')<0&&location.hash.indexOf('/generazione/wizard3')<0&&location.hash.indexOf('/generazione/wizard4')<0)bar.appendChild(b('Genera',function(){clickByText(['Genera il tuo documento','Generazione'])},'#f4c95d'));
      if(location.hash.indexOf('/generazione/wizard2')>=0){bar.appendChild(b('Compila carrello',applyDraft,'#f4c95d'));bar.appendChild(b('Pulisci',clearDraft,'#d7ece8'))}
      if(location.hash.indexOf('/generazione/wizard3')>=0){var understood=allActions().find(function(el){return actionText(el)==='ho capito'});if(understood)bar.appendChild(b('Continua mappatura',function(){state.textContent='Apertura schermata conclusiva…';understood.click();setTimeout(function(){window.scrollTo(0,0)},350)},'#f4c95d'));else bar.appendChild(b('Mappa conferma',function(){clickByText(['Vai a Conferma e stampa'])},'#f4c95d'));var safe=document.createElement('strong');safe.textContent='Emissione ancora BLOCCATA';safe.style.cssText='color:#ffd3d3;padding:0 6px';bar.appendChild(safe)}
      if(location.hash.indexOf('/generazione/wizard4')>=0){if(documentEmitted()){sessionStorage.removeItem(ARM_KEY);var id=findTransactionId();startPdfFetch(id,false);var done=document.createElement('strong');done.textContent='DOCUMENTO EMESSO'+(id?' · DCO-'+id:'')+' · recupero PDF';done.style.cssText='color:#bff7d9;padding:0 6px';bar.appendChild(done);}else{var arm=readArm();if(REAL_TEST){if(arm){bar.appendChild(b('Disarma',function(){sessionStorage.removeItem(ARM_KEY);installSafetyGuard();state.textContent='Emissione nuovamente bloccata.'},'#d7ece8'));var ready=document.createElement('strong');ready.textContent='ARMATA · Conferma → Procedi';ready.style.cssText='color:#bff7d9;padding:0 6px';bar.appendChild(ready);var countdown=document.createElement('strong');countdown.style.cssText='color:#fff;padding:0 6px';bar.appendChild(countdown);(function tick(){var a=readArm();if(!a){countdown.textContent='Scaduta';return}var sec=Math.max(0,Math.ceil((a.expiresAt-Date.now())/1000));countdown.textContent='Tempo '+Math.floor(sec/60)+':'+String(sec%60).padStart(2,'0')+' · '+(a.stage||'armed');if(sec>0)setTimeout(tick,1000)})()}else{bar.appendChild(b('Arma emissione reale',showArmDialog,'#f4c95d'));var locked=document.createElement('strong');locked.textContent='Procedi e Conferma BLOCCATI';locked.style.cssText='color:#ffd3d3;padding:0 6px';bar.appendChild(locked)}}else{var finalMap=document.createElement('strong');finalMap.textContent='Schermata finale · abilita prima la prova reale';finalMap.style.cssText='color:#ffd3d3;padding:0 6px';bar.appendChild(finalMap)}}}
      var hide=document.createElement('button');hide.type='button';hide.textContent='Nascondi';hide.style.cssText='border:0;background:transparent;color:white;text-decoration:underline;padding:8px';hide.onclick=function(){bar.remove()};bar.appendChild(hide);document.documentElement.appendChild(bar);if(location.pathname.indexOf('/ser/documenticommercialionline/')>=0)installSafetyGuard();return{inserted:true,host:location.hostname,logged:!!document.querySelector('#user-info'),draftReady:!!DRAFT.ok,route:location.hash,documentEmitted:documentEmitted(),documentId:findTransactionId(),pdfState:window.__cassaiqDcoPdf?window.__cassaiqDcoPdf.state:''};
    }catch(e){return{inserted:false,error:String(e&&e.message||e)}}
  })()`;
  try{ref.executeScript({code},()=>{})}catch{}
}
function dcoCaptureStructure(ref,reason){
  if(!ref)return;
  const code=`(function(){
    function txt(v){return String(v||'').replace(/\\s+/g,' ').trim().slice(0,180)}
    function safeUrl(v){try{var u=new URL(v,location.href);return u.origin+u.pathname+(u.hash||'')}catch(e){return txt(v)}}
    function attr(el,name){try{return txt(el.getAttribute(name)||'')}catch(e){return ''}}
    function actionInfo(el){return{id:el.id||'',className:txt(el.className),role:attr(el,'role'),href:el.href?safeUrl(el.href):'',routerLink:attr(el,'routerlink')||attr(el,'ng-reflect-router-link'),ngClick:attr(el,'ng-click')||attr(el,'data-ng-click'),ngModel:attr(el,'ng-model')||attr(el,'data-ng-model'),ariaControls:attr(el,'aria-controls'),dataTarget:attr(el,'data-target')}}
    function info(el){return Object.assign({tag:(el.tagName||'').toLowerCase(),type:el.type||'',name:el.name||'',placeholder:el.placeholder||'',ariaLabel:attr(el,'aria-label'),autocomplete:attr(el,'autocomplete'),inputMode:attr(el,'inputmode'),maxLength:Number.isFinite(el.maxLength)&&el.maxLength>0?el.maxLength:null,readOnly:!!el.readOnly,required:!!el.required,disabled:!!el.disabled},actionInfo(el))}
    function scan(root,label,depth){
      var q=function(s){try{return Array.prototype.slice.call(root.querySelectorAll(s))}catch(e){return[]}};
      var inputs=q('input,textarea').slice(0,100).map(info);
      var selects=q('select').slice(0,50).map(function(el){return{tag:'select',id:el.id||'',name:el.name||'',ngModel:attr(el,'ng-model')||attr(el,'data-ng-model'),disabled:!!el.disabled,options:Array.prototype.slice.call(el.options||[]).slice(0,40).map(function(o){return{text:txt(o.textContent),value:String(o.value||'').slice(0,100)}})}});
      var buttons=q('button,input[type=submit],input[type=button],a[role=button]').slice(0,140).map(function(el){return Object.assign({tag:(el.tagName||'').toLowerCase(),name:el.name||'',text:txt(el.textContent||el.value),disabled:!!el.disabled},actionInfo(el))});
      var links=q('a[href]').slice(0,140).map(function(el){return Object.assign({text:txt(el.textContent)},actionInfo(el))});
      var controls=q('[role=button],[role=tab],[role=combobox],[aria-controls],[contenteditable=true],[ng-click],[data-ng-click]').slice(0,140).map(function(el){return Object.assign({tag:(el.tagName||'').toLowerCase(),text:txt(el.textContent),disabled:!!el.disabled},actionInfo(el))});
      var forms=q('form').slice(0,30).map(function(f){return{id:f.id||'',name:f.name||'',method:(f.method||'').toUpperCase(),action:safeUrl(f.action||'')}});
      var headings=q('h1,h2,h3,[role=heading]').slice(0,50).map(function(h){return txt(h.textContent)}).filter(Boolean);
      var labels=q('label,legend').slice(0,90).map(function(h){return txt(h.textContent)}).filter(Boolean);
      var frames=q('iframe,frame').slice(0,30).map(function(f){var item={tag:(f.tagName||'').toLowerCase(),id:f.id||'',name:f.name||'',src:safeUrl(f.src||'')};try{var d=f.contentDocument;if(d&&depth<2)item.document=scan(d,'frame',depth+1);else item.accessible=!!d}catch(e){item.accessible=false;item.error='cross-origin'}return item});
      var shadows=[];q('*').slice(0,2800).forEach(function(el){if(el.shadowRoot&&shadows.length<20)shadows.push({host:(el.tagName||'').toLowerCase()+'#'+(el.id||''),document:scan(el.shadowRoot,'shadow',depth+1)})});
      return{label:label,elementCount:q('*').length,forms:forms,inputs:inputs,selects:selects,buttons:buttons,links:links,interactiveControls:controls,headings:headings,labels:labels,frames:frames,shadowRoots:shadows};
    }
    var body=String(document.body&&document.body.innerText||'');
    var cassaiqArm=null;try{var raw=sessionStorage.getItem('cassaiq_dco_real_arm_v2');if(raw){var aa=JSON.parse(raw);cassaiqArm={active:Number(aa.expiresAt)>Date.now(),expiresInSeconds:Math.max(0,Math.ceil((Number(aa.expiresAt)-Date.now())/1000)),stage:String(aa.stage||''),lines:Number(aa.lines||0),total:String(aa.total||'')}}}catch(e){}
    var cassaiqPdf=null;try{var pp=window.__cassaiqDcoPdf;if(pp)cassaiqPdf={state:String(pp.state||''),documentId:String(pp.documentId||''),bytes:Number(pp.bytes||0),base64Length:String(pp.base64||'').length,error:String(pp.error||''),status:Number(pp.status||0),contentType:String(pp.contentType||''),responseUrl:String(pp.responseUrl||'')}}catch(e){}
    var documentEmitted=Array.prototype.slice.call(document.querySelectorAll('button,a,input[type=button],input[type=submit]')).some(function(el){return txt(el.textContent||el.value).toLowerCase().indexOf('scarica e stampa file')===0});
    var words=['Me stesso','Incaricato','per conto di','Fatture e corrispettivi','Documento commerciale','Utente non autorizzato','Scegli utenza','Utenza di lavoro','Verifica dati','Vai a Conferma e stampa','Ho capito','Conferma e stampa','Genera documento','Conferma','Stampa','Progressivo','Scarica','Totale documento'];
    var keywordMatches=words.filter(function(w){return body.toLowerCase().indexOf(w.toLowerCase())>=0});
    var meta=Array.prototype.slice.call(document.querySelectorAll('meta[http-equiv]')).map(function(m){return{httpEquiv:m.httpEquiv||'',content:txt(m.content)}});
    var scripts=Array.prototype.slice.call(document.scripts||[]).map(function(s){return s.src?safeUrl(s.src):'[inline]'}).slice(0,80);
    return{capturedAt:new Date().toISOString(),reason:'REASON_PLACEHOLDER',url:location.origin+location.pathname+location.hash,title:document.title||'',readyState:document.readyState,visibility:document.visibilityState,referrer:safeUrl(document.referrer||''),hasUserInfo:!!document.querySelector('#user-info'),hasErrorMessage:!!document.querySelector('#error-msg'),documentEmitted:documentEmitted,keywordMatches:keywordMatches,metaRefresh:meta,scripts:scripts,cassaiqArm:cassaiqArm,cassaiqPdf:cassaiqPdf,document:scan(document,'top',0)};
  })()`;
  const finalCode=code.replace('REASON_PLACEHOLDER',String(reason||'capture').replace(/\\/g,'\\\\').replace(/'/g,"\\'"));
  try{ref.executeScript({code:finalCode},results=>{
    const data=Array.isArray(results)?results[0]:results;
    if(!data||typeof data!=='object')return;
    dcoRememberRoute(data.url,`diagnostic:${reason||'capture'}`);
    dcoRenderDiagnostic(data);
    if(data.documentEmitted||data.cassaiqPdf)dcoMaybePullOfficialPdf(ref,data.cassaiqPdf);
    const url=String(data.url||'');
    if(url.includes('#/generazione/wizard4')){if(data.cassaiqPdf?.state==='error'){dcoSetResult('error',`Documento emesso; recupero PDF non riuscito: ${data.cassaiqPdf.error||'errore sconosciuto'}. L’emissione resta valida; il PDF ufficiale non è stato archiviato.`);renderDcoDocumentStatus(`Documento emesso, ma PDF da recuperare: ${data.cassaiqPdf.error||'errore sconosciuto'}`,'error')}else if(data.documentEmitted)dcoSetResult('loading','Documento emesso. Recupero del PDF ufficiale e registrazione in CassaIQ…');else dcoSetResult(dcoRealTestEnabled?'warning':'ok',dcoRealTestEnabled?'Schermata Conferma e stampa raggiunta. Arma la vendita e usa i comandi ufficiali Conferma e Procedi.':'Schermata finale raggiunta, ma l’emissione è bloccata.');}
    else if(url.includes('#/generazione/wizard3'))dcoSetResult('ok','Verifica dati raggiunta. Premi “Mappa conferma”; se compare l’informativa usa “Continua mappatura”.');
    else if(url.includes('#/generazione/wizard2'))dcoSetResult('ok','Schermata di compilazione pronta. Premi “Compila carrello”, controlla ogni campo e poi usa il pulsante ufficiale “Vai a Verifica dati”.');
    else if(url.includes('#/generazione/'))dcoSetResult('ok','Schermata conclusiva raggiunta. I comandi fiscali restano bloccati finché non abiliti e armi esplicitamente la prova reale.');
    else if(data.hasUserInfo&&url.includes('/ser/documenticommercialionline/'))dcoSetResult('ok','DCO autorizzato e sessione valida. Premi “Genera” nella barra CassaIQ.');
    else if(data.hasUserInfo)dcoSetResult('ok','Sessione Agenzia rilevata. Completa l’utenza di lavoro e apri il DCO nella stessa finestra.');
  })}catch(e){dcoSetResult('error',`Diagnostica non disponibile: ${e.message||e}`)}
}
function dcoScheduleDeepCapture(ref){
  dcoClearCaptureTimers();
  // Diagnostica su cambio pagina: due acquisizioni finite, non un ciclo continuo.
  [300,1800].forEach((ms,index)=>dcoCaptureTimers.push(setTimeout(()=>{
    if(dcoBrowserRef===ref&&!dcoAutoSale&&!dcoConnectionPending){
      if(index===0)dcoInjectLabBar(ref);
      dcoCaptureStructure(ref,`page-${index+1}`);
    }
  },ms)));
}

async function dcoConnectionOfficialAction(ref,kind){
  const wanted=JSON.stringify(String(kind||'')),profile=dcoBusinessProfile(),targetVat=JSON.stringify(String(profile.vat||'')),targetName=JSON.stringify(String(profile.legalName||profile.tradeName||'').toLowerCase());
  const code=`(function(){
    try{
      var KIND=${wanted},TARGET_VAT=${targetVat},TARGET_NAME=${targetName};
      function clean(v){return String(v==null?'':v).replace(/\s+/g,' ').trim().toLowerCase()}
      function visible(el){if(!el||el.disabled)return false;try{var st=getComputedStyle(el),r=el.getBoundingClientRect();return st.display!=='none'&&st.visibility!=='hidden'&&r.width>0&&r.height>0}catch(e){return true}}
      function injected(el){try{return !!(el&&el.closest&&el.closest('#cassaiq-dco-labbar,#cassaiq-dco-arm-overlay,#cassaiq-dco-safety'))}catch(e){return false}}
      function text(el){return clean(el&&((el.textContent||el.value)||''))}
      function href(el){try{return String(el.href||el.getAttribute&&el.getAttribute('href')||'')}catch(e){return''}}
      function actions(){return Array.prototype.slice.call(document.querySelectorAll('a,button,input[type=button],input[type=submit],[role=button],[ng-click],[data-ng-click]')).filter(function(el){return !injected(el)})}
      function officialDcoLink(){
        var anchors=Array.prototype.slice.call(document.querySelectorAll('a[href]')).filter(function(el){return !injected(el)});
        return anchors.find(function(el){var h=href(el).toLowerCase(),t=text(el);return h.indexOf('/ser/documenticommercialionline/')>=0&&t.indexOf('documento commerciale')>=0})
          ||anchors.find(function(el){return href(el).toLowerCase().indexOf('/ser/documenticommercialionline/')>=0});
      }
      function clickSoon(el,label){
        if(!el)return{ok:false,action:'',reason:'not-found'};
        var target=href(el),before=String(location.href||'');
        try{el.scrollIntoView({block:'center',inline:'center'})}catch(e){}
        setTimeout(function(){
          try{
            if(el.dispatchEvent)el.dispatchEvent(new MouseEvent('click',{view:window,bubbles:true,cancelable:true}));
            if(typeof el.click==='function')el.click();
          }catch(e){}
          if(target&&target.toLowerCase().indexOf('/ser/documenticommercialionline/')>=0){
            setTimeout(function(){try{if(String(location.href||'')===before)location.assign(target)}catch(e){}},700);
          }
        },220);
        return{ok:true,action:label||text(el),href:target,official:target.toLowerCase().indexOf('/ser/documenticommercialionline/')>=0};
      }
      var list=actions(),body=clean(document.body&&document.body.innerText||'');
      if(KIND==='portal'||KIND==='home'){
        var direct=officialDcoLink();
        if(direct)return clickSoon(direct,'documento-commerciale-online');
        var service=list.find(function(el){var t=text(el),h=href(el).toLowerCase();return visible(el)&&t.indexOf('documento commerciale')>=0&&(h.indexOf('documenticommercialionline')>=0||h.indexOf('/instr/instradamentofcweb/wizard')>=0)})
          ||list.find(function(el){var h=href(el).toLowerCase();return visible(el)&&h.indexOf('/ser/documenticommercialionline/')>=0});
        return clickSoon(service,'documento-commerciale-online');
      }
      if(KIND==='wizard'){
        function matchesBusiness(v){var t=clean(v);if(TARGET_VAT&&t.indexOf(clean(TARGET_VAT))>=0)return true;if(TARGET_NAME&&TARGET_NAME.length>=5&&t.indexOf(clean(TARGET_NAME))>=0)return true;return false}
        var businessAction=list.find(function(el){return visible(el)&&matchesBusiness(text(el))});
        if(businessAction)return clickSoon(businessAction,'utenza-attivita');
        var self=list.find(function(el){var t=text(el);return visible(el)&&(t==='me stesso'||t==='per me stesso'||t.indexOf('opera per me stesso')>=0||t.indexOf('me medesimo')>=0)});
        var radios=Array.prototype.slice.call(document.querySelectorAll('input[type=radio]')).filter(function(el){return !el.disabled&&visible(el)&&!injected(el)});
        var chosen=null;
        radios.forEach(function(r){if(chosen)return;var id=r.id||'',lab=id?Array.prototype.slice.call(document.querySelectorAll('label')).find(function(x){return x.htmlFor===id}):null,t=clean((lab&&lab.textContent)||r.parentElement&&r.parentElement.textContent||'');if(matchesBusiness(t))chosen=r});
        if(!chosen)radios.forEach(function(r){if(chosen)return;var id=r.id||'',lab=id?Array.prototype.slice.call(document.querySelectorAll('label')).find(function(x){return x.htmlFor===id}):null,t=clean((lab&&lab.textContent)||r.parentElement&&r.parentElement.textContent||'');if(t.indexOf('me stesso')>=0||t.indexOf('persona fisica')>=0)chosen=r});
        if(!chosen&&radios.length===1)chosen=radios[0];
        if(chosen){chosen.checked=true;['input','change'].forEach(function(n){try{chosen.dispatchEvent(new Event(n,{bubbles:true}))}catch(e){}});var next=list.find(function(el){var t=text(el);return visible(el)&&(t==='continua'||t==='avanti'||t==='prosegui'||t==='conferma'||t==='seleziona'||t==='accedi')});if(next)return clickSoon(next,'profilo-selezionato');return{ok:true,action:'profilo-selezionato',href:''}}
        if(self)return clickSoon(self,'me-stesso');
        var selects=Array.prototype.slice.call(document.querySelectorAll('select')).filter(function(el){return !el.disabled&&visible(el)&&!injected(el)});
        if(selects.length===1){var sel=selects[0],valid=Array.prototype.slice.call(sel.options||[]).filter(function(o){return !o.disabled&&String(o.value||'').trim()&&clean(o.textContent).indexOf('seleziona')!==0}),matched=valid.find(function(o){return matchesBusiness(o.textContent||'')});if(matched||valid.length===1){var target=matched||valid[0];sel.value=target.value;['input','change'].forEach(function(n){try{sel.dispatchEvent(new Event(n,{bubbles:true}))}catch(e){}});var go=list.find(function(el){var t=text(el);return visible(el)&&(t==='continua'||t==='avanti'||t==='prosegui'||t==='conferma'||t==='seleziona')});if(go)return clickSoon(go,matched?'utenza-attivita':'utenza-unica');return{ok:true,action:matched?'utenza-attivita':'utenza-selezionata',href:''}}}
        return{ok:false,action:'',reason:body.indexOf('utenza')>=0?'choice-not-recognized':'waiting'};
      }
      return{ok:false,action:'',reason:'unknown-kind'};
    }catch(e){return{ok:false,action:'',reason:String(e&&e.message||e)}}
  })()`;
  return dcoExecScript(ref,code,7000);
}

async function dcoConnectionTick(ref,currentUrl=''){
  if(!dcoConnectionPending||dcoConnectionTickBusy||dcoBrowserRef!==ref)return;
  const attempt=dcoConnectionAttempt;
  dcoConnectionTickBusy=true;
  try{
    const info=await dcoExecScript(ref,"(function(){var clean=function(v){return String(v==null?'':v).replace(/\\s+/g,' ').trim().toLowerCase()};var visible=function(el){if(!el||el.disabled)return false;try{var st=getComputedStyle(el),r=el.getBoundingClientRect();return st.display!=='none'&&st.visibility!=='hidden'&&r.width>0&&r.height>0}catch(e){return true}};var els=Array.prototype.slice.call(document.querySelectorAll('a,button,input[type=button],input[type=submit],[role=button]'));var labels=els.map(function(el){return clean(el.textContent||el.value||'')});var body=clean(document.body&&document.body.innerText||'');var hasSpid=els.some(function(el){var t=clean(el.textContent||el.value||'');return visible(el)&&(t.indexOf('entra con spid')>=0||el.id==='spid-btn')});var portalAuth=body.indexOf('fatture e corrispettivi')>=0&&(body.indexOf('stai operando su')>=0||body.indexOf('utente connesso')>=0||body.indexOf('partita iva')>=0||body.indexOf('profilo corrispettivi')>=0||body.indexOf('per conto di')>=0)&&!hasSpid;var profileMarker=body.indexOf('utente connesso')>=0||body.indexOf('per conto di')>=0||body.indexOf('stai operando su')>=0||(body.indexOf('partita iva')>=0&&body.indexOf('profilo corrispettivi')>=0);var agencyAuth=portalAuth||!!document.querySelector('#user-info')||(profileMarker&&!hasSpid&&body.indexOf('accedi all\\'area riservata')<0);var dcoLink=Array.prototype.slice.call(document.querySelectorAll('a[href]')).find(function(el){var h=String(el.href||'').toLowerCase(),t=clean(el.textContent||'');return h.indexOf('/ser/documenticommercialionline/')>=0&&t.indexOf('documento commerciale')>=0})||Array.prototype.slice.call(document.querySelectorAll('a[href]')).find(function(el){return String(el.href||'').toLowerCase().indexOf('/ser/documenticommercialionline/')>=0});return{url:location.href,host:location.hostname,path:location.pathname,hash:location.hash,readyState:document.readyState,logged:!!document.querySelector('#user-info'),hasGeneration:labels.some(function(x){return x==='generazione'||x.indexOf('genera il tuo documento')>=0}),hasVisualization:labels.some(function(x){return x==='visualizzazione'||x.indexOf('visualizzazione')===0}),hasDcoTitle:body.indexOf('documento commerciale')>=0,hasOfficialDcoLink:!!dcoLink,officialDcoHref:dcoLink?String(dcoLink.href||''):'',portalAuthenticated:portalAuth,agencyAuthenticated:agencyAuth,loginPage:hasSpid||body.indexOf('accedi all\\'area riservata agenzia delle entrate')>=0,hasSpidButton:hasSpid,body:body.slice(0,4000)}})()",8000);
    if(attempt!==dcoConnectionAttempt||!dcoConnectionPending||dcoBrowserRef!==ref)return;
    const url=String(info?.url||currentUrl||''),lower=url.toLowerCase(),now=Date.now();
    const route=(target,phase,message)=>{
      if(dcoConnectionPhase===phase&&now-dcoConnectionLastRouteAt<4000)return true;
      if(dcoConnectionRouteAttempts>=10)throw new Error('Il portale non ha completato il passaggio automatico al Documento Commerciale Online.');
      dcoConnectionPhase=phase;dcoConnectionRouteAttempts+=1;dcoConnectionLastRouteAt=now;
      dcoSetResult('loading',message);renderDcoConnectionStatus(message,'loading');
      if(!dcoNavigate(ref,target))throw new Error('Impossibile proseguire automaticamente nel portale dell’Agenzia delle Entrate.');
      return true;
    };
    const act=async(kind,phase,message)=>{
      if(dcoConnectionPhase===phase&&now-dcoConnectionLastRouteAt<2500)return{ok:true,action:'cooldown'};
      if(dcoConnectionRouteAttempts>=10)throw new Error('Il portale non ha completato il passaggio automatico al Documento Commerciale Online.');
      const out=await dcoConnectionOfficialAction(ref,kind);
      if(out?.ok){dcoConnectionPhase=phase;dcoConnectionRouteAttempts+=1;dcoConnectionLastRouteAt=Date.now();dcoSetResult('loading',message);renderDcoConnectionStatus(message,'loading')}
      return out||{ok:false};
    };
    const dcoHome=lower.includes('/ser/documenticommercialionline/')&&lower.includes('#/home');
    const serviceReady=dcoHome&&info?.logged&&info?.readyState==='complete'&&info?.hasGeneration&&info?.hasVisualization&&info?.hasDcoTitle;
    if(serviceReady){
      if(!dcoConnectionLastReadyAt||now-dcoConnectionLastReadyAt>3500)dcoConnectionReadyChecks=0;
      dcoConnectionReadyChecks+=1;dcoConnectionLastReadyAt=now;
      if(dcoConnectionReadyChecks<2){dcoSetResult('loading','Sessione DCO trovata. Verifica finale del portale in corso…');renderDcoConnectionStatus('Verifica finale della sessione DCO…','loading');return}
      dcoConnectionPending=false;dcoConnectionPhase='connected';dcoConnectionReadyChecks=0;const resumeSale=dcoResumeSaleAfterConnect,returnEmergency=emergencyReconnectOnly;dcoResumeSaleAfterConnect=false;emergencyReconnectOnly=false;dcoMarkConnected();
      if(!dcoPdfRetryBusy){try{ref.hide?.()}catch{}}
      showView(returnEmergency&&!resumeSale?'emergenze':'cassa');
      if(resumeSale){
        dcoTimingMark(dcoPendingEmissionTiming,'session-ready','Sessione DCO pronta');
        dcoSetResult('ok','Sessione DCO ripristinata automaticamente. Ripresa della vendita…');renderDcoConnectionStatus('Fisconline ha ripristinato automaticamente la sessione DCO. Ripresa emissione…','ok');
        setTimeout(()=>dcoStartAutomaticSale(),300);return
      }
      if(returnEmergency){dcoSetResult('ok','DCO collegato e verificato.');renderDcoConnectionStatus('DCO collegato e verificato. Le operazioni di emergenza possono essere regolarizzate manualmente.','ok');emergencyRenderConnectivity('Documento Commerciale Online disponibile e sessione valida.');toast('DCO disponibile per la regolarizzazione',4000);return}
      dcoSetResult('ok','DCO collegato e verificato. Ora prepara il carrello e usa Paga → Contanti/Carta → Emetti e stampa.');renderDcoConnectionStatus('DCO collegato e verificato. Sei tornato alla cassa: le prossime vendite useranno DCO + stampante di rete.','ok');toast(dcoConnectionMethod==='fisconline'?'Fisconline collegato e verificato':'DCO collegato e verificato',4500);return;
    }

    const loginPage=info?.loginPage||lower.includes('iampe.agenziaentrate.gov.it/sam/ui/login')||lower.includes('login.id.');
    if(loginPage){
      dcoConnectionPhase='login';dcoConnectionAuthenticatedAt=0;dcoConnectionPortalReadyChecks=0;dcoConnectionWizardStartedAt=0;dcoConnectionReadyChecks=0;dcoConnectionLastReadyAt=0;
      if(dcoConnectionMethod==='fisconline'){
        if(!dcoConnectionCredentials){
          dcoConnectionPending=false;renderDcoConnectionStatus('Credenziali Fisconline non disponibili su questo dispositivo.','error');showView('dcolab');return;
        }
        const loginOut=await dcoFisconlineLoginAction(ref,dcoConnectionCredentials);
        if(loginOut?.error==='PASSWORD_EXPIRED'){
          const resume=dcoResumeSaleAfterConnect,returnEmergency=emergencyReconnectOnly;dcoResumeSaleAfterConnect=false;emergencyReconnectOnly=false;dcoConnectionPending=false;dcoConnectionCredentials=null;isIssuing=false;renderCart();if(resume)emergencyHandleReconnectFailure('Password Fisconline scaduta: ricollegamento necessario.');if(returnEmergency&&!resume)showView('emergenze');try{ref.hide?.()}catch{};
          const detail='La password Fisconline è scaduta. Per sicurezza il rinnovo va eseguito sul sito ufficiale dell’Agenzia delle Entrate. CassaIQ non effettuerà altri tentativi automatici.';
          renderDcoFisconlineStatus(detail,'error');renderDcoConnectionStatus('Password Fisconline scaduta: rinnovala sul sito Agenzia Entrate e poi inserisci qui soltanto la nuova password.','error');if(resume)dcoQuickFinishProgress('Password Fisconline scaduta. Rinnovala sul sito ufficiale AdE e poi aggiorna la password in CassaIQ.','error');showView('dcolab');dcoShowCredentialIssue('PASSWORD_EXPIRED',detail);return
        }
        if(loginOut?.error==='CREDENTIALS_REJECTED'||loginOut?.error==='ACCOUNT_DISABLED'||loginOut?.error==='LOGIN_NOT_COMPLETED'){
          const resume=dcoResumeSaleAfterConnect,returnEmergency=emergencyReconnectOnly;dcoResumeSaleAfterConnect=false;emergencyReconnectOnly=false;dcoConnectionPending=false;dcoConnectionCredentials=null;isIssuing=false;renderCart();if(resume)emergencyHandleReconnectFailure('Ricollegamento Fisconline non completato.');if(returnEmergency&&!resume)showView('emergenze');try{ref.hide?.()}catch{};
          const disabled=loginOut?.error==='ACCOUNT_DISABLED',notCompleted=loginOut?.error==='LOGIN_NOT_COMPLETED';
          const detail=disabled?'Utenza Fisconline temporaneamente disabilitata. CassaIQ non effettuerà altri tentativi automatici.':notCompleted?'Il portale non ha completato il login. CassaIQ non ha ripetuto le credenziali per evitare tentativi multipli.':'Credenziali rifiutate dall’Agenzia delle Entrate. Verifica codice fiscale/nome utente, password e PIN prima di riprovare.';
          renderDcoFisconlineStatus(detail,'error');renderDcoConnectionStatus(detail,'error');if(resume)dcoQuickFinishProgress(detail,'error');showView('dcolab');if(!notCompleted)dcoShowCredentialIssue(disabled?'ACCOUNT_DISABLED':'CREDENTIALS_REJECTED',detail);return
        }
        dcoSetResult('loading',loginOut?.action==='iam-credentials-tab-opened'?'Apertura della scheda Fisconline/Entratel…':loginOut?.action==='iam-login-awaiting-result'?'Credenziali inviate una sola volta. Attendo la risposta dell’Agenzia delle Entrate…':loginOut?.ok?'Accesso Fisconline automatico in corso…':'Attendo il modulo ufficiale Fisconline/Entratel…');
        renderDcoConnectionStatus(loginOut?.ok?'Autenticazione Fisconline automatica in corso…':'Caricamento accesso Fisconline…','loading');
        return;
      }
      dcoSetResult('loading','Completa soltanto l’accesso SPID. CassaIQ attenderà la conferma reale del profilo prima di aprire il DCO.');
      renderDcoConnectionStatus('Completa SPID nella finestra ufficiale. Dopo l’accesso non dovrai premere altro.','loading');
      return;
    }
    if(lower.includes('sp.agenziaentrate.gov.it')||lower.includes('/saml/')||lower.includes('/oauth2/')||lower.includes('/callback')){
      dcoSetResult('loading','Autenticazione SPID in corso…');renderDcoConnectionStatus('Attendi il completamento dello SPID.','loading');return;
    }

    // Percorso Fisconline dedicato:
    // 1) IAM Login diretto (gestito sopra)
    // 2) InstradamentofcWeb/wizard per scegliere l'utenza di lavoro
    // 3) Documento Commerciale Online
    // Quando IAM ha concluso con successo e siamo rientrati su un host AdE autenticato,
    // non passiamo dalla pagina di scelta SPID: apriamo esplicitamente il wizard.
    if(dcoConnectionMethod==='fisconline'
      && !lower.includes('iampe.agenziaentrate.gov.it')
      && !lower.includes('/instr/instradamentofcweb/wizard')
      && !lower.includes('/instr/instradamentofcweb/home')
      && !lower.includes('/ser/documenticommercialionline/')
      && (lower.includes('ivaservizi.agenziaentrate.gov.it')||lower.includes('portale.agenziaentrate.gov.it'))){
      if(!dcoConnectionAuthenticatedAt)dcoConnectionAuthenticatedAt=now;
      // Andiamo al wizard UNA sola volta: il portale poi instrada da solo verso
      // InstradamentofcWeb/home. Senza questo guard, portale<->wizard rimbalza.
      if(dcoWizardEntered&&now-dcoWizardEntered<8000){dcoSetResult('loading','Instradamento al portale Fatture e Corrispettivi in corso…');return;}
      dcoWizardEntered=now;
      dcoResetFisconlineLoginState();
      route(DCO_URLS.entry,'fisconline-work-user','Accesso Fisconline completato. Selezione automatica dell’utenza di lavoro…');
      return;
    }
    if(lower.includes('/ser/documenticommercialionline/nonauth.html')){
      dcoConnectionReadyChecks=0;dcoConnectionLastReadyAt=0;
      if(dcoConnectionAuthenticatedAt&&dcoConnectionPhase!=='nonauth-wait'){
        dcoConnectionPhase='nonauth-wait';
        dcoConnectionLastRouteAt=now;
        dcoSetResult('loading','Il portale ha autenticato Fisconline ma sta ancora associando l’utenza DCO. Attendo 5 secondi senza ripetere il login…');
        renderDcoConnectionStatus('Associazione utenza DCO in corso… attendo il portale senza ripetere le credenziali.','loading');
        const localAttempt=dcoConnectionAttempt;
        setTimeout(()=>{
          if(localAttempt!==dcoConnectionAttempt||!dcoConnectionPending||dcoBrowserRef!==ref)return;
          dcoNavigate(ref,DCO_URLS.entry);
          dcoConnectionPhase='nonauth-retry';
          dcoConnectionLastRouteAt=Date.now();
        },5000);
        return
      }
      dcoSetResult('loading','Il profilo DCO non è ancora pronto. CassaIQ attende senza ripetere l’accesso.');return;
    }
    if(lower.includes('/ser/documenticommercialionline/')){
      dcoConnectionReadyChecks=0;dcoConnectionLastReadyAt=0;
      dcoSetResult('loading','Il portale DCO è aperto. Verifica automatica della sessione in corso…');return;
    }
    dcoConnectionReadyChecks=0;dcoConnectionLastReadyAt=0;

    if(info?.portalAuthenticated&&info?.readyState==='complete'&&lower.includes('portale.agenziaentrate.gov.it/portaleweb/home')){
      if(!dcoConnectionAuthenticatedAt)dcoConnectionAuthenticatedAt=now;
      dcoConnectionPortalReadyChecks+=1;
      dcoSetResult('loading','SPID completato. Il portale sta aprendo automaticamente Fatture e corrispettivi…');
      renderDcoConnectionStatus('Profilo fiscale verificato. Attendo la pagina dei servizi…','loading');
      return;
    }
    if(lower.includes('portale.agenziaentrate.gov.it/portaleweb/home')){
      dcoConnectionPortalReadyChecks=0;
      dcoSetResult('loading','SPID completato. Attendo che nome, profilo fiscale e Partita IVA siano realmente caricati…');
      renderDcoConnectionStatus('Accesso completato. Verifica del profilo fiscale in corso…','loading');
      return;
    }

    if(lower.includes('/instr/instradamentofcweb/wizard')){
      if((dcoConnectionMethod==='fisconline'||info?.agencyAuthenticated)&&!dcoConnectionAuthenticatedAt)dcoConnectionAuthenticatedAt=now;
      if(dcoConnectionMethod==='fisconline')dcoResetFisconlineLoginState();
      if(!dcoConnectionAuthenticatedAt){dcoSetResult('loading','Il portale sta preparando l’accesso. CassaIQ non aprirà il DCO finché il profilo non sarà confermato.');return}
      if(!dcoConnectionWizardStartedAt)dcoConnectionWizardStartedAt=now;
      if(dcoConnectionMethod==='fisconline'&&now-dcoConnectionWizardStartedAt>15000&&!dcoFisconlineWorkUserSelectionAttempted){throw new Error('Utenza di lavoro non riconosciuta automaticamente. Controlla i dati attività e riprova.')}
      if(dcoConnectionMethod!=='fisconline'&&now-dcoConnectionWizardStartedAt>12000){route(DCO_URLS.loggedHome,'wizard-home-fallback','Verifica automatica dell’utenza di lavoro…');return}
      const out=await act('wizard','wizard-choice','Selezione automatica dell’utenza di lavoro…');
      if(out?.ok){if(dcoConnectionMethod==='fisconline')dcoFisconlineWorkUserSelectionAttempted=true;return}
      dcoSetResult('loading','Profilo fiscale riconosciuto. Attendo la conferma automatica dell’utenza di lavoro…');
      renderDcoConnectionStatus('Preparazione utenza di lavoro…','loading');
      return;
    }
    if(lower.includes('/instr/instradamentofcweb/home')){
      if((dcoConnectionMethod==='fisconline'||info?.agencyAuthenticated)&&!dcoConnectionAuthenticatedAt)dcoConnectionAuthenticatedAt=now;
      if(!dcoConnectionAuthenticatedAt){dcoSetResult('loading','Attendo la conferma del profilo fiscale prima di aprire il DCO…');return}
      if(dcoConnectionMethod==='fisconline'&&!dcoFisconlineWorkUserConfirmed){
        const hasWorkingUser=String(info?.body||'').includes('per conto di');
        // Se siamo gia' sulla home autenticata con il link DCO presente, l'utenza
        // e' di fatto attiva: confermiamo senza tornare al wizard (evita il rimbalzo).
        if(hasWorkingUser||info?.hasOfficialDcoLink||dcoFisconlineWorkUserSelectionAttempted){dcoFisconlineWorkUserConfirmed=true;dcoConnectionPhase='fisconline-work-user-confirmed'}
        else{route(DCO_URLS.entry,'fisconline-work-user-required','Accesso riuscito. Selezione dell’utenza di lavoro prima del DCO…');return}
      }
      if(!info?.hasOfficialDcoLink){
        dcoSetResult('loading','Profilo fiscale verificato. Attendo il caricamento del comando ufficiale “Documento Commerciale on line”…');
        renderDcoConnectionStatus('Pagina servizi caricata. Ricerca del comando DCO ufficiale…','loading');
        return;
      }
      // Link DCO presente nella home autenticata: lo apriamo SUBITO.
      // Prima proviamo il click sul comando ufficiale; se non naviga, andiamo
      // direttamente all'href (fallback immediato, senza attesa di 2,5s che nel
      // rimbalzo wizard/home non maturava mai). Un flag evita tentativi doppi.
      // Siamo sulla home autenticata con il link DCO presente.
      // Navighiamo DIRETTAMENTE all'href ufficiale del DCO. Niente flag che
      // durante il rimbalzo wizard/home puo' restare incastrato: usiamo un
      // guard basato sull'URL di destinazione (se ci siamo gia' andati da poco,
      // non ripetiamo). Il click sul comando resta come primo tentativo.
      const dcoHref=info?.officialDcoHref||DCO_URLS.service;
      if(dcoLastServiceNav&&dcoLastServiceNavHref===dcoHref&&now-dcoLastServiceNav<6000){
        dcoSetResult('loading','Apertura del Documento Commerciale on line in corso…');return;
      }
      dcoLastServiceNav=now;dcoLastServiceNavHref=dcoHref;
      const out=await act('home','home-dco-official-link','Apertura del comando ufficiale “Documento Commerciale on line”…');
      if(out?.ok)return;
      route(dcoHref,'home-official-href-fallback','Apertura del collegamento ufficiale Documento Commerciale on line…');
      return;
    }
    if(lower.includes('portale.agenziaentrate.gov.it')){
      dcoSetResult('loading','Accesso SPID completato. Attendo il caricamento del profilo fiscale…');
      renderDcoConnectionStatus('Accesso completato. CassaIQ sta verificando il profilo fiscale…','loading');
      return;
    }
    dcoSetResult('loading','Attendo il completamento del percorso ufficiale dell’Agenzia delle Entrate…');
  }catch(e){
    if(attempt!==dcoConnectionAttempt||dcoBrowserRef!==ref)return;
    const msg=String(e?.message||e||'');
    if(msg.includes('Risposta del browser DCO scaduta')){dcoSetResult('loading','Il portale sta cambiando pagina. Attendo senza ripetere il collegamento…');renderDcoConnectionStatus('Caricamento del portale in corso…','loading');return}
    const resume=dcoResumeSaleAfterConnect,returnEmergency=emergencyReconnectOnly;dcoResumeSaleAfterConnect=false;emergencyReconnectOnly=false;dcoConnectionPending=false;dcoConnectionCredentials=null;dcoConnectionReadyChecks=0;dcoConnectionLastReadyAt=0;dcoClearConnected();if(resume){isIssuing=false;renderCart();emergencyHandleReconnectFailure(`Collegamento DCO non completato: ${msg}`);dcoQuickFinishProgress(`Collegamento DCO non completato: ${msg}`,'error')}if(returnEmergency&&!resume)showView('emergenze');renderDcoConnectionStatus(`Collegamento DCO non completato: ${msg}`,'error');
  }finally{
    if(attempt===dcoConnectionAttempt)dcoConnectionTickBusy=false;
  }
}
function dcoMarkPdfPending(documentId,message='Recupero PDF non riuscito.'){
  const id=String(documentId||dcoAutoSale?.documentId||'').replace(/[^0-9]/g,''),state=dcoAutoSale;
  localStorage.removeItem(K.dcoAutoLock);localStorage.removeItem(K.dcoPendingSale);
  dcoStopAutoTimer();dcoClearBrowserLoadGuard();dcoBrowserLoading=false;dcoClearAutomationWaiters('Documento emesso; PDF in attesa.');dcoResetOperationContext(dcoBrowserRef,'',false).catch(()=>{});dcoAutoSale=null;dcoAutoTickBusy=false;isIssuing=false;
  if(!dcoPdfRetryBusy)dcoShowEmissionOverlay(dcoBrowserRef,`Documento ${id?`DCO-${id} `:''}emesso. Recupero PDF non riuscito. Torna a CassaIQ. L’emissione resta valida anche se il PDF ufficiale non è stato archiviato.`,'error');
  dcoStopLivePoll();
  if(id&&(dcoEmergencyActiveId||localStorage.getItem(K.emergencyActive)))emergencyMarkRegularized(dcoEmergencyActiveId||localStorage.getItem(K.emergencyActive),{documentId:id,documentNumber:`DCO-${id}`,receiptNumber:`DCO-${id}`});
  renderCart();renderDcoConnectionStatus();renderDcoDocumentStatus(`Documento ${id?`DCO-${id} `:''}emesso. Recupero PDF non riuscito: ${message}`,'error');
  dcoQuickFinishProgress(`Documento ${id?`DCO-${id} `:''}emesso. Recupero PDF non riuscito. NON ripetere la vendita. Il PDF ufficiale non è stato archiviato; il documento commerciale resta ristampabile.`,'warning');
}
async function dcoProbeEmissionAfterLoadError(ref,event){
  const state=dcoAutoSale;if(!state||dcoBrowserRef!==ref)return;
  // Il loaderror su wizard4 e' spesso benigno. Prima di Procedi non usiamo mai
  // dati Angular come prova di emissione: lasciamo riprendere il runner.
  if(!state.proceedClicked){
    dcoQuickSetStatus('Il portale ha interrotto un caricamento intermedio. Riprendo la verifica della pagina corrente…');
    setTimeout(()=>{if(dcoAutoSale===state&&dcoBrowserRef===ref)dcoAutoTick(ref)},500);return
  }
  dcoQuickSetStatus('Verifica dell’esito fiscale del nuovo documento…');
  await new Promise(resolve=>setTimeout(resolve,450));
  if(!dcoAutoSale||dcoBrowserRef!==ref)return;
  try{
    const evidence=await dcoExecScript(ref,dcoEmissionEvidenceScript(),6000),id=dcoAcceptAutoDocumentId(state,evidence?.documentId,`loaderror-${evidence?.source||'evidence'}`);
    if(id){
      state.documentId=id;state.stage='emitted';state.lastProgress=Date.now();dcoQuickSetStatus(`Documento DCO-${id} emesso. Recupero numero ufficiale e stampa immediata…`);
      await dcoFinalizeEmittedSale({documentId:id});return
    }
    dcoQuickSetStatus('Il portale ha interrotto il caricamento. Continuo a verificare l’esito senza ripetere Procedi…');setTimeout(()=>{if(dcoAutoSale===state&&dcoBrowserRef===ref)dcoAutoTick(ref)},900)
  }catch(e){
    dcoQuickSetStatus('Il portale non ha ancora restituito l’esito. Continuo a verificare senza ripetere l’emissione…');setTimeout(()=>{if(dcoAutoSale===state&&dcoBrowserRef===ref)dcoAutoTick(ref)},1000)
  }
}

function dcoAttachBrowserListeners(ref){
  ref.addEventListener('message',event=>{if(dcoBrowserRef!==ref)return;dcoHandleBrowserMessage(event)});
  ref.addEventListener('loadstart',event=>{
    if(dcoBrowserRef!==ref)return;
    dcoClearBrowserLoadGuard();dcoBrowserLoading=true;
    const printId=dcoExtractDocumentId(event?.url||'');
    if(printId){
      // Le navigazioni PDF/stampa non garantiscono un loadstop su tutte le WebView.
      // Non lasciamo quindi dcoBrowserLoading bloccato e validiamo sempre l'ID
      // rispetto all'operazione corrente prima di finalizzare.
      dcoClearBrowserLoadGuard();dcoBrowserLoading=false;
      if(dcoAutoSale){
        const accepted=dcoAcceptAutoDocumentId(dcoAutoSale,printId,'loadstart-print-url');
        if(accepted){dcoAutoSale.documentId=accepted;dcoAutoSale.stage='emitted';dcoAutoSale.lastProgress=Date.now();dcoQuickSetStatus(`Documento DCO-${accepted} emesso. Recupero numero ufficiale e stampa immediata…`);dcoFinalizeEmittedSale({documentId:accepted}).catch(error=>dcoAbortQuickSale(`Documento emesso, ma stampa immediata non completata: ${error.message||error}`,false));return}
        dcoScheduleAutoTick(ref,160);return
      }
      if(dcoVoidLab){const accepted=dcoVoidAcceptDocumentId(dcoVoidLab,printId,'loadstart-print-url');if(accepted){dcoVoidLab.documentId=accepted;dcoVoidLab.stage='emitted';dcoVoidLab.lastProgress=Date.now();dcoFinalizeVoid({documentId:accepted}).catch(error=>dcoVoidAbort(`Documento di annullo rilevato, ma finalizzazione non completata: ${error.message||error}`,true,{keepBrowser:true}));return}dcoScheduleVoidLabTick(ref,160);return}
      dcoDownloadOfficialPdfNatively(ref,printId,event?.url||'').catch(error=>dcoLogPdfMeta(`fallback nativo fallito DCO-${printId}`,{error:String(error?.message||error)}));
      return;
    }
    if(dcoAutoSale)dcoAutoSale.lastNavigationAt=Date.now();
    dcoHandlePage(event?.url||'','loadstart');
    dcoBrowserLoadGuardTimer=setTimeout(()=>{
      dcoBrowserLoadGuardTimer=null;
      if(dcoBrowserRef!==ref)return;
      dcoBrowserLoading=false;
      if(dcoAutoSale){
        dcoAutoSale.lastNavigationAt=Date.now();
        dcoQuickSetStatus('Il portale DCO sta completando il cambio pagina…');
        dcoAutoTick(ref);
      }else if(dcoVoidLab)dcoScheduleVoidLabTick(ref,120);
    },10000);
  });
  ref.addEventListener('loadstop',event=>{
    if(dcoBrowserRef!==ref)return;
    dcoClearBrowserLoadGuard();dcoBrowserLoading=false;
    if(dcoAutoSale){dcoAutoSale.lastNavigationAt=Date.now();dcoAutoSale.lastProgress=Date.now()}else if(dcoVoidLab){dcoVoidLab.lastProgress=Date.now();dcoInstallVoidProtection(ref)}
    dcoHandlePage(event?.url||'','loadstop');
  });
  ref.addEventListener('loaderror',event=>{
    if(dcoBrowserRef!==ref)return;
    dcoClearBrowserLoadGuard();dcoBrowserLoading=false;
    const url=event?.url||'';dcoRememberRoute(url,'loaderror');const id=dcoExtractDocumentId(url);
    if(id){
      if(dcoPdfRetryBusy)return;
      if(dcoAutoSale){
        const accepted=dcoAcceptAutoDocumentId(dcoAutoSale,id,'loaderror-print-url');
        if(accepted){dcoAutoSale.documentId=accepted;dcoAutoSale.stage='emitted';dcoAutoSale.lastProgress=Date.now();dcoQuickSetStatus(`Documento DCO-${accepted} emesso. Recupero numero ufficiale e stampa immediata…`);dcoFinalizeEmittedSale({documentId:accepted}).catch(error=>dcoAbortQuickSale(`Documento emesso, ma stampa immediata non completata: ${error.message||error}`,false));return}
        dcoScheduleAutoTick(ref,250);return
      }
      if(dcoVoidLab){const accepted=dcoVoidAcceptDocumentId(dcoVoidLab,id,'loaderror-print-url');if(accepted){dcoVoidLab.documentId=accepted;dcoVoidLab.stage='emitted';dcoVoidLab.lastProgress=Date.now();dcoFinalizeVoid({documentId:accepted}).catch(error=>dcoVoidAbort(`Documento di annullo rilevato, ma finalizzazione non completata: ${error.message||error}`,true,{keepBrowser:true}));return}dcoScheduleVoidLabTick(ref,250);return}
      dcoDownloadOfficialPdfNatively(ref,id,url).catch(error=>dcoLogPdfMeta(`download nativo fallito DCO-${id}`,{error:String(error?.message||error)}));return;
    }
    if(dcoAutoSale){dcoProbeEmissionAfterLoadError(ref,event);return}
    if(dcoVoidLab){dcoScheduleVoidLabTick(ref,350);dcoSetResult(dcoVoidLab.proceedClicked?'warning':'loading',dcoVoidLab.proceedClicked?'Il portale ha interrotto un caricamento dopo l’invio. Verifico l’esito senza ripetere Procedi…':'Il portale ha interrotto un caricamento intermedio. Riprendo l’annullamento senza inviare nulla due volte…');return}
    dcoSetResult('warning',`Caricamento del file DCO interrotto: ${event?.message||event?.code||'errore sconosciuto'}. Se il documento risulta emesso non ripetere la vendita; il documento commerciale resta ristampabile.`);
  });
  ref.addEventListener('exit',()=>{
    if(dcoBrowserRef!==ref)return;
    dcoClearBrowserLoadGuard();dcoBrowserLoading=false;dcoClearAutomationWaiters('La finestra DCO è stata chiusa.');
    dcoClearCaptureTimers();dcoStopLivePoll();dcoBrowserRef=null;dcoVisualHealth='error';dcoVisualHealthCheckedAt=Date.now();renderDcoSettingsCardStatus();
    if(dcoConnectionPending){const resume=dcoResumeSaleAfterConnect,returnEmergency=emergencyReconnectOnly;dcoResumeSaleAfterConnect=false;emergencyReconnectOnly=false;dcoConnectionAttempt+=1;dcoConnectionPending=false;dcoConnectionCredentials=null;dcoConnectionTickBusy=false;dcoConnectionReadyChecks=0;dcoConnectionLastReadyAt=0;dcoConnectionRouteAttempts=0;dcoConnectionLastRouteAt=0;dcoConnectionAuthenticatedAt=0;dcoConnectionPortalReadyChecks=0;dcoConnectionWizardStartedAt=0;if(resume){isIssuing=false;renderCart();emergencyHandleReconnectFailure('Collegamento DCO interrotto prima del completamento.');dcoQuickFinishProgress('Collegamento DCO interrotto prima del completamento.','error')}if(returnEmergency&&!resume)showView('emergenze');renderDcoConnectionStatus('Collegamento annullato prima del completamento.','warning')}
    if(dcoAutoSale)dcoAbortQuickSale('La finestra DCO è stata chiusa durante l’emissione. Verifica l’esito nel portale prima di riprovare.',false);
    else if(dcoVoidLab){const uncertain=!!dcoVoidLab.proceedClicked;dcoVoidAbort(uncertain?'Finestra DCO chiusa dopo l’invio dell’annullamento: verifica l’esito prima di riprovare.':'Finestra DCO chiusa prima dell’invio finale: annullamento non eseguito.',uncertain,{keepBrowser:true})}
    else dcoSetResult('','Browser chiuso. La diagnostica resta disponibile; per continuare apri nuovamente il flusso.');
  });
}
function dcoCreateBrowser(initial,hidden=false){
  const plugin=dcoPlugin();if(!plugin?.open)throw new Error('Modulo InAppBrowser non disponibile. Esegui npm install e npm run ios:sync.');
  dcoBrowserLoading=true;
  // Su Android il collegamento Fisconline automatico nasce nascosto. Quando una
  // vendita lo porta in primo piano, togliamo chrome/toolbar del browser: l'utente
  // vede soltanto l'overlay CassaIQ, mentre la WebView resta realmente attiva.
  const androidAutomaticChromeOff=printerPlatform()==='android'&&hidden;
  const locationOpt=androidAutomaticChromeOff?'no':'yes';
  const toolbarOpt=androidAutomaticChromeOff?'no':'yes';

  // Dopo un ripristino password il server AdE può invalidare i vecchi token IAM.
  // Solo il PRIMO collegamento successivo parte con session-cookie puliti.
  const freshAfterRenew=localStorage.getItem(K.fisRenewFreshDcoSession)==='1'
    &&String(initial||'').toLowerCase().includes('iampe.agenziaentrate.gov.it');
  const sessionCacheOpt=freshAfterRenew?'yes':'no';

  dcoBrowserRef=plugin.open(initial,'_blank',`location=${locationOpt},hidden=${hidden?'yes':'no'},clearcache=no,clearsessioncache=${sessionCacheOpt},hardwareback=yes,toolbar=${toolbarOpt},closebuttoncaption=Annulla,zoom=no,allowInlineMediaPlayback=yes`);
  if(freshAfterRenew)localStorage.removeItem(K.fisRenewFreshDcoSession);
  dcoAttachBrowserListeners(dcoBrowserRef);dcoStartLivePoll(dcoBrowserRef);return dcoBrowserRef;
}
function dcoActiveWebViewDuringEmission(){
  const platform=printerPlatform();return isIosApp()||platform==='android';
}
async function dcoMaskAndActivateBrowser(ref,message='Preparazione del documento commerciale…'){
  if(!ref||dcoBrowserRef!==ref)return;
  // Prima copriamo il portale, poi rendiamo attiva la InAppBrowser. In questo
  // modo Android non lavora piu' come WebView hidden/background e non compare
  // il wizard: visivamente resta una schermata CassaIQ a pieno schermo.
  await dcoShowEmissionOverlay(ref,message,'loading').catch(()=>{});
  try{ref.show?.()}catch{}
}
async function dcoStartConnection(method=dcoAuthMode(),options={}){
  if(dcoConnectionPending){
    dcoShowConnectionOverlay('Connessione al DCO già in corso…');
    renderDcoAuthUi();toast('Connessione al DCO già in corso',2500);return false
  }
  if(!dcoRequireBusinessProfile())return false;
  if(dcoAutoSale)return toast('Attendi la conclusione della vendita in corso');
  if(dcoVoidLab)return toast('Attendi la conclusione dell’annullamento DCO');
  const selected=method==='fisconline'?'fisconline':'spid';
  if(selected==='fisconline'){
    const wait=fisRenewDcoStabilizeSeconds();
    if(wait>0){
      const msg=`Password Fisconline appena rinnovata. Attendi circa ${wait} secondi prima di ricollegare il DCO: CassaIQ aprirà poi una sessione fiscale pulita.`;
      renderDcoConnectionStatus(msg,'warning');
      dcoSetResult('warning',msg);
      toast(`Attendi ${wait}s prima del DCO`,3200);
      return false
    }
  }
  let credentials=null;
  if(selected==='fisconline'){
    credentials=options.credentials||await dcoLoadFisconlineCredentials();
    if(!credentials){
      dcoFisconlineConfigured=false;localStorage.setItem(K.dcoAuthMode,'fisconline');renderDcoAuthUi();renderDcoFisconlineStatus('Salva prima codice fiscale/nome utente, password e PIN.','error');renderDcoConnectionStatus('Fisconline non configurato su questo dispositivo.','error');showView('dcolab');return false
    }
    dcoFisconlineConfigured=true;
  }
  dcoConnectionAttempt+=1;dcoConnectionPending=false;dcoConnectionTickBusy=false;dcoConnectionReadyChecks=0;dcoConnectionLastReadyAt=0;dcoConnectionRouteAttempts=0;dcoConnectionLastRouteAt=0;dcoConnectionAuthenticatedAt=0;dcoConnectionPortalReadyChecks=0;dcoConnectionWizardStartedAt=0;dcoFisconlineWorkUserConfirmed=false;dcoFisconlineWorkUserSelectionAttempted=false;dcoLastServiceNav=0;dcoLastServiceNavHref='';dcoWizardEntered=0;dcoResetFisconlineLoginState();
  dcoConnectionMethod=selected;dcoConnectionCredentials=credentials;if(selected==='fisconline')localStorage.setItem(K.dcoAuthMode,'fisconline');
  if(dcoBrowserRef)dcoDisposeBrowser(selected==='fisconline'?'Apertura di un nuovo collegamento Fisconline.':'Apertura di un nuovo collegamento SPID.');
  dcoClearConnected();
  dcoConnectionPending=true;dcoConnectionPhase='login';dcoRouteHistory=[];
  const automatic=selected==='fisconline';
  dcoSetResult('loading',automatic?'Accesso Fisconline automatico in corso…':'Apertura accesso alternativo SPID/CIE/CNS. Completa l’autenticazione: CassaIQ proseguirà automaticamente fino al DCO.');
  renderDcoConnectionStatus(automatic?'Collegamento Fisconline automatico in corso…':'Collegamento in corso… completa SPID nella finestra ufficiale.','loading');
  // Fisconline deve partire direttamente dal modulo ufficiale CF/password/PIN.
  // SPID/CIE/CNS mantiene invece il percorso manuale gia esistente dal portale servizi.
  const startUrl=selected==='fisconline'?DCO_URLS.login:DCO_URLS.entry;
  try{dcoCreateBrowser(startUrl,automatic);return true}
  catch(e){dcoConnectionPending=false;dcoConnectionCredentials=null;dcoConnectionReadyChecks=0;renderDcoConnectionStatus(`Impossibile aprire l’accesso: ${e.message||e}`,'error');return false}
}
async function dcoSaveAndStartFisconline(){
  if(dcoConnectionStartBusy||dcoConnectionPending){
    dcoShowConnectionOverlay('Connessione al DCO già in corso…');
    renderDcoAuthUi();toast('Connessione al DCO già in corso',2500);return false
  }
  if(dcoHasSessionMarker()){
    renderDcoConnectionStatus('DCO già collegato. Non è necessario ricollegarlo dopo il rinnovo Fisconline.','ok');
    toast('DCO già collegato · nessun ricollegamento necessario',3500);
    return true
  }
  dcoConnectionStartBusy=true;dcoShowConnectionOverlay('Preparazione connessione al DCO…');renderDcoAuthUi();
  try{
    const form=dcoFisconlineCredentialsFromForm(),hasAny=!!(form.username||form.password||form.pin),check=dcoFisconlineCredentialsValidation(form);
    if(hasAny){
      if(!check.ok){renderDcoFisconlineStatus(`Per sostituire le credenziali completa ${check.missing.join(', ')}.`,'error');return false}
      if(!(await dcoSaveFisconlineCredentials(false)))return false;
    }
    await dcoRefreshFisconlineConfigured();
    if(!dcoFisconlineConfigured){renderDcoFisconlineStatus('Inserisci e salva le credenziali Fisconline prima del collegamento.','error');return false}
    dcoSetAuthMode('fisconline');
    return await dcoStartConnection('fisconline')
  }finally{
    dcoConnectionStartBusy=false;renderDcoAuthUi();
    if(!dcoConnectionPending)dcoHideConnectionOverlay()
  }
}

function dcoStopVoidLabTimer(){if(dcoVoidLabTimer){clearTimeout(dcoVoidLabTimer);clearInterval(dcoVoidLabTimer);dcoVoidLabTimer=null}}
function dcoVoidProtectionCode(){
  return `(function(){try{
    var shield=document.getElementById('cassaiq-void-touch-shield');
    if(!shield){
      shield=document.createElement('div');shield.id='cassaiq-void-touch-shield';
      shield.setAttribute('aria-hidden','true');
      shield.style.cssText='position:fixed;inset:0;z-index:2147483646;background:rgba(0,0,0,0.001);pointer-events:auto;touch-action:none;overscroll-behavior:none;-webkit-user-select:none;user-select:none;cursor:wait';
      var stop=function(ev){try{ev.preventDefault()}catch(e){}try{ev.stopPropagation()}catch(e){}try{ev.stopImmediatePropagation()}catch(e){}return false};
      ['touchstart','touchmove','touchend','touchcancel','pointerdown','pointermove','pointerup','pointercancel','mousedown','mousemove','mouseup','click','dblclick','contextmenu','wheel'].forEach(function(name){try{shield.addEventListener(name,stop,{capture:true,passive:false})}catch(e){try{shield.addEventListener(name,stop,true)}catch(x){}}});
      (document.documentElement||document.body).appendChild(shield)
    }
    var banner=document.getElementById('cassaiq-void-progress-banner');
    if(!banner){banner=document.createElement('div');banner.id='cassaiq-void-progress-banner';banner.style.cssText='position:fixed;z-index:2147483647;top:8px;left:50%;transform:translateX(-50%);max-width:94vw;background:#9f2d2d;color:#fff;padding:9px 14px;border-radius:10px;font:700 12px -apple-system,BlinkMacSystemFont,sans-serif;box-shadow:0 4px 18px rgba(0,0,0,.28);text-align:center;pointer-events:none;-webkit-user-select:none;user-select:none';(document.documentElement||document.body).appendChild(banner)}
    banner.textContent='CassaIQ · ANNULLAMENTO DCO IN CORSO · TOUCH BLOCCATO · NON CHIUDERE';
    return true
  }catch(e){return false}})()`
}
function dcoInstallVoidProtection(ref=dcoBrowserRef){
  if(!ref||!dcoVoidLab)return;
  dcoExecScript(ref,dcoVoidProtectionCode(),1800).catch(()=>{})
}
function dcoRemoveVoidProgressBanner(ref=dcoBrowserRef){
  if(!ref)return;
  dcoExecScript(ref,`(function(){try{var ids=['cassaiq-void-progress-banner','cassaiq-void-touch-shield'];ids.forEach(function(id){var el=document.getElementById(id);if(el)el.remove()});return true}catch(e){return false}})()`,1800).catch(()=>{})
}
function dcoVoidNextTickDelay(state=dcoVoidLab){return state&&(state.finalArmed||state.proceedClicked||state.confirmClicked)?420:360}
function dcoScheduleVoidLabTick(ref=dcoBrowserRef,delayMs=null){
  if(!dcoVoidLab||!ref||dcoBrowserRef!==ref)return;
  dcoStopVoidLabTimer();
  const fallback=dcoVoidNextTickDelay(dcoVoidLab);
  dcoVoidLabTimer=setTimeout(async()=>{dcoVoidLabTimer=null;if(!dcoVoidLab||dcoBrowserRef!==ref)return;await dcoVoidLabTick(ref);if(dcoVoidLab&&dcoBrowserRef===ref&&!['done','uncertain','error'].includes(dcoVoidLab.stage))dcoScheduleVoidLabTick(ref,dcoVoidNextTickDelay(dcoVoidLab))},Math.max(120,Number(delayMs)||fallback))
}
function dcoVoidAcceptDocumentId(state,value,source='unknown'){
  const id=String(value||'').replace(/[^0-9]/g,'');
  if(!state||!id||!state.proceedClicked)return'';
  const previous=String(state.previousDocumentId||'').replace(/[^0-9]/g,'');
  if(previous&&id===previous)return'';
  if(state.acceptedEvidenceId!==id){state.acceptedEvidenceId=id;dcoRememberRoute(DCO_URLS.service,`diagnostic:void-document-accepted:${source}:${id}`)}
  return id
}
function dcoVoidSetLock(state){
  if(!state)return localStorage.removeItem(K.dcoVoidLock);
  localStorage.setItem(K.dcoVoidLock,JSON.stringify({saleId:String(state.saleId||''),originalNumber:String(state.originalNumber||''),previousDocumentId:String(state.previousDocumentId||''),stage:String(state.stage||''),finalArmed:!!state.finalArmed,confirmClicked:!!state.confirmClicked,proceedClicked:!!state.proceedClicked,startedAt:state.startedAt||Date.now(),updatedAt:Date.now()}))
}
async function dcoVoidCloudPersist(sale){
  if(!sale?.id||!getSession()?.user?.id)return false;
  const body={void_status:sale.voidStatus||null,voided_at:sale.voidedAt||null,void_reason:sale.voidReason||null,void_original_number:sale.voidOriginalNumber||null,void_document_id:sale.voidDocumentId||null,void_document_number:sale.voidDocumentNumber||null,void_document_date:sale.voidDocumentDate||null};
  try{await cloudRequest('sales',{method:'PATCH',query:`?id=eq.${encodeURIComponent(sale.id)}`,body,prefer:'return=minimal'});return true}catch(e){return false}
}
function dcoVoidAbort(message,uncertain=false,{keepBrowser=false}={}){
  const state=dcoVoidLab;dcoStopVoidLabTimer();dcoRemoveVoidProgressBanner();
  if(state){
    if(uncertain){const updated=dcoVoidSetSale(state.saleId,{voidStatus:'esito_da_verificare',voidReason:String(message||'Esito annullamento da verificare nel DCO.'),voidOriginalNumber:state.originalNumber,voidUpdatedAt:new Date().toISOString()});if(updated)dcoVoidCloudPersist(updated).catch(()=>{})}
    else dcoVoidClearPendingState(state.saleId)
  }
  localStorage.removeItem(K.dcoVoidLock);dcoVoidLab=null;dcoVoidLabTickBusy=false;
  if(dcoBrowserRef&&!keepBrowser){try{dcoBrowserRef.hide?.()}catch{}}
  const msg=String(message||'Annullamento DCO interrotto.');dcoSetResult(uncertain?'warning':'error',uncertain?`${msg} Non ripetere l’annullamento finché non hai controllato l’esito nel DCO.`:msg);toast(uncertain?'Annullamento da verificare':'Annullamento non completato',5000)
}
async function dcoFinalizeVoid(documentMeta){
  const state=dcoVoidLab;if(!state||state.finalizeBusy)return null;
  const id=dcoVoidAcceptDocumentId(state,documentMeta?.documentId,'finalize');if(!id)return null;
  state.finalizeBusy=true;state.stage='finalizing';state.lastProgress=Date.now();
  try{
    let meta=dcoNormalizeDocumentMeta({documentId:id,documentNumber:documentMeta?.documentNumber||'',documentDate:documentMeta?.documentDate||''});
    try{meta=await dcoResolveDocumentMeta(dcoBrowserRef,meta,10)}catch{}
    let voidNumber=String(meta.documentNumber||`DCO-${id}`),voidDate=String(meta.documentDate||'');if(voidNumber===state.originalNumber)voidNumber=`DCO-${id}`;
    const updated=dcoVoidSetSale(state.saleId,{voidStatus:'annullata',voidedAt:new Date().toISOString(),voidReason:'Documento annullato tramite Documento Commerciale Online.',voidOriginalNumber:state.originalNumber,voidDocumentId:id,voidDocumentNumber:voidNumber,voidDocumentDate:voidDate});
    if(updated)dcoVoidCloudPersist(updated).catch(()=>{});
    localStorage.removeItem(K.dcoVoidLock);dcoStopVoidLabTimer();dcoRemoveVoidProgressBanner();dcoClearBrowserLoadGuard();dcoClearAutomationWaiters('Annullamento DCO concluso.');dcoStopLivePoll();dcoClearCaptureTimers();
    dcoVoidLab=null;dcoVoidLabTickBusy=false;dcoBrowserLoading=false;try{dcoBrowserRef?.hide?.()}catch{};dcoMarkConnected();renderStats();
    dcoSetResult('ok',`Documento ${state.originalNumber} annullato. Documento di annullo: ${voidNumber}.`);toast(`Documento annullato · ${voidNumber}`,6000);
    alert(`ANNULLAMENTO COMPLETATO\n\nDocumento originale: ${state.originalNumber}\nDocumento di annullo: ${voidNumber}\n\nCassaIQ ha aggiornato lo storico e le statistiche.`);
    return{documentId:id,documentNumber:voidNumber,documentDate:voidDate}
  }finally{if(dcoVoidLab)dcoVoidLab.finalizeBusy=false}
}
function dcoVoidAutomationCode(originalNumber,finalArmed=false,proceedClicked=false,confirmClicked=false){
  const original=JSON.stringify(String(originalNumber||'').trim()),armed=JSON.stringify(!!finalArmed),proceeded=JSON.stringify(!!proceedClicked),confirmed=JSON.stringify(!!confirmClicked);
  return `(function(){
    try{
      var ORIGINAL=${original},FINAL_ARMED=${armed},APP_PROCEED_CLICKED=${proceeded},APP_CONFIRM_CLICKED=${confirmed};
      function clean(v){return String(v==null?'':v).replace(/\\s+/g,' ').trim()}
      function lower(v){return clean(v).toLowerCase()}
      function fire(el){['input','change','blur'].forEach(function(n){try{el.dispatchEvent(new Event(n,{bubbles:true}))}catch(e){}});try{if(window.angular){var sc=angular.element(el).scope();if(sc&&!sc.$$phase)sc.$applyAsync()}}catch(e){}}
      function setValue(id,value){var el=document.getElementById(id);if(!el)return false;if(el.type==='checkbox')el.checked=!!value;else el.value=value==null?'':String(value);fire(el);return true}
      function setSelect(id,value){var el=document.getElementById(id);if(!el)return false;el.value=String(value);if(el.value!==String(value)){var op=Array.prototype.slice.call(el.options||[]).find(function(o){return String(o.value)===String(value)||clean(o.textContent)===String(value)});if(op)el.selectedIndex=op.index}fire(el);return String(el.value)===String(value)}
      function text(el){return lower(el&&((el.textContent||el.value)||''))}
      function visible(el){if(!el||el.disabled)return false;try{var st=getComputedStyle(el),r=el.getBoundingClientRect();return st.display!=='none'&&st.visibility!=='hidden'&&r.width>0&&r.height>0}catch(e){return true}}
      function actions(){return Array.prototype.slice.call(document.querySelectorAll('button,a,input[type=submit],input[type=button],[role=button]'))}
      function find(labels){var w=labels.map(function(x){return String(x).toLowerCase()});return actions().find(function(el){return visible(el)&&w.indexOf(text(el))>=0})||actions().find(function(el){return visible(el)&&w.some(function(x){return text(el).indexOf(x)>=0})})}
      function clickLater(el){if(!el)return false;setTimeout(function(){try{el.click()}catch(e){}},180);return true}
      function clearDraft(){
        setValue('i2.0','');
        Array.prototype.slice.call(document.querySelectorAll('[id^="i2_2_1_r"]')).forEach(function(el){var m=String(el.id||'').match(/^i2_2_1_r(\\d+)$/);if(!m)return;var i=Number(m[1]);setValue('i2_2_1_r'+i,'');setValue('i2_2_2_r'+i,'');setValue('i2_2_3_r'+i,'');var vat=document.getElementById('i2_2_4_r'+i);if(vat){vat.selectedIndex=0;fire(vat)}setValue('i2_2_5_r'+i,'');setValue('i2_2_6_r'+i,false)});
        setValue('i2_4_1','');setValue('i2_4_2','');setValue('i2_4_3','');setValue('i2_4_3_3','');setValue('i2_4_4',false);setValue('i2_4_5','');setValue('i2_4_6','');setValue('i2_5','')
      }
      function attr(el,name){try{return clean(el.getAttribute(name)||'')}catch(e){return''}}
      function contextText(el){var cur=el,parts=[];for(var i=0;cur&&i<5;i++,cur=cur.parentElement){var t=clean(cur.innerText||cur.textContent||'');if(t)parts.push(t.slice(0,280))}return parts.join(' | ')}
      function candidateScore(el){var ph=lower(attr(el,'placeholder')),model=lower(attr(el,'ng-model')||attr(el,'data-ng-model')),ctx=lower(contextText(el)),score=0;if(ph==='numero progressivo')score+=120;else if(ph.indexOf('numero progressivo')>=0)score+=100;else if(ph.indexOf('progressivo')>=0)score+=55;if(ctx.indexOf('documento originario generato online')>=0)score+=90;if(model.indexOf('progressiv')>=0)score+=30;if(model.indexOf('collegato')>=0)score+=10;return score}
      function pickOriginalField(){var c=Array.prototype.slice.call(document.querySelectorAll('input')).filter(function(el){return visible(el)&&String(el.type||'text').toLowerCase()!=='hidden'}).map(function(el){return{el:el,score:candidateScore(el)}}).filter(function(x){return x.score>0}).sort(function(a,b){return b.score-a.score});if(!c.length)return{field:null};var top=c[0].score,w=c.filter(function(x){return x.score===top});if(w.length!==1)return{field:null,ambiguous:true};return{field:w[0].el}}
      function nativeSetValue(el,value){var val=String(value==null?'':value),done=false,proto=el;try{while(proto&&!done){var d=Object.getOwnPropertyDescriptor(proto,'value');if(d&&typeof d.set==='function'){d.set.call(el,val);done=true;break}proto=Object.getPrototypeOf(proto)}}catch(e){}if(!done)el.value=val;try{if(window.angular){var a=angular.element(el),ctrl=a.controller&&a.controller('ngModel');if(ctrl){ctrl.$setViewValue(val);ctrl.$render();var sc=a.scope&&a.scope();if(sc&&!sc.$$phase)sc.$applyAsync()}}}catch(e){}fire(el);return clean(el.value)===clean(val)}
      function nearestProceed(field){var buttons=actions().filter(function(el){return visible(el)&&text(el)==='prosegui'});if(!buttons.length)return null;for(var cur=field.parentElement,depth=0;cur&&depth<5;cur=cur.parentElement,depth++){var inside=buttons.find(function(b){return cur.contains(b)});if(inside)return inside}try{var fr=field.getBoundingClientRect(),fx=fr.left+fr.width/2,fy=fr.top+fr.height/2;buttons.sort(function(a,b){var ar=a.getBoundingClientRect(),br=b.getBoundingClientRect(),ad=Math.hypot((ar.left+ar.width/2)-fx,(ar.top+ar.height/2)-fy),bd=Math.hypot((br.left+br.width/2)-fx,(br.top+br.height/2)-fy);return ad-bd})}catch(e){}return buttons[0]||null}
      function findEmissionEvidence(){var out={emitted:false,documentId:'',source:''};try{var current=String(location.href||''),m=current.match(/documenti\\/(\\d+)\\/stampa\\/?/i);if(m){out.emitted=true;out.documentId=String(m[1]);out.source='current-url';return out}}catch(e){}try{var el=actions().find(function(x){return visible(x)&&text(x).indexOf('scarica e stampa file')===0});if(!el)return out;out.emitted=true;out.source='visible-download-control';try{var href=String(el.href||el.getAttribute&&el.getAttribute('href')||''),hm=href.match(/documenti\\/(\\d+)\\/stampa\\/?/i);if(hm)out.documentId=String(hm[1])}catch(e){}if(!out.documentId&&window.angular){try{var sc=angular.element(el).scope()||angular.element(el).isolateScope();while(sc){if(sc.vm&&sc.vm.invio&&sc.vm.invio.idtrx!=null){out.documentId=String(sc.vm.invio.idtrx).replace(/[^0-9]/g,'');if(out.documentId)break}sc=sc.$parent}}catch(e){}}return out}catch(e){return out}}
      function installProtection(){
        var shield=document.getElementById('cassaiq-void-touch-shield');
        if(!shield){shield=document.createElement('div');shield.id='cassaiq-void-touch-shield';shield.setAttribute('aria-hidden','true');shield.style.cssText='position:fixed;inset:0;z-index:2147483646;background:rgba(0,0,0,0.001);pointer-events:auto;touch-action:none;overscroll-behavior:none;-webkit-user-select:none;user-select:none;cursor:wait';var stop=function(ev){try{ev.preventDefault()}catch(e){}try{ev.stopPropagation()}catch(e){}try{ev.stopImmediatePropagation()}catch(e){}return false};['touchstart','touchmove','touchend','touchcancel','pointerdown','pointermove','pointerup','pointercancel','mousedown','mousemove','mouseup','click','dblclick','contextmenu','wheel'].forEach(function(name){try{shield.addEventListener(name,stop,{capture:true,passive:false})}catch(e){try{shield.addEventListener(name,stop,true)}catch(x){}}});(document.documentElement||document.body).appendChild(shield)}
        var banner=document.getElementById('cassaiq-void-progress-banner');if(!banner){banner=document.createElement('div');banner.id='cassaiq-void-progress-banner';banner.style.cssText='position:fixed;z-index:2147483647;top:8px;left:50%;transform:translateX(-50%);max-width:94vw;background:#9f2d2d;color:#fff;padding:9px 14px;border-radius:10px;font:700 12px -apple-system,BlinkMacSystemFont,sans-serif;box-shadow:0 4px 18px rgba(0,0,0,.28);text-align:center;pointer-events:none;-webkit-user-select:none;user-select:none';(document.documentElement||document.body).appendChild(banner)}banner.textContent='CassaIQ · ANNULLAMENTO DCO IN CORSO · TOUCH BLOCCATO · NON CHIUDERE'
      }
      var route=String(location.hash||''),lowerUrl=String(location.href||'').toLowerCase(),evidence=findEmissionEvidence(),out={ok:true,route:route,url:location.href,action:'',verificationReady:false,operationVisible:false,originalVisible:false,emitted:!!evidence.emitted,documentId:String(evidence.documentId||''),evidenceSource:String(evidence.source||''),finalReady:false,proceedClicked:APP_PROCEED_CLICKED,confirmClicked:APP_CONFIRM_CLICKED};
      if(out.emitted||out.documentId)return out;
      if(lowerUrl.indexOf('/nonauth.html')>=0){out.ok=false;out.error='SESSION_EXPIRED';return out}
      if(location.pathname.indexOf('/ser/documenticommercialionline/')<0){out.ok=false;out.error='AUTH_REQUIRED';return out}
      installProtection();
      if(route.indexOf('/generazione/wizard4')>=0){
        if(!FINAL_ARMED){out.action='final-ready';out.finalReady=true;return out}
        var confirm=find(['conferma']),proceed=find(['procedi']);
        if(APP_PROCEED_CLICKED&&confirm&&!APP_CONFIRM_CLICKED){out.confirmClicked=true;out.action='confirm-clicked';clickLater(confirm);return out}
        if(!APP_PROCEED_CLICKED&&proceed){out.proceedClicked=true;out.action='proceed-clicked';clickLater(proceed);return out}
        if(!APP_PROCEED_CLICKED&&!proceed&&confirm&&!APP_CONFIRM_CLICKED){out.confirmClicked=true;out.action='confirm-clicked';clickLater(confirm);return out}
        return out
      }
      if(route.indexOf('/generazione/wizard3')>=0){
        var body=clean(document.body&&document.body.innerText||'');out.verificationReady=true;out.operationVisible=body.toLowerCase().indexOf('annullo')>=0;out.originalVisible=body.indexOf(ORIGINAL)>=0;
        if(!FINAL_ARMED){out.action='verification-ready';return out}
        var understood=find(['ho capito']);if(understood){out.action='understood';clickLater(understood);return out}
        var next=find(['vai a conferma e stampa']);if(next){out.action='final-page-clicked';clickLater(next);return out}
        out.action='waiting-final-page';return out
      }
      if(route.indexOf('/generazione/wizard2')<0){var open=find(['genera il tuo documento','generazione']);if(open){out.action='open-wizard2';clickLater(open)}else out.action='waiting-home-action';return out}
      var op=document.getElementById('operazione');if(!op){out.action='waiting-operation-field';return out}
      if(String(op.value)!=='A'){clearDraft();var ok=setSelect('operazione','A');out.action='operation-annullo-set';if(!ok){out.ok=false;out.error='VOID_OPERATION_MAPPING_FAILED'}return out}
      var picked=pickOriginalField();if(picked.ambiguous){out.ok=false;out.error='VOID_ORIGINAL_FIELD_AMBIGUOUS';return out}
      if(picked.field){if(clean(picked.field.value)!==ORIGINAL){var setOk=nativeSetValue(picked.field,ORIGINAL);out.action=setOk?'original-progressivo-filled':'original-progressivo-fill-failed';if(!setOk){out.ok=false;out.error='VOID_ORIGINAL_FIELD_FILL_FAILED'}return out}var p=nearestProceed(picked.field);if(p){out.action='original-progressivo-proceed';clickLater(p);return out}out.action='waiting-original-proceed';return out}
      var verify=find(['vai a verifica dati']);if(verify){out.action='verify-clicked';clickLater(verify);return out}
      var bodyText=lower(document.body&&document.body.innerText||'');if(bodyText.indexOf('documento originario generato online')>=0){out.action='waiting-original-field';return out}out.action='waiting-original-load';return out
    }catch(e){return{ok:false,error:String(e&&e.message||e),route:String(location.hash||''),url:location.href}}
  })()`
}
async function dcoVoidLabTick(ref){
  if(!dcoVoidLab||dcoVoidLabTickBusy||dcoBrowserRef!==ref||dcoBrowserLoading)return;dcoVoidLabTickBusy=true;
  try{
    const state=dcoVoidLab,totalElapsed=Date.now()-state.startedAt,idleElapsed=Date.now()-state.lastProgress,totalMax=state.proceedClicked?240000:180000,idleMax=state.proceedClicked?150000:80000;
    if(totalElapsed>totalMax||idleElapsed>idleMax){if(state.proceedClicked)return dcoVoidAbort('Il DCO non ha restituito l’esito finale dell’annullamento.',true,{keepBrowser:true});throw new Error('Il portale non ha completato la preparazione dell’annullamento.')}
    const out=await dcoExecScript(ref,dcoVoidAutomationCode(state.originalNumber,state.finalArmed,state.proceedClicked,state.confirmClicked),12000);
    if(!out?.ok){
      if(out?.error==='SESSION_EXPIRED'||out?.error==='AUTH_REQUIRED'){if(state.proceedClicked)return dcoVoidAbort('Sessione DCO interrotta dopo l’invio dell’annullamento.',true,{keepBrowser:true});dcoVoidAbort('Sessione DCO non valida. Ricollega il DCO e riprova: nessun annullamento è stato inviato.',false);return}
      throw new Error(out?.error||'Automazione annullamento DCO non disponibile')
    }
    if(out.action&&out.action!==state.lastAction){state.lastAction=out.action;state.lastProgress=Date.now();const labels={'open-wizard2':'Apertura annullamento DCO…','waiting-home-action':'Attendo il comando Genera il tuo documento…','waiting-operation-field':'Attendo il campo Tipo operazione…','operation-annullo-set':'Tipo operazione: Annullo…','original-progressivo-filled':`Documento originale ${state.originalNumber} selezionato…`,'original-progressivo-proceed':'Recupero documento originale…','waiting-original-field':'Attendo il campo del documento originario…','waiting-original-proceed':'Attendo conferma del documento originario…','waiting-original-load':'Caricamento documento originario…','verify-clicked':'Verifica dati dell’annullamento…','verification-ready':'Documento da annullare verificato…','final-page-clicked':'Apertura Conferma e stampa…','understood':'Conferma informativa…','waiting-final-page':'Attendo la pagina finale…','final-ready':'Annullamento pronto per l’invio…','confirm-clicked':'Conferma annullamento…','proceed-clicked':'Invio annullamento all’Agenzia delle Entrate…'};dcoSetResult('loading',labels[out.action]||'Annullamento DCO in corso…')}
    if(out.verificationReady&&!state.finalArmed){
      if(!out.operationVisible||!out.originalVisible){return dcoVoidAbort('Il DCO ha aperto Verifica dati, ma CassaIQ non riconosce con certezza “Annullo” e il documento originario. Nessun invio eseguito.',false,{keepBrowser:true})}
      state.finalArmed=true;state.stage='verified';state.lastProgress=Date.now();dcoVoidSetLock(state);dcoSetResult('loading','Documento originale verificato. Procedo alla conferma fiscale…');return
    }
    if(out.finalReady&&!state.finalArmed){state.finalArmed=true;state.stage='final-armed';state.lastProgress=Date.now();dcoVoidSetLock(state);return}
    if(out.confirmClicked&&!state.confirmClicked){state.confirmClicked=true;state.lastProgress=Date.now();state.stage='confirm-clicked';dcoVoidSetLock(state)}
    if(out.proceedClicked&&!state.proceedClicked){state.proceedClicked=true;state.lastProgress=Date.now();state.stage='proceed-clicked';dcoVoidSetLock(state)}
    if(out.emitted||out.documentId){const id=dcoVoidAcceptDocumentId(state,out.documentId,`runner-${out.evidenceSource||'visible'}`);if(id){state.documentId=id;state.stage='emitted';state.lastProgress=Date.now();dcoVoidSetLock(state);await dcoFinalizeVoid({documentId:id});return}}
  }catch(e){const msg=e?.message||String(e),uncertain=!!dcoVoidLab?.proceedClicked;dcoVoidAbort(uncertain?`Annullamento inviato, ma esito non confermato: ${msg}`:`Annullamento non completato: ${msg}`,uncertain,{keepBrowser:uncertain})}finally{dcoVoidLabTickBusy=false}
}
async function dcoStartVoidForSale(saleId){
  const sale=sales.find(x=>String(x?.id||'')===String(saleId||''));if(!sale)return alert('Vendita non trovata. Aggiorna le statistiche e riprova.');
  const original=dcoSaleOriginalNumber(sale);if(!original)return alert('Questa vendita non contiene il numero ufficiale del documento DCO.');
  if(!dcoSaleLooksLikeDco(sale))return alert('Questa vendita non risulta identificata come Documento Commerciale Online.');
  if(!dcoSaleIsToday(sale))return alert('L’annullamento automatico CassaIQ è abilitato, in questa versione, solo per documenti DCO emessi oggi.');
  const state=dcoVoidStatus(sale);if(state==='annullata')return alert('Questo documento risulta già annullato.');if(state==='esito_da_verificare')return alert('L’esito di un precedente tentativo deve essere verificato nel DCO prima di riprovare.');if(state==='in_corso'||dcoVoidLab)return toast('Un annullamento DCO è già in corso',3500);
  if(dcoAutoSale||isIssuing)return toast('Attendi la conclusione dell’operazione fiscale in corso',3500);
  if(!dcoHasSessionMarker()){alert('Collega prima il Documento Commerciale Online da Impostazioni. Poi torna in Statistiche → Ultime vendite.');showView('dcolab');return}
  if(!confirm(`ANNULLAMENTO FISCALE DCO\n\nDocumento originale: ${original}\nTotale: ${euro(sale.total)}\n\nCassaIQ recupererà il documento nel portale dell’Agenzia delle Entrate e genererà un vero documento di annullo.\n\nContinuare?`))return;
  if(!confirm(`ULTIMA CONFERMA\n\nStai per ANNULLARE fiscalmente il documento ${original} da ${euro(sale.total)}.\n\nL’operazione non è una semplice cancellazione dalle statistiche.\n\nLa procedura può richiedere 30 secondi o più. Dopo la conferma, NON TOCCARE lo schermo e attendi l’esito di CassaIQ.\n\nConfermi l’annullamento?`))return;
  dcoClearCaptureTimers();dcoStopLivePoll();dcoStopVoidLabTimer();
  const previousDocumentId=String(sale.dcoDocumentId||'').replace(/[^0-9]/g,'');dcoVoidLab={saleId:String(sale.id||''),originalNumber:original,previousDocumentId,startedAt:Date.now(),lastProgress:Date.now(),lastAction:'',stage:'opening',finalArmed:false,confirmClicked:false,proceedClicked:false,finalizeBusy:false};
  dcoVoidSetSale(sale.id,{voidStatus:'in_corso',voidStartedAt:new Date().toISOString(),voidOriginalNumber:original,voidReason:'Annullamento DCO in corso.'});dcoVoidSetLock(dcoVoidLab);dcoSetResult('loading',`Annullamento DCO: preparo ${original}…`);
  try{
    /* Base 1.15.7: non resettiamo il contesto e non usiamo stati persistenti nella pagina DCO. È il percorso che ha già raggiunto correttamente Verifica dati nei test reali. */
    if(dcoBrowserRef){try{dcoBrowserRef.show?.()}catch{};dcoInstallVoidProtection(dcoBrowserRef);await dcoExecScript(dcoBrowserRef,`(function(){location.href=${JSON.stringify(DCO_URLS.service)};return true})()`,5000).catch(()=>{dcoNavigate(dcoBrowserRef,DCO_URLS.service)})}
    else dcoCreateBrowser(DCO_URLS.service,false);
    dcoScheduleVoidLabTick(dcoBrowserRef,450)
  }catch(e){dcoVoidAbort(`Impossibile avviare l’annullamento: ${e.message||e}`,false)}
}
function dcoRecoverInterruptedVoid(){
  const lock=loadObjectSafe(K.dcoVoidLock,null);if(!lock?.saleId)return;
  const sale=sales.find(x=>String(x?.id||'')===String(lock.saleId));if(sale){if(lock.proceedClicked){const updated=dcoVoidSetSale(lock.saleId,{voidStatus:'esito_da_verificare',voidReason:'CassaIQ è stato chiuso durante la fase finale dell’annullamento. Verifica l’esito nel DCO prima di riprovare.',voidOriginalNumber:lock.originalNumber||dcoSaleOriginalNumber(sale),voidUpdatedAt:new Date().toISOString()});if(updated)dcoVoidCloudPersist(updated).catch(()=>{})}else dcoVoidClearPendingState(lock.saleId)}localStorage.removeItem(K.dcoVoidLock)
}

function dcoQuickAutomationCode(draft,token,finalArmed=false,callId='',proceedClicked=false,confirmClicked=false){
  const data=JSON.stringify(draft),tok=JSON.stringify(token),armed=JSON.stringify(!!finalArmed),cid=JSON.stringify(callId),proceeded=JSON.stringify(!!proceedClicked),confirmed=JSON.stringify(!!confirmClicked);
  return `(function(){
    var send=function(payload){
      try{
        var encoded=JSON.stringify(payload);
        if(window.webkit&&window.webkit.messageHandlers&&window.webkit.messageHandlers.cordova_iab){window.webkit.messageHandlers.cordova_iab.postMessage(encoded);return true}
        if(window.cordova_iab&&typeof window.cordova_iab.postMessage==='function'){window.cordova_iab.postMessage(encoded);return true}
      }catch(e){}
      return false
    };
    try{
      var D=${data},TOKEN=${tok},FINAL_ARMED=${armed},CALL_ID=${cid},APP_PROCEED_CLICKED=${proceeded},APP_CONFIRM_CLICKED=${confirmed};
      function clean(v){return String(v==null?'':v).replace(/\\s+/g,' ').trim()}
      function money(v){var n=Number(v||0);return Number.isFinite(n)?n.toFixed(2).replace('.',','):'0,00'}
      function quantity(v){var n=Number(v||0);return Number.isInteger(n)?String(n):n.toFixed(2).replace('.',',')}
      function fire(el){['input','change','blur'].forEach(function(n){try{el.dispatchEvent(new Event(n,{bubbles:true}))}catch(e){}});try{if(window.angular){var sc=angular.element(el).scope();if(sc&&!sc.$$phase)sc.$applyAsync()}}catch(e){}}
      function setValue(id,value){var el=document.getElementById(id);if(!el)return false;if(el.type==='checkbox')el.checked=!!value;else el.value=value==null?'':String(value);fire(el);return true}
      function setSelect(id,value){var el=document.getElementById(id);if(!el)return false;el.value=String(value);if(el.value!==String(value)){var op=Array.prototype.slice.call(el.options||[]).find(function(o){return clean(o.textContent)===String(value)||String(o.value)===String(value)});if(op)el.selectedIndex=op.index}fire(el);return el.value===String(value)||Array.prototype.slice.call(el.options||[]).some(function(o){return clean(o.textContent)===String(value)})}
      function lotteryInput(){
        var fields=Array.prototype.slice.call(document.querySelectorAll('input,textarea')).filter(function(el){return el&&!el.disabled&&String(el.type||'').toLowerCase()!=='hidden'}),best=null,bestScore=0;
        fields.forEach(function(el){try{var id=String(el.id||''),label=null;if(id){var labels=Array.prototype.slice.call(document.getElementsByTagName('label'));label=labels.find(function(l){return String(l.htmlFor||'')===id})||null}var near=el.closest&&el.closest('label,.form-group,.row,.col,.field,div'),meta=clean([id,el.name||'',el.placeholder||'',el.getAttribute&&el.getAttribute('aria-label')||'',label&&label.textContent||'',near&&near.textContent||''].join(' ')).toLowerCase(),score=0;if(meta.indexOf('lotter')>=0)score+=5;if(meta.indexOf('codice')>=0)score+=2;if(meta.indexOf('cliente')>=0)score+=1;if(score>bestScore){best=el;bestScore=score}}catch(e){}});return bestScore>=5?best:null
      }
      function text(el){return clean(el&&((el.textContent||el.value)||'')).toLowerCase()}
      function visible(el){if(!el||el.disabled)return false;var st=getComputedStyle(el),r=el.getBoundingClientRect();return st.display!=='none'&&st.visibility!=='hidden'&&r.width>0&&r.height>0}
      function actions(){return Array.prototype.slice.call(document.querySelectorAll('button,a,input[type=submit],input[type=button],[role=button]'))}
      function find(labels){var w=labels.map(function(x){return x.toLowerCase()});return actions().find(function(el){return visible(el)&&w.indexOf(text(el))>=0})||actions().find(function(el){return visible(el)&&w.some(function(x){return text(el).indexOf(x)>=0})})}
      // Android InAppBrowser puo' mantenere il portale correttamente renderizzato
      // pur restituendo temporaneamente rettangoli 0x0 per i controlli della
      // WebView nascosta. In quel caso NON allarghiamo il flusso fiscale: cerchiamo
      // soltanto il pulsante di verifica del wizard2, richiedendo testo/ng-click
      // coerente, elemento non disabilitato e stile non nascosto.
      var IS_ANDROID=/Android/i.test(String(navigator.userAgent||''));
      function findAndroidVerifyFallback(){
        if(!IS_ANDROID)return null;
        return actions().find(function(el){
          try{
            if(!el||el.disabled)return false;
            var st=getComputedStyle(el);if(st.display==='none'||st.visibility==='hidden')return false;
            var t=text(el),ng=clean(el.getAttribute&&el.getAttribute('ng-click')||'').toLowerCase();
            var byText=t.indexOf('verifica')>=0&&t.indexOf('dati')>=0;
            var byNg=ng.indexOf('verifica')>=0;
            return byText||byNg;
          }catch(e){return false}
        })||null
      }
      function refreshWizard2Bindings(){
        if(!IS_ANDROID)return;
        try{
          var ids=['operazione','i2.0','i2_4_1','i2_4_2','i2_5'];
          var maxRows=Math.max(Number((D&&D.lines&&D.lines.length)||0),Array.prototype.slice.call(document.querySelectorAll('[id^=\"i2_2_1_r\"]')).length,8);for(var r=0;r<maxRows;r++)ids.push('i2_2_1_r'+r,'i2_2_2_r'+r,'i2_2_3_r'+r,'i2_2_4_r'+r,'i2_2_5_r'+r,'i2_2_6_r'+r);
          ids.forEach(function(id){var el=document.getElementById(id);if(el)fire(el)});
          if(window.angular){try{var inj=angular.element(document.body).injector&&angular.element(document.body).injector();var root=inj&&inj.get&&inj.get('$rootScope');if(root)root.$evalAsync()}catch(e){}}
        }catch(e){}
      }
      function wizard2RowIndexes(){
        var found={};Array.prototype.slice.call(document.querySelectorAll('[id^="i2_2_1_r"]')).forEach(function(el){var m=String(el.id||'').match(/^i2_2_1_r(\\d+)$/);if(m)found[Number(m[1])]=true});return Object.keys(found).map(Number).filter(Number.isFinite).sort(function(a,b){return a-b})
      }
      function findAddProductRow(){
        return actions().find(function(el){if(!el||el.disabled)return false;var t=text(el),ng=clean(el.getAttribute&&el.getAttribute('ng-click')||'').toLowerCase(),meta=clean((el.getAttribute&&el.getAttribute('aria-label')||'')+' '+(el.getAttribute&&el.getAttribute('title')||'')+' '+ng).toLowerCase();return visible(el)&&((t.indexOf('aggiungi')>=0&&(t.indexOf('riga')>=0||t.indexOf('prodot')>=0||t.indexOf('articol')>=0))||((meta.indexOf('aggiung')>=0||meta.indexOf('add')>=0)&&(meta.indexOf('riga')>=0||meta.indexOf('prod')>=0||meta.indexOf('articol')>=0||meta.indexOf('voce')>=0)))})||null
      }
      // Prova di emissione: niente scansione globale di $rootScope.
      // Un documento esiste per questa operazione solo se il portale mostra
      // realmente il controllo "Scarica e stampa file" oppure se l'URL corrente
      // e' gia' quello di stampa del documento.
      function findEmissionEvidence(){
        var out={emitted:false,documentId:'',source:''};
        try{var current=String(location.href||''),urlMatch=current.match(/documenti\\/(\\d+)\\/stampa\\/?/i);if(urlMatch){out.emitted=true;out.documentId=String(urlMatch[1]);out.source='current-url';return out}}catch(e){}
        try{
          var el=actions().find(function(x){return visible(x)&&text(x).indexOf('scarica e stampa file')===0});
          if(!el)return out;out.emitted=true;out.source='visible-download-control';
          try{var href=String(el.href||el.getAttribute&&el.getAttribute('href')||''),hm=href.match(/documenti\\/(\\d+)\\/stampa\\/?/i);if(hm)out.documentId=String(hm[1])}catch(e){}
          if(!out.documentId&&window.angular){try{var sc=angular.element(el).scope()||angular.element(el).isolateScope();while(sc){if(sc.vm&&sc.vm.invio&&sc.vm.invio.idtrx!=null){out.documentId=String(sc.vm.invio.idtrx).replace(/[^0-9]/g,'');if(out.documentId)break}sc=sc.$parent}}catch(e){}}
          return out
        }catch(e){return out}
      }
      function publish(out,clickEl){
        out.callId=CALL_ID;
        send({source:'cassaiq-dco',type:'result',token:TOKEN,callId:CALL_ID,result:out});
        if(clickEl)setTimeout(function(){
          try{
            if(window.__cassaiqCancelDeferredClicks===true)return;
            if(window.__cassaiqActiveQuickToken!==TOKEN)return;
            if(!window.__cassaiqQuick||window.__cassaiqQuick.token!==TOKEN||window.__cassaiqQuick.cancelled)return;
            clickEl.click()
          }catch(e){}
        },220);
        return out
      }
      // Il bridge route non cattura piu' il TOKEN della prima vendita.
      // Ogni evento legge il token dell'operazione attiva, cosi' la stessa
      // sessione DCO puo' essere riutilizzata senza trascinarsi il contesto prima.
      window.__cassaiqRouteBridgeSendV2=function(){
        try{var payload={source:'cassaiq-dco',type:'route',token:String(window.__cassaiqActiveQuickToken||''),url:location.href,route:String(location.hash||''),at:Date.now()},encoded=JSON.stringify(payload);if(window.webkit&&window.webkit.messageHandlers&&window.webkit.messageHandlers.cordova_iab){window.webkit.messageHandlers.cordova_iab.postMessage(encoded);return}if(window.cordova_iab&&typeof window.cordova_iab.postMessage==='function')window.cordova_iab.postMessage(encoded)}catch(e){}
      };
      if(!window.__cassaiqRouteBridgeV2){
        window.__cassaiqRouteBridgeV2=true;
        var announceRouteV2=function(){setTimeout(function(){try{window.__cassaiqRouteBridgeSendV2&&window.__cassaiqRouteBridgeSendV2()}catch(e){}},250)};
        window.addEventListener('hashchange',announceRouteV2);
        window.addEventListener('popstate',announceRouteV2);
      }
      function takeClick(key,labels){
        var now=Date.now(),at=Number(q.steps[key+'At']||0),attempts=Number(q.steps[key+'Attempts']||0);
        if(now-at<1200)return null;
        if(attempts>=55)throw new Error(key.toUpperCase()+'_TIMEOUT');
        var el=find(labels);q.steps[key+'At']=now;q.steps[key+'Attempts']=attempts+1;
        return el||null
      }
      var q=window.__cassaiqQuick;
      if(!q||q.token!==TOKEN)q=window.__cassaiqQuick={token:TOKEN,steps:{},startedAt:Date.now(),cancelled:false};
      window.__cassaiqActiveQuickToken=TOKEN;
      if(q.cancelled){var cancelled={ok:true,action:'cancelled',route:String(location.hash||''),url:location.href};return publish(cancelled)}
      if(APP_PROCEED_CLICKED)q.steps.proceed=true;
      if(APP_CONFIRM_CLICKED)q.steps.confirm=true;
      var route=String(location.hash||''),lower=(location.href||'').toLowerCase(),evidence=findEmissionEvidence(),out={ok:true,route:route,url:location.href,logged:!!document.querySelector('#user-info'),action:'',emitted:!!evidence.emitted,documentId:String(evidence.documentId||''),evidenceSource:String(evidence.source||''),documentNumber:'',documentDate:'',proceedClicked:!!q.steps.proceed,confirmClicked:!!q.steps.confirm,pdf:window.__cassaiqDcoPdf?{state:String(window.__cassaiqDcoPdf.state||''),documentId:String(window.__cassaiqDcoPdf.documentId||''),bytes:Number(window.__cassaiqDcoPdf.bytes||0),base64Length:String(window.__cassaiqDcoPdf.base64||'').length,error:String(window.__cassaiqDcoPdf.error||'')}:null};
      if(lower.indexOf('/nonauth.html')>=0){out.ok=false;out.error='SESSION_EXPIRED';return publish(out)}
      if(location.pathname.indexOf('/ser/documenticommercialionline/')<0){out.ok=false;out.error='AUTH_REQUIRED';return publish(out)}
      if(out.emitted&&out.documentId){return publish(out);}
      if(route.indexOf('/generazione/wizard2')<0&&route.indexOf('/generazione/wizard3')<0&&route.indexOf('/generazione/wizard4')<0){
        var open=takeClick('open',['genera il tuo documento','generazione']);
        if(open){out.action=Number(q.steps.openAttempts||0)>1?'retry-open-wizard2':'open-wizard2';return publish(out,open)}
        return publish(out)
      }
      if(route.indexOf('/generazione/wizard2')>=0){
        var ready=document.getElementById('i2_2_1_r0')&&document.getElementById('i2_2_2_r0')&&document.getElementById('i2_2_3_r0')&&document.getElementById('i2_2_4_r0');
        if(!ready)return publish(out);
        var rowIndexes=wizard2RowIndexes(),availableRows=rowIndexes.length;
        if(D.lines.length>availableRows){
          var addRow=findAddProductRow();
          if(addRow){q.steps.addRowAttempts=Number(q.steps.addRowAttempts||0)+1;if(q.steps.addRowAttempts>40){out.ok=false;out.error='DCO_ROW_CREATION_TIMEOUT';out.availableRows=availableRows;out.requestedRows=D.lines.length;return publish(out)}out.action='add-product-row';out.availableRows=availableRows;out.requestedRows=D.lines.length;return publish(out,addRow)}
          out.ok=false;out.error='DCO_ROW_LIMIT';out.availableRows=availableRows;out.requestedRows=D.lines.length;return publish(out)
        }
        if(!q.steps.fill){
          var ok=setSelect('operazione','V');setValue('i2.0','');
          rowIndexes.forEach(function(i){setValue('i2_2_1_r'+i,'');setValue('i2_2_2_r'+i,'');setValue('i2_2_3_r'+i,'');var vat=document.getElementById('i2_2_4_r'+i);if(vat){vat.selectedIndex=0;fire(vat)}setValue('i2_2_5_r'+i,'');setValue('i2_2_6_r'+i,false)});
          D.lines.forEach(function(line,i){ok=setValue('i2_2_1_r'+i,quantity(line.quantity))&&ok;ok=setValue('i2_2_2_r'+i,line.description)&&ok;ok=setValue('i2_2_3_r'+i,money(line.grossPrice))&&ok;ok=setSelect('i2_2_4_r'+i,line.vat)&&ok;if(line.discount)ok=setValue('i2_2_5_r'+i,money(line.discount))&&ok});
          ok=setValue('i2_4_1',D.cash?money(D.cash):'')&&ok;ok=setValue('i2_4_2',D.electronic?money(D.electronic):'')&&ok;setValue('i2_5',D.discount?money(D.discount):'');
          var lot=lotteryInput();if(D.lotteryCode){if(!lot){q.steps.lotteryWaitAttempts=Number(q.steps.lotteryWaitAttempts||0)+1;if(q.steps.lotteryWaitAttempts<=12){out.action='lottery-field-wait';return publish(out)}out.ok=false;out.error='DCO_LOTTERY_FIELD_NOT_FOUND';return publish(out)}lot.value=String(D.lotteryCode);fire(lot)}else if(lot){lot.value='';fire(lot)}
          if(!ok){out.ok=false;out.error='FORM_MAPPING_FAILED';return publish(out)}
          q.steps.fill=true;q.steps.fillAt=Date.now();out.action='filled';out.availableRows=availableRows;return publish(out)
        }
        var verify=find(['vai a verifica dati']);
        if(!verify&&IS_ANDROID&&Date.now()-Number(q.steps.fillAt||Date.now())>900){
          var pokeAt=Number(q.steps.verifyPokeAt||0);
          if(Date.now()-pokeAt>1200){q.steps.verifyPokeAt=Date.now();refreshWizard2Bindings()}
          verify=findAndroidVerifyFallback();
          if(verify)out.verifyFallback='android-wizard2-dom';
        }
        if(verify&&!q.steps.verify){q.steps.verify=true;q.steps.verifyAt=Date.now();out.action='verify-clicked';return publish(out,verify)}
        if(!verify&&Date.now()-Number(q.steps.fillAt||Date.now())>12000){q.steps.fill=false;q.steps.fillRetries=Number(q.steps.fillRetries||0)+1;if(q.steps.fillRetries>3){out.ok=false;out.error='VERIFY_BUTTON_TIMEOUT'}}
        return publish(out)
      }
      if(route.indexOf('/generazione/wizard3')>=0){
        var understood=find(['ho capito']);
        if(understood&&!q.steps.understood){q.steps.understood=true;out.action='understood';return publish(out,understood)}
        if(!q.steps.finalpage||Date.now()-Number(q.steps.finalpageAt||0)>3500){
          var next=find(['vai a conferma e stampa']);
          if(next){q.steps.finalpage=true;q.steps.finalpageAt=Date.now();q.steps.finalpageAttempts=Number(q.steps.finalpageAttempts||0)+1;out.action=q.steps.finalpageAttempts>1?'retry-final-page':'final-page-clicked';return publish(out,next)}
        }
        if(Number(q.steps.finalpageAttempts||0)>8){out.ok=false;out.error='FINAL_PAGE_TIMEOUT'}
        return publish(out)
      }
      if(route.indexOf('/generazione/wizard4')>=0){
        var confirm=find(['conferma']),proceed=find(['procedi']);
        if(!q.steps.proceed&&((proceed)||(!proceed&&confirm&&!q.steps.confirm))&&!FINAL_ARMED){out.action='final-ready';out.finalReady=true;return publish(out)}
        if(q.steps.proceed&&confirm&&!q.steps.confirm){q.steps.confirm=true;out.confirmClicked=true;out.action='confirm-clicked';return publish(out,confirm)}
        if(proceed&&!q.steps.proceed&&FINAL_ARMED){q.steps.proceed=true;out.proceedClicked=true;out.action='proceed-clicked';return publish(out,proceed)}
        if(!q.steps.proceed&&!proceed&&confirm&&!q.steps.confirm&&FINAL_ARMED){q.steps.confirm=true;out.confirmClicked=true;out.action='confirm-clicked';return publish(out,confirm)}
        return publish(out)
      }
      return publish(out)
    }catch(e){
      var fail={ok:false,error:String(e&&e.message||e),route:String(location.hash||''),url:location.href,callId:typeof CALL_ID==='undefined'?'':CALL_ID};
      send({source:'cassaiq-dco',type:'result',token:typeof TOKEN==='undefined'?'':TOKEN,callId:fail.callId,result:fail});
      return fail
    }
  })()`;
}
async function dcoAutoTick(ref){
  if(!dcoAutoSale||dcoAutoTickBusy||dcoAutoPdfRecoveryBusy||dcoBrowserRef!==ref||dcoBrowserLoading)return;dcoAutoTickBusy=true;
  try{
    const state=dcoAutoSale,totalElapsed=Date.now()-state.startedAt,idleElapsed=Date.now()-state.lastProgress,totalMax=state.proceedClicked||state.finalArmed?300000:180000,idleMax=state.proceedClicked||state.finalArmed?180000:60000;
    if(totalElapsed>totalMax||idleElapsed>idleMax)throw new Error(state.proceedClicked||state.finalArmed?'Invio finale avviato ma risposta non completata: verifica il portale prima di riprovare.':'Il portale non ha completato la preparazione del documento. Nessun invio eseguito: riprova senza ricollegare se lo stato DCO è ancora verde.');
    // Dopo l'emissione il runner fiscale si ferma. Da questo momento controlliamo
    // soltanto il PDF, usando lo stesso percorso che ha funzionato con “Riprova recupero”.
    if(state.pdfRecoveryStarted&&state.documentId){
      let meta=null;
      try{meta=await dcoReadPdfMeta(ref)}catch(error){dcoLogPdfMeta(`lettura automatica PDF DCO-${state.documentId} non disponibile`,{error:String(error?.message||error)});return}
      if(meta?.state==='ready'){await dcoMaybePullOfficialPdf(ref,meta);return}
      const elapsed=Date.now()-Number(meta?.startedAt||state.pdfRecoveryStartedAt||state.lastProgress||Date.now());
      if(meta?.state==='loading'&&elapsed>3500){
        try{await dcoDownloadOfficialPdfNatively(ref,state.documentId,meta.navigationUrl||meta.responseUrl||'');return}
        catch(error){dcoLogPdfMeta(`download automatico PDF fallito DCO-${state.documentId}`,{error:String(error?.message||error),meta});if(elapsed<25000)return;dcoMarkPdfPending(state.documentId,error?.message||error);return}
      }
      if(meta?.state==='error'){
        try{await dcoDownloadOfficialPdfNatively(ref,state.documentId,meta.navigationUrl||meta.responseUrl||'');return}
        catch(error){dcoMarkPdfPending(state.documentId,error?.message||meta.error||error);return}
      }
      return;
    }
    const callId=`${state.token}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
    const code=dcoQuickAutomationCode(state.draft,state.token,state.finalArmed,callId,state.proceedClicked,state.confirmClicked);
    const out=await dcoRunAutomation(ref,code,callId,14000);
    state.scriptTimeouts=0;
    if(!out?.ok){
      if(out?.error==='SESSION_EXPIRED'||out?.error==='AUTH_REQUIRED'){if(dcoAuthMode()==='fisconline'&&!state.finalArmed&&!state.proceedClicked)return dcoReconnectFisconlineSale();return dcoAbortQuickSale('Sessione DCO scaduta. Ricollega il metodo di accesso prima della vendita.',true);}
      if(out?.error==='DCO_ROW_LIMIT')return dcoAbortQuickSale(`Il portale DCO espone ${Number(out.availableRows||0)} righe prodotto e il carrello ne contiene ${Number(out.requestedRows||state.draft?.lines?.length||0)}. CassaIQ non dividerà automaticamente la vendita: verifica il limite effettivo del portale prima di proseguire.`,false);
      if(out?.error==='DCO_ROW_CREATION_TIMEOUT')return dcoAbortQuickSale('Il DCO non ha completato la creazione delle righe prodotto aggiuntive. Nessun invio eseguito.',false);
      if(out?.error==='DCO_LOTTERY_FIELD_NOT_FOUND')return dcoAbortQuickSale('Il campo Codice lotteria non è stato trovato nella pagina DCO. Nessun invio fiscale eseguito: controlla il campo sul portale e riprova.',false);
      throw new Error(out?.error||'Automazione DCO non disponibile');
    }
    if(out.verifyFallback&&!state.verifyFallbackLogged){state.verifyFallbackLogged=true;dcoRememberRoute(out.url||DCO_URLS.service,'diagnostic:android-verify-fallback-clicked')}
    const timingActions={'open-wizard2':['wizard-open','Apertura documento'],'retry-open-wizard2':['wizard-open','Apertura documento'],'filled':['cart-filled','Carrello trasferito'],'verify-clicked':['verify-clicked','Verifica dati fiscali'],'final-page-clicked':['final-page','Pagina finale'],'retry-final-page':['final-page','Pagina finale'],'understood':['understood','Conferma informativa'],'final-ready':['final-armed','Invio finale pronto'],'confirm-clicked':['confirm-clicked','Conferma definitiva'],'proceed-clicked':['proceed-clicked','Richiesta emissione AdE']};
    if(out.action&&timingActions[out.action])dcoTimingMark(state,timingActions[out.action][0],timingActions[out.action][1]);
    if(out.finalReady&&!state.finalArmed){
      state.finalArmed=true;state.stage='final-armed';state.lastProgress=Date.now();dcoTimingMark(state,'final-armed','Invio finale pronto');
      localStorage.setItem(K.dcoAutoLock,JSON.stringify({token:state.token,total:euro(state.draft.total),createdAt:new Date().toISOString(),stage:'final-armed'}));
      renderDcoConnectionStatus();dcoQuickSetStatus('Preparazione invio finale…');return;
    }
    if(out.action&&out.action!==state.lastAction){
      state.lastAction=out.action;state.lastProgress=Date.now();
      const labels={'open-wizard2':'Apertura documento commerciale…','retry-open-wizard2':'Apertura documento commerciale…','filled':'Carrello trasferito al DCO…','verify-clicked':'Verifica dati fiscali…','final-page-clicked':'Preparazione conferma finale…','retry-final-page':'Preparazione conferma finale…','understood':'Apertura conferma finale…','final-ready':'Preparazione invio finale…','confirm-clicked':'Conferma definitiva…','proceed-clicked':'Richiesta di emissione all’Agenzia delle Entrate…'};
      dcoQuickSetStatus(labels[out.action]||'Emissione DCO in corso…');
    }
    if(out.confirmClicked&&!state.confirmClicked){state.confirmClicked=true;state.lastProgress=Date.now();dcoTimingMark(state,'confirm-clicked','Conferma definitiva')}
    if(out.proceedClicked&&!state.proceedClicked){
      state.proceedClicked=true;state.stage='proceed-clicked';state.lastProgress=Date.now();dcoTimingMark(state,'proceed-clicked','Richiesta emissione AdE');
      localStorage.setItem(K.dcoAutoLock,JSON.stringify({token:state.token,total:euro(state.draft.total),createdAt:new Date().toISOString(),stage:'proceed-clicked'}));
      renderDcoConnectionStatus();
    }
    if(out.emitted||out.documentId){
      const id=dcoAcceptAutoDocumentId(state,out.documentId,`runner-${out.evidenceSource||'visible'}`);
      if(out.emitted&&!out.documentId&&!state.emissionVisibleAt){state.emissionVisibleAt=Date.now();dcoRememberRoute(out.url||DCO_URLS.service,'diagnostic:emission-visible-waiting-id');dcoQuickSetStatus('Emissione completata dal portale. Attendo l’identificativo del nuovo documento…')}
      if(id&&!state.documentId){
        const meta={documentId:id,documentNumber:'',documentDate:''};
        state.documentId=id;state.stage='emitted';state.lastProgress=Date.now();dcoTimingMark(state,'emitted-detected','Emissione rilevata');
        localStorage.setItem(K.dcoAutoLock,JSON.stringify({token:state.token,total:euro(state.draft.total),createdAt:new Date().toISOString(),stage:'emitted',documentId:id}));
        dcoQuickSetStatus(`Documento DCO-${id} emesso. Recupero numero ufficiale e stampa immediata…`);
        await dcoFinalizeEmittedSale(meta);
        return;
      }
    }
    if(out.pdf?.documentId){
      const pdfId=dcoAcceptAutoDocumentId(state,out.pdf.documentId,'runner-pdf');
      if(pdfId){await dcoFinalizeEmittedSale({documentId:pdfId});return}
    }
  }catch(e){
    const message=e?.message||String(e),state=dcoAutoSale;
    if(state&&message==='Risposta del browser DCO scaduta.'){
      state.scriptTimeouts=Number(state.scriptTimeouts||0)+1;
      if(!state.finalArmed&&!state.proceedClicked){
        dcoQuickSetStatus('Il portale sta cambiando pagina… attesa del caricamento DCO.');
        return;
      }
      dcoAbortQuickSale('Il comando finale potrebbe essere stato ricevuto, ma il browser non ha restituito l’esito.',false);
      return;
    }
    dcoAbortQuickSale(message,false);
  }finally{dcoAutoTickBusy=false}
}

async function dcoReconnectFisconlineSale(){
  const state=dcoAutoSale;
  if(!state||state.finalArmed||state.proceedClicked)return dcoAbortQuickSale('La sessione DCO è scaduta in una fase non ripetibile automaticamente. Verifica il portale prima di riprovare.',true);
  const credentials=await dcoLoadFisconlineCredentials();
  if(!credentials){dcoAbortQuickSale('Sessione DCO scaduta e credenziali Fisconline non disponibili su questo dispositivo. Configura Fisconline oppure usa l’accesso alternativo SPID/CIE/CNS.',true);showView('dcolab');renderDcoFisconlineStatus('Salva le credenziali Fisconline per riattivare il collegamento automatico, oppure apri l’accesso alternativo SPID/CIE/CNS.','error');return}
  dcoTimingMark(state,'session-reconnect-start','Ricollegamento Fisconline');dcoPendingEmissionTiming=state.timing||dcoPendingEmissionTiming;
  dcoStopAutoTimer();dcoClearBrowserLoadGuard();dcoClearAutomationWaiters('Ricollegamento automatico Fisconline.');
  dcoDisposeBrowser('Sessione DCO scaduta durante la vendita: ricreo la WebView mantenendo il flusso di vendita.');dcoClearConnected();
  dcoAutoSale=null;dcoAutoTickBusy=false;localStorage.removeItem(K.dcoAutoLock);
  dcoResumeSaleAfterConnect=true;isIssuing=true;renderCart();dcoQuickSetStatus('Sessione DCO scaduta. Ricollegamento Fisconline automatico…');
  const ok=await dcoStartConnection('fisconline',{credentials});
  if(!ok){dcoResumeSaleAfterConnect=false;isIssuing=false;renderCart();dcoQuickFinishProgress('Ricollegamento Fisconline non riuscito. Controlla le credenziali in Documento Commerciale Online.','error')}
}

let dcoFailureSnapshot=null,dcoFailureReason='';
function dcoOpenFailureChoice(snapshot,message){dcoFailureSnapshot=snapshot?JSON.parse(JSON.stringify(snapshot)):null;dcoFailureReason=String(message||'Emissione DCO non completata.');const dlg=$('dcoFailureDialog'),msg=$('dcoFailureMessage');if(msg)msg.textContent=dcoFailureReason;if(dlg&&!dlg.open)dlg.showModal()}
function dcoClearFailureChoice(){dcoFailureSnapshot=null;dcoFailureReason='';const dlg=$('dcoFailureDialog');if(dlg?.open)dlg.close()}
function dcoAbortQuickSale(message,sessionExpired=false){
  const state=dcoAutoSale,snapshot=state?.snapshot||dcoLoadPendingSale(),uncertain=!!state?.finalArmed||!!state?.proceedClicked||!!loadObjectSafe(K.dcoAutoLock,null),timing=state?.timing||dcoPendingEmissionTiming;dcoTimingMark(timing,'aborted','Blocco/interruzione');const timingResult=dcoPersistEmissionTiming(timing,{outcome:'aborted',printError:String(message||'')});
  dcoStopAutoTimer();dcoClearBrowserLoadGuard();dcoBrowserLoading=false;dcoClearAutomationWaiters(message);dcoResetOperationContext(dcoBrowserRef,'',false).catch(()=>{});dcoAutoSale=null;dcoAutoTickBusy=false;isIssuing=false;
  if(sessionExpired)dcoClearConnected();
  // Il lock resta una protezione SOLO durante il tentativo. A tentativo concluso
  // la vendita viene trasferita nel registro emergenze oppure resta in cassa per il retry.
  localStorage.removeItem(K.dcoAutoLock);localStorage.removeItem(K.dcoPendingSale);
  if(uncertain){
    const emergencyResult=emergencyHandleDcoAbort(snapshot,true,message);if(snapshot&&dcoCurrentCartMatchesSnapshot(snapshot))resetSale();
    if(!dcoPdfRetryBusy){dcoRemoveEmissionOverlay(dcoBrowserRef);try{dcoBrowserRef?.hide?.()}catch{}}
    renderCart();dcoQuickFinishProgress(`${message} Esito fiscale incerto: l’operazione è stata salvata come ESITO DA VERIFICARE. Non può essere reinviata finché non controlli il DCO; puoi continuare con nuove vendite.`,'warning');dcoRenderQuickTiming(timingResult);renderDcoConnectionStatus();emergencyRenderSettingsSummary();return
  }
  if(!dcoPdfRetryBusy){dcoRemoveEmissionOverlay(dcoBrowserRef);try{dcoBrowserRef?.hide?.()}catch{}}
  renderCart();dcoQuickFinishProgress(`${message} Nessun invio finale rilevato: scegli se riprovare oppure registrare la vendita come emergenza.`,'error');dcoRenderQuickTiming(timingResult);renderDcoConnectionStatus();dcoOpenFailureChoice(snapshot,message)
}
async function dcoStartAutomaticSale(options={}){
  if(dcoVoidLab)return toast('Attendi la conclusione dell’annullamento DCO',3500);
  const requestedEmergency=options?.emergencyRecord||emergencyFind(dcoEmergencyActiveId||localStorage.getItem(K.emergencyActive)||'');
  if(!dcoRequireBusinessProfile()){if(requestedEmergency){emergencyUpdateRow(requestedEmergency.id,{status:'da_regolarizzare',reason:'Dati attività da completare prima della regolarizzazione.'});emergencyClearActive()}return}
  const draft=requestedEmergency?emergencyBuildDraftFromSnapshot(requestedEmergency.snapshot):dcoBuildDraftPayload();if(!draft.ok){if(requestedEmergency){emergencyUpdateRow(requestedEmergency.id,{status:'da_regolarizzare',reason:draft.error});emergencyClearActive()}alert(draft.error);return}
  // Nessun controllo preventivo della sessione. Se il portale ha realmente
  // terminato la sessione, dcoAutoTick riceve AUTH_REQUIRED/SESSION_EXPIRED e
  // dcoReconnectFisconlineSale() effettua il login automatico prima dell'invio finale.
  if(!dcoHasSessionMarker()){
    if(dcoAuthMode()==='fisconline'){
      const credentials=await dcoLoadFisconlineCredentials();
      if(credentials){
        dcoFisconlineConfigured=true;dcoResumeSaleAfterConnect=true;dcoTimingMark(dcoPendingEmissionTiming,'session-reconnect-start','Ricollegamento Fisconline');isIssuing=true;renderCart();dcoQuickOpenProgress();dcoQuickSetStatus('Apertura automatica della sessione Fisconline…');
        const ok=await dcoStartConnection('fisconline',{credentials});
        if(!ok){dcoResumeSaleAfterConnect=false;isIssuing=false;renderCart();if(requestedEmergency){emergencyUpdateRow(requestedEmergency.id,{status:'da_regolarizzare',reason:'Ricollegamento Fisconline non avviato.'});emergencyClearActive()}dcoQuickFinishProgress('Impossibile aprire automaticamente Fisconline. Controlla la configurazione.','error')}
        return
      }
      if(requestedEmergency){emergencyUpdateRow(requestedEmergency.id,{status:'da_regolarizzare',reason:'Fisconline non configurato su questo dispositivo.'});emergencyClearActive()}
      dcoFisconlineConfigured=false;renderDcoAuthUi();renderDcoFisconlineStatus('Configura Fisconline per l’accesso automatico. In alternativa puoi aprire manualmente SPID/CIE/CNS.','error');showView('dcolab');return
    }
    if(requestedEmergency){emergencyUpdateRow(requestedEmergency.id,{status:'da_regolarizzare',reason:'DCO da ricollegare prima della regolarizzazione.'});emergencyClearActive()}
    alert('Prima collega il DCO con SPID/CIE/CNS da Impostazioni → Documento Commerciale Online.');showView('dcolab');return
  }
  const snapshot=requestedEmergency?{...requestedEmergency.snapshot,emergencyOperationId:requestedEmergency.id,emergencyOriginalDate:requestedEmergency.snapshot?.date||requestedEmergency.createdAt||''}:dcoStorePendingSale();if(!snapshot)return alert('Impossibile preparare la vendita DCO.');if(requestedEmergency)localStorage.setItem(K.dcoPendingSale,JSON.stringify(snapshot));isIssuing=true;renderCart();dcoQuickOpenProgress();dcoQuickSetStatus('Connessione alla sessione DCO…');const timing=dcoPendingEmissionTiming||dcoTimingBegin(),previous=dcoLoadLastDocument();dcoAutoSale={token:uid(),draft,snapshot,stage:'opening',startedAt:Date.now(),lastProgress:Date.now(),lastNavigationAt:0,lastAction:'',scriptTimeouts:0,finalArmed:false,proceedClicked:false,confirmClicked:false,documentId:'',documentNumber:'',documentDate:'',previousDocumentId:String(previous?.documentId||'').replace(/[^0-9]/g,''),previousDocumentNumber:String(previous?.documentNumber||previous?.receiptNumber||''),ignoredEvidence:{},acceptedEvidenceId:'',pdfRecoveryStarted:false,pdfRecoveryStartedAt:0,timing};dcoTimingMark(dcoAutoSale,'automation-start','Avvio automazione DCO');if(dcoAutoSale.previousDocumentId)dcoRememberRoute(DCO_URLS.service,`diagnostic:previous-document-baseline:${dcoAutoSale.previousDocumentId}`);
  try{
    // v1.14.64: SOLO Android passa dalla InAppBrowser hidden alla WebView
    // attiva durante l'emissione, coperta da un overlay CassaIQ. Il percorso iOS
    // resta esattamente quello della v1.14.63, che nei test e' gia' stabile/rapido.
    const keepDcoVisibleDuringEmission=isIosApp();
    const androidActiveDuringEmission=printerPlatform()==='android';
    dcoClearBrowserLoadGuard();dcoBrowserLoading=false;
    if(dcoBrowserRef){
      if(androidActiveDuringEmission){
        // Android: reset e controllo Home mentre il browser e' ancora nascosto,
        // poi maschera CassaIQ e show(). In questo modo non compare il wizard.
        const context=await dcoResetOperationContext(dcoBrowserRef,dcoAutoSale.token,true),healthyHome=!!(context&&context.readyState==='complete'&&context.logged&&context.home);
        if(healthyHome){dcoRememberRoute(context.url||DCO_URLS.service,'diagnostic:operation-context-reset-home-reused')}
        else{
          dcoRememberRoute(context?.url||DCO_URLS.service,'diagnostic:operation-context-reset-navigate-home');
          await dcoExecScript(dcoBrowserRef,`(function(){location.href=${JSON.stringify(DCO_URLS.service)};return true})()`,5000).catch(()=>{dcoNavigate(dcoBrowserRef,DCO_URLS.service)})
        }
        await dcoMaskAndActivateBrowser(dcoBrowserRef,'Preparazione del documento commerciale…');
        dcoRememberRoute(context?.url||DCO_URLS.service,'diagnostic:android-active-webview-shown');
      }else{
        // iOS/web: comportamento v1.14.63 invariato.
        try{keepDcoVisibleDuringEmission?dcoBrowserRef.show?.():dcoBrowserRef.hide?.()}catch{}
        const context=await dcoResetOperationContext(dcoBrowserRef,dcoAutoSale.token,true),healthyHome=!!(context&&context.readyState==='complete'&&context.logged&&context.home);
        if(healthyHome){dcoRememberRoute(context.url||DCO_URLS.service,'diagnostic:operation-context-reset-home-reused')}
        else{
          dcoRememberRoute(context?.url||DCO_URLS.service,'diagnostic:operation-context-reset-navigate-home');
          await dcoExecScript(dcoBrowserRef,`(function(){location.href=${JSON.stringify(DCO_URLS.service)};return true})()`,5000).catch(()=>{dcoNavigate(dcoBrowserRef,DCO_URLS.service)})
        }
        await dcoShowEmissionOverlay(dcoBrowserRef,'Preparazione del documento commerciale…','loading');
      }
      dcoStartLivePoll(dcoBrowserRef)
    }else{
      if(androidActiveDuringEmission){
        // Android: crea nascosto, installa prima la maschera e poi attiva.
        dcoCreateBrowser(DCO_URLS.service,true);
        setTimeout(()=>{const ref=dcoBrowserRef;if(ref)dcoMaskAndActivateBrowser(ref,'Preparazione del documento commerciale…')},500)
      }else{
        // iOS/web: comportamento v1.14.63 invariato.
        dcoCreateBrowser(DCO_URLS.service,!keepDcoVisibleDuringEmission);
        setTimeout(()=>dcoShowEmissionOverlay(dcoBrowserRef,'Preparazione del documento commerciale…','loading'),500)
      }
    };
    // v1.14.54: runner adattivo. Durante i passaggi preparatori controlla il DCO
    // ogni 350 ms; appena l'invio viene armato torna al ritmo prudente di 1100 ms.
    // I timeout complessivi, il lock anti-doppia-emissione e la fase irreversibile
    // restano invariati. Gli eventi loadstop/route continuano inoltre a provocare
    // un controllo immediato quando la pagina segnala realmente un avanzamento.
    dcoStopAutoTimer();dcoScheduleAutoTick(dcoBrowserRef,350);
  }catch(e){dcoAbortQuickSale(`Impossibile avviare il DCO: ${e.message||e}`,false)}
}

function dcoHandlePage(current,eventType){
  const safe=dcoSafeUrl(current),lower=String(current||'').toLowerCase();
  dcoRememberRoute(current,eventType||'loadstop');
  const documentId=dcoExtractDocumentId(current);
  if(documentId){
    if(dcoPdfRetryBusy)return;
    if(dcoAutoSale){
      const accepted=dcoAcceptAutoDocumentId(dcoAutoSale,documentId,`route-${eventType||'page'}`);
      if(accepted){dcoAutoSale.documentId=accepted;dcoAutoSale.stage='emitted';dcoAutoSale.lastProgress=Date.now();dcoQuickSetStatus(`Documento DCO-${accepted} emesso. Recupero numero ufficiale e stampa immediata…`);dcoFinalizeEmittedSale({documentId:accepted}).catch(error=>dcoAbortQuickSale(`Documento emesso, ma stampa immediata non completata: ${error.message||error}`,false));return}
      if(!dcoAutoSale.proceedClicked){dcoBrowserLoading=false;dcoClearBrowserLoadGuard();dcoScheduleAutoTick(dcoBrowserRef,120)}
      return
    }
    if(dcoVoidLab){const accepted=dcoVoidAcceptDocumentId(dcoVoidLab,documentId,`route-${eventType||'page'}`);if(accepted){dcoVoidLab.documentId=accepted;dcoVoidLab.stage='emitted';dcoVoidLab.lastProgress=Date.now();dcoFinalizeVoid({documentId:accepted}).catch(error=>dcoVoidAbort(`Documento di annullo rilevato, ma finalizzazione non completata: ${error.message||error}`,true,{keepBrowser:true}));return}dcoScheduleVoidLabTick(dcoBrowserRef,160);return}
    dcoDownloadOfficialPdfNatively(dcoBrowserRef,documentId,current).catch(error=>{dcoLogPdfMeta(`download nativo fallito DCO-${documentId}`,{error:String(error?.message||error)});dcoMarkPdfPending(documentId,error?.message||error)});return
  }
  if(dcoAutoSale){dcoShowEmissionOverlay(dcoBrowserRef,dcoAutoSale.documentId?`Documento DCO-${dcoAutoSale.documentId} emesso. Recupero PDF e preparazione stampa…`:'Emissione automatica in corso…','loading');dcoAutoTick(dcoBrowserRef);return}
  if(dcoVoidLab){dcoScheduleVoidLabTick(dcoBrowserRef,eventType==='loadstop'?120:420);return}
  if(dcoConnectionPending){dcoConnectionTick(dcoBrowserRef,current);return}
  // Sessione già pronta: nessun polling permanente.
  dcoStopLivePoll();
  dcoInjectLabBar(dcoBrowserRef);dcoScheduleDeepCapture(dcoBrowserRef);
  if(lower.includes('/ser/documenticommercialionline/nonauth.html'))return dcoSetResult('error','Il DCO non ha ancora ricevuto l’utenza di lavoro. Nel browser tocca “Verifica”, poi “Utenza”; non chiudere la finestra.');
  if(lower.includes('#/generazione/wizard4'))return dcoSetResult(dcoRealTestEnabled?'warning':'ok',dcoRealTestEnabled?'Pagina Conferma e stampa aperta. Arma l’emissione reale solo per una vendita effettiva, poi usa Conferma e Procedi.':'Pagina finale aperta. L’emissione è bloccata.');
  if(lower.includes('#/generazione/wizard3'))return dcoSetResult('ok','Pagina Verifica dati aperta. Controlla il riepilogo, poi usa “Mappa conferma”.');
  if(lower.includes('#/generazione/wizard2'))return dcoSetResult('ok','Pagina Dati documento commerciale aperta. Premi “Compila carrello” nella barra CassaIQ.');
  if(lower.includes('#/generazione/'))return dcoSetResult('ok','Schermata conclusiva DCO aperta.');
  if(lower.includes('/ser/documenticommercialionline/'))return dcoSetResult('ok',`Documento Commerciale Online autorizzato: ${safe}. Premi “Genera” nella barra CassaIQ.`);
  if(lower.includes('/instr/instradamentofcweb/home'))return dcoSetResult('loading','Pagina di verifica sessione aperta. Attendi il controllo; se la sessione è valida usa “Utenza”.');
  if(lower.includes('/instr/instradamentofcweb/wizard'))return dcoSetResult('loading','Wizard utenza aperto. Attendi il caricamento e usa i comandi nella barra CassaIQ senza chiudere.');
  if(lower.includes('iampe.agenziaentrate.gov.it')||lower.includes('portale.agenziaentrate.gov.it'))return dcoSetResult('loading','Completa l’autenticazione. Dopo il ritorno all’Agenzia usa la barra CassaIQ: “Verifica” → “Utenza” → “DCO”.');
  dcoSetResult('loading',dcoOfficialUrl(current)?`Pagina ufficiale: ${safe}`:'Autenticazione esterna in corso. CassaIQ non analizza il sito del gestore SPID.');
}
function dcoOpenFlow(label,startUrl){
  const plugin=dcoPlugin();
  if(!plugin?.open){dcoSetResult('error','Modulo InAppBrowser non disponibile. Esegui npm install e npm run ios:sync oppure npm run sync.');return}
  const draft=dcoBuildDraftPayload();
  if((startUrl===DCO_URLS.entry||startUrl===DCO_URLS.service)&&!draft.ok){dcoSetResult('error',draft.error);renderDcoDraftSummary();return}
  if(dcoBrowserRef){try{dcoBrowserRef.show?.();dcoSetResult('loading','Sessione già aperta. Continua nella stessa finestra usando la barra CassaIQ in basso.');return}catch{}}
  dcoRouteHistory=[];dcoLastDiagnostic=null;dcoClearCaptureTimers();
  const initial=startUrl||DCO_URLS.login;dcoSetResult('loading',`Apertura ${label}…`);
  dcoCreateBrowser(initial,false);
}

/* --------- Diagnostica assistenza manuale v1.15.5 ---------
   Il cliente invia solo quando richiesto dall'assistenza.
   Nessun invio automatico o in background. */
const SUPPORT_DIAGNOSTIC_MAX_ARRAY=500;
const SUPPORT_DIAGNOSTIC_REDACT_KEY=/(password|passwd|passcode|pin(?:code)?|token|secret|authorization|cookie|credential|api[_-]?key|anon[_-]?key|access[_-]?token|refresh[_-]?token)/i;
function supportDiagnosticSanitize(value,depth=0){
  if(depth>10)return'[omesso: profondità]';
  if(value==null||typeof value==='number'||typeof value==='boolean')return value;
  if(typeof value==='string'){
    let s=value.slice(0,12000);
    s=s.replace(/Bearer\s+[A-Za-z0-9._~+\/=-]+/gi,'Bearer [REDACTED]');
    s=s.replace(/sb_(?:publishable|secret)_[A-Za-z0-9_-]+/gi,'sb_[REDACTED]');
    s=s.replace(/\beyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b/g,'[JWT REDACTED]');
    return s
  }
  if(Array.isArray(value))return value.slice(-SUPPORT_DIAGNOSTIC_MAX_ARRAY).map(v=>supportDiagnosticSanitize(v,depth+1));
  if(typeof value==='object'){
    const out={};
    for(const [k,v] of Object.entries(value)){
      if(SUPPORT_DIAGNOSTIC_REDACT_KEY.test(String(k))){out[k]='[REDACTED]';continue}
      out[k]=supportDiagnosticSanitize(v,depth+1)
    }
    return out
  }
  return String(value).slice(0,1000)
}
function supportDiagnosticPayload(){
  const session=getSession(),primary=kitchenPrinterOptions(),secondary=kitchenSecondPrinterOptions();
  const diagnostic=dcoLastDiagnostic||{
    capturedAt:new Date().toISOString(),
    routes:dcoRouteHistory.slice(),
    page:null,
    emissionTimings:dcoTimingLoadHistory()
  };
  return supportDiagnosticSanitize({
    schema_version:1,
    app_name:'CassaIQ RT',
    app_version:APP_VERSION,
    build:APP_BUILD,
    platform:String(APP_CONFIG.platform||'web'),
    captured_at:new Date().toISOString(),
    owner_user_id:session?.user?.id||null,
    summary:'Invio manuale richiesto dall’assistenza CassaIQ',
    state:{
      fiscal_mode:fiscalMode(),
      online:navigator.onLine!==false,
      dco_session_marker:!!dcoHasSessionMarker(),
      dco_connection_pending:!!dcoConnectionPending,
      dco_connection_phase:String(dcoConnectionPhase||''),
      dco_sale_active:!!dcoAutoSale,
      emergency_pending:Number(emergencyPendingRows().length||0),
      kitchen_printer_1_enabled:!!primary.enabled,
      kitchen_printer_2_enabled:!!secondary.enabled,
      kitchen_printer_2_scope:String(secondary.scope||''),
      kitchen_printer_2_routing:String(secondary.routing||''),
      lan_pending_orders:Number(lanLocalOrders().filter(o=>o?.cloudDirty!==false).length||0),
      authorized_clients:Number(lanAuthorizedClientIds().length||0),
      last_cloud_sync:String(localStorage.getItem(K.lastSync)||'')
    },
    diagnostic
  })
}
function supportDiagnosticCodeFromRpc(data){
  if(typeof data==='string')return data.replace(/^"|"$/g,'').trim();
  if(Array.isArray(data)&&data.length){
    const first=data[0];
    if(typeof first==='string')return first;
    if(first&&typeof first==='object')return String(first.code||first.short_code||first.cassaiq_submit_diagnostic||'')
  }
  if(data&&typeof data==='object')return String(data.code||data.short_code||data.cassaiq_submit_diagnostic||'');
  return''
}
async function supportSubmitDiagnostic(){
  if(!getSession()?.user?.id)throw new Error('Accedi prima all’Area utente per inviare la diagnostica.');
  const payload=supportDiagnosticPayload();
  const result=await cloudRpc('cassaiq_submit_diagnostic',{p_payload:payload});
  const code=supportDiagnosticCodeFromRpc(result);
  if(!/^CQ-[A-Z0-9]{6,12}$/i.test(code))throw new Error('Diagnostica inviata, ma non è stato restituito un codice valido.');
  return code.toUpperCase()
}

function initDcoLabView(){
  const status=$('dcoPluginStatus');if(!status)return;
  renderDcoDraftSummary();renderDcoRealTestStatus();renderDcoDocumentStatus();renderDcoConnectionStatus();dcoRenderTimingHistory();
  const available=!!dcoPlugin()?.open,printerAvailable=!!printerNativePlugin();
  status.className=`printer-plugin-status ${available&&printerAvailable?'ok':'error'}`;
  status.textContent=available&&printerAvailable?'Browser protetto e modulo PDF/ESC-POS disponibili. Dopo l’emissione CassaIQ registra la vendita e stampa subito il documento commerciale sulla stampante di rete. Il PDF ufficiale resta opzionale.':'Modulo incompleto. Esegui npm install e sincronizza nuovamente il progetto nativo.';
  try{dcoFillBusinessForm()}catch(e){console.error('Inizializzazione dati attività DCO',e)}
  const auto=$('dcoAutoPrint'),ip=$('dcoPrinterIp'),port=$('dcoPrinterPort');
  if(auto){auto.checked=localStorage.getItem(K.dcoAutoPrint)!=='0';auto.onchange=()=>localStorage.setItem(K.dcoAutoPrint,auto.checked?'1':'0')}
  if(ip){ip.value=localStorage.getItem(K.printerTestIp)||'192.168.1.201';ip.onchange=()=>localStorage.setItem(K.printerTestIp,ip.value.trim())}
  if(port){port.value=localStorage.getItem(K.printerTestPort)||'9100';port.onchange=()=>localStorage.setItem(K.printerTestPort,port.value)}
  const kitchenEnabled=$('kitchenPrinterEnabled'),kitchenIp=$('kitchenPrinterIp'),kitchenPort=$('kitchenPrinterPort'),kitchenEnabled2=$('kitchenPrinter2Enabled'),kitchenIp2=$('kitchenPrinter2Ip'),kitchenPort2=$('kitchenPrinter2Port'),kitchenScope2=$('kitchenPrinter2Scope'),kitchenRouting2=$('kitchenPrinter2Routing');
  kitchenApplyConfig({});
  if(kitchenEnabled)kitchenEnabled.onchange=()=>localStorage.setItem(K.kitchenPrinterEnabled,kitchenEnabled.checked?'1':'0');
  if(kitchenIp)kitchenIp.onchange=()=>localStorage.setItem(K.kitchenPrinterIp,kitchenIp.value.trim());
  if(kitchenPort)kitchenPort.onchange=()=>localStorage.setItem(K.kitchenPrinterPort,kitchenPort.value||'9100');
  if(kitchenEnabled2)kitchenEnabled2.onchange=()=>localStorage.setItem(K.kitchenPrinter2Enabled,kitchenEnabled2.checked?'1':'0');
  if(kitchenIp2)kitchenIp2.onchange=()=>localStorage.setItem(K.kitchenPrinter2Ip,kitchenIp2.value.trim());
  if(kitchenPort2)kitchenPort2.onchange=()=>localStorage.setItem(K.kitchenPrinter2Port,kitchenPort2.value||'9100');
  if(kitchenScope2)kitchenScope2.onchange=()=>{localStorage.setItem(K.kitchenPrinter2Scope,kitchenScope2.value);kitchenRenderSecondCategories()};
  if(kitchenRouting2)kitchenRouting2.onchange=()=>localStorage.setItem(K.kitchenPrinter2Routing,kitchenRouting2.value);
  kitchenRenderSecondCategories();kitchenLoadConfigFromCloud(true).catch(()=>{});
  localStorage.setItem(K.dcoAuthMode,'fisconline');
  renderConfigFiscalMode();renderDcoAuthUi();dcoRefreshFisconlineConfigured().then(()=>dcoMaybeShowFisconlinePasswordReminder()).catch(()=>{});
  if(dcoLabInitialized)return;dcoLabInitialized=true;
  if($('configUseEpson'))$('configUseEpson').onclick=()=>setFiscalMode('epson');
  if($('configUseDco'))$('configUseDco').onclick=()=>setFiscalMode('dco');
  if($('configEpsonTest'))$('configEpsonTest').onclick=configTestEpson;
  if($('configEpsonSave'))$('configEpsonSave').onclick=configSaveEpson;
  if($('configNetworkPrinterTest'))$('configNetworkPrinterTest').onclick=configTestNetworkPrinter;
  if($('configKitchenPrinterTest'))$('configKitchenPrinterTest').onclick=kitchenTestPrinter;
  if($('configKitchenPrinter2Test'))$('configKitchenPrinter2Test').onclick=kitchenTestSecondPrinter;
  if($('configKitchenPrinterSave'))$('configKitchenPrinterSave').onclick=kitchenSaveConfig;
  if($('configBusinessSave'))$('configBusinessSave').onclick=()=>dcoSaveBusinessProfile(true);
  const logoInput=$('businessReceiptLogoInput'),logoChoose=$('businessReceiptLogoChoose'),logoTest=$('businessReceiptLogoTest'),logoRemove=$('businessReceiptLogoRemove'),logoEnabled=$('businessReceiptLogoEnabled');
  if(logoInput)logoInput.onchange=async e=>{
    const file=e.target.files?.[0];if(!file)return;
    printerSetBusy(logoChoose,true,'Ottimizzo logo…');
    try{dcoReceiptLogoDraftData=await dcoReceiptLogoPrepareFile(file);dcoReceiptLogoDraftEnabled=true;dcoReceiptLogoRender();toast('Logo pronto. Premi “Salva dati attività”.',3800)}
    catch(err){alert(err.message||String(err))}
    finally{logoInput.value='';printerSetBusy(logoChoose,false)}
  };
  if(logoTest)logoTest.onclick=dcoTestReceiptLogo;
  if($('businessReceiptLogoEpsonSend'))$('businessReceiptLogoEpsonSend').onclick=dcoSendReceiptLogoToEpson;
  if($('businessReceiptLogoEpsonDisable'))$('businessReceiptLogoEpsonDisable').onclick=dcoDisableReceiptLogoOnEpson;
  if(logoRemove)logoRemove.onclick=()=>{if(!dcoReceiptLogoDraftData)return toast('Nessun logo da rimuovere.');dcoReceiptLogoDraftData='';dcoReceiptLogoDraftEnabled=false;dcoReceiptLogoRender();toast('Logo rimosso dalla configurazione. Salva per confermare.',3500)};
  if(logoEnabled)logoEnabled.onchange=()=>{dcoReceiptLogoDraftEnabled=!!logoEnabled.checked&&!!dcoReceiptLogoDraftData};
  for(const id of Object.values(DCO_BUSINESS_FIELDS)){const el=$(id);if(el)el.addEventListener('input',()=>{el.classList.remove('invalid');const profile=dcoBusinessProfileFromForm(),check=dcoBusinessValidation(profile),statusEl=$('configBusinessStatus'),dot=$('configBusinessDot'),connect=$('dcoConnectQuick'),spid=$('dcoSpidConnect'),saveDco=$('configUseDcoAndSave');if(statusEl){statusEl.className=`config-status-line ${check.ok?'ok':'error'}`;statusEl.textContent=check.ok?'Dati completi: salva per abilitarli.':`Da completare: ${check.missing.join(', ')}.`}if(dot)dot.className=`mini-status-dot ${check.ok?'ok':'error'}`;if(connect)connect.disabled=true;if(spid)spid.disabled=true;if(saveDco)saveDco.disabled=true})}
  if($('configUseDcoAndSave'))$('configUseDcoAndSave').onclick=configSaveDco;
  if($('dcoFisconlineSave'))$('dcoFisconlineSave').onclick=()=>dcoSaveFisconlineCredentials(true);
  if($('dcoFisconlineClear'))$('dcoFisconlineClear').onclick=()=>{if(confirm('Eliminare le credenziali Fisconline salvate su questo dispositivo?'))dcoClearFisconlineCredentials()};
  if($('dcoFisconlineRenewNow'))$('dcoFisconlineRenewNow').onclick=()=>fisRenewManualTest();
  if($('dcoOpenPasswordRenewal'))$('dcoOpenPasswordRenewal').onclick=dcoOpenPasswordRenewalExternal;
  if($('dcoSaveRenewedPassword'))$('dcoSaveRenewedPassword').onclick=()=>dcoUpdateFisconlinePasswordOnly();
  if($('dcoCredentialIssueClose'))$('dcoCredentialIssueClose').onclick=()=>{const dlg=$('dcoCredentialIssueDialog');if(dlg?.open)dlg.close()};
  if($('dcoCredentialEdit'))$('dcoCredentialEdit').onclick=()=>{const dlg=$('dcoCredentialIssueDialog');if(dlg?.open)dlg.close();showView('dcolab');setTimeout(()=>{const panel=$('dcoFisconlinePanel');panel?.scrollIntoView?.({behavior:'smooth',block:'center'});const pass=$('dcoFisconlinePassword');pass?.focus?.()},150)};
  if($('dcoConnectQuick'))$('dcoConnectQuick').onclick=()=>dcoSaveAndStartFisconline();
  if($('dcoSpidConnect'))$('dcoSpidConnect').onclick=()=>dcoStartConnection('spid');
  if($('dcoDisconnectQuick'))$('dcoDisconnectQuick').onclick=()=>{if(dcoAutoSale)return;dcoConnectionAttempt+=1;dcoConnectionPending=false;dcoConnectionCredentials=null;dcoConnectionTickBusy=false;dcoConnectionReadyChecks=0;dcoConnectionLastReadyAt=0;dcoConnectionRouteAttempts=0;dcoConnectionLastRouteAt=0;dcoConnectionAuthenticatedAt=0;dcoConnectionPortalReadyChecks=0;dcoConnectionWizardStartedAt=0;dcoDisposeBrowser('Collegamento DCO rimosso.');dcoClearConnected();renderDcoConnectionStatus(dcoFisconlineConfigured?'Sessione DCO rimossa. Fisconline resta configurato e potrà ricollegarsi automaticamente alla prossima emissione.':'Sessione DCO rimossa. Configura Fisconline per il ricollegamento automatico.','warning')};
  if($('dcoFiscalMode'))$('dcoFiscalMode').onchange=e=>setFiscalMode(e.target.value);
  if($('dcoClearPendingLock'))$('dcoClearPendingLock').onclick=()=>{if(!confirm('Hai verificato nel portale se il documento è stato emesso? Sbloccare senza controllo può causare duplicazioni.'))return;localStorage.removeItem(K.dcoAutoLock);localStorage.removeItem(K.dcoPendingSale);renderDcoConnectionStatus('Blocco rimosso dopo verifica manuale.','ok');renderCart()};
  if($('dcoQuickProgressClose'))$('dcoQuickProgressClose').onclick=()=>{const dlg=$('dcoQuickProgressDialog');if(dlg?.open)dlg.close()};
  if($('dcoQuickProgressDialog'))$('dcoQuickProgressDialog').addEventListener('cancel',e=>{if(dcoAutoSale)e.preventDefault()});
  if($('dcoOpenCredentials'))$('dcoOpenCredentials').onclick=()=>{dcoStorePendingSale();dcoOpenFlow('accesso Fisconline',DCO_URLS.login)};
  if($('dcoOpenIdentity'))$('dcoOpenIdentity').onclick=()=>dcoStartConnection('spid');
  if($('dcoOpenService'))$('dcoOpenService').onclick=()=>{dcoStorePendingSale();dcoOpenFlow('laboratorio DCO',DCO_URLS.entry)};
  if($('dcoCloseSession'))$('dcoCloseSession').onclick=()=>{if(dcoPdfRetryBusy)return dcoSetResult('loading','Recupero PDF in corso: la sessione DCO non può essere chiusa finché lo stato non diventa ready o error.');if(!dcoBrowserRef)return dcoSetResult('','Nessun browser fiscale aperto.');try{dcoBrowserRef.close()}catch{}};
  if($('dcoEnableRealTest'))$('dcoEnableRealTest').onclick=()=>{const draft=dcoBuildDraftPayload();if(!draft.ok)return dcoSetResult('error',draft.error);const phrase=prompt(`ATTENZIONE: la prossima procedura potrà emettere un documento fiscale reale da ${euro(draft.total)}.

Digita PROVA REALE per bloccare Epson e abilitare la fase finale.`);if(String(phrase||'').trim().toUpperCase()!=='PROVA REALE')return dcoSetResult('','Prova reale non abilitata.');dcoStorePendingSale();setDcoRealTestEnabled(true);dcoSetResult('warning','Prova reale abilitata. Epson è bloccata. Dopo l’emissione CassaIQ recupererà il PDF ufficiale e registrerà la vendita.');};
  if($('dcoDisableRealTest'))$('dcoDisableRealTest').onclick=()=>{if(!confirm('Disabilitare la prova reale? Fallo solo dopo aver verificato se il documento è stato emesso, per evitare duplicazioni.'))return;setDcoRealTestEnabled(false);dcoSetResult('ok','Prova reale disabilitata. Emissione Epson nuovamente disponibile.');};
  if($('dcoRetryPdf'))$('dcoRetryPdf').onclick=dcoRetryPendingPdf;
  if($('dcoPrintLast'))$('dcoPrintLast').onclick=()=>dcoReprintLastDocument();
  if($('dcoCopyDiagnostic'))$('dcoCopyDiagnostic').onclick=async()=>{if(!dcoLastDiagnostic)return dcoSetResult('error','Non c’è ancora una diagnostica da copiare.');const text=JSON.stringify(dcoLastDiagnostic,null,2);try{await navigator.clipboard.writeText(text);dcoSetResult('ok','Diagnostica copiata. I valori dei campi, password e PIN non vengono raccolti.')}catch{dcoSetResult('error','Copia automatica non disponibile. Seleziona manualmente il testo nel riquadro.')}};
  if($('dcoSendDiagnostic'))$('dcoSendDiagnostic').onclick=async()=>{
    const button=$('dcoSendDiagnostic'),oldText=button?.textContent||'Invia diagnostica';
    if(button){button.disabled=true;button.textContent='Invio…'}
    dcoSetResult('loading','Invio diagnostica all’assistenza…');
    try{
      const code=await supportSubmitDiagnostic();
      dcoSetResult('ok',`Diagnostica inviata correttamente · Codice ${code}. Comunica questo codice all’assistenza.`);
      try{await navigator.clipboard.writeText(code)}catch{}
    }catch(e){
      const msg=String(e?.message||e);
      if(/cassaiq_submit_diagnostic|schema cache|function/i.test(msg))dcoSetResult('error','Invio diagnostica non ancora configurato. Esegui in Supabase il file supabase-diagnostica-assistenza-v1.15.5.sql.');
      else dcoSetResult('error',`Invio diagnostica non riuscito: ${msg}`)
    }finally{
      if(button){button.disabled=false;button.textContent=oldText}
    }
  };
}

const dialog=$('printerDialog'),input=$('printerIp'),result=$('testResult');
$('closePrinterDialog').onclick=()=>dialog.close();
/* Su iOS, se il permesso 'Rete locale' viene negato al primo tentativo,
   iOS non lo richiede mai piu' e ogni chiamata all'Epson fallisce con un
   errore di connessione, qualunque sia l'IP. Va riattivato da Impostazioni. */
function isIosApp(){return (APP_CONFIG.platform||'web')==='ios'}
function looksLikeNetworkBlock(msg){return /could not connect|network|load failed|failed to fetch|timeout|connessione/i.test(String(msg||''))}
function showEpsonError(el,msg){el.hidden=false;el.className='test-result error';
 const base=`Epson non raggiungibile: ${xmlEscape(String(msg||''))}`;
 if(isIosApp()&&looksLikeNetworkBlock(msg)){
   el.innerHTML=`${base}<span class="perm-hint"><strong>Hai negato l’accesso alla rete locale?</strong>Senza quel permesso il registratore non è raggiungibile con nessun indirizzo. Attivalo in <em>Impostazioni › Privacy e sicurezza › Rete locale › CassaIQ</em>, poi riprova.<button type="button" id="openIosSettings" class="secondary perm-button">Apri Impostazioni</button></span>`;
   const b=$('openIosSettings');if(b)b.onclick=()=>{try{window.location.href='app-settings:'}catch(e){toast('Apri Impostazioni › Privacy e sicurezza › Rete locale',5000)}};
 }else{el.textContent=base}}
function openPrinter(){input.value=localStorage.getItem(K.ip)||'';$('endpointPreview').textContent=endpoint(input.value);result.hidden=true;dialog.showModal()}
$('openPrinterSettings').onclick=()=>showView('stampanti');

input.oninput=()=>$('endpointPreview').textContent=endpoint(input.value);$('printerForm').onsubmit=e=>{if(e.submitter&&e.submitter.value==='cancel')return;e.preventDefault();if(!valid(input.value)){result.hidden=false;result.className='test-result error';result.textContent='IP non valido.';return}localStorage.setItem(K.ip,norm(input.value));status('','Epson configurato');$('headerIp').textContent=norm(input.value);dialog.close();toast('Indirizzo Epson salvato')};$('testConnection').onclick=async()=>{if(!valid(input.value)){result.hidden=false;result.className='test-result error';result.textContent='Inserisci un IP valido.';return}localStorage.setItem(K.ip,norm(input.value));result.hidden=false;result.className='test-result loading';result.textContent='Lettura stato Epson…';try{const res=await sendEpson('<printerCommand><queryPrinterStatus operator="1" /></printerCommand>',10000);if(!res.success)throw new Error(`${res.code||'stato non disponibile'}${res.status?` (${res.status})`:''}`);result.className='test-result ok';result.textContent='Epson FP-81II RT collegato e operativo.';status('ok','Epson connesso');$('headerIp').textContent=norm(input.value)}catch(err){showEpsonError(result,err.message);status('error','Epson offline')}};
const closureDialog=$('dailyClosureDialog'),closureResult=$('closureResult');
function openDailyClosure(){const ip=localStorage.getItem(K.ip)||'';if(!valid(ip)){toast('Configura prima il registratore Epson');openPrinter();return}$('closurePrinterIp').textContent=ip;closureResult.hidden=true;closureDialog.showModal()}
if($('configDailyClosure'))$('configDailyClosure').onclick=openDailyClosure;
$('startDailyClosure').onclick=async()=>{const button=$('startDailyClosure');if(!confirm('Confermi la chiusura fiscale giornaliera?\n\nL’operazione verrà inviata realmente al registratore Epson.'))return;button.disabled=true;button.textContent='Chiusura in corso…';closureResult.hidden=false;closureResult.className='test-result loading';closureResult.textContent='Invio comando di chiusura giornaliera all’Epson…';status('','Chiusura giornaliera…');try{const request='<printerFiscalReport><printXZReport operator="1" timeout="20000" /></printerFiscalReport>';const res=await sendEpson(request,30000);if(!res.success)throw new Error(`Epson: ${res.code||'chiusura rifiutata'}${res.status?` (stato ${res.status})`:''}`);const at=new Date().toISOString(),history=load(K.closures,[]);history.push({date:at,code:res.code||'',status:res.status||'',info:res.info||{}});save(K.closures,history);closureResult.className='test-result ok';closureResult.textContent=`Chiusura completata il ${new Date(at).toLocaleString('it-IT')}.`;status('ok','Chiusura completata');toast('Chiusura giornaliera completata',4000)}catch(err){closureResult.className='test-result error';closureResult.textContent=`Esito da verificare: ${err.message}. Controlla il registratore prima di ripetere.`;status('error','Chiusura da verificare')}finally{button.disabled=false;button.textContent='Esegui chiusura'}};

const changeDialog=$('changeDialog'),cashInput=$('cashReceived');
function updateChange(){const received=Number((cashInput.value||'').replace(',','.')),total=cartTotal();$('changeTotal').textContent=euro(total);if(!Number.isFinite(received)){cashReceived=0;changeDue=0;$('changeAmount').textContent=euro(0);$('changeError').textContent='';return}cashReceived=received;changeDue=Math.max(0,received-total);$('changeAmount').textContent=euro(changeDue);$('changeError').textContent=received<total?'L’importo ricevuto è inferiore al totale.':''}
$('changeButton').onclick=()=>{if(!cartLines().length)return toast('Aggiungi almeno un prodotto');cashInput.value='';cashReceived=0;changeDue=0;updateChange();changeDialog.showModal();setTimeout(()=>cashInput.focus(),100)};cashInput.oninput=updateChange;$('changeForm').onsubmit=e=>{e.preventDefault();updateChange();if(cashReceived<cartTotal())return;payment='Contanti';document.querySelectorAll('[data-pay]').forEach(x=>x.classList.toggle('selected',x.dataset.pay==='Contanti'));changeDialog.close();showPay(true);renderCart()};
const discountDialog=$('discountDialog'),discountInput=$('discountAmountInput');
function updateDiscountPreview(){const subtotal=cartSubtotal(),value=parseMoneyInput(discountInput.value),validValue=Number.isFinite(value)&&value>=0;const preview=validValue?Math.max(0,subtotal-value):subtotal;$('discountSubtotal').textContent=euro(subtotal);$('discountNewTotal').textContent=euro(preview);$('discountError').textContent=!discountInput.value?'':(!validValue?'Inserisci un importo valido.':value<=0?'Lo sconto deve essere maggiore di zero.':value>=subtotal?'Lo sconto deve essere inferiore al subtotale.':'')}
$('discountButton').onclick=()=>{if(!cartLines().length)return toast('Aggiungi almeno un prodotto');discountInput.value=discountAmount>0?String(discountAmount).replace('.',','):'';updateDiscountPreview();discountDialog.showModal();setTimeout(()=>discountInput.focus(),100)};discountInput.oninput=updateDiscountPreview;$('discountForm').onsubmit=e=>{e.preventDefault();const value=parseMoneyInput(discountInput.value),subtotal=cartSubtotal();if(!Number.isFinite(value)||value<=0||value>=subtotal){updateDiscountPreview();return}discountAmount=value;discountDialog.close();renderCart();toast(`Sconto applicato: ${euro(discountAmount)}`,3000)};$('removeDiscount').onclick=()=>{discountAmount=0;discountDialog.close();renderCart();toast('Sconto rimosso')};

const userDialog=$('userDialog');
function getSession(){try{return JSON.parse(localStorage.getItem(K.session)||'null')}catch{return null}}
/* Il token di accesso Supabase dura circa un'ora. Senza rinnovo, dopo quel
   tempo ogni scrittura fallisce con 401 e l'utente sembra 'uscito'. Qui lo
   rinnoviamo in modo trasparente usando il refresh_token salvato al login. */
let refreshingPromise=null;
async function fetchWithCloudTimeout(url,options={},timeoutMs=15000){
  if(typeof AbortController==='undefined')return fetch(url,options);
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),Math.max(1000,Number(timeoutMs)||15000));
  try{return await fetch(url,{...options,signal:controller.signal})}
  catch(e){if(e?.name==='AbortError')throw new Error('Timeout connessione cloud. Riprova tra qualche secondo.');throw e}
  finally{clearTimeout(timer)}
}
async function refreshSession(){
  const session=getSession();
  if(!session?.refresh_token) return null;
  if(refreshingPromise) return refreshingPromise;
  const {url,key}=supabaseConfig();
  refreshingPromise=(async()=>{
    try{
      const r=await fetchWithCloudTimeout(`${url}/auth/v1/token?grant_type=refresh_token`,{method:'POST',
        headers:{'Content-Type':'application/json','apikey':key,'Authorization':`Bearer ${key}`},
        body:JSON.stringify({refresh_token:session.refresh_token})},15000);
      if(!r.ok) return null;
      const data=await r.json().catch(()=>null);
      if(!data?.access_token) return null;
      /* Supabase a volte non rimanda il refresh_token: conserviamo il vecchio. */
      if(!data.refresh_token) data.refresh_token=session.refresh_token;
      localStorage.setItem(K.session,JSON.stringify(data));
      return data;
    }catch(e){return null}finally{refreshingPromise=null}
  })();
  return refreshingPromise;
}
function renderUserState(){const s=getSession();$('userLoggedOut').hidden=!!s;$('userLoggedIn').hidden=!s;if(s)$('loggedUserEmail').textContent=s.user?.email||'Account collegato'}
function openUserDialog(){$('userResult').hidden=true;renderUserState();userDialog.showModal()}
function supabaseConfig(){const fallbackUrl='https://fmwoycukrablixqqatmo.supabase.co';const fallbackKey='sb_publishable_cgeNpt6V56Wc95lFZUDYSA_xFcmxTTZ';const url=(APP_CONFIG.supabaseUrl||fallbackUrl).trim().replace(/\/+$/,'').replace(/\/rest\/v1$/i,'');const key=(APP_CONFIG.supabaseAnonKey||fallbackKey).trim();if(!/^https:\/\/.+\.supabase\.co$/i.test(url)||!key)throw new Error('Collegamento Supabase non disponibile.');return{url,key}}
function cloudHeaders(extra={}){const {key}=supabaseConfig(),session=getSession();if(!session?.access_token)throw new Error('Accedi prima all’Area utente.');return{'Content-Type':'application/json','apikey':key,'Authorization':`Bearer ${session.access_token}`,...extra}}
async function cloudRequest(table,{method='GET',query='',body,prefer,_retried=false,timeoutMs=15000}={}){const {url}=supabaseConfig();const headers=cloudHeaders(prefer?{'Prefer':prefer}:{});const r=await fetchWithCloudTimeout(`${url}/rest/v1/${table}${query}`,{method,headers,body:body===undefined?undefined:JSON.stringify(body)},timeoutMs);const text=await r.text();let data=null;try{data=text?JSON.parse(text):null}catch{data=text}if(!r.ok){if(r.status===401&&!_retried){/* Token scaduto: proviamo a rinnovarlo e ripetiamo la richiesta una volta. */const refreshed=await refreshSession();if(refreshed)return cloudRequest(table,{method,query,body,prefer,_retried:true,timeoutMs});throw new Error('Sessione scaduta. Esci e accedi nuovamente.');}if(r.status===401)throw new Error('Sessione scaduta. Esci e accedi nuovamente.');throw new Error(data?.message||data?.hint||`Errore cloud ${r.status}`)}return data}

async function cloudRpc(name,body={},_retried=false){const {url}=supabaseConfig();const headers=cloudHeaders();const r=await fetchWithCloudTimeout(`${url}/rest/v1/rpc/${encodeURIComponent(name)}`,{method:'POST',headers,body:JSON.stringify(body||{})},15000);const text=await r.text();let data=null;try{data=text?JSON.parse(text):null}catch{data=text}if(!r.ok){if(r.status===401&&!_retried){const refreshed=await refreshSession();if(refreshed)return cloudRpc(name,body,true);throw new Error('Sessione scaduta. Esci e accedi nuovamente.')}throw new Error(data?.message||data?.hint||data?.details||`Errore cloud ${r.status}`)}return data}

const CLIENT_LAN_DEFAULT_PORT=8765;
let clientLanTimer=null,clientLanSyncTimer=null,clientLanDrainBusy=false,clientLanSyncBusy=false,clientLanStartPromise=null,clientLanLastRecoveryAt=0,clientLanConfigSignature='';
function lanLocalOrders(){return load(K.lanOrders,[])}
function lanSaveOrders(rows){const all=Array.isArray(rows)?rows:[],critical=[],archived=[];for(const o of all){if(lanOpenStatuses().has(String(o?.status||''))||o?.cloudDirty!==false)critical.push(o);else archived.push(o)}archived.sort((a,b)=>String(b.updated_at||b.created_at||'').localeCompare(String(a.updated_at||a.created_at||'')));save(K.lanOrders,[...archived.slice(0,200).reverse(),...critical])}

function lanCancellationEvents(){return load(K.lanOrderChanges,[])}
function lanSaveCancellationEvents(rows){const list=Array.isArray(rows)?rows:[];save(K.lanOrderChanges,list.slice(-300))}
function lanFindCancellationEvent(id){return lanCancellationEvents().find(e=>String(e.id)===String(id))||null}
function lanReplaceCancellationEvent(updated){const rows=lanCancellationEvents(),i=rows.findIndex(e=>String(e.id)===String(updated.id));if(i<0)rows.push(updated);else rows[i]=updated;lanSaveCancellationEvents(rows);return updated}
function lanItemCancelledQty(item){return Math.max(0,Number(item?.cancelled_quantity||0))}
function lanItemRemainingQty(item){return Math.max(0,Number(item?.quantity||0)-lanItemCancelledQty(item))}
function lanOrderRemainingQty(order){return(order?.items||[]).reduce((n,i)=>n+lanItemRemainingQty(i),0)}
function lanRecalculateOrder(order){
  const total=roundMoney((order?.items||[]).reduce((n,i)=>n+lanItemRemainingQty(i)*Number(i.unit_price||0),0)),remaining=lanOrderRemainingQty(order);
  return{...order,subtotal:total,total,status:remaining>0?(order.status==='cancelled'?'sent':order.status):'cancelled',updated_at:new Date().toISOString(),cloudDirty:true,cloudSynced:false}
}
function lanValidateChangeEnvelope(raw){
  const session=getSession(),current=String(session?.user?.id||''),owner=String(raw?.owner_user_id||''),deviceId=String(raw?.device_id||''),tableId=String(raw?.table_id||'');
  if(!current)throw new Error('Account CassaIQ non disponibile. Accedi almeno una volta con Internet.');
  if(!owner||owner!==current)throw new Error('Comanda LAN di un account diverso.');
  const authorized=lanAuthorizedClientIds();if(authorized.length&&!authorized.includes(deviceId))throw new Error('CassaIQ Client non autorizzato.');
  const table=(restaurantTables.length?restaurantTables:lanCachedTables()).find(t=>String(t.id)===tableId);if(!table)throw new Error('Tavolo non riconosciuto dalla cassa.');
  const eventId=String(raw?.order_id||''),targetId=String(raw?.target_order_id||'');if(!/^[A-Za-z0-9-]{8,80}$/.test(eventId)||!/^[A-Za-z0-9-]{8,80}$/.test(targetId))throw new Error('ID annullamento LAN non valido.');
  return{current,deviceId,tableId,table,eventId,targetId}
}
function lanOrderFromCancellationSnapshot(raw,ctx){
  const snap=raw?.target_snapshot;if(!snap||String(snap.id||'')!==ctx.targetId)return null;
  const input=Array.isArray(snap.items)?snap.items:[];if(!input.length)return null;
  // Se la cassa non ha più la comanda locale, ricostruiamo dallo snapshot solo
  // quando ogni riga ha un line_id stabile. Generare nuovi ID qui potrebbe
  // duplicare le righe su Supabase durante la sincronizzazione.
  if(input.some(x=>!/^[A-Za-z0-9-]{8,80}$/.test(String(x?.id||''))))return null;
  const now=new Date().toISOString(),items=input.map((x,index)=>{
    const id=String(x.id),qty=Math.max(0,Number(x.quantity)||0),cancelled=Math.max(0,Math.min(qty,Number(x.cancelled_quantity)||0)),unit=roundMoney(Number(x.unit_price)||0);
    return{id,order_id:ctx.targetId,owner_user_id:ctx.current,product_id:x.product_id==null?null:String(x.product_id),product_name:String(x.product_name||'Prodotto'),quantity:qty,cancelled_quantity:cancelled,cancelled_at:x.cancelled_at||null,cancelled_by_device_id:x.cancelled_by_device_id||null,cancellation_note:x.cancellation_note||null,unit_price:unit,line_total:roundMoney(qty*unit),notes:String(x.notes||'').trim()||null,created_at:String(x.created_at||snap.created_at||now)}
  }).filter(i=>i.quantity>0);
  if(!items.length)return null;
  const order={id:ctx.targetId,owner_user_id:ctx.current,table_id:ctx.tableId,table_name:ctx.table.name||raw.table_name||'Tavolo',created_by:ctx.current,created_by_device_id:raw.device_id||null,status:String(snap.status||'sent'),notes:null,subtotal:0,total:0,created_at:String(snap.created_at||now),updated_at:String(snap.updated_at||now),items,localLan:true,cloudSynced:false,cloudDirty:true,kitchenAttempted:true,kitchenPrinted:true,kitchenError:''};
  return lanRecalculateOrder(order)
}
function lanFindCancellationTargetItem(order,cancel){
  const items=order?.items||[],id=String(cancel?.target_item_id||'');if(id){const byId=items.find(i=>String(i.id)===id);if(byId)return byId}
  const index=Number(cancel?.item_index);if(Number.isInteger(index)&&index>=0&&index<items.length){const candidate=items[index];if(lanItemRemainingQty(candidate)>0)return candidate}
  const productId=String(cancel?.product_id||''),name=String(cancel?.product_name||'').trim(),notes=String(cancel?.notes||'').trim();
  return items.find(i=>lanItemRemainingQty(i)>0&&(!productId||String(i.product_id||'')===productId)&&(!name||String(i.product_name||'')===name)&&String(i.notes||'').trim()===notes)||null
}
function lanApplyIncomingCancellation(raw){
  const ctx=lanValidateChangeEnvelope(raw),existingEvent=lanFindCancellationEvent(ctx.eventId);if(existingEvent)return existingEvent;
  let target=lanFindOrder(ctx.targetId);
  if(!target){target=lanOrderFromCancellationSnapshot(raw,ctx);if(!target)throw new Error('Comanda originale non disponibile sulla cassa.');const rows=lanLocalOrders();rows.push(target);lanSaveOrders(rows)}
  if(!lanOpenStatuses().has(String(target.status||'')))throw new Error('La comanda non è più modificabile.');
  const requested=Array.isArray(raw.cancellations)&&raw.cancellations.length?raw.cancellations:(Array.isArray(raw.items)?raw.items:[]);if(!requested.length)throw new Error('Annullamento LAN senza righe.');
  const applied=[],reason=String(raw.reason||'').trim().slice(0,200),now=new Date().toISOString();
  for(const c of requested){
    const item=lanFindCancellationTargetItem(target,c);if(!item)throw new Error(`Riga da annullare non trovata: ${c?.product_name||'Prodotto'}`);
    const remaining=lanItemRemainingQty(item),qty=Math.max(0,Number(c.quantity)||0);if(!(qty>0)||qty>remaining)throw new Error(`Quantità da annullare non valida per ${item.product_name||'Prodotto'}.`);
    item.cancelled_quantity=roundMoney(lanItemCancelledQty(item)+qty);item.cancelled_at=now;item.cancelled_by_device_id=ctx.deviceId||null;item.cancellation_note=reason||null;
    applied.push({id:String(c.cancel_id||uid()),order_item_id:item.id,product_id:item.product_id||null,product_name:item.product_name||'Prodotto',quantity:qty,unit_price:Number(item.unit_price||0),notes:item.notes||null,reason:reason||null})
  }
  target=lanRecalculateOrder(target);lanReplaceOrder(target);
  if(lanOpenLocalOrders(ctx.tableId).length)lanMarkTableLocal(ctx.tableId,'occupied');else lanMarkTableLocal(ctx.tableId,'free');
  const event={id:ctx.eventId,target_order_id:ctx.targetId,owner_user_id:ctx.current,table_id:ctx.tableId,table_name:ctx.table.name||raw.table_name||'Tavolo',created_by_device_id:ctx.deviceId||null,created_at:String(raw.created_at||now),reason:reason||null,items:applied,kitchenAttempted:false,kitchenPrinted:false,kitchenError:'',cloudSynced:false};
  return lanReplaceCancellationEvent(event)
}
async function lanPrintCancellationEvent(event){
  let current=lanFindCancellationEvent(event.id)||event;if(current.kitchenAttempted)return current;
  current={...current,kitchenAttempted:true,kitchenError:'',updated_at:new Date().toISOString()};lanReplaceCancellationEvent(current);
  try{
    const result=await kitchenPrintCancellation({tableName:current.table_name||'Tavolo',lines:(current.items||[]).map(i=>({name:i.product_name,quantity:i.quantity,note:i.notes,productId:i.product_id})),reason:current.reason||'',source:'CassaIQ Client',orderId:current.target_order_id});
    current={...current,kitchenPrinted:!result?.skipped,kitchenError:result?.skipped?'Stampante cucina disattivata':'',updated_at:new Date().toISOString()}
  }catch(e){current={...current,kitchenPrinted:false,kitchenError:String(e?.message||e),updated_at:new Date().toISOString()};console.warn('Annullamento ricevuto, stampa cucina non riuscita',e)}
  return lanReplaceCancellationEvent(current)
}
async function lanSyncCancellationEventsForOrder(order){
  const events=lanCancellationEvents().filter(e=>String(e.target_order_id)===String(order.id)&&e.cloudSynced!==true);if(!events.length)return;
  for(const event of events){
    const body=(event.items||[]).map(i=>({id:i.id,event_id:event.id,owner_user_id:order.owner_user_id,table_id:order.table_id,order_id:order.id,order_item_id:i.order_item_id,product_name:i.product_name||'Prodotto',quantity:Number(i.quantity)||0,reason:event.reason||null,created_by_device_id:event.created_by_device_id||null,created_at:event.created_at||new Date().toISOString()}));
    if(body.length)await cloudRequest('order_cancellations',{method:'POST',body,prefer:'resolution=merge-duplicates,return=minimal',timeoutMs:6000});
    lanReplaceCancellationEvent({...event,cloudSynced:true,lastCloudSync:new Date().toISOString()})
  }
}
function lanCachedTables(){return load(K.restaurantTablesCache,[])}
function lanSaveTables(rows){save(K.restaurantTablesCache,Array.isArray(rows)?rows:[])}
function lanAuthorizedClientIds(){return load(K.clientAuthorizedIds,[]).map(String)}
function lanOpenStatuses(){return new Set(['sent','accepted'])}
function lanOpenLocalOrders(tableId){const open=lanOpenStatuses();return lanLocalOrders().filter(o=>String(o.table_id)===String(tableId)&&open.has(String(o.status||'')))}
function lanFindOrder(id){return lanLocalOrders().find(o=>String(o.id)===String(id))||null}
function lanPatchOrders(ids,patch){const wanted=new Set((ids||[]).map(String)),now=new Date().toISOString();let changed=false;const rows=lanLocalOrders().map(o=>{if(!wanted.has(String(o.id)))return o;changed=true;return{...o,...patch,updated_at:patch?.updated_at||now,cloudDirty:true}});if(changed)lanSaveOrders(rows);return changed}
function lanMergeTableOccupancy(rows){const openTableIds=new Set(lanLocalOrders().filter(o=>lanOpenStatuses().has(String(o.status||''))).map(o=>String(o.table_id)));return (rows||[]).map(t=>openTableIds.has(String(t.id))?{...t,status:'occupied'}:t)}
function lanMarkTableLocal(tableId,status){const now=new Date().toISOString(),id=String(tableId);restaurantTables=restaurantTables.map(t=>String(t.id)===id?{...t,status,updated_at:now}:t);let cached=lanCachedTables();if(cached.length)cached=cached.map(t=>String(t.id)===id?{...t,status,updated_at:now}:t);else cached=restaurantTables;lanSaveTables(cached);renderTablesGrid()}
async function lanPublishTableStatus(tableId,status){const session=getSession(),id=String(tableId||'');if(!session?.user?.id||!id||!navigator.onLine)return false;try{await cloudRequest('restaurant_tables',{method:'PATCH',query:`?id=eq.${encodeURIComponent(id)}`,body:{status,updated_at:new Date().toISOString()},prefer:'return=minimal',timeoutMs:4500});return true}catch(e){console.warn('Stato tavolo cloud rinviato',id,status,e);return false}}
function refreshVisibleTableOrder(tableId){const dlg=$('tableOrderDialog'),state=tableOrderState;if(!dlg?.open||!state?.table?.id||String(state.table.id)!==String(tableId))return;openTableOrder(state.table).catch(e=>console.warn('Aggiornamento finestra comanda non riuscito',e))}
function clientLanUi(type,address,state){const addressEl=$('clientLanAddress'),stateEl=$('clientLanState'),box=addressEl?.closest?.('.client-lan-box');if(addressEl&&address!=null)addressEl.textContent=address;if(stateEl&&state!=null)stateEl.textContent=state;if(box){box.classList.remove('ok','error','warning');if(type)box.classList.add(type)}}
function clientLanPort(){const raw=Number(localStorage.getItem(K.clientLanPort)||CLIENT_LAN_DEFAULT_PORT);return Number.isInteger(raw)&&raw>=1024&&raw<=65535?raw:CLIENT_LAN_DEFAULT_PORT}
async function clientLanStart(forceRestart=false,showToast=false){
  const plugin=printerNativePlugin(),port=clientLanPort();
  if(!plugin?.lanServerStart){clientLanUi('warning','LAN locale non disponibile',`Porta ${port} · modulo LAN nativo non disponibile`);return false}
  if(clientLanStartPromise)return clientLanStartPromise;
  clientLanStartPromise=(async()=>{
    try{
      const ownerUserId=String(getSession()?.user?.id||''),authorizedDeviceIdsCsv=lanAuthorizedClientIds().join(','),signature=`${port}|${ownerUserId}|${authorizedDeviceIdsCsv}`;
      /* Evita di spegnere e riaccendere un listener sano ogni volta che si apre
         la pagina Client. Se invece cambiano account o dispositivi autorizzati,
         il listener viene ricreato per applicare subito la nuova autorizzazione. */
      if(!forceRestart&&signature===clientLanConfigSignature&&plugin.lanServerStatus){
        try{
          const current=await plugin.lanServerStatus();
          if(current?.running===true&&Number(current?.port||port)===port){
            const ip=String(current?.ip||'').trim();
            clientLanUi(ip?'ok':'warning',ip?`${ip}:${port}`:`Porta ${port}`,current?.pending?`Server locale attivo · ${current.pending} in coda`:'Server locale attivo · pronto');
            if(showToast)toast(ip?`LAN CassaIQ attiva · ${ip}:${port}`:'LAN attiva, IP non rilevato',3500);
            return true
          }
        }catch{}
      }
      const out=await plugin.lanServerStart({port,ownerUserId,authorizedDeviceIdsCsv});
      clientLanConfigSignature=signature;
      const ip=String(out?.ip||'').trim();
      clientLanUi(ip?'ok':'warning',ip?`${ip}:${out?.port||port}`:`Porta ${out?.port||port}`,ip?'Server locale attivo · Client può inviare senza Internet':'Server attivo · IP Wi-Fi non rilevato');
      if(showToast)toast(ip?`LAN CassaIQ attiva · ${ip}:${out?.port||port}`:'LAN attiva, IP non rilevato',3500);
      return true
    }catch(e){
      clientLanUi('error','LAN non avviata',String(e?.message||e));
      if(showToast)toast(`LAN non avviata: ${e?.message||e}`,5000);
      return false
    }
  })();
  try{return await clientLanStartPromise}finally{clientLanStartPromise=null}
}
function lanApplyIncomingTableReplacement(raw){
  const session=getSession(),current=String(session?.user?.id||''),owner=String(raw?.owner_user_id||''),deviceId=String(raw?.device_id||''),tableId=String(raw?.table_id||'');
  if(!current)throw new Error('Account CassaIQ non disponibile. Accedi almeno una volta con Internet.');if(!owner||owner!==current)throw new Error('Comanda LAN di un account diverso.');const authorized=lanAuthorizedClientIds();if(authorized.length&&!authorized.includes(deviceId))throw new Error('CassaIQ Client non autorizzato.');
  const table=(restaurantTables.length?restaurantTables:lanCachedTables()).find(t=>String(t.id)===tableId);if(!table)throw new Error('Tavolo non riconosciuto dalla cassa.');
  const newId=String(raw?.order_id||''),targetIds=(Array.isArray(raw?.target_order_ids)?raw.target_order_ids:[]).map(String).filter(Boolean),targetSet=new Set(targetIds);
  if(!/^[A-Za-z0-9-]{8,80}$/.test(newId)||!targetIds.length||targetSet.has(newId))throw new Error('ID aggiornamento ordine completo non valido.');
  const existingNew=lanFindOrder(newId);if(existingNew)return existingNew;
  const localOpen=lanOpenLocalOrders(tableId);
  if(localOpen.some(o=>String(o.status||'')==='accepted'))throw new Error('Una comanda del tavolo è già stata presa in cassa e non è più modificabile dal Client.');
  const localSent=localOpen.filter(o=>String(o.status||'')==='sent');
  if(localSent.some(o=>!targetSet.has(String(o.id))))throw new Error('L ordine del tavolo è cambiato: aggiorna il Client e riprova.');
  const now=new Date().toISOString();
  for(const old of localSent){if(targetSet.has(String(old.id)))lanReplaceOrder({...old,status:'cancelled',updated_at:now,cloudDirty:true,cloudSynced:false,replacedByOrderId:newId})}
  const normalized=lanNormalizeIncoming({...raw,action:'new_order'}),updated={...normalized,isUpdate:true,replace_all_table_orders:true,replaces_order_ids:targetIds,cloudDirty:true,cloudSynced:false,kitchenAttempted:false,kitchenPrinted:false,kitchenError:''};
  lanReplaceOrder(updated);lanMarkTableLocal(tableId,'occupied');return updated
}
function lanApplyIncomingReplacement(raw){
  const session=getSession(),current=String(session?.user?.id||''),owner=String(raw?.owner_user_id||''),deviceId=String(raw?.device_id||''),tableId=String(raw?.table_id||'');
  if(!current)throw new Error('Account CassaIQ non disponibile. Accedi almeno una volta con Internet.');if(!owner||owner!==current)throw new Error('Comanda LAN di un account diverso.');const authorized=lanAuthorizedClientIds();if(authorized.length&&!authorized.includes(deviceId))throw new Error('CassaIQ Client non autorizzato.');
  const table=(restaurantTables.length?restaurantTables:lanCachedTables()).find(t=>String(t.id)===tableId);if(!table)throw new Error('Tavolo non riconosciuto dalla cassa.');const targetId=String(raw?.target_order_id||''),newId=String(raw?.order_id||'');if(!/^[A-Za-z0-9-]{8,80}$/.test(targetId)||!/^[A-Za-z0-9-]{8,80}$/.test(newId)||targetId===newId)throw new Error('ID aggiornamento comanda non valido.');
  const existingNew=lanFindOrder(newId);if(existingNew)return existingNew;const old=lanFindOrder(targetId);if(!old)throw new Error('Comanda precedente non disponibile sulla cassa. Aggiorna lo storico del tavolo e riprova.');if(String(old.status||'')!=='sent')throw new Error('Comanda già presa in cassa e non più modificabile dal Client.');lanReplaceOrder({...old,status:'cancelled',updated_at:new Date().toISOString(),cloudDirty:true,cloudSynced:false,replacedByOrderId:newId});
  const normalized=lanNormalizeIncoming({...raw,action:'new_order'}),updated={...normalized,isUpdate:true,replaces_order_id:targetId,cloudDirty:true,cloudSynced:false,kitchenAttempted:false,kitchenPrinted:false,kitchenError:''};lanReplaceOrder(updated);lanMarkTableLocal(tableId,'occupied');return updated
}
function lanNormalizeIncoming(raw){if(!raw||raw.type!=='cassaiq_order')throw new Error('Messaggio LAN non valido.');const session=getSession(),owner=String(raw.owner_user_id||''),current=String(session?.user?.id||'');if(!current)throw new Error('Account CassaIQ non disponibile. Accedi almeno una volta con Internet.');if(!owner||owner!==current)throw new Error('Comanda LAN di un account diverso.');const authorized=lanAuthorizedClientIds(),deviceId=String(raw.device_id||'');if(authorized.length&&!authorized.includes(deviceId))throw new Error('CassaIQ Client non autorizzato.');const tableId=String(raw.table_id||''),table=(restaurantTables.length?restaurantTables:lanCachedTables()).find(t=>String(t.id)===tableId);if(!table)throw new Error('Tavolo non riconosciuto dalla cassa. Sincronizza i tavoli almeno una volta.');const orderId=String(raw.order_id||'');if(!/^[A-Za-z0-9-]{8,80}$/.test(orderId))throw new Error('ID comanda LAN non valido.');const now=new Date().toISOString(),input=Array.isArray(raw.items)?raw.items:[];if(!input.length)throw new Error('Comanda LAN senza prodotti.');const items=input.map(x=>{const productId=x.product_id==null?null:String(x.product_id),product=products.find(p=>String(p.id)===productId),qty=Math.max(0,Number(x.quantity)||0),unit=roundMoney(Number(x.unit_price)||Number(product?.price)||0);if(qty<=0)throw new Error('Quantità non valida nella comanda LAN.');const incomingLineId=String(x.line_id||x.id||''),lineId=/^[A-Za-z0-9-]{8,80}$/.test(incomingLineId)?incomingLineId:uid();return{id:lineId,order_id:orderId,owner_user_id:current,product_id:productId,product_name:String(product?.name||x.product_name||'Prodotto'),quantity:qty,cancelled_quantity:0,cancelled_at:null,cancelled_by_device_id:null,cancellation_note:null,unit_price:unit,line_total:roundMoney(qty*unit),notes:String(x.notes||'').trim()||null,supplements:Array.isArray(x.supplements)?x.supplements.map(v=>({...v})):[],created_at:String(raw.created_at||now)}});const total=roundMoney(items.reduce((n,x)=>n+Number(x.line_total||0),0));return{id:orderId,owner_user_id:current,table_id:tableId,table_name:table.name||raw.table_name||'Tavolo',created_by:current,created_by_device_id:deviceId||null,status:'sent',notes:null,subtotal:total,total,created_at:String(raw.created_at||now),updated_at:now,items,localLan:true,cloudSynced:false,cloudDirty:true,kitchenAttempted:false,kitchenPrinted:false,kitchenError:''}}
function lanPersistIncoming(raw){const orderId=String(raw?.order_id||'');const existing=lanFindOrder(orderId);if(existing)return existing;const order=lanNormalizeIncoming(raw),rows=lanLocalOrders();rows.push(order);lanSaveOrders(rows);lanMarkTableLocal(order.table_id,'occupied');return order}
function lanReplaceOrder(updated){const rows=lanLocalOrders(),idx=rows.findIndex(o=>String(o.id)===String(updated.id));if(idx<0)rows.push(updated);else rows[idx]=updated;lanSaveOrders(rows);return updated}
async function lanPrintIncoming(order){let current=lanFindOrder(order.id)||order;if(current.kitchenAttempted)return current;current={...current,kitchenAttempted:true,kitchenError:'',updated_at:new Date().toISOString()};lanReplaceOrder(current);try{const result=await kitchenPrintOrder({tableName:current.table_name||restaurantTables.find(t=>String(t.id)===String(current.table_id))?.name||'Tavolo',lines:(current.items||[]).map(i=>({name:i.product_name,quantity:i.quantity,note:i.notes,productId:i.product_id})),notes:'',source:'CassaIQ LAN',orderId:current.id,isUpdate:current.isUpdate===true,replacesOrderId:''});current={...current,kitchenPrinted:!result?.skipped,kitchenError:result?.skipped?'Stampante cucina disattivata':'',updated_at:new Date().toISOString()}}catch(e){current={...current,kitchenPrinted:false,kitchenError:String(e?.message||e),updated_at:new Date().toISOString()};console.warn(current.isUpdate?'Aggiornamento LAN ricevuto, stampa cucina non riuscita':'Comanda LAN ricevuta, stampa cucina non riuscita',e)}lanReplaceOrder(current);return current}
async function lanSyncOneOrder(order){
  const session=getSession();if(!session?.user?.id||String(order.owner_user_id)!==String(session.user.id))return false;
  if(order.replace_all_table_orders){const ids=(order.replaces_order_ids||[]).map(encodeURIComponent).join(',');if(ids)await cloudRequest('orders',{method:'PATCH',query:`?owner_user_id=eq.${encodeURIComponent(order.owner_user_id)}&table_id=eq.${encodeURIComponent(order.table_id)}&status=eq.sent&id=in.(${ids})`,body:{status:'cancelled',updated_at:new Date().toISOString()},prefer:'return=minimal',timeoutMs:6000})}else if(order.replaces_order_id)await cloudRequest('orders',{method:'PATCH',query:`?id=eq.${encodeURIComponent(order.replaces_order_id)}&owner_user_id=eq.${encodeURIComponent(order.owner_user_id)}&table_id=eq.${encodeURIComponent(order.table_id)}&status=eq.sent`,body:{status:'cancelled',updated_at:new Date().toISOString()},prefer:'return=minimal',timeoutMs:6000});
  const body={id:order.id,owner_user_id:order.owner_user_id,table_id:order.table_id,created_by:order.created_by||session.user.id,created_by_device_id:order.created_by_device_id||null,status:order.status||'sent',notes:order.notes||null,subtotal:roundMoney(order.subtotal),total:roundMoney(order.total),created_at:order.created_at,updated_at:order.updated_at||new Date().toISOString()};
  await cloudRequest('orders',{method:'POST',body,prefer:'resolution=merge-duplicates,return=minimal',timeoutMs:6000});
  const items=(order.items||[]).map(i=>({id:i.id,order_id:order.id,owner_user_id:order.owner_user_id,product_id:i.product_id||null,product_name:i.product_name||'Prodotto',quantity:Number(i.quantity)||0,unit_price:roundMoney(i.unit_price),line_total:roundMoney(Number(i.quantity||0)*Number(i.unit_price||0)),notes:i.notes||null,created_at:i.created_at||order.created_at}));
  if(items.length)await cloudRequest('order_items',{method:'POST',body:items,prefer:'resolution=merge-duplicates,return=minimal',timeoutMs:6000});
  for(const i of order.items||[]){
    if(lanItemCancelledQty(i)<=0)continue;
    await cloudRequest('order_items',{method:'PATCH',query:`?id=eq.${encodeURIComponent(i.id)}&owner_user_id=eq.${encodeURIComponent(order.owner_user_id)}`,body:{cancelled_quantity:lanItemCancelledQty(i),cancelled_at:i.cancelled_at||new Date().toISOString(),cancelled_by_device_id:i.cancelled_by_device_id||null,cancellation_note:i.cancellation_note||null},prefer:'return=minimal',timeoutMs:6000})
  }
  await lanSyncCancellationEventsForOrder(order);
  const open=lanOpenStatuses().has(String(order.status||''))&&lanOrderRemainingQty(order)>0;
  if(open)await cloudRequest('restaurant_tables',{method:'PATCH',query:`?id=eq.${encodeURIComponent(order.table_id)}`,body:{status:'occupied',updated_at:new Date().toISOString()},prefer:'return=minimal',timeoutMs:6000});
  else{
    const localRemaining=lanOpenLocalOrders(order.table_id).filter(o=>String(o.id)!==String(order.id)&&lanOrderRemainingQty(o)>0);
    if(!localRemaining.length){const cloudRemaining=await cloudRequest('orders',{query:`?select=id&table_id=eq.${encodeURIComponent(order.table_id)}&status=in.(sent,accepted)&id=neq.${encodeURIComponent(order.id)}&limit=1`,timeoutMs:6000});if(!Array.isArray(cloudRemaining)||!cloudRemaining.length)await cloudRequest('restaurant_tables',{method:'PATCH',query:`?id=eq.${encodeURIComponent(order.table_id)}`,body:{status:'free',updated_at:new Date().toISOString()},prefer:'return=minimal',timeoutMs:6000})}
  }
  lanReplaceOrder({...order,cloudSynced:true,cloudDirty:false,lastCloudSync:new Date().toISOString()});return true
}
async function lanSyncPendingOrders(){if(clientLanSyncBusy||!getSession()?.user?.id||!navigator.onLine)return;clientLanSyncBusy=true;try{const rows=lanLocalOrders().filter(o=>o.cloudDirty!==false);for(const row of rows){try{await lanSyncOneOrder(row)}catch(e){console.warn('Sync comanda LAN rinviata',row.id,e);break}}}finally{clientLanSyncBusy=false}}
async function clientLanDrain(){
  if(clientLanDrainBusy)return;
  const plugin=printerNativePlugin();if(!plugin?.lanGetPendingOrders)return;
  clientLanDrainBusy=true;
  try{
    const out=await plugin.lanGetPendingOrders({max:20}),pending=Array.isArray(out?.orders)?out.orders:[];
    for(const raw of pending){
      const orderId=String(raw?.order_id||'');
      try{
        if(raw?.action==='replace_table_orders'){
          let order=lanApplyIncomingTableReplacement(raw);if(orderId)await plugin.lanAcknowledgeOrder({orderId});order=await lanPrintIncoming(order);
          if(order.kitchenError)tablesStatus('warning',`${order.table_name}: ordine completo aggiornato · stampa cucina da verificare: ${order.kitchenError}`);else tablesStatus('ok',`${order.table_name}: ordine completo aggiornato${order.kitchenPrinted?' e ristampato in cucina':''} · tutte le comande precedenti sostituite.`);
          lanSyncPendingOrders().catch(()=>{});refreshVisibleTableOrder(order.table_id);continue
        }
        if(raw?.action==='replace_order'){
          let order=lanApplyIncomingReplacement(raw);if(orderId)await plugin.lanAcknowledgeOrder({orderId});order=await lanPrintIncoming(order);
          if(order.kitchenError)tablesStatus('warning',`${order.table_name}: aggiornamento ricevuto · stampa cucina da verificare: ${order.kitchenError}`);else tablesStatus('ok',`${order.table_name}: aggiornamento ricevuto${order.kitchenPrinted?' e ristampato in cucina':''} · precedente non più valida.`);
          lanSyncPendingOrders().catch(()=>{});refreshVisibleTableOrder(order.table_id);continue
        }
        if(raw?.action==='cancel_items'){
          let event=lanApplyIncomingCancellation(raw);
          if(orderId)await plugin.lanAcknowledgeOrder({orderId});
          event=await lanPrintCancellationEvent(event);
          if(event.kitchenError)tablesStatus('warning',`${event.table_name}: annullamento ricevuto · stampa cucina da verificare: ${event.kitchenError}`);
          else tablesStatus('ok',`${event.table_name}: annullamento ricevuto${event.kitchenPrinted?' e stampato in cucina':''}.`);
          lanSyncPendingOrders().catch(()=>{});
          refreshVisibleTableOrder(event.table_id);
          continue
        }
        let order=lanPersistIncoming(raw);
        if(orderId)await plugin.lanAcknowledgeOrder({orderId});
        order=await lanPrintIncoming(order);
        if(order.kitchenError)tablesStatus('warning',`${order.table_name}: comanda ricevuta in LAN · stampa cucina da verificare: ${order.kitchenError}`);
        else tablesStatus('ok',`${order.table_name}: comanda ricevuta in LAN${order.kitchenPrinted?' e stampata in cucina':''}.`);
        lanSyncPendingOrders().catch(()=>{});
        refreshVisibleTableOrder(order.table_id)
      }catch(e){
        console.warn('Comanda LAN in coda non acquisita',raw,e);
        const errText=String(e?.message||e);
        if(orderId&&/account diverso|client non autorizzato/i.test(errText)){try{await plugin.lanAcknowledgeOrder({orderId})}catch{}}
        clientLanUi('warning',$('clientLanAddress')?.textContent||'LAN attiva',`Comanda in coda da verificare · ${errText}`)
      }
    }
    for(const local of lanLocalOrders().filter(o=>lanOpenStatuses().has(String(o.status||''))&&!o.kitchenAttempted).slice(0,10)){
      await lanPrintIncoming(local);lanSyncPendingOrders().catch(()=>{})
    }
    try{
      const st=await plugin.lanServerStatus(),ip=String(st?.ip||'').trim(),port=st?.port||clientLanPort(),running=st?.running===true;
      if(running){
        clientLanUi(ip?'ok':'warning',ip?`${ip}:${port}`:`Porta ${port}`,st?.pending?`Server locale attivo · ${st.pending} in coda`:'Server locale attivo · pronto')
      }else{
        clientLanUi('warning',ip?`${ip}:${port}`:`Porta ${port}`,'Server locale fermo · riavvio automatico…');
        const now=Date.now();
        if(now-clientLanLastRecoveryAt>2500){clientLanLastRecoveryAt=now;clientLanStart(true,false).catch(()=>{})}
      }
    }catch{}
  }finally{clientLanDrainBusy=false}
}
function clientLanInit(){
  clientLanStart(false,false).catch(()=>{});
  clearInterval(clientLanTimer);clearInterval(clientLanSyncTimer);
  clientLanTimer=setInterval(()=>{if(!document.hidden)clientLanDrain().catch(()=>{})},700);
  clientLanSyncTimer=setInterval(()=>{if(!document.hidden)lanSyncPendingOrders().catch(()=>{})},12000);
  window.addEventListener('online',()=>{lanSyncPendingOrders().catch(()=>{});scheduleSalesRecovery(500,{force:true})});
  const recoverLan=()=>{
    if(document.hidden)return;
    clientLanLastRecoveryAt=Date.now();
    /* Dopo background/blocco schermo iOS il listener viene ricreato di proposito:
       non ci affidiamo a uno stato NWListener eventualmente rimasto stale. */
    clientLanStart(true,false).then(()=>clientLanDrain()).catch(()=>{});
    lanSyncPendingOrders().catch(()=>{})
  };
  document.addEventListener('visibilitychange',()=>{if(!document.hidden){recoverLan();scheduleSalesRecovery(900)}});
  document.addEventListener('resume',()=>{recoverLan();scheduleSalesRecovery(900)});
  window.addEventListener('pageshow',()=>{if(!document.hidden)clientLanStart(false,false).catch(()=>{})});
  if($('clientLanRestart')&&!$('clientLanRestart').dataset.bound){$('clientLanRestart').dataset.bound='1';$('clientLanRestart').onclick=()=>clientLanStart(true,true)}
}
let restaurantTables=[];
let tableOrderState=null;
let tablesViewBound=false;
function tableStatusLabel(status){return status==='occupied'?'Occupato':status==='bill_requested'?'Conto richiesto':'Libero'}
function tableStatusClass(status){return status==='occupied'?'occupied':status==='bill_requested'?'bill-requested':'free'}
function updateTablesHeader(){const el=$('headerTablesStatus');if(!el)return;const active=restaurantTables.filter(t=>t.active!==false),occupied=active.filter(t=>t.status==='occupied'||t.status==='bill_requested').length;el.textContent=active.length?`${occupied} occupati · ${active.length} tavoli`:'Sala e comande'}
function tablesStatus(type,text){const el=$('tablesSyncStatus');if(!el)return;el.className=`config-status-line ${type||''}`.trim();el.textContent=text}
function startTableOrderDraft(table){
  if(!table?.id)return;
  if(isIssuing)return toast('Attendi il completamento dell’operazione fiscale in corso');
  const tableId=String(table.id),tableName=String(table.name||'Tavolo');
  const currentLines=cartLines();
  if(currentLines.length){
    const currentName=tableOrderDraft?.tableName||activeTableCheckout?.tableName||'vendita corrente';
    if(!confirm(`Il carrello contiene già ${currentName}. Svuotarlo e iniziare un nuovo ordine per ${tableName}?`))return
  }
  const dlg=$('tableOrderDialog');if(dlg?.open)dlg.close();
  resetSale();
  tableOrderDraft={tableId,tableName,startedAt:new Date().toISOString()};
  showView('cassa');
  renderCart();
  toast(`${tableName}: inserisci i prodotti e premi AGGIUNGI AL TAVOLO`,3800)
}

async function saveTableOrderFromCart(){
  const draft=tableOrderDraft;
  if(!draft?.tableId||tableOrderDraftSaving)return;
  const session=getSession(),ownerUserId=String(session?.user?.id||'');
  if(!ownerUserId){toast('Accedi almeno una volta all’Area utente prima di creare ordini tavolo');return}
  const snapshot=cartLines();
  if(!snapshot.length){toast('Aggiungi almeno un prodotto');return}
  const orderId=uid(),now=new Date().toISOString(),items=[];
  for(const line of snapshot){
    const p=line.product,productId=String(p?.sourceProductId||p?.id||'');
    const catalogProduct=products.find(x=>String(x.id)===productId);
    if(!catalogProduct){toast(`Prodotto non riconosciuto: ${p?.name||'Prodotto'}`,4500);return}
    const quantity=Number(line.quantity||0),unitPrice=lineUnitTotal(line);
    if(!(quantity>0)||unitPrice<0){toast(`Quantità o prezzo non valido per ${p?.name||'Prodotto'}`);return}
    items.push({id:uid(),order_id:orderId,owner_user_id:ownerUserId,product_id:productId,product_name:String(p?.name||catalogProduct.name||'Prodotto'),quantity,unit_price:unitPrice,line_total:roundMoney(quantity*unitPrice),notes:composeOrderItemNote(line)||null,created_at:now})
  }
  const total=roundMoney(items.reduce((n,x)=>n+Number(x.line_total||0),0));
  let localOrder={id:orderId,owner_user_id:ownerUserId,table_id:String(draft.tableId),table_name:String(draft.tableName||'Tavolo'),created_by:ownerUserId,created_by_device_id:null,status:'sent',notes:null,subtotal:total,total,created_at:now,updated_at:now,items,localCashier:true,cloudSynced:false,cloudDirty:true,kitchenAttempted:false,kitchenPrinted:false,kitchenError:''};
  tableOrderDraftSaving=true;renderCart();
  try{
    const rows=lanLocalOrders();
    if(!rows.some(o=>String(o.id)===orderId)){rows.push(localOrder);lanSaveOrders(rows)}
    lanMarkTableLocal(draft.tableId,'occupied');
    /* Lo stato occupato viene pubblicato subito e non resta bloccato dietro
       eventuali vecchie comande LAN ancora da sincronizzare. In questo modo
       CassaIQ Client vede il tavolo occupato appena la cassa salva l'ordine. */
    lanPublishTableStatus(draft.tableId,'occupied').catch(()=>{});
    localOrder=await lanPrintIncoming(localOrder);
    const kitchenError=String((lanFindOrder(orderId)||localOrder)?.kitchenError||'');
    const tableName=draft.tableName||'Tavolo';
    /* La comanda appena creata dalla cassa ha priorita': sincronizziamo proprio
       questa, senza aspettare la coda storica. La coda generale resta come
       recupero per eventuali operazioni precedenti. */
    const currentOrder=lanFindOrder(orderId)||localOrder;
    lanSyncOneOrder(currentOrder).catch(e=>{console.warn('Sync ordine creato dalla cassa rinviata',orderId,e);lanSyncPendingOrders().catch(()=>{})});
    resetSale();
    showView('tavoli');
    renderTablesGrid();
    if(kitchenError&&kitchenError!=='Stampante cucina disattivata')tablesStatus('warning',`${tableName}: ordine salvato · stampa cucina da verificare: ${kitchenError}`);
    else tablesStatus('ok',`${tableName}: ordine salvato in locale · sincronizzazione cloud automatica.`);
    toast(kitchenError&&kitchenError!=='Stampante cucina disattivata'?`${tableName}: ordine salvato · controlla la stampa cucina`:`${tableName}: ordine aggiunto`,4200)
  }catch(e){
    console.error('Salvataggio ordine tavolo non riuscito',e);
    toast(`Ordine non salvato: ${e?.message||e}`,5000)
  }finally{
    tableOrderDraftSaving=false;
    if(tableOrderDraft)renderCart()
  }
}

function renderTablesGrid(){const box=$('tablesGrid');if(!box)return;box.innerHTML='';const rows=restaurantTables.filter(t=>t.active!==false).sort((a,b)=>(Number(a.sort_order)||0)-(Number(b.sort_order)||0)||String(a.name||'').localeCompare(String(b.name||''),'it'));updateTablesHeader();if(!rows.length){box.innerHTML='<div class="tables-empty"><strong>Nessun tavolo configurato</strong><span>Premi “Nuovo tavolo” per creare il primo tavolo e renderlo disponibile su CassaIQ Client.</span></div>';return}for(const t of rows){const occupied=t.status==='occupied'||t.status==='bill_requested',card=document.createElement('article');card.className=`table-card ${tableStatusClass(t.status)}${occupied?' has-order':''}`;const state=tableStatusLabel(t.status);card.innerHTML=`<div class="table-card-top"><span class="table-number">▦</span><span class="table-state">${state}</span></div><strong class="table-name"></strong><small class="table-updated"></small><div class="table-actions">${occupied?'<button type="button" class="table-open-order">Apri ordine</button>':''}<button type="button" class="table-add-order">${occupied?'+ Aggiungi':'Nuovo ordine'}</button><button type="button" class="edit table-edit">Rinomina</button><button type="button" class="delete table-disable">Disattiva</button></div>`;card.querySelector('.table-name').textContent=t.name||'Tavolo';const date=t.updated_at?new Date(t.updated_at):null;card.querySelector('.table-updated').textContent=date&&!Number.isNaN(date.getTime())?`Aggiornato ${date.toLocaleString('it-IT')}`:'Disponibile su CassaIQ Client';const open=card.querySelector('.table-open-order');if(open)open.onclick=e=>{e.stopPropagation();openTableOrder(t)};const addOrder=card.querySelector('.table-add-order');if(addOrder)addOrder.onclick=e=>{e.stopPropagation();startTableOrderDraft(t)};if(occupied)card.onclick=e=>{if(e.target.closest('button'))return;openTableOrder(t)};card.querySelector('.table-edit').onclick=e=>{e.stopPropagation();openTableDialog(t)};const disable=card.querySelector('.table-disable');disable.disabled=t.status!=='free';disable.title=t.status!=='free'?'Libera il tavolo prima di disattivarlo':'';disable.onclick=e=>{e.stopPropagation();disableRestaurantTable(t)};box.appendChild(card)}}
async function loadRestaurantTables(showMessage=true){const cached=lanCachedTables();if(!getSession()?.user?.id){restaurantTables=lanMergeTableOccupancy(cached);renderTablesGrid();tablesStatus(cached.length?'warning':'warning',cached.length?'Cloud non disponibile · uso tavoli salvati su questa cassa.':'Accedi all’Area utente almeno una volta per sincronizzare i tavoli.');return restaurantTables}if(showMessage)tablesStatus('loading','Aggiornamento tavoli…');try{const rows=await cloudRequest('restaurant_tables',{query:'?select=id,name,sort_order,status,active,updated_at&active=eq.true&order=sort_order.asc,name.asc'});const cloudRows=Array.isArray(rows)?rows:[];lanSaveTables(cloudRows);restaurantTables=lanMergeTableOccupancy(cloudRows);renderTablesGrid();tablesStatus('ok',restaurantTables.length?`${restaurantTables.length} tavoli sincronizzati · LAN pronta anche senza Internet.`:'Nessun tavolo configurato. Crea il primo tavolo.');return restaurantTables}catch(e){restaurantTables=lanMergeTableOccupancy(cached);renderTablesGrid();const msg=String(e?.message||e);if(cached.length){tablesStatus('warning',`Cloud non raggiungibile · uso ${cached.length} tavoli locali. Le comande LAN continuano a funzionare.`);return restaurantTables}tablesStatus('error',/restaurant_tables|schema cache|relation/i.test(msg)?'Tabelle sala non disponibili. Esegui in Supabase il file supabase-cassaiq-client-v0.3.sql.':`Tavoli non disponibili: ${msg}`);return[]}}
function openTableDialog(table=null){if(!getSession()?.user?.id){toast('Accedi prima all’Area utente');openUserDialog();return}const dlg=$('tableDialog');if(!dlg)return;$('tableId').value=table?.id||'';$('tableName').value=table?.name||`Tavolo ${restaurantTables.length+1}`;$('tableDialogTitle').textContent=table?'Rinomina tavolo':'Nuovo tavolo';dlg.showModal();setTimeout(()=>{$('tableName')?.focus();$('tableName')?.select()},120)}
async function saveRestaurantTable(event){event?.preventDefault?.();const id=$('tableId')?.value||'',name=String($('tableName')?.value||'').trim();if(!name)return;const session=getSession();if(!session?.user?.id){toast('Sessione non disponibile');return}const submit=$('tableForm')?.querySelector('button[type="submit"]');if(submit){submit.disabled=true;submit.textContent='Salvataggio…'}try{const now=new Date().toISOString();if(id){await cloudRequest('restaurant_tables',{method:'PATCH',query:`?id=eq.${encodeURIComponent(id)}`,body:{name,updated_at:now},prefer:'return=representation'})}else{const max=restaurantTables.reduce((m,t)=>Math.max(m,Number(t.sort_order)||0),0);await cloudRequest('restaurant_tables',{method:'POST',body:{owner_user_id:session.user.id,name,sort_order:restaurantTables.length?max+1:1,status:'free',active:true,updated_at:now},prefer:'return=representation'})}const dlg=$('tableDialog');if(dlg?.open)dlg.close();await loadRestaurantTables(false);tablesStatus('ok',id?'Tavolo rinominato e sincronizzato.':'Tavolo creato e disponibile su CassaIQ Client.');toast(id?'Tavolo rinominato':'Tavolo creato')}catch(e){toast(`Tavolo non salvato: ${e.message||e}`,5000)}finally{if(submit){submit.disabled=false;submit.textContent='Salva tavolo'}}}
async function disableRestaurantTable(table){if(!table?.id)return;if(table.status!=='free'){toast('Il tavolo deve essere libero prima di disattivarlo');return}if(!confirm(`Disattivare “${table.name}”?\n\nNon comparirà più sui dispositivi CassaIQ Client.`))return;try{await cloudRequest('restaurant_tables',{method:'PATCH',query:`?id=eq.${encodeURIComponent(table.id)}`,body:{active:false,updated_at:new Date().toISOString()},prefer:'return=representation'});await loadRestaurantTables(false);tablesStatus('ok','Tavolo disattivato.');toast('Tavolo disattivato')}catch(e){toast(`Operazione non riuscita: ${e.message||e}`,5000)}}
function tableOrderSetStatus(type,text){const el=$('tableOrderStatus');if(!el)return;el.className=`config-status-line ${type||''}`.trim();el.textContent=text}
function tableOrderAggregateItems(items){const map=new Map();for(const x of items||[]){const activeQty=Math.max(0,Number(x.quantity||0)-Number(x.cancelled_quantity||0));if(!(activeQty>0))continue;const modifierKey=Array.isArray(x.supplements)?x.supplements.map(v=>`${v.id||v.name}:${supplementKind(v)}:${roundMoney(v.price)}`).sort().join(','):'';const key=`${x.product_id||x.product_name}|${roundMoney(x.unit_price)}|${String(x.notes||'').trim()}|${modifierKey}`,activeTotal=roundMoney(activeQty*Number(x.unit_price||0)),prev=map.get(key);if(prev){prev.quantity=Number(prev.quantity)+activeQty;prev.line_total=roundMoney(Number(prev.line_total)+activeTotal)}else map.set(key,{...x,quantity:activeQty,unit_price:Number(x.unit_price||0),line_total:activeTotal})}return [...map.values()]}
function renderTableOrderDialog(){const state=tableOrderState,box=$('tableOrderItems'),meta=$('tableOrderMeta'),notes=$('tableOrderNotes'),total=$('tableOrderTotal'),toCart=$('tableOrderToCart'),removeBtn=$('tableOrderDelete'),reprintBtn=$('tableOrderKitchenReprint');if(!box||!meta||!notes||!total||!toCart)return;box.innerHTML='';meta.innerHTML='';notes.hidden=true;notes.textContent='';total.hidden=true;toCart.disabled=true;if(reprintBtn)reprintBtn.disabled=true;if(removeBtn){removeBtn.disabled=!state?.table?.id;removeBtn.textContent='Elimina'}if(!state)return;const orders=state.orders||[],items=tableOrderAggregateItems(state.items||[]);if(removeBtn)removeBtn.textContent=orders.length?'Elimina':'Libera tavolo';if(!orders.length){tableOrderSetStatus('warning','Il tavolo risulta occupato, ma non ci sono comande aperte. Puoi liberarlo con “Libera tavolo”.');return}const first=new Date(orders[0].created_at),last=new Date(orders[orders.length-1].created_at);meta.hidden=false;meta.innerHTML=`<span>${orders.length} ${orders.length===1?'comanda':'comande'}</span><span>${items.reduce((n,x)=>n+Number(x.quantity||0),0)} articoli</span><span>${Number.isNaN(first.getTime())?'':first.toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit'})}${orders.length>1&&!Number.isNaN(last.getTime())?` → ${last.toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit'})}`:''}</span>`;if(!items.length){tableOrderSetStatus('warning','Comanda trovata, ma senza righe prodotto. Puoi eliminarla e liberare il tavolo.');return}for(const x of items){const row=document.createElement('div');row.className='table-order-row';const left=document.createElement('div'),name=document.createElement('strong'),sub=document.createElement('small'),line=document.createElement('strong');name.textContent=x.product_name||'Prodotto';sub.textContent=`${Number(x.quantity||0)} × ${euro(Number(x.unit_price||0))}`;line.className='table-order-line-total';line.textContent=euro(Number(x.line_total||0));left.append(name,sub);const itemNote=String(x.notes||'').trim();if(itemNote){const noteEl=document.createElement('div');noteEl.className='table-order-item-note';noteEl.textContent=`📝 ${itemNote}`;left.appendChild(noteEl)}row.append(left,line);box.appendChild(row)}const allNotes=orders.map(o=>String(o.notes||'').trim()).filter(Boolean);if(allNotes.length){notes.hidden=false;notes.textContent=`Note: ${allNotes.join(' · ')}`}const sum=roundMoney(items.reduce((n,x)=>n+Number(x.line_total||0),0));total.hidden=false;total.querySelector('strong').textContent=euro(sum);toCart.disabled=false;if(reprintBtn)reprintBtn.disabled=false;tableOrderSetStatus('ok','Comanda pronta. Puoi portarla nel carrello della cassa o ristamparla in cucina.')}
async function openTableOrder(table){if(!table?.id)return;const dlg=$('tableOrderDialog');if(!dlg)return;$('tableOrderTitle').textContent=table.name||'Tavolo';tableOrderState={table,orders:[],items:[]};renderTableOrderDialog();tableOrderSetStatus('loading','Caricamento comanda…');if(!dlg.open)dlg.showModal();const local=lanOpenLocalOrders(table.id),localOrders=local.map(({items,...o})=>o),localItems=local.flatMap(o=>o.items||[]);try{const orders=await cloudRequest('orders',{query:`?select=id,table_id,status,notes,subtotal,total,created_at,updated_at&table_id=eq.${encodeURIComponent(table.id)}&status=in.(sent,accepted)&order=created_at.asc`,timeoutMs:6000});const cloudOrders=Array.isArray(orders)?orders:[];let cloudItems=[];if(cloudOrders.length){const ids=cloudOrders.map(o=>o.id).filter(Boolean);const filter=ids.map(encodeURIComponent).join(',');cloudItems=await cloudRequest('order_items',{query:`?select=id,order_id,product_id,product_name,quantity,cancelled_quantity,cancelled_at,cancelled_by_device_id,cancellation_note,unit_price,line_total,notes,created_at&order_id=in.(${filter})&order=created_at.asc`,timeoutMs:6000})}const orderMap=new Map();for(const o of cloudOrders)orderMap.set(String(o.id),o);for(const o of localOrders)orderMap.set(String(o.id),{...(orderMap.get(String(o.id))||{}),...o});const itemMap=new Map();for(const i of Array.isArray(cloudItems)?cloudItems:[])itemMap.set(String(i.id),i);for(const i of localItems)itemMap.set(String(i.id),{...(itemMap.get(String(i.id))||{}),...i});tableOrderState={table,orders:[...orderMap.values()].sort((a,b)=>String(a.created_at||'').localeCompare(String(b.created_at||''))),items:[...itemMap.values()].sort((a,b)=>String(a.created_at||'').localeCompare(String(b.created_at||'')))};renderTableOrderDialog();if(local.length)tableOrderSetStatus('ok',local.some(o=>o.cloudDirty!==false)?'Comanda disponibile in locale · sincronizzazione cloud automatica quando Internet è disponibile.':'Comanda pronta · LAN e cloud sincronizzati.')}catch(e){if(localOrders.length){tableOrderState={table,orders:localOrders,items:localItems};renderTableOrderDialog();tableOrderSetStatus('warning','Internet non disponibile · stai lavorando sulla comanda salvata localmente.')}else{tableOrderSetStatus('error',`Comanda non disponibile: ${e.message||e}`);$('tableOrderToCart').disabled=true}}}
async function tableOrderReprintKitchen(){
  const state=tableOrderState,button=$('tableOrderKitchenReprint');
  if(!state?.table?.id||!state?.orders?.length||!state?.items?.length)return toast('Nessuna comanda da ristampare');
  const rows=tableOrderAggregateItems(state.items||[]);
  if(!rows.length)return toast('Nessuna riga da ristampare');
  const oldText=button?.textContent||'Ristampa cucina';if(button){button.disabled=true;button.textContent='Stampa…'}
  tableOrderSetStatus('loading','Invio nuova stampa alla cucina…');
  try{
    const notes=(state.orders||[]).map(o=>String(o.notes||'').trim()).filter(Boolean).join(' · ');
    await kitchenPrintOrder({tableName:state.table.name||'Tavolo',lines:rows.map(x=>({name:x.product_name||'Prodotto',quantity:Number(x.quantity||0),note:String(x.notes||'').trim(),productId:x.product_id||x.productId||null})),notes,source:'CassaIQ · RISTAMPA',orderId:state.orders[0]?.id||''},{force:true});
    tableOrderSetStatus('ok','Nuova stampa della comanda inviata in cucina.');
    toast(`${state.table.name||'Tavolo'}: ristampa inviata in cucina`,3500);
  }catch(e){tableOrderSetStatus('error',`Ristampa cucina non riuscita: ${e.message||e}`);toast('Ristampa cucina non riuscita',4000)}
  finally{if(button){button.textContent=oldText;button.disabled=!(tableOrderState?.orders?.length&&tableOrderState?.items?.length)}}
}
async function tableOrderDelete(){
  const state=tableOrderState;if(!state?.table?.id)return;const hasOrders=(state.orders||[]).length>0,tableName=state.table.name||'Tavolo';
  if(!confirm(hasOrders?`Eliminare la comanda di ${tableName} e liberare il tavolo? Non verrà inviato alcun messaggio in cucina e non verrà chiuso alcun conto.`:`Liberare ${tableName}? Il tavolo tornerà disponibile su CassaIQ Client.`))return;
  const removeBtn=$('tableOrderDelete'),toCart=$('tableOrderToCart');if(removeBtn)removeBtn.disabled=true;if(toCart)toCart.disabled=true;

  // v1.15.3: liberare/eliminare un tavolo dalla cassa NON invia nulla in cucina.
  // Gli aggiornamenti o annullamenti destinati alla cucina vengono gestiti dal CassaIQ Client.
  const orderIds=(state.orders||[]).map(o=>o.id).filter(Boolean),now=new Date().toISOString();lanPatchOrders(orderIds,{status:'cancelled',subtotal:0,total:0,updated_at:now});lanMarkTableLocal(state.table.id,'free');
  if(activeTableCheckout?.tableId===state.table.id)activeTableCheckout=null;tableOrderState={table:state.table,orders:[],items:[]};renderTableOrderDialog();tableOrderSetStatus('loading','Tavolo liberato in locale · sincronizzazione cloud…');
  try{
    if(orderIds.length){const ids=orderIds.map(encodeURIComponent).join(',');await cloudRequest('orders',{method:'PATCH',query:`?id=in.(${ids})`,body:{status:'cancelled',subtotal:0,total:0,updated_at:now},prefer:'return=minimal',timeoutMs:6000})}
    await cloudRequest('restaurant_tables',{method:'PATCH',query:`?id=eq.${encodeURIComponent(state.table.id)}`,body:{status:'free',updated_at:now},prefer:'return=minimal',timeoutMs:6000});tableOrderSetStatus('ok',hasOrders?'Comanda chiusa e tavolo liberato. Nessun messaggio inviato in cucina.':'Tavolo liberato correttamente.')
  }catch(e){tableOrderSetStatus('warning','Tavolo liberato localmente · cloud non disponibile, sincronizzazione rinviata.');lanSyncPendingOrders().catch(()=>{})}
  toast(`${tableName} liberato`,3000);renderTablesGrid();const dlg=$('tableOrderDialog');setTimeout(()=>{if(dlg?.open)dlg.close()},500)
}
function parseTableOrderLinePersonalization(row){
  let supplements=Array.isArray(row?.supplements)?row.supplements.map(x=>({...x,kind:supplementKind(x)})):[];
  const raw=String(row?.notes||'').trim();if(!raw)return{supplements,note:''};
  const segments=raw.split(/\s+\|\s+/),parsed=[],consumed=[];
  for(const segment of segments){
    const tokens=segment.split(/\s*·\s*/).filter(Boolean),found=[];let valid=tokens.length>0;
    for(const token of tokens){const m=token.match(/^([+\-−])\s*(.+)$/);if(!m){valid=false;break}const wanted=normalizedCatalogName(m[2]),product=supplementProducts().find(p=>normalizedCatalogName(p.name)===wanted);if(!product){valid=false;break}found.push({id:product.id,name:product.name,price:m[1]==='+'?roundMoney(product.price):0,kind:m[1]==='+'?'add':'remove',categoryId:product.categoryId||'',departmentId:product.departmentId||''})}
    if(!valid)break;parsed.push(...found);consumed.push(segment)
  }
  if(!supplements.length&&parsed.length)supplements=parsed;
  const note=segments.slice(consumed.length).join(' | ').trim();
  return{supplements,note}
}
async function tableOrderToCart(){const state=tableOrderState;if(!state?.orders?.length||!state?.items?.length)return;const rows=tableOrderAggregateItems(state.items);if(cartLines().length&&!confirm('Il carrello attuale verrà sostituito con la comanda del tavolo. Continuare?'))return;try{await syncCatalogFromCloud(false)}catch{}const prepared=[],missing=[];for(const row of rows){const product=products.find(p=>String(p.id)===String(row.product_id));if(!product||!product.departmentId){missing.push(row.product_name||'Prodotto');continue}prepared.push({row,product})}if(missing.length){tableOrderSetStatus('error',`Non posso portare in cassa: manca il reparto fiscale per ${missing.slice(0,3).join(', ')}${missing.length>3?'…':''}. Controlla i prodotti in CassaIQ.`);return}resetSale();for(const {row,product} of prepared){const qty=Number(row.quantity)||0,storedPrice=roundMoney(row.unit_price),personal=parseTableOrderLinePersonalization(row),supplements=personal.supplements||[],suppTotal=supplementUnitTotal(supplements),expected=roundMoney(Number(product.price||0)+suppTotal),hasPersonal=!!personal.note||supplements.length>0;let lineId;if(!product.variablePrice&&expected===storedPrice){lineId=hasPersonal?cartLineKeyForProduct(product.id,false):(mergeableNormalCartLine(product.id)||cartLineKeyForProduct(product.id,true));cart[lineId]=(cart[lineId]||0)+qty}else{const basePrice=Math.max(0,roundMoney(storedPrice-suppTotal)),item={id:uid(),name:row.product_name||product.name,price:basePrice,manual:true,sourceProductId:product.id,categoryId:product.categoryId||'',departmentId:product.departmentId||'',icon:'',image:'',imageLibraryId:''};manualItems.push(item);lineId=item.id;cart[lineId]=qty}if(personal.note)cartItemNotes[lineId]=personal.note;if(supplements.length)cartSupplements[lineId]=supplements.map(x=>({...x}))}activeTableCheckout={tableId:state.table.id,tableName:state.table.name||'Tavolo',orderIds:state.orders.map(o=>o.id),loadedAt:new Date().toISOString()};const now=new Date().toISOString();lanPatchOrders(activeTableCheckout.orderIds,{status:'accepted',updated_at:now});try{const ids=activeTableCheckout.orderIds.map(encodeURIComponent).join(',');await cloudRequest('orders',{method:'PATCH',query:`?id=in.(${ids})`,body:{status:'accepted',updated_at:now},prefer:'return=minimal',timeoutMs:6000})}catch(e){console.warn('Comanda caricata localmente; stato accepted cloud rinviato',e);lanSyncPendingOrders().catch(()=>{})}const dlg=$('tableOrderDialog');if(dlg?.open)dlg.close();showView('cassa');renderCart(true);toast(`${activeTableCheckout.tableName}: comanda caricata in cassa`,3500)}
async function finalizeActiveTableCheckout(){const ctx=activeTableCheckout;if(!ctx?.tableId||!ctx.orderIds?.length)return false;activeTableCheckout=null;const now=new Date().toISOString();lanPatchOrders(ctx.orderIds,{status:'closed',updated_at:now});if(!lanOpenLocalOrders(ctx.tableId).length)lanMarkTableLocal(ctx.tableId,'free');try{const ids=ctx.orderIds.map(encodeURIComponent).join(',');await cloudRequest('orders',{method:'PATCH',query:`?id=in.(${ids})`,body:{status:'closed',updated_at:now},prefer:'return=minimal',timeoutMs:6000});const remaining=await cloudRequest('orders',{query:`?select=id&table_id=eq.${encodeURIComponent(ctx.tableId)}&status=in.(sent,accepted)&limit=1`,timeoutMs:6000});if(!Array.isArray(remaining)||!remaining.length)await cloudRequest('restaurant_tables',{method:'PATCH',query:`?id=eq.${encodeURIComponent(ctx.tableId)}`,body:{status:'free',updated_at:now},prefer:'return=minimal',timeoutMs:6000});loadRestaurantTables(false).catch(()=>{});return true}catch(e){console.warn('Tavolo chiuso localmente; sincronizzazione cloud rinviata',e);lanSyncPendingOrders().catch(()=>{});toast(`${ctx.tableName}: tavolo chiuso localmente · cloud da sincronizzare`,5000);return true}}
function initTablesView(){if(!tablesViewBound){tablesViewBound=true;if($('addTable'))$('addTable').onclick=()=>openTableDialog();if($('refreshTables'))$('refreshTables').onclick=()=>loadRestaurantTables(true);if($('tableForm'))$('tableForm').onsubmit=saveRestaurantTable;if($('tableOrderToCart'))$('tableOrderToCart').onclick=tableOrderToCart;if($('tableOrderKitchenReprint'))$('tableOrderKitchenReprint').onclick=tableOrderReprintKitchen;if($('tableOrderAdd'))$('tableOrderAdd').onclick=()=>tableOrderState?.table&&startTableOrderDraft(tableOrderState.table);if($('tableOrderDelete'))$('tableOrderDelete').onclick=tableOrderDelete;const orderDlg=$('tableOrderDialog');if(orderDlg&&!orderDlg.dataset.stateCloseBound){orderDlg.dataset.stateCloseBound='1';orderDlg.addEventListener('close',()=>{tableOrderState=null})}}loadRestaurantTables(true)}
let clientPairingTimer=null;
function clientPairingStatus(type,text){const el=$('clientPairingStatus');if(!el)return;el.className=`config-status-line ${type||''}`;el.textContent=text||''}

function clientShortDeviceCode(id){const raw=String(id||'').replace(/[^a-fA-F0-9]/g,'').toUpperCase();return raw?raw.slice(-5).padStart(5,'0'):'-----'}
function clientDeviceDisplayName(device){
  const saved=String(device?.device_name||'').trim();
  if(saved && !/^cassaiq client$/i.test(saved) && !/^client$/i.test(saved))return saved;
  return `Client ${clientShortDeviceCode(device?.id)}`;
}
function clientFormatLastSeen(value){if(!value)return'Mai';const d=new Date(value);if(Number.isNaN(d.getTime()))return'Mai';return d.toLocaleString('it-IT',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}
function clientRenderPairingCode(code,expiresAt){const box=$('clientPairingCodeBox'),codeEl=$('clientPairingCode'),exp=$('clientPairingExpiry');clearInterval(clientPairingTimer);if(!box||!codeEl||!exp)return;if(!code||!expiresAt){box.hidden=true;codeEl.textContent='------';return}box.hidden=false;codeEl.textContent=String(code).padStart(6,'0');const tick=()=>{const left=Math.max(0,new Date(expiresAt).getTime()-Date.now());if(left<=0){clearInterval(clientPairingTimer);box.hidden=true;clientPairingStatus('warning','Codice scaduto. Generane uno nuovo per collegare un dispositivo.');return}const m=Math.floor(left/60000),sec=Math.floor((left%60000)/1000);exp.textContent=`Scade tra ${m}:${String(sec).padStart(2,'0')} · monouso`};tick();clientPairingTimer=setInterval(tick,1000)}
async function clientLoadCurrentPairingCode(){if(!getSession()?.user?.id){clientRenderPairingCode(null,null);return}try{const now=encodeURIComponent(new Date().toISOString());const rows=await cloudRequest('cassaiq_pairing_codes',{query:`?select=code,expires_at&used_at=is.null&expires_at=gt.${now}&order=created_at.desc&limit=1`});const row=rows?.[0];if(row)clientRenderPairingCode(row.code,row.expires_at);else clientRenderPairingCode(null,null)}catch(e){console.warn('Codice pairing non disponibile',e)}}
async function clientLoadDevices(showStatus=false){const list=$('clientDevicesList'),count=$('clientDeviceCount');if(!list)return;const session=getSession();if(!session?.user?.id){list.innerHTML='<div class="client-device-empty">Accedi all’Area utente per vedere i dispositivi.</div>';if(count)count.textContent='';return}if(showStatus)clientPairingStatus('loading','Aggiornamento dispositivi…');try{const rows=await cloudRequest('cassaiq_client_devices',{query:'?select=id,device_name,status,paired_at,last_seen_at,revoked_at&order=paired_at.desc'});const active=(rows||[]).filter(x=>x.status==='active');save(K.clientAuthorizedIds,active.map(x=>String(x.id)));clientLanStart(false).catch(()=>{});if(count)count.textContent=`${active.length} attiv${active.length===1?'o':'i'}`;if(!active.length)list.innerHTML='<div class="client-device-empty">Nessun dispositivo collegato.</div>';else list.innerHTML=active.map(d=>`<div class="client-device-row"><span class="device-dot">CI</span><div><strong>${escapeHtml(clientDeviceDisplayName(d))}</strong><small>Collegato · ultimo contatto ${escapeHtml(clientFormatLastSeen(d.last_seen_at||d.paired_at))}</small></div><button type="button" data-revoke-client="${escapeHtml(d.id)}">Revoca</button></div>`).join('');list.querySelectorAll('[data-revoke-client]').forEach(btn=>btn.onclick=()=>clientRevokeDevice(btn.dataset.revokeClient));if(showStatus)clientPairingStatus('ok','Dispositivi aggiornati.')}catch(e){list.innerHTML='<div class="client-device-empty">Impossibile leggere i dispositivi collegati.</div>';if(showStatus)clientPairingStatus('error',`Aggiornamento non riuscito: ${e.message||e}`)}}
async function clientGeneratePairingCode(){const button=$('clientGeneratePairingCode');if(!getSession()?.user?.id){clientPairingStatus('error','Accedi prima all’Area utente di CassaIQ.');return}if(button)button.disabled=true;clientPairingStatus('loading','Generazione codice temporaneo…');try{const out=await cloudRpc('cassaiq_create_pairing_code',{}),row=Array.isArray(out)?out[0]:out;if(!row?.code||!row?.expires_at)throw new Error('Il server non ha restituito il codice.');clientRenderPairingCode(row.code,row.expires_at);clientPairingStatus('ok','Codice pronto. Inseriscilo ora su CassaIQ Client.');await clientLoadDevices(false)}catch(e){clientRenderPairingCode(null,null);const msg=String(e?.message||e);clientPairingStatus('error',/cassaiq_create_pairing_code|schema cache|function/i.test(msg)?'Funzione pairing non disponibile. Esegui in Supabase il file supabase-cassaiq-client-v0.3.sql.':`Codice non generato: ${msg}`)}finally{if(button)button.disabled=false}}
async function clientRevokeDevice(id){if(!id||!getSession()?.user?.id)return;if(!confirm('Revocare questo dispositivo? CassaIQ Client perderà subito l’accesso al catalogo e alle comande.'))return;try{await cloudRequest('cassaiq_client_devices',{method:'PATCH',query:`?id=eq.${encodeURIComponent(id)}`,body:{status:'revoked',revoked_at:new Date().toISOString()},prefer:'return=minimal'});toast('Dispositivo revocato');await clientLoadDevices(false)}catch(e){clientPairingStatus('error',`Revoca non riuscita: ${e.message||e}`)}}
function initClientPairingPanel(){const generate=$('clientGeneratePairingCode'),refresh=$('clientRefreshDevices');if(getSession()?.user?.id)loadRestaurantTables(false);if(!generate)return;const logged=!!getSession()?.user?.id;generate.disabled=!logged;if(refresh)refresh.disabled=!logged;if(!generate.dataset.bound){generate.dataset.bound='1';generate.onclick=clientGeneratePairingCode;if(refresh)refresh.onclick=()=>clientLoadDevices(true)}if(!logged){clearInterval(clientPairingTimer);clientRenderPairingCode(null,null);clientPairingStatus('warning','Accedi all’Area utente per generare il codice CassaIQ Client.');clientLoadDevices(false);return}clientPairingStatus('ok','Pronto per collegare telefoni e tablet a questa CassaIQ.');clientLoadCurrentPairingCode();clientLoadDevices(false)}

/* Dati fiscali/anagrafici dell'attivita': il localStorage resta il fallback
   immediato per la stampa, mentre Supabase li rende disponibili a tutti i
   dispositivi collegati allo stesso account. */
function mapBusinessProfileFromCloud(row,fallback={}){
  const hasLogo=Object.prototype.hasOwnProperty.call(row||{},'receipt_logo_data'),logoData=hasLogo?String(row?.receipt_logo_data||''):String(fallback?.receiptLogoData||'');
  return{legalName:String(row?.legal_name||'').trim(),tradeName:String(row?.trade_name||'').trim(),vat:String(row?.vat_number||'').replace(/\D/g,'').slice(0,11),taxCode:String(row?.tax_code||'').trim().toUpperCase().slice(0,16),address:String(row?.address||'').trim(),civic:String(row?.civic||'').trim(),zip:String(row?.zip_code||'').replace(/\D/g,'').slice(0,5),city:String(row?.city||'').trim(),province:String(row?.province||'').trim().toUpperCase().slice(0,2),phone:String(row?.phone||'').trim(),email:String(row?.email||'').trim(),receiptLogoData:logoData,receiptLogoEnabled:!!logoData&&(hasLogo?row?.receipt_logo_enabled!==false:fallback?.receiptLogoEnabled!==false)}
}
function businessProfileCloudPayload(profile,includeLogo=true){
  const session=getSession();if(!session?.user?.id)throw new Error('Accedi prima all’Area utente.');
  const out={user_id:session.user.id,legal_name:profile.legalName,trade_name:profile.tradeName||null,vat_number:profile.vat,tax_code:profile.taxCode||null,address:profile.address,civic:profile.civic,zip_code:profile.zip,city:profile.city,province:profile.province,phone:profile.phone||null,email:profile.email||null,updated_at:new Date().toISOString()};
  if(includeLogo){out.receipt_logo_data=profile.receiptLogoData||null;out.receipt_logo_enabled=!!profile.receiptLogoData&&profile.receiptLogoEnabled!==false}
  return out
}
async function cloudSaveBusinessProfile(profile){
  let rows;
  try{
    rows=await cloudRequest('business_profiles',{method:'POST',body:businessProfileCloudPayload(profile,true),prefer:'resolution=merge-duplicates,return=representation'});dcoReceiptLogoCloudSchemaMissing=false
  }catch(e){
    if(!/receipt_logo_|schema cache|column/i.test(String(e?.message||e)))throw e;
    dcoReceiptLogoCloudSchemaMissing=true;
    rows=await cloudRequest('business_profiles',{method:'POST',body:businessProfileCloudPayload(profile,false),prefer:'resolution=merge-duplicates,return=representation'})
  }
  return rows?.[0]?mapBusinessProfileFromCloud(rows[0],profile):profile
}
async function syncBusinessProfileFromCloud(showMessage=false){
  const session=getSession();if(!session?.user?.id)return false;const localProfile=dcoBusinessProfile(),localValid=dcoBusinessValidation(localProfile).ok;
  try{
    const rows=await cloudRequest('business_profiles',{query:`?user_id=eq.${encodeURIComponent(session.user.id)}&select=*&limit=1`});
    if(rows?.length){
      const hasLogo=Object.prototype.hasOwnProperty.call(rows[0],'receipt_logo_data');dcoReceiptLogoCloudSchemaMissing=!hasLogo&&!!localProfile.receiptLogoData;
      const remote=mapBusinessProfileFromCloud(rows[0],localProfile);localStorage.setItem(dcoBusinessProfileStorageKey(),JSON.stringify(remote));
      if(Object.prototype.hasOwnProperty.call(rows[0],'kitchen_printer_enabled'))kitchenApplyConfig({enabled:!!rows[0].kitchen_printer_enabled,host:rows[0].kitchen_printer_ip||'',port:Number(rows[0].kitchen_printer_port)||9100});
      dcoFillBusinessForm();renderCart();
      if(showMessage)renderDcoBusinessStatus(dcoReceiptLogoCloudSchemaMissing&&remote.receiptLogoData?'Dati attività recuperati. Il logo resta salvato su questo dispositivo; esegui lo SQL logo per sincronizzarlo nel cloud.':'Dati dell’attivita recuperati dal tuo account.',dcoReceiptLogoCloudSchemaMissing&&remote.receiptLogoData?'warning':'ok');
      return true
    }
    if(localValid){await cloudSaveBusinessProfile(localProfile);dcoFillBusinessForm();renderCart();if(showMessage)renderDcoBusinessStatus(dcoReceiptLogoCloudSchemaMissing&&localProfile.receiptLogoData?'Dati attività caricati. Logo locale attivo; SQL cloud logo da eseguire.':'Dati locali dell’attivita caricati nel tuo account.',dcoReceiptLogoCloudSchemaMissing&&localProfile.receiptLogoData?'warning':'ok');return true}
    dcoFillBusinessForm();return false
  }catch(e){console.warn('Sincronizzazione profilo attivita non disponibile',e);if(showMessage)renderDcoBusinessStatus(`Dati attività disponibili solo su questo dispositivo: ${e.message||e}`,'warning');return false}
}
function mapCategoryFromCloud(x){return{id:x.id,name:x.name,icon:x.icon||'▦',color:x.color||'#4F8FD8'}}
function mapDepartmentFromCloud(x){return{id:x.id,name:x.name,number:Number(x.epson_department),vat:Number(x.vat_rate)}}
function mapProductFromCloud(x){const local=products.find(p=>p.id===x.id),hasLibraryField=Object.prototype.hasOwnProperty.call(x,'image_library_id');const hasShow=Object.prototype.hasOwnProperty.call(x,'show_price');const hasVar=Object.prototype.hasOwnProperty.call(x,'variable_price');return{id:x.id,name:x.name,price:Number(x.price),icon:'',image:local?.image||'',imageLibraryId:hasLibraryField?(x.image_library_id||''):(local?.imageLibraryId||''),categoryId:x.category_id,departmentId:x.department_id,showPrice:hasShow?x.show_price!==false:(local?local.showPrice!==false:true),variablePrice:hasVar?!!x.variable_price:!!local?.variablePrice}}
async function cloudSaveCategory(obj){const s=getSession(),payload={id:obj.id,user_id:s.user.id,name:obj.name,icon:obj.icon,color:obj.color||'#4F8FD8',sector:'generico',active:true};const rows=await cloudRequest('categories',{method:'POST',body:payload,prefer:'resolution=merge-duplicates,return=representation'});localStorage.setItem(K.lastSync,new Date().toISOString());return mapCategoryFromCloud(rows[0])}
async function cloudSaveDepartment(obj){const s=getSession(),payload={id:obj.id,user_id:s.user.id,name:obj.name,epson_department:obj.number,vat_rate:obj.vat,active:true};const rows=await cloudRequest('departments',{method:'POST',body:payload,prefer:'resolution=merge-duplicates,return=representation'});localStorage.setItem(K.lastSync,new Date().toISOString());return mapDepartmentFromCloud(rows[0])}
async function cloudSaveProduct(obj){const s=getSession(),payload={id:obj.id,user_id:s.user.id,name:obj.name,description:'',price:obj.price,icon:'',category_id:obj.categoryId,department_id:obj.departmentId,image_library_id:obj.imageLibraryId||null,active:true,show_price:obj.showPrice!==false,variable_price:!!obj.variablePrice};let rows;try{rows=await cloudRequest('products',{method:'POST',body:payload,prefer:'resolution=merge-duplicates,return=representation'})}catch(e){if(!/image_library_id|show_price|variable_price|schema cache/i.test(e.message||''))throw e;delete payload.image_library_id;delete payload.show_price;delete payload.variable_price;rows=await cloudRequest('products',{method:'POST',body:payload,prefer:'resolution=merge-duplicates,return=representation'});toast('Esegui gli SQL aggiornati per sincronizzare figura e opzioni prezzo',4600)}localStorage.setItem(K.lastSync,new Date().toISOString());const mapped=mapProductFromCloud(rows[0]);mapped.image=obj.image||'';mapped.imageLibraryId=obj.imageLibraryId||'';/* Le opzioni scelte dall'utente vincono sempre: se le colonne non esistono
   ancora su Supabase, la risposta non le contiene e andrebbero perse. */
mapped.showPrice=obj.showPrice!==false;mapped.variablePrice=!!obj.variablePrice;return mapped}
async function cloudDelete(type,id){const table={category:'categories',product:'products',department:'departments'}[type];if(!table)return;await cloudRequest(table,{method:'DELETE',query:`?id=eq.${encodeURIComponent(id)}`});localStorage.setItem(K.lastSync,new Date().toISOString())}
async function syncCatalogFromCloud(showMessage=false){if(!getSession())return;try{if(showMessage)userStatus('loading','Sincronizzazione catalogo…');const [rc,rd,rp]=await Promise.all([cloudRequest('categories',{query:'?select=*&active=eq.true&order=sort_order.asc,created_at.asc'}),cloudRequest('departments',{query:'?select=*&active=eq.true&order=epson_department.asc'}),cloudRequest('products',{query:'?select=*&active=eq.true&order=sort_order.asc,created_at.asc'})]);categories=(rc||[]).map(mapCategoryFromCloud);departments=(rd||[]).map(mapDepartmentFromCloud);products=(rp||[]).map(mapProductFromCloud);/* Se il database non ha ancora le colonne delle opzioni prezzo, avvisa:
   quei valori vivono solo in locale e si perdono a ogni reinstallazione. */
cloudPriceOptionsMissing=!!(rp&&rp.length)&&!Object.prototype.hasOwnProperty.call(rp[0],'show_price');renderSchemaWarning();save(K.categories,categories);save(K.departments,departments);save(K.products,products);localStorage.setItem(K.lastSync,new Date().toISOString());renderCategoryButtons();renderProducts();renderCategoryManager();renderProductManager();renderDepartmentManager();if(showMessage)userStatus('ok','Catalogo sincronizzato con Supabase.');return true}catch(e){if(showMessage)userStatus('error',`Sincronizzazione non riuscita: ${e.message}`);else toast('Cloud non raggiungibile: uso i dati locali',3500);return false}}

/* Inserisce una riga tollerando colonne mancanti sul database: se PostgREST
   segnala che una colonna non esiste, la toglie dal payload e ritenta, finche'
   la riga entra. Cosi' una vendita non va mai persa per un semplice disallineamento. */
async function postWithFallback(table,payload,optional){
  let body={...payload},attempts=0;
  while(true){
    try{await cloudRequest(table,{method:'POST',body,prefer:'resolution=merge-duplicates,return=minimal'});return}
    catch(e){
      const msg=String(e.message||'');
      const m=msg.match(/'([a-z_][a-z0-9_]*)'\s+column/i)||msg.match(/column\s+'?\"?([a-z_][a-z0-9_]*)'?\"?/i);
      const col=m&&m[1];
      if(col&&col in body&&(optional.includes(col)||/schema cache|could not find/i.test(msg))){delete body[col];attempts++;if(attempts<=optional.length+2)continue}
      throw e;
    }
  }
}
async function cloudSaveSale(sale){
  const session=getSession();
  if(!session?.user?.id)throw new Error('Accedi prima all’Area utente.');
  const u=session.user.id,payload={id:sale.id,user_id:u,sold_at:sale.date,total:sale.total,subtotal:sale.subtotal,discount_amount:sale.discount||0,payment_method:sale.payment,receipt_number:sale.receiptNumber||null,item_count:sale.items,cash_received:sale.cashReceived||0,change_due:sale.changeDue||0};
  /* La testata della vendita e' la parte essenziale per incasso, numero di
     scontrini e ultime vendite. La salviamo prima e non la consideriamo persa
     se una singola riga prodotto incontra un problema di schema. */
  await postWithFallback('sales',payload,['subtotal','discount_amount','payment_method','receipt_number','item_count','cash_received','change_due']);
  const itemErrors=[];
  if(sale.lines?.length){
    for(const l of sale.lines){
      try{
        await postWithFallback('sale_items',{id:l.id,sale_id:sale.id,user_id:u,product_id:l.productId||null,product_name:l.name,quantity:l.quantity,unit_price:l.unitPrice,line_total:l.lineTotal,category_name:l.categoryName||'',department_name:l.departmentName||'',vat_rate:l.vatRate||0},['category_name','department_name','vat_rate']);
      }catch(e){itemErrors.push(e);console.warn('Riga vendita non sincronizzata',l.id,e)}
    }
  }
  return{headerSaved:true,itemErrors};
}
let salesSyncPromise=null;
let salesSyncAfterCurrent=false;
let lastSalesSyncStartedAt=0;
const SALES_SYNC_MIN_INTERVAL_MS=15000;
const SALES_BACKGROUND_UPLOAD_LIMIT=2;
const SALES_MANUAL_UPLOAD_LIMIT=12;
const SALES_BACKGROUND_DETAIL_REPAIR_LIMIT=0;
const SALES_MANUAL_DETAIL_REPAIR_LIMIT=24;
let salesRecoveryTimer=null;
function scheduleSalesRecovery(delay=800,{force=false}={}){if(!getSession()?.user?.id||!navigator.onLine)return;clearTimeout(salesRecoveryTimer);salesRecoveryTimer=setTimeout(()=>{if(force)lastSalesSyncStartedAt=0;syncSalesFromCloud(false).catch(()=>{})},Math.max(0,delay))}

function scheduleSalesSyncAfterSale(delay=450){
  if(!getSession()?.user?.id)return;
  if(salesSyncPromise){salesSyncAfterCurrent=true;return}
  setTimeout(()=>syncSalesFromCloud(false).catch(()=>{}),delay);
}
function setStatsSyncStatus(type,text){const el=$('statsSyncStatus');if(!el)return;el.className=`stats-sync-status ${type||''}`.trim();el.textContent=text}
const SALES_CLOUD_PAGE_SIZE=1000;
async function cloudFetchAllPages(table,{order='',snapshotColumn='created_at',snapshotAt='',showProgress=false,progressLabel='Dati'}={}){
  /* Supabase/PostgREST applica normalmente un limite massimo di 1000 righe
     per risposta. CassaIQ deve quindi continuare a chiedere pagine successive
     finche' non ha ricevuto l'intero archivio. Un cutoff temporale rende lo
     snapshot stabile anche se nel frattempo viene emessa una nuova vendita. */
  const out=[],seen=new Set();
  let offset=0,page=0;
  while(true){
    const q=['select=*'];
    if(snapshotColumn&&snapshotAt)q.push(`${snapshotColumn}=lte.${encodeURIComponent(snapshotAt)}`);
    if(order)q.push(`order=${order}`);
    q.push(`limit=${SALES_CLOUD_PAGE_SIZE}`,`offset=${offset}`);
    const rows=await cloudRequest(table,{query:`?${q.join('&')}`});
    const block=Array.isArray(rows)?rows:[];
    for(const row of block){
      const key=row&&row.id!=null?String(row.id):'';
      if(key){if(seen.has(key))continue;seen.add(key)}
      out.push(row);
    }
    page++;
    if(showProgress)setStatsSyncStatus('loading',`${progressLabel}: ${out.length} righe ricevute…`);
    if(block.length<SALES_CLOUD_PAGE_SIZE)break;
    offset+=block.length;
    if(page>500)throw new Error(`Archivio ${table} troppo grande per la sincronizzazione automatica.`);
  }
  return out;
}
async function fetchCloudSalesSnapshot(showProgress=false){
  /* RLS limita gia' le righe all'utente autenticato. Non aggiungiamo un
     secondo filtro user_id. La lettura e' paginata, quindi non si ferma piu'
     alle prime 1000 righe restituite da PostgREST. */
  const snapshotAt=new Date().toISOString();
  let rs;
  try{
    rs=await cloudFetchAllPages('sales',{order:'created_at.desc,id.desc',snapshotColumn:'created_at',snapshotAt,showProgress,progressLabel:'Vendite cloud'});
  }catch(e){
    if(!/created_at|column|schema cache/i.test(String(e.message||e)))throw e;
    /* Compatibilita' con eventuali schemi storici privi di created_at. */
    rs=await cloudFetchAllPages('sales',{order:'sold_at.desc,id.desc',snapshotColumn:'sold_at',snapshotAt,showProgress,progressLabel:'Vendite cloud'});
  }
  let ri=[],itemsWarning='';
  try{
    ri=await cloudFetchAllPages('sale_items',{order:'created_at.desc,id.desc',snapshotColumn:'created_at',snapshotAt,showProgress,progressLabel:'Dettagli prodotti'});
  }catch(itemError){
    itemsWarning=itemError?.message||String(itemError);
    console.warn('Dettaglio sale_items non disponibile',itemError);
  }
  return{rs:rs||[],ri:ri||[],itemsWarning,snapshotAt};
}
function mapCloudSales(rs,ri,userId,localById){
  const by={};
  (ri||[]).forEach(x=>(by[x.sale_id]||(by[x.sale_id]=[])).push({id:x.id,productId:x.product_id,name:x.product_name,quantity:Number(x.quantity||0),unitPrice:Number(x.unit_price||0),lineTotal:Number(x.line_total||0),categoryName:x.category_name||'',departmentName:x.department_name||'',vatRate:Number(x.vat_rate||0)}));
  return(rs||[]).map(x=>{
    let lines=by[x.id]||[];
    /* Se la testata e' gia' sul cloud ma le righe non lo sono, manteniamo le
       righe locali a video e le ritentiamo durante lo stesso aggiornamento. */
    if(!lines.length&&localById.get(x.id)?.lines?.length)lines=localById.get(x.id).lines;
    const lineSubtotal=lines.reduce((sum,l)=>sum+Number(l.lineTotal||0),0),subtotal=Number(x.subtotal??lineSubtotal??x.total??0),discount=Number(x.discount_amount??Math.max(0,subtotal-Number(x.total||0))),storedItems=Number(x.item_count),calculatedItems=lines.reduce((sum,l)=>sum+Number(l.quantity||0),0),local=localById.get(x.id)||{};
    return{...local,id:x.id,userId:x.user_id||userId,date:x.sold_at||x.created_at||local.date||new Date().toISOString(),total:Number(x.total||0),subtotal,discount,payment:x.payment_method||local.payment||'Non indicato',receiptNumber:x.receipt_number||local.receiptNumber||'',items:Number.isFinite(storedItems)&&storedItems>0?storedItems:calculatedItems,cashReceived:Number(x.cash_received??local.cashReceived??0),changeDue:Number(x.change_due??local.changeDue??0),lines,voidStatus:x.void_status??local.voidStatus,voidedAt:x.voided_at??local.voidedAt,voidReason:x.void_reason??local.voidReason,voidOriginalNumber:x.void_original_number??local.voidOriginalNumber,voidDocumentId:x.void_document_id??local.voidDocumentId,voidDocumentNumber:x.void_document_number??local.voidDocumentNumber,voidDocumentDate:x.void_document_date??local.voidDocumentDate}
  });
}
async function reconcileLocalVoidStatesToCloud(localSaved,snap){
  const rawById=new Map((snap?.rs||[]).map(r=>[String(r?.id||''),r]));
  let updated=0;
  for(const sale of (localSaved||[])){
    const status=String(sale?.voidStatus||'').trim();
    if(!sale?.id||!['annullata','esito_da_verificare'].includes(status))continue;
    const remote=rawById.get(String(sale.id));if(!remote)continue;
    const same=String(remote.void_status||'')===status&&String(remote.void_original_number||'')===String(sale.voidOriginalNumber||'')&&String(remote.void_document_number||'')===String(sale.voidDocumentNumber||'');
    if(same)continue;
    if(await dcoVoidCloudPersist(sale))updated++;
  }
  return updated
}

async function syncSalesFromCloud(showMessage=false){
  const session=getSession();
  if(!session?.user?.id){setStatsSyncStatus('error','Accedi all’Area utente per sincronizzare le statistiche.');return false}
  if(salesSyncPromise)return salesSyncPromise;
  const nowMs=Date.now();
  /* Le sincronizzazioni automatiche ravvicinate (ritorno in foreground,
     apertura statistiche, fine vendita) vengono accorpate. Il pulsante
     Aggiorna dati forza invece sempre un nuovo controllo. */
  if(!showMessage&&nowMs-lastSalesSyncStartedAt<SALES_SYNC_MIN_INTERVAL_MS)return false;
  lastSalesSyncStartedAt=nowMs;
  salesSyncPromise=(async()=>{
    const userId=session.user.id;
    if(showMessage)setStatsSyncStatus('loading','Aggiornamento vendite da Supabase…');
    try{
      const localSaved=(load(K.sales,[])||[]).filter(v=>v&&v.id&&(!v.userId||v.userId===userId));
      const localById=new Map(localSaved.map(v=>[v.id,v]));
      let snap=await fetchCloudSalesSnapshot(showMessage);
      let remoteSales=mapCloudSales(snap.rs,snap.ri,userId,localById);
      let cloudIds=new Set(remoteSales.map(x=>x.id));
      const localOnly=localSaved.filter(v=>!cloudIds.has(v.id));
      const uploadLimit=showMessage?SALES_MANUAL_UPLOAD_LIMIT:SALES_BACKGROUND_UPLOAD_LIMIT;
      let uploaded=0,pending=Math.max(0,localOnly.length-uploadLimit),lastUploadError='';

      /* Le vendite nuove vengono gia' salvate nel cloud immediatamente dopo
         l'emissione. Qui recuperiamo solo un piccolo numero di eventuali
         vendite rimaste locali (es. rete assente), evitando centinaia di POST
         consecutivi all'avvio dell'app. */
      for(const v of localOnly.slice(0,uploadLimit)){
        try{v.userId=userId;await cloudSaveSale(v);uploaded++}
        catch(e){pending++;lastUploadError=e?.message||String(e)}
      }

      /* Se una versione precedente ha completato un annullamento prima che le
         colonne Supabase fossero presenti, lo stato fiscale resta comunque nel
         dispositivo. Appena la migrazione SQL è disponibile lo riallineiamo al
         cloud senza ripetere alcun comando DCO. */
      const voidBackfilled=await reconcileLocalVoidStatesToCloud(localSaved,snap);

      /* Non riscriviamo piu' intere vendite solo perche' manca una riga
         sale_items: era la causa della raffica continua di richieste vista in
         Xcode. Se l'utente forza Aggiorna dati, ripariamo soltanto le singole
         righe mancanti e con un limite preciso per ogni sincronizzazione. */
      const remoteItemIds=new Set((snap.ri||[]).map(x=>x.id));
      const detailLimit=showMessage?SALES_MANUAL_DETAIL_REPAIR_LIMIT:SALES_BACKGROUND_DETAIL_REPAIR_LIMIT;
      let repairedDetails=0,missingDetails=0;
      if(detailLimit>0){
        outer: for(const v of localSaved){
          if(!cloudIds.has(v.id)||!v.lines?.length)continue;
          for(const l of v.lines){
            if(remoteItemIds.has(l.id))continue;
            missingDetails++;
            if(repairedDetails>=detailLimit)continue;
            try{
              await postWithFallback('sale_items',{id:l.id,sale_id:v.id,user_id:userId,product_id:l.productId||null,product_name:l.name,quantity:l.quantity,unit_price:l.unitPrice,line_total:l.lineTotal,category_name:l.categoryName||'',department_name:l.departmentName||'',vat_rate:l.vatRate||0},['category_name','department_name','vat_rate']);
              remoteItemIds.add(l.id);repairedDetails++;
            }catch(e){lastUploadError=e?.message||String(e)}
          }
        }
      }else{
        for(const v of localSaved){
          if(!cloudIds.has(v.id)||!v.lines?.length)continue;
          for(const l of v.lines)if(!remoteItemIds.has(l.id))missingDetails++;
        }
      }

      /* Rileggiamo Supabase solo se abbiamo realmente scritto qualcosa. */
      if(uploaded||repairedDetails||voidBackfilled){
        snap=await fetchCloudSalesSnapshot(showMessage);
        remoteSales=mapCloudSales(snap.rs,snap.ri,userId,localById);
        cloudIds=new Set(remoteSales.map(x=>x.id));
      }

      /* Una vendita puo' essere emessa mentre questa sincronizzazione e' in corso.
         Rileggiamo SEMPRE il localStorage alla fine e facciamo il merge sull'id. */
      const latestLocal=(load(K.sales,[])||[]).filter(v=>v&&v.id&&(!v.userId||v.userId===userId));
      const latestById=new Map(latestLocal.map(v=>[v.id,v]));
      remoteSales=mapCloudSales(snap.rs,snap.ri,userId,latestById);
      cloudIds=new Set(remoteSales.map(x=>x.id));
      const stillLocal=latestLocal.filter(v=>!cloudIds.has(v.id));
      const mergedById=new Map(remoteSales.map(v=>[v.id,v]));
      for(const v of stillLocal)if(!mergedById.has(v.id))mergedById.set(v.id,v);
      sales=Array.from(mergedById.values()).sort((a,b)=>new Date(a.date||0)-new Date(b.date||0));
      save(K.sales,sales);renderStats();
      const now=new Date().toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit'}),cloudCount=remoteSales.length,localCount=sales.length;
      if(lastUploadError||pending||stillLocal.length){
        setStatsSyncStatus('error',`Cloud ${cloudCount} · dispositivo ${localCount} · ${Math.max(pending,stillLocal.length)} in attesa. ${lastUploadError||'Sincronizzazione automatica in corso quando la rete è disponibile.'}`);
        if(!showMessage&&navigator.onLine&&stillLocal.length)scheduleSalesRecovery(SALES_SYNC_MIN_INTERVAL_MS+700);
      }else if(snap.itemsWarning){
        setStatsSyncStatus('warning',`Cloud ${cloudCount} vendite · dispositivo ${localCount}. Totali aggiornati alle ${now}; dettaglio prodotti non disponibile: ${snap.itemsWarning}`);
      }else if(missingDetails>repairedDetails){
        setStatsSyncStatus('warning',`Cloud ${cloudCount} vendite · dispositivo ${localCount} · aggiornato alle ${now}. Dettagli storici da completare: ${missingDetails-repairedDetails}; usa Aggiorna dati per procedere a blocchi.`);
      }else{
        setStatsSyncStatus('ok',`Cloud ${cloudCount} vendite · dispositivo ${localCount} · aggiornato alle ${now}.`);
      }
      return true;
    }catch(e){
      console.warn('Sincronizzazione vendite non disponibile',e);
      const localCount=(load(K.sales,[])||[]).length;
      setStatsSyncStatus('error',`Cloud non raggiungibile · ${localCount} vendite sul dispositivo. ${e.message||e}`);
      renderStats();return false;
    }
  })();
  try{return await salesSyncPromise}finally{
    salesSyncPromise=null;
    if(salesSyncAfterCurrent){salesSyncAfterCurrent=false;setTimeout(()=>syncSalesFromCloud(false).catch(()=>{}),500)}
  }
}

async function authRequest(path,body){const {url,key}=supabaseConfig();const r=await fetch(`${url}/auth/v1/${path}`,{method:'POST',headers:{'Content-Type':'application/json','apikey':key,'Authorization':`Bearer ${key}`},body:JSON.stringify(body)});const data=await r.json().catch(()=>({}));if(!r.ok){const err=new Error(data.msg||data.error_description||data.message||`Errore ${r.status}`);err.status=r.status;throw err}return data}
function authErrorMessage(error){const raw=String(error?.message||error||'Errore di autenticazione.'),msg=raw.toLowerCase();if(error?.status===429||/rate limit|too many requests|email rate limit exceeded/.test(msg))return 'Hai richiesto troppe email in poco tempo. Attendi circa un’ora oppure completa la configurazione SMTP personalizzata in Supabase.';if(/email not confirmed/.test(msg))return 'Email non ancora confermata. Apri il messaggio ricevuto e premi “Conferma email”.';if(/user already registered|already been registered/.test(msg))return 'Esiste già un account con questa email. Accedi oppure usa “Password dimenticata?”.';if(/invalid login credentials/.test(msg))return 'Email o password non corrette.';return raw}
function userStatus(type,text){const r=$('userResult');r.hidden=false;r.className=`test-result ${type}`;r.textContent=text}
function changePasswordStatus(type,text){const r=$('changePasswordResult');r.hidden=false;r.className=`test-result ${type}`;r.textContent=text}
function validateEmail(){const email=$('userEmail').value.trim();if(!email||!email.includes('@'))throw new Error('Inserisci un indirizzo email valido.');return email}
function validateCredentials(){const email=validateEmail();const password=$('userPassword').value;if(password.length<6)throw new Error('La password deve contenere almeno 6 caratteri.');return{email,password}}
$('registerUser').onclick=async()=>{try{const credentials=validateCredentials();userStatus('loading','Registrazione in corso…');const path=`signup?redirect_to=${encodeURIComponent(CONFIRM_EMAIL_URL)}`;const data=await authRequest(path,credentials);if(data.access_token){localStorage.setItem(K.session,JSON.stringify(data));renderUserState();await loadTrialState(true);await syncBusinessProfileFromCloud(true);await syncCatalogFromCloud(true);await syncSalesFromCloud();await initRevenueCat();clientLanStart(false).catch(()=>{});toast('Registrazione completata')}else userStatus('ok','Registrazione completata. Controlla l’email: dopo la conferma si aprirà la pagina CassaIQ dedicata.')}catch(e){userStatus('error',authErrorMessage(e))}};
$('loginUser').onclick=async()=>{try{const credentials=validateCredentials();userStatus('loading','Accesso in corso…');const data=await authRequest('token?grant_type=password',credentials);localStorage.setItem(K.session,JSON.stringify(data));renderUserState();await loadTrialState(true);await syncBusinessProfileFromCloud(true);await syncCatalogFromCloud(true);await syncSalesFromCloud();await initRevenueCat();clientLanStart(false).catch(()=>{});toast('Accesso effettuato e dati sincronizzati')}catch(e){userStatus('error',authErrorMessage(e))}};
$('forgotPassword').onclick=async()=>{try{const email=validateEmail();userStatus('loading','Invio email di recupero…');await authRequest(`recover?redirect_to=${encodeURIComponent(RESET_PASSWORD_URL)}`,{email});userStatus('ok','Email inviata. Apri il collegamento ricevuto per scegliere una nuova password.')}catch(e){userStatus('error',authErrorMessage(e))}};
async function updateCurrentUserPassword(password,retried=false){let session=getSession();if(!session?.access_token)throw new Error('Accedi prima al tuo account.');const {url,key}=supabaseConfig();const r=await fetch(`${url}/auth/v1/user`,{method:'PUT',headers:{'Content-Type':'application/json','apikey':key,'Authorization':`Bearer ${session.access_token}`},body:JSON.stringify({password})});const data=await r.json().catch(()=>({}));if(r.status===401&&!retried){const refreshed=await refreshSession();if(refreshed)return updateCurrentUserPassword(password,true)}if(!r.ok){const err=new Error(data.msg||data.error_description||data.message||`Errore ${r.status}`);err.status=r.status;throw err}return data}
$('changePasswordBtn').onclick=()=>{if(!getSession())return openUserDialog();$('newPassword').value='';$('confirmNewPassword').value='';$('changePasswordResult').hidden=true;if(userDialog.open)userDialog.close();$('changePasswordDialog').showModal();setTimeout(()=>$('newPassword').focus(),100)};
$('changePasswordForm').onsubmit=async e=>{e.preventDefault();const password=$('newPassword').value,confirmPassword=$('confirmNewPassword').value;if(password.length<8)return changePasswordStatus('error','La nuova password deve contenere almeno 8 caratteri.');if(password!==confirmPassword)return changePasswordStatus('error','Le due password non coincidono.');const btn=$('saveNewPassword');btn.disabled=true;changePasswordStatus('loading','Aggiornamento password…');try{await updateCurrentUserPassword(password);changePasswordStatus('ok','Password aggiornata correttamente.');$('newPassword').value='';$('confirmNewPassword').value='';toast('Password aggiornata')}catch(err){changePasswordStatus('error',authErrorMessage(err))}finally{btn.disabled=false}};
$('logoutUser').onclick=async()=>{try{await rcPlugin()?.logOut?.()}catch{}localStorage.removeItem(K.session);localStorage.removeItem(K.subscription);localStorage.removeItem(K.trial);rcCustomerInfo=null;rcOffering=null;trialState={loaded:false,valid:false,endsAt:null,startedAt:null};renderUserState();renderSubscriptionState();renderAccessGate();clientLanStart(false).catch(()=>{});toast('Account disconnesso')};
$('deleteAccountBtn').onclick=async()=>{
  const session=getSession();if(!session){toast('Nessun account collegato');return}
  const email=session.user?.email||'';
  if(!confirm(`Eliminare definitivamente l'account ${email}?\n\nVerranno rimossi dal cloud catalogo e vendite sincronizzati. L'operazione non e' reversibile.`))return;
  const btn=$('deleteAccountBtn');btn.disabled=true;const old=btn.textContent;btn.textContent='Eliminazione…';
  try{
    await refreshSession();
    /* Cancella i dati dell'utente e poi l'account. Le tabelle hanno ON DELETE
       CASCADE, ma rimuoviamo prima le righe per sicurezza sui vincoli. */
    try{await cloudRequest('sale_items',{method:'DELETE',query:`?user_id=eq.${session.user.id}`});}catch(e){}
    try{await cloudRequest('sales',{method:'DELETE',query:`?user_id=eq.${session.user.id}`});}catch(e){}
    try{await cloudRequest('products',{method:'DELETE',query:`?user_id=eq.${session.user.id}`});}catch(e){}
    try{await cloudRequest('categories',{method:'DELETE',query:`?user_id=eq.${session.user.id}`});}catch(e){}
    try{await cloudRequest('departments',{method:'DELETE',query:`?user_id=eq.${session.user.id}`});}catch(e){}
    try{await cloudRequest('business_profiles',{method:'DELETE',query:`?user_id=eq.${session.user.id}`});}catch(e){}
    /* L'endpoint admin /auth/v1/user non e' accessibile dal client (401).
       Usiamo una funzione RPC che cancella l'utente corrente via auth.uid(),
       definita in supabase-delete-account.sql. */
    const {url,key}=supabaseConfig();
    const r=await fetch(`${url}/rest/v1/rpc/delete_own_account`,{method:'POST',headers:{'Content-Type':'application/json','apikey':key,'Authorization':`Bearer ${getSession().access_token}`},body:'{}'});
    if(!r.ok){const t=await r.text().catch(()=>'');throw new Error(t||`Errore ${r.status}`);}
    try{await rcPlugin()?.logOut?.()}catch(e){}
    localStorage.removeItem(K.session);localStorage.removeItem(K.subscription);
    renderUserState();renderSubscriptionState();
    $('userDialog').close();toast('Account eliminato');
  }catch(e){console.error('deleteAccount',e);alert(`Impossibile eliminare l'account: ${e.message}\n\nScrivi a hello@menoova.it e provvederemo noi.`);}
  finally{btn.disabled=false;btn.textContent=old;}
};

const subscriptionDialog=$('subscriptionDialog');let rcConfigured=false,rcOffering=null,rcCustomerInfo=null;
function rcPlugin(){return window.Capacitor?.Plugins?.Purchases||null}
function storeName(){const platform=APP_CONFIG.platform||'web';if((APP_CONFIG.revenueCatApiKey||'').startsWith('test_'))return 'RevenueCat Test Store';return platform==='ios'?'App Store':'Google Play'}
(()=>{const t=$('termsLink'),p=$('privacyLink'),platform=APP_CONFIG.platform||'web';if(t&&APP_CONFIG.termsUrl){t.href=APP_CONFIG.termsUrl;t.textContent=platform==='ios'?'Termini di utilizzo (EULA)':'Termini e condizioni'}if(p){if(APP_CONFIG.privacyUrl)p.href=APP_CONFIG.privacyUrl;else p.remove()}})();
function subscriptionResult(type,text){const e=$('subscriptionResult');e.hidden=false;e.className=`test-result ${type}`;e.textContent=text}
function isPro(info){return !!info?.entitlements?.active?.[APP_CONFIG.revenueCatEntitlement||'pro']}
function daysRemaining(endsAt){if(!endsAt)return 0;return Math.max(0,Math.ceil((new Date(endsAt).getTime()-Date.now())/86400000))}
async function loadTrialState(showError=false){
  const session=getSession();
  if(!session){trialState={loaded:false,valid:false,endsAt:null,startedAt:null};renderSubscriptionState();renderAccessGate();return trialState}
  try{
    let rows=await cloudRequest('profiles',{query:`?id=eq.${encodeURIComponent(session.user.id)}&select=id,trial_started_at,trial_ends_at,subscription_status&limit=1`});
    if(!rows?.length){
      rows=await cloudRequest('profiles',{method:'POST',body:{id:session.user.id},prefer:'resolution=merge-duplicates,return=representation'});
    }
    const row=rows?.[0]||{};
    if(!row.trial_ends_at)throw new Error('Date prova non disponibili. Esegui lo SQL della prova gratuita in Supabase.');
    trialState={loaded:true,startedAt:row.trial_started_at||null,endsAt:row.trial_ends_at,valid:new Date(row.trial_ends_at).getTime()>Date.now(),status:row.subscription_status||'trial'};
    localStorage.setItem(K.trial,JSON.stringify(trialState));
  }catch(e){
    const cached=loadObjectSafe(K.trial,null);
    if(cached?.endsAt)trialState={...cached,loaded:true,valid:new Date(cached.endsAt).getTime()>Date.now(),offline:true};
    else trialState={loaded:false,valid:false,endsAt:null,startedAt:null,error:e.message};
    if(showError)toast(e.message||'Impossibile verificare la prova gratuita',4500);
  }
  renderSubscriptionState();renderAccessGate();return trialState;
}
function currentPackage(){return rcOffering?.monthly||rcOffering?.availablePackages?.find(p=>p.packageType==='MONTHLY'||p.identifier==='$rc_monthly')||rcOffering?.availablePackages?.[0]||null}
function packagePrice(pack=currentPackage()){const product=pack?.product||pack?.storeProduct||{};return product.priceString||product.pricePerMonthString||''}
function renderSubscriptionState(info){
  const session=getSession();
  const saved=session?(info||rcCustomerInfo||loadObjectSafe(K.subscription,{})):{};
  const pro=!!session&&isPro(saved),ent=saved?.entitlements?.active?.[APP_CONFIG.revenueCatEntitlement||'pro'];
  const price=session?packagePrice():'';let status='Accedi per iniziare',summary='Accedi per la prova',expiry='';
  if(pro){status='Piano Pro attivo';summary='Piano Pro attivo';expiry=ent?.expirationDate?`Rinnovo/scadenza: ${new Date(ent.expirationDate).toLocaleDateString('it-IT')}`:''}
  else if(session&&trialState.loaded&&trialState.valid){const days=daysRemaining(trialState.endsAt);status='Prova gratuita attiva';summary=`Prova gratuita · ${days} ${days===1?'giorno':'giorni'}`;expiry=`Scadenza: ${new Date(trialState.endsAt).toLocaleDateString('it-IT')}`}
  else if(session&&trialState.loaded&&!trialState.valid){status='Prova gratuita terminata';summary='Prova terminata';expiry='Abbonati per continuare a usare CassaIQ.'}
  $('subscriptionStatus').textContent=status;$('subscriptionSummary').textContent=summary;$('subscriptionExpiry').textContent=expiry;
  $('subscriptionPrice').textContent=price?`${price} al mese`:(session&&rcConfigured?'Piano mensile disponibile':'');
  $('buySubscription').hidden=pro;$('manageSubscription').hidden=!pro;$('restoreSubscription').hidden=!session;
  $('buySubscription').disabled=!session;$('restoreSubscription').disabled=!session;$('manageSubscription').disabled=!session;
  $('buySubscription').textContent=session?(price?`Abbonati · ${price}/mese`:'Abbonati'):'Accedi per abbonarti';
  renderAccessGate();
}
function renderAccessGate(){
  const gate=$('accessGate');if(!gate)return;const session=getSession(),pro=!!session&&isPro(rcCustomerInfo||loadObjectSafe(K.subscription,{}));
  if(session&&(pro||(trialState.loaded&&trialState.valid))){gate.hidden=true;return}
  gate.hidden=false;
  if(!session){$('accessGateTitle').textContent='Inizia la prova gratuita';$('accessGateText').textContent='Accedi o registrati per usare CassaIQ gratuitamente per un mese.';$('accessGateSubscribe').hidden=true}
  else if(trialState.loaded&&!trialState.valid){$('accessGateTitle').textContent='La prova gratuita è terminata';$('accessGateText').textContent='I tuoi dati restano al sicuro. Attiva CassaIQ Pro per continuare a usare la cassa.';$('accessGateSubscribe').hidden=false}
  else{$('accessGateTitle').textContent='Verifica accesso';$('accessGateText').textContent=trialState.error||'Collegati a internet per verificare la prova gratuita.';$('accessGateSubscribe').hidden=false}
}
$('accessGateLogin').onclick=openUserDialog;$('accessGateSubscribe').onclick=()=>getSession()?openSubscriptionDialog():openUserDialog();
function requireSubscriptionLogin(){if(getSession())return true;if(subscriptionDialog.open)subscriptionDialog.close();toast('Accedi o registrati per collegare l’abbonamento al tuo account.',4200);openUserDialog();return false}
async function initRevenueCat(){const plugin=rcPlugin(),key=(APP_CONFIG.revenueCatApiKey||'').trim(),session=getSession();if(!session?.user?.id){rcCustomerInfo=null;rcOffering=null;localStorage.removeItem(K.subscription);renderSubscriptionState();return false}renderSubscriptionState();if(!plugin||!key)return false;try{if(!rcConfigured){try{await plugin.setLogLevel?.({level:'DEBUG'})}catch{}await plugin.configure({apiKey:key,appUserID:session.user.id});rcConfigured=true}else{try{await plugin.logIn({appUserID:session.user.id})}catch(e){if(!/same|already/i.test(String(e?.message||e)))throw e}}const ci=await plugin.getCustomerInfo();rcCustomerInfo=ci.customerInfo;localStorage.setItem(K.subscription,JSON.stringify(ci.customerInfo));const off=await plugin.getOfferings();rcOffering=off.current||off.offerings?.current||Object.values(off.all||off.offerings?.all||{})[0]||null;renderSubscriptionState(ci.customerInfo);return true}catch(e){console.warn('RevenueCat',e);renderSubscriptionState();return false}}
async function openSubscriptionDialog(){if(!requireSubscriptionLogin())return;subscriptionResult('loading','Verifica abbonamento…');subscriptionDialog.showModal();await loadTrialState(false);const ok=await initRevenueCat();const price=packagePrice();subscriptionResult(ok?'ok':'error',ok?(price?`Piano mensile disponibile: ${price}.`:'Stato abbonamento aggiornato.'):'Abbonamenti non disponibili su questo dispositivo.')}
$('buySubscription').onclick=async()=>{if(!requireSubscriptionLogin())return;try{subscriptionResult('loading',`Apertura ${storeName()}…`);const ready=await initRevenueCat();if(!ready)throw new Error('RevenueCat non disponibile per questo account.');const pack=currentPackage();if(!pack)throw new Error('Nessun pacchetto mensile disponibile nell’Offering RevenueCat.');const out=await rcPlugin().purchasePackage({aPackage:pack});rcCustomerInfo=out.customerInfo;localStorage.setItem(K.subscription,JSON.stringify(out.customerInfo));renderSubscriptionState(out.customerInfo);subscriptionResult('ok',isPro(out.customerInfo)?'Abbonamento Pro attivato.':'Acquisto completato, ma entitlement Pro non trovato.')}catch(e){const msg=e?.message||String(e);subscriptionResult('error',String(msg).toLowerCase().includes('cancel')?'Acquisto annullato.':msg)}};
$('restoreSubscription').onclick=async()=>{if(!requireSubscriptionLogin())return;try{subscriptionResult('loading','Ripristino acquisti…');const ready=await initRevenueCat();if(!ready)throw new Error('RevenueCat non disponibile per questo account.');const out=await rcPlugin().restorePurchases();rcCustomerInfo=out.customerInfo;localStorage.setItem(K.subscription,JSON.stringify(out.customerInfo));renderSubscriptionState(out.customerInfo);subscriptionResult('ok',isPro(out.customerInfo)?'Abbonamento ripristinato.':'Nessun abbonamento attivo trovato.')}catch(e){subscriptionResult('error',e.message||String(e))}};
$('manageSubscription').onclick=()=>{if(!requireSubscriptionLogin())return;const saved=rcCustomerInfo||loadObjectSafe(K.subscription,{}),url=saved?.managementURL||saved?.entitlements?.active?.[APP_CONFIG.revenueCatEntitlement||'pro']?.managementURL;if(url)window.open(url,'_system');else subscriptionResult('ok','Nel Test Store la gestione avviene dalla dashboard RevenueCat.')};

if($('dcoFailureRetry'))$('dcoFailureRetry').onclick=async()=>{const snap=dcoFailureSnapshot;if(!snap)return dcoClearFailureChoice();dcoClearFailureChoice();if(!dcoCurrentCartMatchesSnapshot(snap)){alert('La vendita in cassa non corrisponde più al tentativo fallito. Registrala nelle Operazioni di emergenza invece di riprovare.');return}dcoTimingBegin();await dcoStartAutomaticSale()};
if($('dcoFailureEmergency'))$('dcoFailureEmergency').onclick=()=>{const snap=dcoFailureSnapshot,reason=dcoFailureReason;if(!snap)return dcoClearFailureChoice();const row=emergencyRecordSnapshot(snap,'da_regolarizzare',reason||'Emissione DCO non completata.',{capturedFromDcoFailure:true,tableCheckout:emergencyTableContext()});if(row){emergencyAfterRecorded(snap);status('','Operazione salvata in emergenza');toast(`Operazione ${euro(snap.total)} salvata · da regolarizzare`,4200)}dcoClearFailureChoice()};
if($('dcoFailureDialog'))$('dcoFailureDialog').addEventListener('cancel',e=>e.preventDefault());
const issueDialog=$('issueDialog');
function populateIssueDialog(){
  const hasDiscount=discountAmount>0;$('confirmSubtotalLabel').hidden=!hasDiscount;$('confirmSubtotal').hidden=!hasDiscount;$('confirmDiscountLabel').hidden=!hasDiscount;$('confirmDiscount').hidden=!hasDiscount;if(hasDiscount){$('confirmSubtotal').textContent=euro(cartSubtotal());$('confirmDiscount').textContent=`− ${euro(discountAmount)}`}$('confirmTotal').textContent=euro(cartTotal());$('confirmPayment').textContent=payment;const lotLabel=$('confirmLotteryLabel'),lotValue=$('confirmLottery'),showLottery=lotteryEligible()&&!!lotteryCode;if(lotLabel)lotLabel.hidden=!showLottery;if(lotValue){lotValue.hidden=!showLottery;if(showLottery)lotValue.textContent=lotteryCode}const showChange=payment==='Contanti'&&cashReceived>=cartTotal()&&cashReceived>0;$('confirmReceivedLabel').hidden=!showChange;$('confirmReceived').hidden=!showChange;$('confirmChangeLabel').hidden=!showChange;$('confirmChange').hidden=!showChange;if(showChange){$('confirmReceived').textContent=euro(cashReceived);$('confirmChange').textContent=euro(changeDue)}const warning=$('issueWarning');if(warning)warning.textContent=fiscalMode()==='dco'?'Conferma: CassaIQ invierà il documento al DCO e, appena riceve il numero DCO, stamperà subito il documento commerciale sulla stampante di rete.':'Questa operazione invia un vero documento fiscale all’Epson FP-81II RT.';issueDialog.showModal()
}
$('issueButton').onclick=()=>{
  if(!requireValidLotteryCode())return;
  if(fiscalMode()==='dco'){
    const draft=dcoBuildDraftPayload();if(!draft.ok)return alert(draft.error);
    if(!emergencyInternetOnline()){
      if(confirm(`Connessione internet assente.

Il Documento Commerciale Online non può essere emesso adesso. Salvare questa vendita da ${euro(cartTotal())} nelle Operazioni di emergenza da regolarizzare?

Non verrà stampato alcun documento.`))emergencySaveCurrentOfflineSale();
      return
    }
    if(!dcoHasSessionMarker()){alert('Collega prima il DCO con SPID da Impostazioni → Documento Commerciale Online.');showView('dcolab');return}
  }else{
    if(dcoRealTestEnabled){alert('Emissione Epson bloccata: è attiva una prova DCO reale.');return}
    if(!valid(localStorage.getItem(K.ip)||'')){toast('Configura prima l’indirizzo IP Epson');openPrinter();return}
  }
  populateIssueDialog();
};
$('cancelIssue').onclick=()=>issueDialog.close();
async function issueEpsonSale(){
  isIssuing=true;renderCart();$('issueButton').textContent='Emissione in corso…';status('','Invio documento…');const subtotal=cartSubtotal(),discount=discountAmount,total=cartTotal(),snapshot={id:uid(),userId:getSession()?.user?.id||null,date:new Date().toISOString(),subtotal,discount,total,payment,lotteryCode:payment==='Carta'&&total>=1?normalizeLotteryCode(lotteryCode):'',items:expandedCartFiscalLines().reduce((s,x)=>s+x.quantity,0),lines:expandedCartFiscalLines().map(({product:p,quantity:q,isSupplement})=>{const c=categoryById(p.categoryId),d=departmentById(p.departmentId);return{id:uid(),productId:p.manual?null:p.id,name:isSupplement?`SUPPL. ${p.name}`:p.name,quantity:q,unitPrice:Number(p.price),lineTotal:Number(p.price)*q,categoryName:c?.name||'',departmentName:d?.name||'',vatRate:Number(d?.vat||0)}}),cashReceived:payment==='Contanti'?cashReceived||total:0,changeDue:payment==='Contanti'?changeDue:0};try{const res=await sendEpson(buildFiscalReceipt(),25000);if(!res.success)throw new Error(`Epson: ${res.code||'operazione rifiutata'}${res.status?` (stato ${res.status})`:''}`);snapshot.receiptNumber=res.info.fiscalReceiptNumber||res.info.receiptNumber||'';sales.push(snapshot);save(K.sales,sales);try{await cloudSaveSale(snapshot)}catch(e){console.error('cloudSaveSale',e);toast(`Documento emesso, ma non salvato nel cloud: ${e.message}`,6000)}scheduleSalesSyncAfterSale();status('ok','Documento emesso');toast(snapshot.receiptNumber?`Documento fiscale emesso: ${snapshot.receiptNumber}`:'Documento fiscale emesso correttamente',4000);if(activeTableCheckout)finalizeActiveTableCheckout().catch(()=>{});resetSale();renderStats()}catch(err){status('error','Emissione da verificare');alert(`ATTENZIONE\n\n${err.message}\n\nControlla il registratore e verifica se il documento è stato stampato prima di riprovare, per evitare una doppia emissione.`)}finally{isIssuing=false;renderCart()}
}
$('confirmIssue').onclick=async()=>{issueDialog.close();if(fiscalMode()==='dco'){dcoTimingBegin();await dcoStartAutomaticSale()}else await issueEpsonSale()};

clientLanInit();if(fiscalMode()==='dco'){fisRenewStartUiCooldown();setTimeout(()=>{dcoRefreshFisconlineConfigured().then(()=>dcoMaybeShowFisconlinePasswordReminder()).catch(()=>{})},1200);}if(localStorage.getItem(K.ip)&&fiscalMode()==='epson'){status('','Epson configurato');$('headerIp').textContent=localStorage.getItem(K.ip)}renderConfigFiscalMode();dcoVisualHealth=dcoHasSessionMarker()&&emergencyInternetOnline()?'ok':'error';dcoVisualHealthCheckedAt=Date.now();renderDcoConnectionStatus();renderDcoSettingsCardStatus();renderCategoryButtons();renderProducts();renderCart();renderHoldButton();renderStats();renderSubscriptionState();renderAccessGate();emergencyRecoverInterruptedAttempt();dcoRecoverLegacyGlobalLock();dcoRecoverInterruptedVoid();emergencyRenderSettingsSummary();setStatsSyncStatus(getSession()?'':'error',getSession()?'Visualizzazione dati locali; sincronizzazione in corso…':'Accedi all’Area utente per sincronizzare le statistiche.');if(getSession()){/* All'avvio rinnoviamo la sessione prima di sincronizzare: se l'app e' stata
   chiusa per oltre un'ora il token e' gia' scaduto. Le statistiche partono
   subito dopo il rinnovo, senza attendere catalogo/profilo/tavoli. */(async()=>{await refreshSession();await syncSalesFromCloud(false);await loadTrialState(false);await syncBusinessProfileFromCloud(false);await syncCatalogFromCloud(false);await loadRestaurantTables(false);await initRevenueCat();})();}
})();
