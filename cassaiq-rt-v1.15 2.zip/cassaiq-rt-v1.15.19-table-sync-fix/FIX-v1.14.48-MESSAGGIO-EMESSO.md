# CassaIQ RT v1.14.48

- Messaggio finale DCO nella barra superiore/progresso semplificato a `Documento <numero> emesso`.
- Rimossa dal messaggio principale l'indicazione `stampato subito sulla MUNBYN`; lo stato di stampa resta disponibile nelle aree tecniche/ultimo documento.
- Nessuna modifica al motore DCO, alla stampa o al flusso tavoli.
- Versione 1.14.48 · iOS build 78 · Android versionCode 78.
