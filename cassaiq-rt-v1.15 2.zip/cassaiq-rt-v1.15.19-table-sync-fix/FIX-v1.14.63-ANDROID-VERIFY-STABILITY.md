# CassaIQ RT v1.14.63 — Android wizard2 verify stability

Base: v1.14.62 operation-isolation.

Modifica mirata solo al passaggio Android wizard2 -> Verifica:

- nessuna modifica al flusso iOS;
- nessuna modifica a Conferma/Procedi o alle protezioni anti-doppia-emissione;
- dopo il trasferimento del carrello, Android continua prima a cercare il pulsante ufficiale “Vai a verifica dati” con la logica normale;
- se la WebView nascosta restituisce temporaneamente un rettangolo 0x0, viene usato un fallback ristretto al solo controllo di verifica del wizard2, richiedendo testo/ng-click coerente, elemento non disabilitato e stile non nascosto;
- prima del fallback vengono riattivati gli eventi input/change/blur dei campi gia compilati e richiesto un digest Angular, senza cambiare i valori;
- diagnostica: `diagnostic:android-verify-fallback-clicked` quando il fallback viene realmente usato.

Versione app: 1.14.63
iOS build: 94
Android versionCode: 94
