# CassaIQ RT v1.14.28 — Fisconline automatico + archivio sicuro + rete soltanto

## Fisconline
- Aggiunta in Area DCO la scelta tra **Fisconline automatico** e **SPID**.
- Fisconline usa codice fiscale/nome utente, password e PIN configurati dall'esercente.
- Le credenziali NON vengono salvate in Supabase e NON vengono salvate in localStorage.
- iOS: credenziali nel Keychain con `kSecAttrAccessibleWhenUnlockedThisDeviceOnly`.
- Android: credenziali cifrate AES/GCM con chiave generata e custodita nell'Android Keystore; in SharedPreferences resta solo il testo cifrato.
- Quando la sessione DCO non è presente, CassaIQ può aprire il login Fisconline in background, compilare l'accesso e proseguire fino al DCO.
- Se la sessione scade PRIMA dei passaggi finali non ripetibili, CassaIQ può ricollegarsi automaticamente e riprendere la vendita.
- Se la sessione scade dopo l'armamento/conferma finale, CassaIQ NON ripete automaticamente l'emissione: mostra una verifica obbligatoria per evitare duplicati fiscali.
- SPID resta disponibile come alternativa e continua ad aprire il portale ufficiale per l'autenticazione manuale.

## Limiti volutamente mantenuti
- Il rinnovo automatico della password Fisconline scaduta non è implementato: CassaIQ segnala il problema e richiede l'aggiornamento delle credenziali.
- In presenza di più utenze di lavoro, CassaIQ tenta di identificare quella corretta dai dati attività; se il portale non consente una scelta univoca può essere necessario un intervento manuale.
- Il login Fisconline end-to-end non può essere collaudato senza credenziali reali dell'esercente. Sono stati validati sintassi, flussi, archivio nativo e protezioni anti-ripetizione; la prima prova reale va eseguita con una piccola vendita.

## Stampante MUNBYN
- Rimossa la modalità Bluetooth dalla UI e dal codice JavaScript.
- Rimossi metodi e dipendenze Bluetooth dal plugin nativo iOS/Android.
- Rimossi i permessi Bluetooth Android e le descrizioni Bluetooth da Info.plist iOS.
- Resta esclusivamente la stampa ESC/POS tramite rete/IP.

## DCO già funzionante
Non vengono modificati il payload fiscale, il punto di emissione, il recupero del numero documento ufficiale, la copia di cortesia a 32 colonne, il taglio carta e la guardia anti-doppia-emissione.
