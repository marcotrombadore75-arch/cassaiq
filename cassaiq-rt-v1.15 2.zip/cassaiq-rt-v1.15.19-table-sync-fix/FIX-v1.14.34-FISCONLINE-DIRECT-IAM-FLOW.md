# CassaIQ RT v1.14.34 — Fisconline direct IAM flow

## Problema corretto
La connessione Fisconline veniva aperta da `InstradamentofcWeb/wizard`, cioè troppo avanti nel percorso. La sonda cercava quindi il modulo credenziali in una pagina che non contiene necessariamente CF/password/PIN.

## Nuovo percorso
- Fisconline apre direttamente `DCO_URLS.login` (`iampe.../sam/UI/Login?realm=/agenziaentrate`).
- Dopo l'uscita riuscita da IAM, CassaIQ instrada esplicitamente verso `DCO_URLS.entry` per selezionare l'utenza di lavoro.
- Dal wizard continua il percorso già presente verso il servizio DCO.
- SPID/CIE/CNS continua a partire da `DCO_URLS.entry` e resta manuale.

## Invariato
Secure storage nativo, RSA-OAEP, emissione, anti-doppia-emissione, recupero numero ufficiale e stampa MUNBYN.
