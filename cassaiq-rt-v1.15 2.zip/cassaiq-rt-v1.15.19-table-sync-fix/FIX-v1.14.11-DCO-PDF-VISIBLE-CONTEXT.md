# CassaIQ RT v1.14.11 — DCO PDF visible context fix

Versione 1.14.11, build iOS 41, Android versionCode 41.

## Problema rilevato

La richiesta PDF partiva correttamente, ma il browser DCO era già nascosto. Su iOS il processo WebKit della finestra nascosta poteva essere sospeso o terminato subito dopo il primo controllo, facendo sparire lo stato `window.__cassaiqDcoPdf`.

## Correzione

- La finestra DCO viene mostrata temporaneamente durante il solo recupero PDF.
- Un pannello non interattivo informa che il documento è già emesso e che non partirà una nuova vendita.
- Il browser non viene nascosto fino al completamento del download e del trasferimento del PDF a CassaIQ.
- I controlli transitori di WebKit vengono ritentati senza riavviare l'emissione.
- Timeout dedicato aumentato a 60 secondi.
- Al termine, riuscito o meno, il pannello viene rimosso e la finestra DCO torna nascosta.

La parte fiscale, SPID, Epson e MUNBYN non è stata modificata.
