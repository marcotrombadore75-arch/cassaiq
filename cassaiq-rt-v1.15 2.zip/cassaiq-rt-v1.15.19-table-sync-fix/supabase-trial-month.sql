-- CassaIQ — prova gratuita di un mese per account
-- Eseguire una sola volta in Supabase > SQL Editor.

ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS trial_started_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS trial_ends_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS subscription_status TEXT NOT NULL DEFAULT 'trial';

ALTER TABLE public.profiles
ALTER COLUMN trial_started_at SET DEFAULT NOW(),
ALTER COLUMN trial_ends_at SET DEFAULT (NOW() + INTERVAL '1 month');

-- Avvia la prova solo per i profili che non hanno ancora date.
-- Rieseguendo questo script non si prolunga una prova già iniziata.
UPDATE public.profiles
SET trial_started_at = COALESCE(trial_started_at, NOW()),
    trial_ends_at = COALESCE(trial_ends_at, NOW() + INTERVAL '1 month'),
    subscription_status = COALESCE(NULLIF(subscription_status, ''), 'trial')
WHERE trial_started_at IS NULL
   OR trial_ends_at IS NULL;
