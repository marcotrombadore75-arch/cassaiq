# CassaIQ RT v1.14.60 — iOS WebView visible reference

Base: v1.14.55 numero-immediato.

Obiettivo: test di stabilità iOS isolato.

Modifica unica al motore DCO:
- iOS: durante l’emissione automatica la InAppBrowser viene mostrata e mantenuta attiva, come nella v1.14.20; se deve essere creata per la vendita, nasce `hidden=no`.
- Android: comportamento v1.14.55 invariato (`hidden=yes` durante l’emissione).

Invariati:
- runner preparatorio 350 ms;
- fase finale 1100 ms;
- recupero numero ufficiale immediato;
- verifiche quantità/prezzo/IVA/pagamento;
- lock anti-doppia-emissione;
- timeout e recovery;
- stampa MUNBYN.

Versione 1.14.60, iOS build 91, Android versionCode 91.
