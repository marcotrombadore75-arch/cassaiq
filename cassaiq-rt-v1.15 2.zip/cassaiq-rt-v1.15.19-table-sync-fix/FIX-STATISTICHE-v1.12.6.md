# Correzione statistiche v1.12.6

La schermata Statistiche ora sincronizza le vendite da Supabase ogni volta che viene aperta e quando l’app torna in primo piano.

È stato aggiunto il pulsante **Aggiorna dati** e uno stato visibile con eventuali errori di sessione/cloud.

La sincronizzazione non viene più annullata completamente se la tabella `sale_items` non risponde: incasso, numero scontrini e ultime vendite continuano a essere mostrati.

Versione app: 1.12.6 — build 17.
