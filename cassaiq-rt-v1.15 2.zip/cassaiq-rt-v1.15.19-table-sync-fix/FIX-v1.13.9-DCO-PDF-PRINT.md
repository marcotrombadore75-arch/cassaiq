# CassaIQ 1.13.9 — recupero PDF DCO e stampa MUNBYN

Questa versione completa il primo flusso reale Documento Commerciale Online dopo la conferma positiva dell'Agenzia delle Entrate.

## Novità

- Rileva la comparsa del documento emesso e dell'identificativo transazione DCO.
- Blocca immediatamente un secondo click su `Conferma` o `Procedi` quando il documento risulta già emesso.
- Recupera il PDF ufficiale dalla stessa sessione autenticata del browser DCO, senza salvare credenziali, cookie, SPID, OTP o PIN.
- Trasferisce il PDF all'app in blocchi, lo verifica e lo salva nella cartella documenti privata di CassaIQ.
- Registra la vendita nelle statistiche locali e prova la sincronizzazione Supabase usando `DCO-<id>` come numero documento.
- Svuota il carrello e riabilita Epson soltanto dopo il riconoscimento certo del documento ufficiale; il carrello viene svuotato solo se coincide ancora con la bozza che ha generato il DCO.
- Converte il PDF in raster ESC/POS a 576 punti e lo invia alla stampante MUNBYN 80 mm.
- Supporta stampa PDF via rete e via Bluetooth già collegato.
- Consente la ristampa dell'ultimo PDF salvato.
- Evita di associare un documento già acquisito a un carrello nuovo o diverso; se manca la bozza locale, salva il PDF senza alterare le statistiche.
- Intercetta il `loaderror` del download PDF: non viene più presentato come errore fiscale.

## Sicurezza contro duplicazioni

La presenza dei pulsanti ufficiali `Scarica e stampa file` e dell'identificativo DCO viene considerata conferma dell'emissione. Da quel momento CassaIQ blocca ulteriori invii della stessa schermata.

In caso di mancato recupero o mancata stampa, il documento non deve essere emesso di nuovo. Si usa `Riprova recupero PDF` o `Ristampa ultimo documento`.

## Versione

- App: 1.13.9
- iOS build: 29
- Android versionCode: 29
- Plugin stampante: 0.2.0
