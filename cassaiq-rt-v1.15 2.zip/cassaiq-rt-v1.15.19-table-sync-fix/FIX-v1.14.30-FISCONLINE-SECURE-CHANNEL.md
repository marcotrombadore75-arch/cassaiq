# CassaIQ RT 1.14.30 — Canale sicuro Fisconline

Versione 1.14.30 · build iOS 60 · Android versionCode 60.

## Obiettivo
Evitare che username, password e PIN Fisconline compaiano in chiaro negli argomenti di `InAppBrowser.executeScript` e quindi nei log Cordova/Capacitor.

## Modifica
- La pagina ufficiale AdE genera una coppia RSA-OAEP 2048 temporanea tramite WebCrypto.
- Alla app viene restituita solo la chiave pubblica.
- CassaIQ cifra in memoria il JSON delle credenziali con RSA-OAEP/SHA-256.
- Alla WebView viene inviato solo il ciphertext Base64.
- La chiave privata resta esclusivamente nel contesto della pagina e viene eliminata subito dopo l'uso.
- Le credenziali decifrate vengono usate solo per valorizzare i campi visibili e poi azzerate dal riferimento JavaScript.
- Il login e' a fasi: vengono valorizzati solo username/password/PIN effettivamente presenti nella pagina corrente.
- Restano i controlli PASSWORD_EXPIRED e CREDENTIALS_REJECTED.

## Invariato
Keychain iOS / Android Keystore, emissione DCO, anti-doppia-emissione, stampa MUNBYN, numero documento ufficiale e fallback SPID.
