# CassaIQ RT v1.14.26 — emissione DCO in background

Versione 1.14.26, build iOS 56, Android versionCode 56.

## Correzione

Durante `Paga → Emetti e stampa` il browser ufficiale DCO non viene più mostrato a schermo.

- la finestra SPID continua a essere visibile durante il collegamento iniziale;
- durante la vendita il browser esistente viene nascosto prima della navigazione;
- se deve essere creato un nuovo InAppBrowser, viene aperto con `hidden=yes`;
- l’automazione DCO e il polling continuano in background;
- l’utente vede soltanto il dialogo di avanzamento CassaIQ;
- in caso di esito incerto o necessità di verifica, la sessione rimane disponibile dalla configurazione DCO.

Non sono stati modificati emissione fiscale, acquisizione numero ufficiale, stampa ESC/POS, centratura, avanzamento o taglio.
