# CassaIQ RT v1.14.77 — centratura intestazione copia DCO

- Versione: 1.14.77
- iOS build: 108
- Android versionCode: 108

## Correzione
La copia di cortesia DCO ora centra con il comando hardware ESC/POS `ESC a 1` tutto il blocco superiore:

- denominazione attività;
- eventuale nome commerciale;
- Partita IVA;
- indirizzo;
- CAP / città / provincia;
- DOCUMENTO COMMERCIALE;
- COPIA DI CORTESIA.

Dopo l'inizializzazione della stampante viene emessa una riga vuota e il comando di centratura viene ripetuto, così la prima riga utile non dipende dal comportamento della MUNBYN subito dopo `ESC @`.

L'allineamento torna a sinistra soltanto prima delle righe prodotto. Nessuna modifica a emissione DCO, Epson RT, calcoli fiscali, note prodotto o stampa cucina.
