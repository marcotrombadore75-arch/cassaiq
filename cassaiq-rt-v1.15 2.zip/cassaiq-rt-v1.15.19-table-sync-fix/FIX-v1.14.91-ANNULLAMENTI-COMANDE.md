# CassaIQ RT v1.14.91 / build 122

## Annullamenti tavolo

- Riceve dal CassaIQ Client v0.5.7 annullamenti di singole righe, riduzioni quantità e annullamenti completi.
- Il messaggio viaggia prioritariamente in LAN e resta idempotente: lo stesso evento non viene applicato/stampato due volte.
- La quantità originale non viene eliminata: viene registrata `cancelled_quantity` e il totale tavolo usa solo la quantità residua.
- Se una comanda resta senza righe attive viene marcata `cancelled`; il tavolo si libera solo quando non esistono altre comande aperte.
- La cucina riceve un ticket dedicato `*** ANNULLAMENTO ***` con `NON PREPARARE`.
- Anche il pulsante `Elimina` dalla cassa invia un ticket di annullamento in cucina prima di liberare il tavolo.
- Le nuove righe LAN mantengono il `line_id` generato dal Client, così una pizza personalizzata può essere annullata senza toccare la riga gemella.
- La sincronizzazione cloud usa il file SQL `supabase-order-cancellations-v1.14.91-client0.5.7.sql`.
