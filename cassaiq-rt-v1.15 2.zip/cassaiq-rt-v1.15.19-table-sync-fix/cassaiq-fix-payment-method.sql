-- CassaIQ - correzione vincolo metodo di pagamento
-- Non cancella vendite o statistiche.

begin;

-- Rimuove il vecchio vincolo incompatibile con i valori usati dall'app.
alter table public.sales
  drop constraint if exists sales_payment_method_valid;

-- Uniforma eventuali valori storici inglesi/varianti ai due valori CassaIQ.
update public.sales
set payment_method = case
  when lower(trim(payment_method)) in ('cash', 'contanti', 'contante')
    then 'Contanti'
  when lower(trim(payment_method)) in (
    'card', 'carta', 'carta di credito', 'carta di debito',
    'electronic', 'elettronico', 'pagamento elettronico'
  )
    then 'Carta'
  else payment_method
end
where payment_method is not null;

-- Il codice attuale di CassaIQ invia esattamente "Contanti" oppure "Carta".
alter table public.sales
  add constraint sales_payment_method_valid
  check (payment_method in ('Contanti', 'Carta'));

notify pgrst, 'reload schema';

commit;

-- Controllo finale facoltativo
select payment_method, count(*) as vendite
from public.sales
group by payment_method
order by payment_method;
