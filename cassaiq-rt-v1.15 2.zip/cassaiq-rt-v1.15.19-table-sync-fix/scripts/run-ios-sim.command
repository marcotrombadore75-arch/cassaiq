#!/bin/bash
# ============================================================
#  CassaIQ RT - avvio nel Simulatore iOS (macOS)
#  Doppio clic su questo file, oppure: ./scripts/run-ios-sim.command
# ============================================================
set -u

# Vai alla cartella del progetto (questo file sta in /scripts)
cd "$(dirname "$0")/.." || exit 1

echo "============================================"
echo "  CassaIQ RT - Simulatore iOS"
echo "============================================"
echo

fail() {
  echo
  echo "*** $1"
  echo
  read -r -p "Premi INVIO per chiudere."
  exit 1
}

# ---- macOS ----
[ "$(uname)" = "Darwin" ] || fail "Questo script funziona solo su macOS."

# ---- Node ----
command -v node >/dev/null 2>&1 || fail "Node.js non trovato. Installalo da https://nodejs.org (versione LTS)."
echo "Node        : $(node -v)"

# ---- Xcode ----
command -v xcodebuild >/dev/null 2>&1 || fail "Xcode non trovato. Installalo dal Mac App Store, poi apri Xcode una volta per accettare la licenza."
if ! xcode-select -p >/dev/null 2>&1; then
  fail "Strumenti da riga di comando non configurati. Esegui: sudo xcode-select --install"
fi
echo "Xcode       : $(xcodebuild -version | head -1)"

# ---- CocoaPods ----
if ! command -v pod >/dev/null 2>&1; then
  echo
  echo "CocoaPods non trovato: serve per le dipendenze iOS."
  echo "Installalo con UNO di questi comandi, poi rilancia lo script:"
  echo "   brew install cocoapods"
  echo "   sudo gem install cocoapods"
  fail "CocoaPods mancante."
fi
echo "CocoaPods   : $(pod --version)"
echo

# ---- .env ----
if [ ! -f ".env" ]; then
  if [ -f ".env.example" ]; then
    cp .env.example .env
    echo "Creato .env da .env.example: apri il file e inserisci i valori Supabase."
    fail "Configura .env e rilancia."
  else
    fail "File .env mancante."
  fi
fi

# ---- dipendenze npm ----
if [ ! -d "node_modules" ]; then
  echo "[1/4] Installazione dipendenze npm (la prima volta richiede qualche minuto)..."
  npm install || fail "npm install non riuscito."
else
  echo "[1/4] Dipendenze npm gia' presenti."
fi

# ---- piattaforma iOS ----
if [ ! -d "ios" ]; then
  echo "[2/4] Creazione progetto iOS..."
  npm run ios:add || fail "Creazione progetto iOS non riuscita."
else
  echo "[2/4] Progetto iOS gia' presente."
fi

# ---- sync + configurazione Info.plist ----
echo "[3/4] Sincronizzazione asset web e configurazione iOS..."
npm run ios:sync || fail "Sincronizzazione non riuscita."

# ---- avvio nel simulatore ----
echo "[4/4] Avvio nel Simulatore iOS..."
echo "      (scegli un simulatore dall'elenco, es. iPad Pro per la vista cassa completa)"
echo
if npx cap run ios; then
  echo
  echo "============================================"
  echo "  App avviata nel Simulatore."
  echo "============================================"
else
  echo
  echo "Avvio automatico non riuscito. Apro il progetto in Xcode:"
  echo "  premi il tasto Play scegliendo un simulatore dal menu in alto."
  npm run ios:open
fi

echo
read -r -p "Premi INVIO per chiudere."
