import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

function parseEnv(text){const out={};for(const raw of text.split(/\r?\n/)){const line=raw.trim();if(!line||line.startsWith('#'))continue;const i=line.indexOf('=');if(i<1)continue;out[line.slice(0,i).trim()]=line.slice(i+1).trim().replace(/^['"]|['"]$/g,'');}return out;}
const env=parseEnv(readFileSync(resolve(process.cwd(),'.env'),'utf8'));
const key=(env.REVENUECAT_ANDROID_API_KEY||'').trim();
const terms=(env.APP_TERMS_URL_ANDROID||env.APP_TERMS_URL||'').trim();
const privacy=(env.APP_PRIVACY_URL_ANDROID||env.APP_PRIVACY_URL||'').trim();
const errors=[];
if(!key.startsWith('goog_')) errors.push('REVENUECAT_ANDROID_API_KEY deve iniziare con goog_.');
if(key.startsWith('test_')) errors.push('Non usare una chiave test_ nella build Play Console.');
if(!/^https:\/\//i.test(terms)) errors.push('APP_TERMS_URL_ANDROID deve essere un URL HTTPS valido.');
if(!/^https:\/\//i.test(privacy)) errors.push('APP_PRIVACY_URL_ANDROID deve essere un URL HTTPS valido.');
if(errors.length){console.error('\nControllo release Android non superato:\n- '+errors.join('\n- ')+'\n');process.exit(1);}
console.log('Controllo release Android superato: chiave goog_ e link legali presenti.');
