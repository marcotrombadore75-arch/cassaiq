import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const plistFile = path.join(root, 'ios', 'App', 'App', 'Info.plist');

if (!fs.existsSync(plistFile)) {
  console.error('Info.plist non trovato. Esegui prima: npm run ios:add');
  process.exit(1);
}

let plist = fs.readFileSync(plistFile, 'utf8');

/**
 * Rimuove una chiave (e il suo valore) dal plist, per poterla riscrivere
 * senza creare duplicati a ogni esecuzione.
 */
function removeKey(text, key) {
  const re = new RegExp(
    `\\s*<key>${key}</key>\\s*(<dict>[\\s\\S]*?</dict>|<array>[\\s\\S]*?</array>|<string>[\\s\\S]*?</string>|<true\\s*/>|<false\\s*/>|<integer>[\\s\\S]*?</integer>)`,
    'g'
  );
  return text.replace(re, '');
}

const keys = [
  'NSAppTransportSecurity',
  'NSLocalNetworkUsageDescription',
  'NSBluetoothAlwaysUsageDescription',
  'NSBluetoothPeripheralUsageDescription',
  'NSCameraUsageDescription',
  'NSPhotoLibraryUsageDescription',
  'ITSAppUsesNonExemptEncryption',
  'UIRequiresFullScreen',
  'UIStatusBarHidden',
  'UIViewControllerBasedStatusBarAppearance',
  'UISupportedInterfaceOrientations',
  'UISupportedInterfaceOrientations~ipad'
];
for (const key of keys) plist = removeKey(plist, key);

const additions = `
	<!-- CassaIQ: consente la comunicazione HTTP in chiaro con il registratore
	     Epson sulla rete locale. iOS blocca l'HTTP non cifrato per impostazione
	     predefinita: senza questa eccezione il test connessione fallisce. -->
	<key>NSAppTransportSecurity</key>
	<dict>
		<key>NSAllowsLocalNetworking</key>
		<true/>
	</dict>
	<key>NSLocalNetworkUsageDescription</key>
	<string>CassaIQ usa la rete locale per comunicare con il registratore Epson, le stampanti ESC/POS e i dispositivi CassaIQ Client del locale.</string>
	<key>NSCameraUsageDescription</key>
	<string>CassaIQ usa la fotocamera per aggiungere le foto dei prodotti.</string>
	<key>NSPhotoLibraryUsageDescription</key>
	<string>CassaIQ accede alle foto per impostare le immagini dei prodotti.</string>
	<!-- L'app usa solo HTTPS standard: dichiarando questo, App Store Connect
	     non chiede la conformita' sull'esportazione a ogni caricamento. -->
	<key>ITSAppUsesNonExemptEncryption</key>
	<false/>
	<!-- Modalita' cassa: schermo intero, senza barra di stato -->
	<key>UIRequiresFullScreen</key>
	<true/>
	<key>UIStatusBarHidden</key>
	<true/>
	<key>UIViewControllerBasedStatusBarAppearance</key>
	<false/>
	<key>UISupportedInterfaceOrientations</key>
	<array>
		<string>UIInterfaceOrientationPortrait</string>
		<string>UIInterfaceOrientationLandscapeLeft</string>
		<string>UIInterfaceOrientationLandscapeRight</string>
	</array>
	<key>UISupportedInterfaceOrientations~ipad</key>
	<array>
		<string>UIInterfaceOrientationPortrait</string>
		<string>UIInterfaceOrientationPortraitUpsideDown</string>
		<string>UIInterfaceOrientationLandscapeLeft</string>
		<string>UIInterfaceOrientationLandscapeRight</string>
	</array>
</dict>
</plist>`;

const closing = plist.lastIndexOf('</dict>');
if (closing === -1) {
  console.error('Info.plist non riconosciuto: struttura inattesa.');
  process.exit(1);
}

plist = plist.slice(0, closing).replace(/\s*$/, '\n') + additions.replace(/^\n/, '') + '\n';
fs.writeFileSync(plistFile, plist, 'utf8');

console.log('Info.plist aggiornato: rete locale e modalita\' cassa fullscreen.');

// --- iPhone + iPad ---
// TARGETED_DEVICE_FAMILY = "1,2" mantiene la build universale sui dispositivi Apple.
// --- Icona app ---
// Copia l'icona di CassaIQ (cartella ios-assets/AppIcon.appiconset) dentro
// gli asset del progetto Xcode generato, sostituendo quella segnaposto.
const iconSrc = path.join(root, 'ios-assets', 'AppIcon.appiconset');
const iconDest = path.join(root, 'ios', 'App', 'App', 'Assets.xcassets', 'AppIcon.appiconset');
if (fs.existsSync(iconSrc) && fs.existsSync(path.dirname(iconDest))) {
  fs.rmSync(iconDest, { recursive: true, force: true });
  fs.cpSync(iconSrc, iconDest, { recursive: true });
  console.log('Icona app CassaIQ applicata al progetto iOS.');
} else if (fs.existsSync(iconSrc)) {
  console.log('Nota: Assets.xcassets non trovato, esegui prima npm run ios:add.');
}

const pbxproj = path.join(root, 'ios', 'App', 'App.xcodeproj', 'project.pbxproj');
if (fs.existsSync(pbxproj)) {
  let proj = fs.readFileSync(pbxproj, 'utf8');
  const before = proj;
  proj = proj.replace(/TARGETED_DEVICE_FAMILY = "?[0-9,]+"?;/g, 'TARGETED_DEVICE_FAMILY = "1,2";');
  if (proj !== before) {
    fs.writeFileSync(pbxproj, proj, 'utf8');
    console.log('App impostata per iPhone e iPad (TARGETED_DEVICE_FAMILY = 1,2).');
  } else if (/TARGETED_DEVICE_FAMILY = "?1,2"?;/.test(proj)) {
    console.log('App gia impostata per iPhone e iPad (TARGETED_DEVICE_FAMILY = 1,2).');
  } else {
    console.log('Nota: TARGETED_DEVICE_FAMILY non trovato nel progetto, imposta a mano in Xcode (iPhone e iPad).');
  }
}
