import fs from 'node:fs';
import { spawnSync } from 'node:child_process';

const project = 'ios/App/App.xcodeproj/project.pbxproj';

if (fs.existsSync(project)) {
  console.log('iOS gia presente: mantengo il progetto Xcode stabile e salto "cap add ios".');
  process.exit(0);
}

console.log('Progetto iOS non presente: lo creo con Capacitor...');
const cmd = process.platform === 'win32' ? 'npx.cmd' : 'npx';
const result = spawnSync(cmd, ['cap', 'add', 'ios'], { stdio: 'inherit' });
process.exit(result.status ?? 1);
