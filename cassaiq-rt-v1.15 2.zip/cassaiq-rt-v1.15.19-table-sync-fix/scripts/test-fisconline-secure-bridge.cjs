const { webcrypto } = require('crypto');
globalThis.crypto = webcrypto;
globalThis.CSS = {escape:s=>s};
globalThis.Event = class Event {constructor(n,o){this.type=n;this.bubbles=!!(o&&o.bubbles)}};
class HTMLInputElement {constructor(o){Object.assign(this,o);this._value='';this.disabled=false;} get value(){return this._value} set value(v){this._value=String(v)} getAttribute(n){return this[n]||''} closest(){return null} dispatchEvent(){} getBoundingClientRect(){return {width:100,height:20}} }
globalThis.HTMLInputElement=HTMLInputElement; globalThis.HTMLTextAreaElement=HTMLInputElement;
globalThis.getComputedStyle=()=>({display:'block',visibility:'visible'});
const form={ requestSubmit(){form.submitted=true}, submitted:false, querySelectorAll(){return [button]} };
const user=new HTMLInputElement({id:'username',name:'username',placeholder:'Codice fiscale',type:'text',form});
const pass=new HTMLInputElement({id:'password',name:'password',placeholder:'Password',type:'password',form});
const pin=new HTMLInputElement({id:'pin',name:'pin',placeholder:'PIN',type:'password',form});
const button={disabled:false,textContent:'Accedi',value:'',click(){button.clicked=true},clicked:false,getBoundingClientRect(){return {width:100,height:20}}};
globalThis.document={body:{innerText:'Accedi con credenziali Agenzia delle Entrate'},querySelectorAll(sel){if(sel==='input')return [user,pass,pin]; return [button]},querySelector(){return null}};
globalThis.location={hostname:'iampe.agenziaentrate.gov.it'};
const waits=new Map(); const codes=[];
globalThis.window={webkit:{messageHandlers:{cordova_iab:{postMessage(encoded){const d=JSON.parse(encoded);const w=waits.get(d.callId);if(w){waits.delete(d.callId);w(d.result)}}}}}};
let dcoFisconlineActionBusy=false,dcoFisconlineLastActionAt=0;
function dcoRunAutomation(ref,code,callId,timeoutMs){codes.push(code);return new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(new Error('timeout')),timeoutMs);waits.set(callId,v=>{clearTimeout(t);resolve(v)});const value=eval(code);if(value!==undefined&&value!==null){clearTimeout(t);waits.delete(callId);resolve(value)}})}
async function dcoFisconlineEncryptPayload(publicJwk,credentials){
  if(!globalThis.crypto?.subtle)throw new Error('Cifratura WebCrypto non disponibile.');
  const key=await crypto.subtle.importKey('jwk',publicJwk,{name:'RSA-OAEP',hash:'SHA-256'},false,['encrypt']);
  const clear=new TextEncoder().encode(JSON.stringify({username:String(credentials?.username||''),password:String(credentials?.password||''),pin:String(credentials?.pin||'')}));
  const encrypted=await crypto.subtle.encrypt({name:'RSA-OAEP'},key,clear);
  const bytes=new Uint8Array(encrypted);let binary='';for(let i=0;i<bytes.length;i++)binary+=String.fromCharCode(bytes[i]);
  return btoa(binary)
}
async function dcoFisconlineLoginAction(ref,credentials){
  if(dcoFisconlineActionBusy||Date.now()-dcoFisconlineLastActionAt<900)return{ok:true,action:'cooldown'};
  dcoFisconlineActionBusy=true;dcoFisconlineLastActionAt=Date.now();
  try{
    const probeCallId=`fis-probe-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
    const probeCode=`(function(){
      var CALL_ID=${JSON.stringify(probeCallId)};
      var send=function(result){
        try{
          var payload=JSON.stringify({source:'cassaiq-dco',callId:CALL_ID,result:result});
          if(window.webkit&&window.webkit.messageHandlers&&window.webkit.messageHandlers.cordova_iab){window.webkit.messageHandlers.cordova_iab.postMessage(payload);return true}
          if(window.cordova_iab&&typeof window.cordova_iab.postMessage==='function'){window.cordova_iab.postMessage(payload);return true}
        }catch(e){}
        return false
      };
      try{
        var host=String(location.hostname||'').toLowerCase();
        if(host.indexOf('agenziaentrate.gov.it')<0){send({ok:false,reason:'external-host'});return null}
        function clean(v){return String(v==null?'':v).replace(/\\s+/g,' ').trim().toLowerCase()}
        function visible(el){if(!el||el.disabled)return false;try{var st=getComputedStyle(el),r=el.getBoundingClientRect();return st.display!=='none'&&st.visibility!=='hidden'&&r.width>0&&r.height>0}catch(e){return true}}
        function labelText(el){var out=[el.id,el.name,el.placeholder,el.getAttribute&&el.getAttribute('aria-label'),el.autocomplete].filter(Boolean).join(' ');try{if(el.id){var lab=document.querySelector('label[for="'+CSS.escape(el.id)+'"]');if(lab)out+=' '+lab.textContent}var parent=el.closest&&el.closest('label');if(parent)out+=' '+parent.textContent}catch(e){}return clean(out)}
        var body=clean(document.body&&document.body.innerText||'');
        if(body.indexOf('password scaduta')>=0||body.indexOf('password risulta scaduta')>=0){send({ok:false,error:'PASSWORD_EXPIRED'});return null}
        if(body.indexOf('credenziali non valide')>=0||body.indexOf('credenziali errate')>=0||(body.indexOf('utente o password')>=0&&body.indexOf('errat')>=0)){send({ok:false,error:'CREDENTIALS_REJECTED'});return null}
        var inputs=Array.prototype.slice.call(document.querySelectorAll('input')).filter(function(el){return visible(el)&&String(el.type||'').toLowerCase()!=='hidden'&&String(el.type||'').toLowerCase()!=='submit'&&String(el.type||'').toLowerCase()!=='button'});
        var userEl=inputs.find(function(el){var d=labelText(el);return /codice fiscale|nome utente|username|user name|userid|login/.test(d)&&!/pin|password/.test(d)});
        var pinEl=inputs.find(function(el){return /\\bpin\\b|pincode|codice pin/.test(labelText(el))});
        var passEl=inputs.find(function(el){var d=labelText(el);return /password|passwd|pwd/.test(d)&&el!==pinEl})||inputs.find(function(el){return String(el.type||'').toLowerCase()==='password'&&el!==pinEl});
        if(!userEl&&!passEl&&!pinEl){
          var actions=Array.prototype.slice.call(document.querySelectorAll('a,button,[role=button],input[type=button],input[type=submit]')).filter(visible);
          var reveal=actions.find(function(el){var t=clean(el.textContent||el.value||'');return t.indexOf('accedi con credenziali')>=0||t.indexOf('credenziali agenzia')>=0||(t.indexOf('fisconline')>=0&&t.indexOf('acced')>=0)});
          if(reveal){try{reveal.click()}catch(e){}send({ok:true,action:'reveal-credentials'});return null}
          send({ok:false,reason:'credentials-fields-not-found',inputCount:inputs.length});return null
        }
        if(!globalThis.crypto||!crypto.subtle){send({ok:false,error:'SECURE_CHANNEL_UNAVAILABLE'});return null}
        crypto.subtle.generateKey({name:'RSA-OAEP',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},false,['encrypt','decrypt'])
          .then(function(pair){window.__cassaiqFisconlinePrivateKey=pair.privateKey;return crypto.subtle.exportKey('jwk',pair.publicKey)})
          .then(function(publicJwk){send({ok:true,action:'secure-channel-ready',publicJwk:publicJwk,fields:{username:!!userEl,password:!!passEl,pin:!!pinEl}})})
          .catch(function(e){try{window.__cassaiqFisconlinePrivateKey=null}catch(_){}send({ok:false,error:'SECURE_CHANNEL_FAILED',reason:String(e&&e.message||e)})});
      }catch(e){send({ok:false,reason:String(e&&e.message||e)})}
      return null
    })()`;
    const probe=await dcoRunAutomation(ref,probeCode,probeCallId,12000);
    if(!probe?.ok||probe.action!=='secure-channel-ready')return probe;
    const cipher=await dcoFisconlineEncryptPayload(probe.publicJwk,credentials||{});
    const cipherLiteral=JSON.stringify(cipher);
    const fillCallId=`fis-fill-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
    const fillCode=`(function(){
      var CALL_ID=${JSON.stringify(fillCallId)},CIPHER=${cipherLiteral};
      var send=function(result){
        try{
          var payload=JSON.stringify({source:'cassaiq-dco',callId:CALL_ID,result:result});
          if(window.webkit&&window.webkit.messageHandlers&&window.webkit.messageHandlers.cordova_iab){window.webkit.messageHandlers.cordova_iab.postMessage(payload);return true}
          if(window.cordova_iab&&typeof window.cordova_iab.postMessage==='function'){window.cordova_iab.postMessage(payload);return true}
        }catch(e){}
        return false
      };
      try{
        var host=String(location.hostname||'').toLowerCase();
        if(host.indexOf('agenziaentrate.gov.it')<0){send({ok:false,reason:'external-host'});return null}
        var privateKey=window.__cassaiqFisconlinePrivateKey;window.__cassaiqFisconlinePrivateKey=null;
        if(!privateKey){send({ok:false,error:'SECURE_CHANNEL_EXPIRED'});return null}
        if(!globalThis.crypto||!crypto.subtle){send({ok:false,error:'SECURE_CHANNEL_UNAVAILABLE'});return null}
        function clean(v){return String(v==null?'':v).replace(/\\s+/g,' ').trim().toLowerCase()}
        function visible(el){if(!el||el.disabled)return false;try{var st=getComputedStyle(el),r=el.getBoundingClientRect();return st.display!=='none'&&st.visibility!=='hidden'&&r.width>0&&r.height>0}catch(e){return true}}
        function labelText(el){var out=[el.id,el.name,el.placeholder,el.getAttribute&&el.getAttribute('aria-label'),el.autocomplete].filter(Boolean).join(' ');try{if(el.id){var lab=document.querySelector('label[for="'+CSS.escape(el.id)+'"]');if(lab)out+=' '+lab.textContent}var parent=el.closest&&el.closest('label');if(parent)out+=' '+parent.textContent}catch(e){}return clean(out)}
        function setValue(el,value){if(!el)return;var proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,desc=Object.getOwnPropertyDescriptor(proto,'value');if(desc&&desc.set)desc.set.call(el,value);else el.value=value;['input','change','keyup'].forEach(function(n){try{el.dispatchEvent(new Event(n,{bubbles:true}))}catch(e){}})}
        var raw=atob(CIPHER),bytes=new Uint8Array(raw.length);for(var i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);CIPHER='';raw='';
        crypto.subtle.decrypt({name:'RSA-OAEP'},privateKey,bytes).then(function(clear){
          bytes.fill(0);privateKey=null;
          var clearBytes=new Uint8Array(clear),text=new TextDecoder().decode(clearBytes),creds;
          try{creds=JSON.parse(text)}finally{clearBytes.fill(0);text=''}
          var inputs=Array.prototype.slice.call(document.querySelectorAll('input')).filter(function(el){return visible(el)&&String(el.type||'').toLowerCase()!=='hidden'&&String(el.type||'').toLowerCase()!=='submit'&&String(el.type||'').toLowerCase()!=='button'});
          var userEl=inputs.find(function(el){var d=labelText(el);return /codice fiscale|nome utente|username|user name|userid|login/.test(d)&&!/pin|password/.test(d)});
          var pinEl=inputs.find(function(el){return /\\bpin\\b|pincode|codice pin/.test(labelText(el))});
          var passEl=inputs.find(function(el){var d=labelText(el);return /password|passwd|pwd/.test(d)&&el!==pinEl})||inputs.find(function(el){return String(el.type||'').toLowerCase()==='password'&&el!==pinEl});
          var filled=[];
          if(userEl){setValue(userEl,String(creds.username||''));filled.push('username')}
          if(passEl){setValue(passEl,String(creds.password||''));filled.push('password')}
          if(pinEl){setValue(pinEl,String(creds.pin||''));filled.push('pin')}
          creds.username='';creds.password='';creds.pin='';creds=null;
          if(!filled.length){send({ok:false,reason:'credentials-fields-changed'});return}
          var form=(userEl&&userEl.form)||(passEl&&passEl.form)||(pinEl&&pinEl.form);
          var buttons=Array.prototype.slice.call((form||document).querySelectorAll('button,input[type=submit],input[type=button],[role=button]')).filter(visible);
          var submit=buttons.find(function(el){var t=clean(el.textContent||el.value||'');return t==='accedi'||t==='entra'||t==='login'||t.indexOf('accedi')===0||t.indexOf('continua')===0||t.indexOf('prosegui')===0});
          if(submit){send({ok:true,action:'secure-credentials-submit',filled:filled});setTimeout(function(){try{submit.click()}catch(e){}},180);return}
          if(form&&typeof form.requestSubmit==='function'){send({ok:true,action:'secure-credentials-request-submit',filled:filled});setTimeout(function(){try{form.requestSubmit()}catch(e){}},180);return}
          if(form){send({ok:true,action:'secure-credentials-form-submit',filled:filled});setTimeout(function(){try{form.submit()}catch(e){}},180);return}
          send({ok:false,reason:'submit-not-found',filled:filled})
        }).catch(function(e){try{bytes.fill(0)}catch(_){}send({ok:false,error:'SECURE_CHANNEL_FAILED',reason:String(e&&e.message||e)})});
      }catch(e){try{window.__cassaiqFisconlinePrivateKey=null}catch(_){}send({ok:false,error:'SECURE_CHANNEL_FAILED',reason:String(e&&e.message||e)})}
      return null
    })()`;
    return await dcoRunAutomation(ref,fillCode,fillCallId,12000)
  }finally{dcoFisconlineActionBusy=false}
}

(async()=>{const creds={username:'USER_SECRET_ABC',password:'PASS_SECRET_XYZ',pin:'PIN_SECRET_123'};const out=await dcoFisconlineLoginAction({},creds);await new Promise(r=>setTimeout(r,250));console.log('OUT',JSON.stringify(out));console.log('VALUES',user.value,pass.value,pin.value,'CLICKED',button.clicked);console.log('CODE_HAS_SECRET',codes.some(c=>c.includes(creds.username)||c.includes(creds.password)||c.includes(creds.pin)));if(!out.ok||!button.clicked||user.value!==creds.username||pass.value!==creds.password||pin.value!==creds.pin||codes.some(c=>c.includes(creds.username)||c.includes(creds.password)||c.includes(creds.pin)))process.exit(2);})().catch(e=>{console.error(e);process.exit(1)});
