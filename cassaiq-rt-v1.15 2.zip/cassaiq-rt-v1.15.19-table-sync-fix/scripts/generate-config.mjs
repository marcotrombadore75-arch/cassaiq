import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

const root = resolve(process.cwd());
const envPath = resolve(root, '.env');
const outputPath = resolve(root, 'www', 'config.js');

function parseEnv(text) {
  const values = {};
  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const index = line.indexOf('=');
    if (index < 1) continue;
    const key = line.slice(0, index).trim();
    let value = line.slice(index + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    values[key] = value;
  }
  return values;
}

let env;
try {
  env = parseEnv(readFileSync(envPath, 'utf8'));
} catch {
  console.error('File .env non trovato. Copia .env.example in .env e compila i valori Supabase.');
  process.exit(1);
}

const url = (env.VITE_SUPABASE_URL || '').replace(/\/+$/, '').replace(/\/rest\/v1$/i, '');
const anonKey = env.VITE_SUPABASE_ANON_KEY || '';
if (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(url)) {
  console.error('VITE_SUPABASE_URL non valido. Usa il dominio base https://xxxx.supabase.co');
  process.exit(1);
}
if (!anonKey.startsWith('sb_publishable_') && !anonKey.startsWith('eyJ')) {
  console.error('VITE_SUPABASE_ANON_KEY non valida. Usa la publishable key o la anon key.');
  process.exit(1);
}

const androidKey = env.REVENUECAT_ANDROID_API_KEY || '';
const iosKey = env.REVENUECAT_IOS_API_KEY || '';
const entitlement = env.REVENUECAT_ENTITLEMENT || 'pro';
// Link legali separati per piattaforma.
// iOS mantiene l'EULA standard Apple e la privacy gia' pubblicata.
// Android usa condizioni e privacy dedicate alla distribuzione Google Play.
// Le vecchie APP_TERMS_URL / APP_PRIVACY_URL restano accettate come fallback.
const termsUrlIos = env.APP_TERMS_URL_IOS || env.APP_TERMS_URL || 'https://www.apple.com/legal/internet-services/itunes/dev/stdeula/';
const privacyUrlIos = env.APP_PRIVACY_URL_IOS || env.APP_PRIVACY_URL || '';
const termsUrlAndroid = env.APP_TERMS_URL_ANDROID || env.APP_TERMS_URL || '';
const privacyUrlAndroid = env.APP_PRIVACY_URL_ANDROID || env.APP_PRIVACY_URL || '';
const confirmEmailUrl = env.APP_CONFIRM_EMAIL_URL || 'https://menoova.it/cassaiq-conferma.html';
const resetPasswordUrl = env.APP_RESET_PASSWORD_URL || 'https://menoova.it/cassaiq-reset-password.html';
const j = (v) => JSON.stringify(v);

// La chiave RevenueCat viene scelta al momento dell'uso in base alla piattaforma:
// Apple su iOS, Google su Android. Il getter viene valutato quando l'app lo legge,
// cioe' a bridge Capacitor gia' disponibile.
const output = `window.CASSAIQ_CONFIG = Object.freeze({
  supabaseUrl: ${j(url)},
  supabaseAnonKey: ${j(anonKey)},
  revenueCatAndroidApiKey: ${j(androidKey)},
  revenueCatIosApiKey: ${j(iosKey)},
  revenueCatEntitlement: ${j(entitlement)},
  termsUrlIos: ${j(termsUrlIos)},
  privacyUrlIos: ${j(privacyUrlIos)},
  termsUrlAndroid: ${j(termsUrlAndroid)},
  privacyUrlAndroid: ${j(privacyUrlAndroid)},
  confirmEmailUrl: ${j(confirmEmailUrl)},
  resetPasswordUrl: ${j(resetPasswordUrl)},
  get platform() {
    try { return window.Capacitor?.getPlatform?.() || 'web'; } catch (e) { return 'web'; }
  },
  get revenueCatApiKey() {
    return this.platform === 'ios' ? this.revenueCatIosApiKey : this.revenueCatAndroidApiKey;
  },
  get termsUrl() {
    return this.platform === 'ios' ? this.termsUrlIos : this.termsUrlAndroid;
  },
  get privacyUrl() {
    return this.platform === 'ios' ? this.privacyUrlIos : this.privacyUrlAndroid;
  }
});
`;

writeFileSync(outputPath, output, 'utf8');
console.log('Configurazione Supabase generata in www/config.js');
if (!androidKey) console.log('  nota: REVENUECAT_ANDROID_API_KEY vuota (abbonamenti disattivati su Android).');
if (!iosKey) console.log('  nota: REVENUECAT_IOS_API_KEY vuota (abbonamenti disattivati su iOS).');
if (!privacyUrlIos) console.log('  ATTENZIONE: APP_PRIVACY_URL_IOS vuota.');
if (!termsUrlAndroid) console.log('  ATTENZIONE: APP_TERMS_URL_ANDROID vuota.');
if (!privacyUrlAndroid) console.log('  ATTENZIONE: APP_PRIVACY_URL_ANDROID vuota.');
