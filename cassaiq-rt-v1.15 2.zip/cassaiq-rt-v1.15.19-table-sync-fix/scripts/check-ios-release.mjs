import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

function parseEnv(text){const out={};for(const raw of text.split(/\r?\n/)){const line=raw.trim();if(!line||line.startsWith('#'))continue;const i=line.indexOf('=');if(i<1)continue;out[line.slice(0,i).trim()]=line.slice(i+1).trim().replace(/^['"]|['"]$/g,'');}return out;}
const env=parseEnv(readFileSync(resolve(process.cwd(),'.env'),'utf8'));
const key=(env.REVENUECAT_IOS_API_KEY||'').trim();
const terms=(env.APP_TERMS_URL_IOS||env.APP_TERMS_URL||'').trim();
const privacy=(env.APP_PRIVACY_URL_IOS||env.APP_PRIVACY_URL||'').trim();
const errors=[];
if(!key.startsWith('appl_')) errors.push('REVENUECAT_IOS_API_KEY deve iniziare con appl_.');
if(key.startsWith('test_')) errors.push('Non usare una chiave test_ in Release/TestFlight.');
if(!/^https:\/\//i.test(terms)) errors.push('APP_TERMS_URL_IOS deve essere un URL HTTPS valido.');
if(!/^https:\/\//i.test(privacy)) errors.push('APP_PRIVACY_URL_IOS deve essere un URL HTTPS valido.');
if(errors.length){console.error('\nControllo release iOS non superato:\n- '+errors.join('\n- ')+'\n');process.exit(1);}
console.log('Controllo release iOS superato: chiave appl_ e link legali presenti.');
