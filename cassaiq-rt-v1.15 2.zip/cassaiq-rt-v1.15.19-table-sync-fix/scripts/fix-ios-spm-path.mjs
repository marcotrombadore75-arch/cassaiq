import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const packageSwift = path.join(root, 'ios', 'App', 'CapApp-SPM', 'Package.swift');
const revenueCatPackage = path.join(root, 'node_modules', '@revenuecat', 'purchases-capacitor');

if (!fs.existsSync(packageSwift)) {
  console.error('Package.swift iOS non trovato. Esegui prima npx cap add ios oppure npm run ios:sync.');
  process.exit(1);
}

if (!fs.existsSync(revenueCatPackage)) {
  console.error('Dipendenza RevenueCat non installata. Esegui prima: npm install');
  process.exit(1);
}

const expectedPath = '../../../node_modules/@revenuecat/purchases-capacitor';
let source = fs.readFileSync(packageSwift, 'utf8');
const pattern = /\.package\(name:\s*"RevenuecatPurchasesCapacitor",\s*path:\s*"[^"]+"\)/;

if (!pattern.test(source)) {
  console.error('Riferimento RevenueCat non trovato in ios/App/CapApp-SPM/Package.swift.');
  process.exit(1);
}

source = source.replace(
  pattern,
  `.package(name: "RevenuecatPurchasesCapacitor", path: "${expectedPath}")`
);
fs.writeFileSync(packageSwift, source, 'utf8');

console.log(`Percorso SPM RevenueCat corretto: ${expectedPath}`);
