# CassaIQ RT v1.14.74 — Statistiche: stop raffica Supabase

- Rimossa la riscrittura automatica di intere vendite quando mancava un dettaglio `sale_items`.
- Le sincronizzazioni automatiche sono accorpate (minimo 15 secondi).
- In background si recuperano al massimo 2 vendite rimaste solo locali per ciclo.
- La riparazione dei dettagli storici avviene solo con **Aggiorna dati**, massimo 24 righe per ciclo.
- Le nuove vendite continuano a essere salvate subito tramite `cloudSaveSale`.
- Nessuna modifica al motore DCO, timer 350/1100 ms, WebView, Epson o stampante cucina.
