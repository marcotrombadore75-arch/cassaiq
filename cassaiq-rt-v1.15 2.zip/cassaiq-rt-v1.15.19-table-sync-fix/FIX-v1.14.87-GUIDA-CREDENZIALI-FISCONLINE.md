# CassaIQ RT v1.14.87 / build 118

- Attivato nelle FAQ in-app il pulsante **Guida passo passo · Come ottenere le Credenziali Fisconline**.
- Collegamento video: https://www.youtube.com/watch?v=E8mnc1HtqRg
- Il pulsante **Guida incarico Fisconline** resta predisposto e verrà attivato quando sarà disponibile il relativo video.
