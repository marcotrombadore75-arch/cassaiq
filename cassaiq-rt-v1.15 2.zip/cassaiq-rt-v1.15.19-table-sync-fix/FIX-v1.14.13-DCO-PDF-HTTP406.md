# CassaIQ RT v1.14.13 — fix HTTP 406 recupero PDF DCO

Versione 1.14.13, build iOS 43, Android versionCode 43.

## Problema verificato

Il logging terminale della v1.14.12 ha dimostrato che il browser DCO restava vivo, ma l’endpoint ufficiale di stampa rispondeva `HTTP 406` alla `fetch` con header forzato `Accept: application/pdf`. Il documento fiscale risultava già emesso; falliva soltanto l’acquisizione del PDF.

## Correzione

- eliminato l’header rigido `Accept: application/pdf`;
- recupero tramite una sequenza controllata di trasporti nella stessa sessione autenticata: Angular `$http`, XHR senza header forzati, `fetch` predefinita, XHR con Accept binario;
- passaggio al tentativo successivo soltanto per risposte compatibili con un problema di negoziazione (`0`, `406`, `415`);
- verifica della firma `%PDF` prima di dichiarare il file pronto;
- logging completo di `transport`, numero tentativo e cronologia degli esiti;
- la barra diagnostica non può più sovrascrivere il motore robusto con la vecchia fetch;
- browser DCO mantenuto aperto fino a `ready` o `error`, come nella v1.14.12.

La vendita non deve essere ripetuta: usare soltanto **Riprova recupero PDF**.
