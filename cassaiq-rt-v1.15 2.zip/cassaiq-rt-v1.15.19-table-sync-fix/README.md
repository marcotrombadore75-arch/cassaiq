# CassaIQ RT v1.14.37 — Ripristino core POS + Fisconline state machine

Versione: **1.14.37**  
iOS build: **66**  
Android versionCode: **67**

## Correzione v1.14.37
Il login Fisconline usa ora una macchina a stati precisa, basata sulla struttura reale della pagina IAM:

1. apre `https://iampe.agenziaentrate.gov.it/sam/UI/Login?realm=/agenziaentrate`;
2. attiva `#tab-4` (Fisconline/Entratel) quando necessario;
3. usa esclusivamente i campi `IDToken1`, `IDToken2`, `IDToken3` / ID ufficiali del pannello;
4. preme esclusivamente `#tab-4 [type="submit"]`;
5. invia le credenziali una sola volta per tentativo e attende l'esito senza retry automatici;
6. dopo il login passa al wizard dell'utenza di lavoro;
7. solo dopo la selezione dell'utenza apre Documento Commerciale Online.

Keychain iOS, Android Keystore/AES-GCM e canale RSA-OAEP restano invariati. SPID/CIE/CNS resta accesso alternativo. Il flusso di emissione DCO e la stampa MUNBYN non sono stati modificati.

## iOS
```bash
cd ~/Downloads/cassaiq-rt-v1.14.37-restore-core-fisconline-state-machine
npm install
npm run ios:sync
npm run ios:open
```

## Android
```bash
cd ~/Downloads/cassaiq-rt-v1.14.37-restore-core-fisconline-state-machine
npm install
npm run sync
npm run open
```


## v1.14.42 — Configurazione DCO semplificata
- Rimossi dalla UI “Salva e usa DCO” e “Riprova recupero PDF”.
- Resta “Ristampa ultimo documento”.
- Accesso SPID/CIE/CNS nascosto tramite flag, logica mantenuta nel codice.
- Informativa credenziali semplificata: salvataggio sicuro sul dispositivo, senza dettagli tecnici Keychain/Keystore.
- Il salvataggio delle credenziali Fisconline imposta automaticamente la modalità DCO; IP/porta MUNBYN continuano a salvarsi al cambio campo.

## v1.14.43 — Catalogo e FAQ più puliti
- Libreria immagini: eliminate dalla visualizzazione 26 voci duplicate per nome; gli ID storici restano compatibili con i prodotti già salvati.
- Nuove installazioni/account: nessuna categoria `Generale` predefinita. La vecchia `Generale` viene rimossa automaticamente solo se è vuota e non usata da prodotti.
- FAQ > Primi passi: rimossa la prima domanda.
- FAQ Epson: aggiunta la procedura per leggere l’IP dal registratore: `3333` → tasto chiave → `19` → `Subtotale`.
- Nessuna modifica al motore Fisconline/DCO, riconnessione o stampa.
