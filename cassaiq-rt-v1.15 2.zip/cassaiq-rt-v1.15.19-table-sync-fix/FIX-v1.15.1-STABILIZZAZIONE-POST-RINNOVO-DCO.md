# CassaIQ RT v1.15.1 — Stabilizzazione post-rinnovo Fisconline

Dal test reale è emerso che il reset password può invalidare temporaneamente i token IAM lato Agenzia Entrate anche quando il rinnovo usa una connessione nativa separata.

Correzioni:
- dopo rinnovo riuscito: attesa protetta di 60 secondi prima di consentire un nuovo collegamento DCO;
- durante l'attesa il pulsante mostra il countdown;
- il primo collegamento Fisconline successivo pulisce solo la cache di sessione della InAppBrowser, così non riusa token IAM precedenti al reset;
- se il portale restituisce `nonauth.html` dopo un login valido, CassaIQ attende 5 secondi senza reinviare le credenziali e poi riprova l'instradamento dell'utenza;
- nessuna modifica al motore di emissione DCO o alla stampa;
- rinnovo Fisconline nativo/isolato invariato.
