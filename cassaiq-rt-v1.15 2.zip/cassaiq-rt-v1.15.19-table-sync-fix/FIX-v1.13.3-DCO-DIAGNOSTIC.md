# CassaIQ 1.13.3 — DCO deep diagnostic

- accesso, verifica, utenza e DCO restano nella stessa InAppBrowser;
- barra CassaIQ iniettata solo nelle pagine ufficiali Agenzia;
- diagnostica ripetuta fino a 12 secondi;
- rilevamento iframe/frame, Shadow DOM, meta refresh, link e cronologia URL;
- nessuna lettura dei valori input, password, PIN o cookie;
- nessun invio fiscale abilitato.
