# CassaIQ RT v1.15.19 / build 150

Base: v1.15.18 / build 149. DCO, annullamento DCO, touch-lock, stampanti e tempi fiscali non modificati.

## Correzioni

- Quando un ordine tavolo viene creato direttamente dalla cassa, lo stato `occupied` del tavolo viene pubblicato subito su `restaurant_tables`, senza aspettare la coda generale delle sincronizzazioni LAN.
- La comanda appena creata dalla cassa viene sincronizzata direttamente con priorità (`orders` + `order_items`), quindi un vecchio elemento in errore nella coda locale non può impedire al Client di ricevere il nuovo stato/comanda.
- Gli eventi LAN in background non possono più aprire da soli la finestra “Comanda ricevuta”. Se la finestra è già aperta sullo stesso tavolo, viene solo aggiornata.
- Alla chiusura della finestra ordine viene azzerato `tableOrderState`, eliminando lo stato residuo che poteva causare riaperture apparentemente casuali.

## Test consigliato

1. Crea un ordine su un tavolo direttamente dalla cassa e premi “AGGIUNGI AL TAVOLO”.
2. Sul Client verifica che il tavolo passi a occupato dopo il normale aggiornamento del Client.
3. Apri e poi chiudi una comanda sulla cassa; continua a lavorare e attendi/ricevi altre sincronizzazioni: la finestra non deve riaprirsi da sola.
