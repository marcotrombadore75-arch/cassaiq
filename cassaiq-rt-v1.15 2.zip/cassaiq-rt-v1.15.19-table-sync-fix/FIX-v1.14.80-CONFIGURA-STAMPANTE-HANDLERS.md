# CassaIQ RT v1.14.80 / build 111

Correzione regressione introdotta con la gestione logo DCO.

- Ripristinata `renderDcoBusinessStatus()`, rimossa accidentalmente nella v1.14.78/79.
- La sua assenza interrompeva `initDcoLabView()` prima del binding dei pulsanti di Configura stampante.
- Ripristinati quindi i comandi Epson RT, stampante DCO di rete, stampante cucina e logo.
- Aggiunto isolamento difensivo dell'inizializzazione del form DCO: un eventuale errore futuro nel pannello dati attività non deve più bloccare i controlli hardware.
- Nessuna modifica al motore fiscale DCO/Epson, alla stampa cucina o alle note prodotto.
