# CassaIQ 1.13.8 — Correzione armamento DCO reale

- La finestra di armamento dura 5 minuti e mostra un conto alla rovescia.
- I pulsanti ufficiali non vengono più disabilitati artificialmente: CassaIQ blocca i click in modo protetto finché la prova non è armata.
- Corretto il flusso finale: **Conferma → Procedi**.
- L’armamento non viene cancellato prima dell’invio Angular/submit.
- Dopo il click su Procedi resta valido per 2 minuti, così il portale può completare l’operazione.
- La diagnostica indica stato, fase e secondi residui dell’armamento.
- Versione 1.13.8, build/versionCode 28.

La prova deve riguardare una vendita reale. In caso di esito incerto non ripetere l’emissione: verificare prima nello storico DCO.
