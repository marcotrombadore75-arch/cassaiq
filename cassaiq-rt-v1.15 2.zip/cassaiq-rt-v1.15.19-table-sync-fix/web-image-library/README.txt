Carica il contenuto di questa cartella sul tuo hosting, ad esempio in /cassaiq-immagini/.
La pagina contiene solo immagini generiche senza marchi commerciali.
