# CassaIQ RT v1.14.78 / build 109

## Logo sul Documento Commerciale DCO

- Aggiunta in **Impostazioni → DCO → Dati dell’attività** la sezione **Logo documento commerciale**.
- L'utente può caricare un'immagine; CassaIQ la ritaglia, converte in bianco/nero e la ottimizza automaticamente per la stampante termica 80 mm.
- Il logo viene stampato centrato tramite raster ESC/POS a 576 dot, con contenuto massimo 448 dot di larghezza.
- Il logo è opzionale e può essere disattivato o rimosso.
- Aggiunto **Prova stampa logo**: invia logo + dicitura `STAMPA NON FISCALE` alla MUNBYN senza emettere alcun DCO.
- Il logo viene salvato localmente nel profilo attività; con `supabase-receipt-logo-v1.14.78.sql` viene sincronizzato anche tra dispositivi.
- Se la sincronizzazione logo non è ancora disponibile nel database, la stampa locale continua a funzionare e il salvataggio degli altri dati attività non viene bloccato.
- Un eventuale errore di decodifica/stampa del logo **non blocca mai l'emissione o la stampa del documento**: CassaIQ prosegue senza logo.

## Layout

- Rimossa la dicitura **COPIA DI CORTESIA**.
- Rimane in evidenza **DOCUMENTO COMMERCIALE**.
- Restano invariati numero ufficiale DCO, data/ora, imponibile, IVA, totale e pagamento.

## Fiscalità

La modifica riguarda esclusivamente la rappresentazione grafica della stampa locale ESC/POS. Il payload e il flusso di emissione DCO verso l'Agenzia delle Entrate non sono stati modificati.
