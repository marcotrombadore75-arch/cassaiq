# CassaIQ RT v1.14.51 — Elimina comanda e libera tavolo

- Nella schermata Tavoli, aprendo una comanda ricevuta dalla sala ora compare il pulsante **Elimina** con conferma.
- Il pulsante annulla le comande aperte del tavolo (`status = cancelled`) e riporta subito il tavolo in stato `free`, senza passare dalla chiusura del conto.
- Se il tavolo risulta occupato ma non ha righe comanda, il pulsante resta disponibile come **Libera tavolo** per sbloccare la situazione.
- Nessuna modifica a Epson, DCO/Fisconline, pairing Client o catalogo.
