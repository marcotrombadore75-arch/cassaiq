# CassaIQ RT v1.14.49 — fix Genera codice Client

- Ripristinate le funzioni pairing CassaIQ Client rimosse accidentalmente durante l’integrazione Tavoli.
- `Genera codice` torna a chiamare `cassaiq_create_pairing_code`.
- Ripristinati countdown, codice attivo, elenco dispositivi e revoca.
- Nessuna modifica a Tavoli, ordini, Epson RT, DCO/Fisconline o stampa.
