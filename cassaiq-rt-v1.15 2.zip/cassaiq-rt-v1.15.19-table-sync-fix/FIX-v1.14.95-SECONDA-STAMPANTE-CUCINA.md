# CassaIQ RT v1.14.95 / build 126

- Aggiunta una seconda stampante ESC/POS di rete opzionale per bar/reparto.
- La seconda stampante può ricevere tutta la comanda oppure solo categorie selezionate.
- Modalità **Stampa anche sulla principale**: le righe selezionate vanno su entrambe le stampanti.
- Modalità **Ordine splittato**: le righe selezionate vanno solo sulla stampante 2 e vengono escluse dalla stampante 1.
- Lo stesso routing viene applicato agli annullamenti e alle ristampe.
- La stampante cucina 1 esistente resta compatibile e continua a funzionare anche prima della nuova migrazione Supabase.
- Eseguire `supabase-kitchen-printer2-v1.14.95.sql` per sincronizzare la nuova configurazione ai Client.
