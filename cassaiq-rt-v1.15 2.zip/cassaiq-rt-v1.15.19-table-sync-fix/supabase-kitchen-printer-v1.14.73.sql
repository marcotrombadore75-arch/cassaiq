-- CassaIQ RT v1.14.73 / CassaIQ Client v0.4.6
-- Terza stampante ESC/POS dedicata alla cucina.
-- La configurazione resta nel profilo dell'attivita e viene restituita ai Client autorizzati.

alter table public.business_profiles
  add column if not exists kitchen_printer_enabled boolean not null default false,
  add column if not exists kitchen_printer_ip text not null default '',
  add column if not exists kitchen_printer_port integer not null default 9100;

alter table public.business_profiles
  drop constraint if exists business_profiles_kitchen_printer_port_check;
alter table public.business_profiles
  add constraint business_profiles_kitchen_printer_port_check
  check (kitchen_printer_port between 1 and 65535);

-- Il Client riceve solo la configurazione necessaria per inviare la comanda
-- alla stampante cucina. Il token dispositivo continua a essere verificato.
create or replace function public.cassaiq_client_bootstrap(p_device_id uuid,p_device_token text)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_owner uuid;
  v_categories jsonb;
  v_products jsonb;
  v_tables jsonb;
  v_profile jsonb;
begin
  select d.owner_user_id into v_owner
  from public.cassaiq_client_devices d
  where d.id=p_device_id
    and d.status='active'
    and d.token_hash=encode(digest(coalesce(p_device_token,''),'sha256'),'hex');
  if v_owner is null then raise exception 'DEVICE_NOT_AUTHORIZED'; end if;

  update public.cassaiq_client_devices set last_seen_at=now() where id=p_device_id;

  select coalesce(jsonb_agg(jsonb_build_object(
    'id',c.id,
    'name',c.name,
    'icon',coalesce(c.icon,''),
    'color',coalesce(to_jsonb(c)->>'color','')
  ) order by coalesce((to_jsonb(c)->>'sort_order')::int,0),c.created_at),'[]'::jsonb)
  into v_categories
  from public.categories c
  where c.user_id=v_owner and coalesce(c.active,true)=true;

  select coalesce(jsonb_agg(jsonb_build_object(
    'id',p.id,
    'name',p.name,
    'price',p.price,
    'category_id',p.category_id,
    'image_library_id',coalesce(to_jsonb(p)->>'image_library_id',''),
    'show_price',coalesce((to_jsonb(p)->>'show_price')::boolean,true),
    'variable_price',coalesce((to_jsonb(p)->>'variable_price')::boolean,false)
  ) order by coalesce((to_jsonb(p)->>'sort_order')::int,0),p.created_at),'[]'::jsonb)
  into v_products
  from public.products p
  where p.user_id=v_owner and coalesce(p.active,true)=true;

  select coalesce(jsonb_agg(jsonb_build_object(
    'id',t.id,
    'name',t.name,
    'sort_order',t.sort_order,
    'status',t.status
  ) order by t.sort_order,t.name),'[]'::jsonb)
  into v_tables
  from public.restaurant_tables t
  where t.owner_user_id=v_owner and t.active=true;

  select jsonb_build_object(
    'business_name',coalesce(nullif(bp.trade_name,''),nullif(bp.legal_name,''),'CassaIQ'),
    'kitchen_printer',jsonb_build_object(
      'enabled',coalesce(bp.kitchen_printer_enabled,false),
      'host',coalesce(bp.kitchen_printer_ip,''),
      'port',coalesce(bp.kitchen_printer_port,9100)
    )
  ) into v_profile
  from public.business_profiles bp
  where bp.user_id=v_owner;

  return jsonb_build_object(
    'owner_user_id',v_owner,
    'business_name',coalesce(v_profile->>'business_name','CassaIQ'),
    'categories',v_categories,
    'products',v_products,
    'tables',v_tables,
    'kitchen_printer',coalesce(v_profile->'kitchen_printer',jsonb_build_object('enabled',false,'host','','port',9100))
  );
end;
$$;

revoke all on function public.cassaiq_client_bootstrap(uuid,text) from public;
grant execute on function public.cassaiq_client_bootstrap(uuid,text) to anon,authenticated;
