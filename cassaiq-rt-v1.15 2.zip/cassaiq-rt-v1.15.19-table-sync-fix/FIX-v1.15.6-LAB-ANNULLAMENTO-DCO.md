# CassaIQ RT v1.15.6 / build 137 — LAB annullamento DCO

## Scopo
Versione di prova controllata per mappare l’annullamento di un Documento Commerciale Online senza inviare alcuna operazione fiscale finale.

## Flusso
- Statistiche → Ultime vendite.
- Per una vendita DCO emessa oggi compare **Prova annullo DCO**.
- CassaIQ apre il DCO e imposta `operazione = A` (Annullo).
- Compila `i2_4_7` / `progressivoCollegato` con il numero ufficiale del documento originale.
- Avanza automaticamente fino a **Verifica dati**.
- Si ferma lì. **Conferma**, **Procedi** e **Vai a conferma e stampa** sono bloccati dal LAB.
- Un banner visibile ricorda: `SOLO VERIFICA · NESSUN INVIO FISCALE`.

## Sicurezza
La normale emissione DCO non è stata modificata. Il LAB usa stato, runner e blocchi separati. Chiudendo il browser DCO il test viene azzerato.

## Cosa verificare nel test
Nella schermata ufficiale **Verifica dati** controllare che compaiano:
1. Tipo operazione: **Annullo**.
2. Documento commerciale collegato: numero del documento originale selezionato.
3. Nessun prodotto/pagamento della vendita normale compilato come nuova vendita.

Non premere/forzare comandi finali: la build è progettata per bloccarli, ma il test deve terminare alla schermata Verifica dati.
