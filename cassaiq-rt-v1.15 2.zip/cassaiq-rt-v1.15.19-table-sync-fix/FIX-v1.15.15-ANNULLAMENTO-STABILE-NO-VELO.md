# CassaIQ RT v1.15.15 / build 146

## Base
Ripartenza dalla v1.15.12, confermata funzionante per l’annullamento DCO reale.

## Modifiche
- rimosso completamente il velo full-screen e qualsiasi guardia touch introdotta nelle build successive;
- motore annullamento DCO (routing, selettori, tempi e sequenza fiscale) identico alla v1.15.12 / v1.15.10;
- mantenuto l’avviso prima dell’invio: l’operazione può richiedere 30 secondi o più e non bisogna toccare lo schermo;
- FAQ aggiornata per l’annullamento DCO;
- versione installata visibile in Impostazioni;
- mantenuti overlay centrale del collegamento DCO, nota precauzionale emergenze e persistenza cloud annullamenti della v1.15.12.

## Percorso annullamento verificato nel codice
Home DCO → Genera il tuo documento / Generazione → wizard2 → Tipo operazione Annullo → Numero progressivo documento originario → Prosegui → recupero documento → Vai a verifica dati → wizard3 → Vai a Conferma e stampa → wizard4 → Procedi / Conferma → rilevamento nuovo documento di annullo.
