# CassaIQ RT v1.14.76

- Aggiunto pulsante `+ Nota` su ogni prodotto nel carrello quando si crea un ordine tavolo dalla cassa.
- La nota viene salvata in `order_items.notes`.
- La nota compare nella comanda del tavolo e nella ristampa cucina.
- La stampa cucina mostra la nota subito sotto il prodotto.
- Nessuna modifica al motore fiscale DCO/Epson.
