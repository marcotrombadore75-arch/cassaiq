# CassaIQ 1.13.2 — DCO session fix

Correzione del flusso Documento Commerciale Online:

- accesso tramite `InstradamentofcWeb/wizard`;
- stessa istanza InAppBrowser per login, scelta utenza e DCO;
- nessuna chiusura tra autenticazione e servizio;
- passaggio automatico da `InstradamentofcWeb/home` al DCO;
- recupero automatico da `nonauth.html`;
- emissione fiscale ancora disabilitata.
