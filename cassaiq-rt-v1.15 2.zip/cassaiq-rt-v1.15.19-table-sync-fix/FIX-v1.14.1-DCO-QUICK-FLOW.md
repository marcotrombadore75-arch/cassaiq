# CassaIQ RT 1.14.1 — correzione vendita rapida DCO

Correzioni principali:

- apertura del documento tramite il comando ufficiale **Generazione / Genera il tuo documento**, non più con un solo cambio diretto dell'hash;
- tentativi controllati se la SPA dell'Agenzia non cambia schermata al primo click;
- attesa reale del caricamento dei campi prima di segnare il carrello come compilato;
- compilazione considerata riuscita solo se i campi obbligatori vengono trovati;
- nuovi tentativi per il passaggio **Vai a Conferma e stampa**;
- sequenza finale resa compatibile con il comportamento effettivo del portale: **Procedi**, quindi eventuale **Conferma** nel riquadro;
- timeout basato anche sull'assenza di avanzamento, con limite totale aumentato;
- messaggio chiaro: se il blocco avviene prima dell'invio, nessun documento è stato emesso e non serve necessariamente rifare SPID se lo stato DCO è ancora verde.

La parte Epson non è stata modificata.
