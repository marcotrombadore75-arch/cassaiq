# Fix firma per test su dispositivo reale

Questa variante mantiene invariata CassaIQ RT v1.14.7 (build 37) e modifica soltanto la configurazione **Debug** di Xcode:

- firma automatica;
- certificato Apple Development;
- Team `CMN5ZMGB26`;
- nessun profilo App Store/TestFlight forzato durante `Run`.

La configurazione **Release** resta manuale con il profilo di distribuzione `cassaiq`, quindi il flusso Archive/TestFlight non viene modificato.
