# CassaIQ RT v1.14.67 — Palette azzurro acqua marina

Modifica esclusivamente grafica rispetto a v1.14.66.

- Colore principale: `#2FA8D7`
- Colore principale scuro: `#0F6F97`
- Accento chiaro: `#72CBE8`
- Testi secondari resi più scuri per maggiore leggibilità.
- Mantenuti verdi/rossi semantici per stati OK/errore.
- Nessuna modifica al motore DCO, isolamento emissioni, Android Active WebView, Operazioni di emergenza, stampanti o CassaIQ Client.
- iOS build 98; Android versionCode 98.
