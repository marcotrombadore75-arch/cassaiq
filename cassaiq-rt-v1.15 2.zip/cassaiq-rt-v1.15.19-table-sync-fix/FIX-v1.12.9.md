# CassaIQ RT v1.12.9

- Aggiunto nelle Statistiche il totale dei pagamenti con carta per il periodo selezionato.
- Mostrati anche numero di scontrini pagati con carta e percentuale sull’incasso del periodo.
- Riconosciuti i valori `Carta`, `card`, `credit card`, `debit card` e le principali varianti elettroniche già presenti nei dati storici.
- La statistica segue tutti i filtri già disponibili: periodo, intervallo personalizzato e prodotto.
- Nessuna modifica al protocollo o ai comandi fiscali Epson.
- Versione 1.12.9, build/versionCode 20.
