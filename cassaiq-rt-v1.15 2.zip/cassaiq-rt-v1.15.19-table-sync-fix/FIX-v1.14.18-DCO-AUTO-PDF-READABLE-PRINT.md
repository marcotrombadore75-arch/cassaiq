# CassaIQ RT v1.14.18

Versione 1.14.18 · build iOS 48 · Android versionCode 48.

## Correzioni

- Recupero PDF automatico dopo l’emissione: viene aperto il dettaglio ufficiale del documento e viene riutilizzato lo stesso flusso affidabile di “Riprova recupero PDF”.
- Il runner fiscale viene arrestato appena il documento è emesso; da quel momento lavora soltanto il motore PDF.
- Stampa MUNBYN corretta nell’orientamento verticale, senza specchiatura.
- Rimozione automatica delle ampie aree bianche del PDF A4.
- Impaginazione termica leggibile: intestazioni e blocchi stretti vengono ingranditi; tabelle molto larghe vengono stampate in pannelli consecutivi da sinistra a destra.
- Epson invariata.
