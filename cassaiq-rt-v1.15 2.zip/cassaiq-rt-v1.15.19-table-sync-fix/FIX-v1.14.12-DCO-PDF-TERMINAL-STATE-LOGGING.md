# CassaIQ RT v1.14.12 — DCO PDF terminal state & logging

Versione 1.14.12, build iOS 42, Android versionCode 42.

## Correzioni

- Il browser DCO non viene nascosto o chiuso mentre `__cassaiqDcoPdf.state` è `loading`.
- Ogni lettura del polling viene stampata integralmente nella console Xcode con prefisso `CassaIQ DCO PDF`.
- Il metadata include stato, byte, lunghezza base64, errore, HTTP status, content-type, URL risposta, tempi, visibilità e focus della WebView.
- Al timeout viene eseguita una lettura finale completa.
- Se il fetch è ancora `loading`, viene annullato e trasformato in uno stato `error` esplicito prima di nascondere il browser.
- Se non è possibile leggere o impostare uno stato terminale, la WebView resta visibile e non viene terminata automaticamente.
- La vendita fiscale non viene ripetuta; la patch riguarda esclusivamente il recupero del PDF già emesso.
