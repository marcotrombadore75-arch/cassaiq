# CassaIQ RT v1.15.4 — aggiornamento ordine completo del tavolo

- Nuovo messaggio LAN `replace_table_orders`.
- Un aggiornamento dal Client sostituisce tutte le comande `sent` del tavolo con una sola comanda consolidata.
- Le comande precedenti restano nello storico come `cancelled`.
- La cucina riceve l'intero ordine aggiornato con una testata inequivocabile.
- Se esiste una comanda `accepted`, l'aggiornamento viene rifiutato.
- Se la lista delle comande del tavolo è cambiata rispetto a quella caricata dal Client, l'update viene rifiutato per evitare perdita di righe.
- Libera tavolo continua a non inviare nulla in cucina.
- La sincronizzazione LAN annulla nel cloud solo gli ID che facevano parte dell'ordine caricato dal Client: eventuali nuove aggiunte concorrenti non vengono cancellate per errore.
