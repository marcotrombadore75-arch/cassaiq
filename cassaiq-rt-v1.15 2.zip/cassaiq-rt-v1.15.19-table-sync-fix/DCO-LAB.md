# CassaIQ 1.13.1 — Laboratorio Documento Commerciale Online

Questa versione serve esclusivamente a studiare il flusso ufficiale del portale Fatture e Corrispettivi.

## Cosa fa

- usa Fisconline come accesso principale; SPID/CIE/CNS resta disponibile come accesso alternativo in un browser interno;
- mantiene la sessione sul dispositivo;
- apre il servizio Documento Commerciale Online;
- raccoglie soltanto la struttura tecnica della pagina: URL, titolo, nomi/ID dei controlli, pulsanti e select;
- non legge mai i valori digitati nei campi;
- non salva credenziali, password o PIN;
- non emette, annulla o rende documenti fiscali.

## Test

1. Apri Impostazioni → Documento commerciale online.
2. Configura e usa Fisconline. Apri SPID/CIE/CNS solo dall’accesso alternativo quando necessario.
3. Completa l’accesso esclusivamente nelle pagine ufficiali.
4. Chiudi il browser e torna nell’app.
5. Premi Apri servizio DCO.
6. Quando compare la schermata del servizio, chiudi il browser.
7. Premi Copia diagnostica e incolla il risultato in chat.

Non confermare vendite reali durante questa fase.
