# CassaIQ RT v1.15.3 — Libera tavolo senza invio in cucina

- Rimosso l'invio automatico del ticket ANNULLAMENTO quando dalla cassa si elimina una comanda/libera un tavolo.
- L'azione libera il tavolo e chiude la comanda lato cassa/cloud, senza stampare nulla in cucina.
- La conferma avvisa esplicitamente che non verrà inviato alcun messaggio in cucina.
- Gli aggiornamenti/annullamenti destinati alla cucina restano gestiti dal CassaIQ Client.
- La funzione tecnica di stampa annullamento ricevuta dal Client resta invariata.
