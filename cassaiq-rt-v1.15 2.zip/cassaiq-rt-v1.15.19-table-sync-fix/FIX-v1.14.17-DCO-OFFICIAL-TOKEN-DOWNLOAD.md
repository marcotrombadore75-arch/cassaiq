# CassaIQ RT v1.14.17 — Download PDF ufficiale con token

- Seleziona esclusivamente “Scarica e stampa file”, escludendo la variante “per regalo”.
- Intercetta `window.open` senza aprire una seconda WebView.
- Pulisce ritorni a capo e spazi dall’URL ufficiale.
- Conserva il token `v` generato dal portale e rimuove l’eventuale parametro `regalo`.
- Prova il download nello stesso contesto WebKit e usa rapidamente il fallback nativo con i cookie della sessione.
- Referer impostato sul dettaglio ufficiale del documento.

Versione 1.14.17, build iOS 47, Android versionCode 47.
