# CassaIQ RT v1.14.86 / build 117

- Nuova sezione FAQ in-app “Fisconline e Agenzia delle Entrate”.
- Pulsante portale Agenzia delle Entrate: https://portale.agenziaentrate.gov.it/PortaleWeb/home
- Pulsante ripristino password Fisconline: https://telematici.agenziaentrate.gov.it/Abilitazione/RipristinaPassword/IRipristinaPassword.jsp
- Pulsante predisposto “Guida incarico Fisconline” (video/link da aggiungere).
- Pulsante predisposto “Guida passo passo · Come ottenere le Credenziali Fisconline” (video/link da aggiungere).
- Collegamenti esterni aperti nel browser di sistema.
- Aggiunti alias npm `android:sync` e `android:open` per uniformare i comandi.
