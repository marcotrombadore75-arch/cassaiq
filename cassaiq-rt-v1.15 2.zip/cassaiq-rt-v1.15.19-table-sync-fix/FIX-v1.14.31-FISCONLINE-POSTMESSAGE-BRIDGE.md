# CassaIQ RT v1.14.31 — Fisconline secure postMessage bridge

Correzione del login Fisconline su iOS InAppBrowser.

- `executeScript()` non viene più usato per attendere il valore restituito da funzioni `async`.
- La generazione della coppia RSA e la decifratura restano dentro la pagina AdE.
- I risultati asincroni vengono restituiti a CassaIQ tramite il bridge `cordova_iab.postMessage`, già usato dall’automazione DCO.
- Username, password e PIN non vengono inseriti in chiaro nel codice passato a `executeScript`.
- Nel log nativo può apparire soltanto il payload RSA cifrato, non le credenziali in chiaro.
- Il login continua a gestire separatamente le pagine username/password e PIN.
- Nessuna modifica al flusso di emissione DCO, anti-doppia-emissione o stampa MUNBYN.
