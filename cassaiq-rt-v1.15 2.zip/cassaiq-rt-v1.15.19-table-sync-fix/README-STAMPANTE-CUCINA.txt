CassaIQ RT v1.14.73 / build 104 - Stampante cucina

1) In Supabase SQL Editor eseguire una sola volta:
   supabase-kitchen-printer-v1.14.73.sql

2) In CassaIQ RT aprire:
   Impostazioni > Configura stampante > Stampante cucina

3) Impostare:
   - Attiva stampa automatica delle comande in cucina
   - IP della stampante
   - Porta (normalmente 9100)
   - Stampa test cucina
   - Salva stampante cucina

La configurazione viene salvata anche su Supabase e resa disponibile a CassaIQ Client.
Per stampare direttamente dal Client serve CassaIQ Client v0.4.6 o successivo.

Il ticket cucina contiene tavolo, data/ora, quantita, prodotti e note, senza prezzi.
La stampa cucina e separata da Epson RT e dalla stampante copia cliente DCO.
