-- CassaIQ Client v0.5.13 / CassaIQ RT v1.15.2
-- Modifica di una comanda già inviata: la nuova comanda sostituisce quella selezionata.
-- Eseguire UNA VOLTA nel progetto Supabase di CassaIQ.

create or replace function public.cassaiq_client_replace_order(
  p_device_id uuid,
  p_device_token text,
  p_table_id uuid,
  p_target_order_id uuid,
  p_new_order_id uuid,
  p_items jsonb,
  p_notes text default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_owner uuid;
  v_item jsonb;
  v_product_id uuid;
  v_name text;
  v_db_price numeric(12,2);
  v_variable boolean;
  v_qty numeric(12,3);
  v_unit numeric(12,2);
  v_total numeric(12,2):=0;
  v_existing_total numeric(12,2);
begin
  select d.owner_user_id into v_owner from public.cassaiq_client_devices d
  where d.id=p_device_id and d.status='active' and d.token_hash=encode(digest(coalesce(p_device_token,''),'sha256'),'hex');
  if v_owner is null then raise exception 'DEVICE_NOT_AUTHORIZED'; end if;
  if not exists(select 1 from public.restaurant_tables t where t.id=p_table_id and t.owner_user_id=v_owner and t.active=true) then raise exception 'TABLE_NOT_AVAILABLE'; end if;
  if p_new_order_id is null or p_target_order_id is null or p_new_order_id=p_target_order_id then raise exception 'INVALID_REPLACEMENT_ORDER_ID'; end if;

  select o.total into v_existing_total from public.orders o
  where o.id=p_new_order_id and o.owner_user_id=v_owner and o.table_id=p_table_id and o.created_by_device_id=p_device_id;
  if found then return jsonb_build_object('order_id',p_new_order_id,'replaced_order_id',p_target_order_id,'total',coalesce(v_existing_total,0),'status','sent','duplicate',true); end if;

  if not exists(select 1 from public.orders o where o.id=p_target_order_id and o.owner_user_id=v_owner and o.table_id=p_table_id and o.status='sent') then raise exception 'ORDER_NOT_EDITABLE'; end if;
  if p_items is null or jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 or jsonb_array_length(p_items)>200 then raise exception 'INVALID_ORDER_ITEMS'; end if;

  update public.orders set status='cancelled',updated_at=now()
  where id=p_target_order_id and owner_user_id=v_owner and table_id=p_table_id and status='sent';

  insert into public.orders(id,owner_user_id,table_id,created_by,created_by_device_id,status,notes,subtotal,total,created_at,updated_at)
  values(p_new_order_id,v_owner,p_table_id,null,p_device_id,'sent',nullif(left(coalesce(p_notes,''),500),''),0,0,now(),now());

  for v_item in select value from jsonb_array_elements(p_items) loop
    begin v_product_id:=(v_item->>'product_id')::uuid; v_qty:=(v_item->>'quantity')::numeric; exception when others then raise exception 'INVALID_ORDER_ITEM'; end;
    if v_qty<=0 or v_qty>99 then raise exception 'INVALID_ORDER_ITEM'; end if;
    select p.name,p.price,coalesce((to_jsonb(p)->>'variable_price')::boolean,false) into v_name,v_db_price,v_variable
    from public.products p where p.id=v_product_id and p.user_id=v_owner and coalesce(p.active,true)=true;
    if not found then raise exception 'PRODUCT_NOT_AVAILABLE'; end if;
    if v_variable then begin v_unit:=(v_item->>'unit_price')::numeric; exception when others then raise exception 'INVALID_VARIABLE_PRICE'; end; if v_unit<0 or v_unit>999999 then raise exception 'INVALID_VARIABLE_PRICE'; end if; else v_unit:=v_db_price; end if;
    v_total:=v_total+(v_qty*v_unit);
    insert into public.order_items(id,order_id,owner_user_id,product_id,product_name,quantity,unit_price,line_total,notes,created_at)
    values(gen_random_uuid(),p_new_order_id,v_owner,v_product_id,v_name,v_qty,v_unit,v_qty*v_unit,nullif(left(coalesce(v_item->>'notes',''),300),''),now());
  end loop;

  update public.orders set subtotal=v_total,total=v_total,updated_at=now() where id=p_new_order_id;
  update public.restaurant_tables set status='occupied',updated_at=now() where id=p_table_id and owner_user_id=v_owner;
  update public.cassaiq_client_devices set last_seen_at=now() where id=p_device_id;
  return jsonb_build_object('order_id',p_new_order_id,'replaced_order_id',p_target_order_id,'total',v_total,'status','sent','duplicate',false);
end;
$$;

revoke all on function public.cassaiq_client_replace_order(uuid,text,uuid,uuid,uuid,jsonb,text) from public;
grant execute on function public.cassaiq_client_replace_order(uuid,text,uuid,uuid,uuid,jsonb,text) to anon,authenticated;
