# CassaIQ RT v1.12.7

- Ripristinata la lettura statistiche affidandosi alle policy RLS, come nella versione che funzionava.
- Le vendite locali vengono reinviate e poi rilette nello stesso aggiornamento.
- La testata vendita resta sincronizzabile anche se una riga prodotto fallisce.
- Stato diagnostico con conteggio vendite cloud/dispositivo ed errore preciso.
- Target iOS universale: iPhone + iPad.
- Versione 1.12.7, build 18.
