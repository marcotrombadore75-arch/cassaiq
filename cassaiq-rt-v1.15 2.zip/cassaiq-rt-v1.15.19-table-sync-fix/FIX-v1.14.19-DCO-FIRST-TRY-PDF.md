# CassaIQ RT v1.14.19

Versione 1.14.19 · build iOS 49 · Android versionCode 49.

## Correzione

- Il recupero automatico dopo l’emissione usa lo stesso flusso robusto del comando “Riprova recupero PDF”.
- Il runner fiscale viene fermato prima dell’apertura del dettaglio e non si reinietta durante il download.
- Il timer diagnostico viene arrestato prima di nascondere il browser dopo un recupero riuscito.
- In caso di errore il documento resta marcato come già emesso e viene proposta solo la ripresa del PDF, senza una nuova vendita.
- Il formato di stampa resta quello della v1.14.18 e verrà rifinito separatamente.
