# CassaIQ RT v1.14.92 / build 123

## Statistiche Supabase oltre 1000 righe

Correzione del caricamento cloud delle statistiche quando `sales` o `sale_items` superano il limite di 1000 righe per risposta di PostgREST.

- lettura `sales` paginata a blocchi da 1000 fino a completamento archivio;
- lettura `sale_items` paginata a blocchi da 1000;
- snapshot con cutoff temporale per evitare salti/duplicazioni se viene emessa una nuova vendita durante il caricamento;
- deduplicazione per `id` tra le pagine;
- il confronto tra vendite locali e cloud avviene ora sull'intero insieme cloud, evitando falsi reinvii di vendite gia presenti;
- la verifica dei dettagli prodotto usa l'intero insieme `sale_items`, evitando falsi tentativi di riparazione;
- durante Aggiorna dati viene mostrato l'avanzamento del numero di righe ricevute;
- lo stato finale `Cloud ... · dispositivo ...` mostra il numero effettivo salvato sul dispositivo dopo il merge.

Nessuna modifica SQL richiesta.
