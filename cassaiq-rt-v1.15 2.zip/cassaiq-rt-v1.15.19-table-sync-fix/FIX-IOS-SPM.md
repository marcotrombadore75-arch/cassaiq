# Correzione iOS – No such module 'Capacitor'

La versione 1.12.4 conteneva in `ios/App/CapApp-SPM/Package.swift` un percorso locale RevenueCat appartenente all'ambiente di preparazione dello ZIP. Xcode non riusciva quindi a risolvere l'intero pacchetto Swift e mostrava `No such module 'Capacitor'` in `AppDelegate.swift`.

La versione 1.12.5 usa il percorso portabile:

```text
../../../node_modules/@revenuecat/purchases-capacitor
```

Inoltre `npm run ios:sync` lo ricontrolla e lo corregge automaticamente dopo ogni sincronizzazione Capacitor.

## Installazione pulita su Mac

Chiudi Xcode, apri Terminale nella cartella del progetto ed esegui:

```bash
rm -rf node_modules
npm install
npm run ios:sync
npm run ios:open
```

Se Xcode resta aperto su un errore memorizzato:

1. `File → Packages → Reset Package Caches`
2. `File → Packages → Resolve Package Versions`
3. `Product → Clean Build Folder`
4. Avvia di nuovo sul simulatore iPad.
