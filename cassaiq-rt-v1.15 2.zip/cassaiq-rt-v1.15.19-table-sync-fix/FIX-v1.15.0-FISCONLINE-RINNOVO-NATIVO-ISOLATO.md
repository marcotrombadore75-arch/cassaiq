# CassaIQ RT v1.15.0 — Rinnovo Fisconline nativo e isolato

Obiettivo: preservare la fluidità del DCO.

- Il rinnovo password non usa più una seconda InAppBrowser/WebView.
- iOS usa URLSessionConfiguration.ephemeral; Android usa HttpURLConnection con CookieManager locale.
- Nessun cookie della sessione DCO viene letto, scritto o cancellato dal rinnovo.
- Il rinnovo non parte se il DCO risulta collegato, se è in corso una vendita o se è in corso un collegamento.
- Il controllo automatico avviene all'avvio, non a ogni ritorno dell'app in primo piano.
- Massimo un tentativo automatico al giorno.
- Il rinnovo manuale è limitato a una volta ogni 24 ore dopo un successo, per evitare reset ripetuti a distanza di pochi minuti.
- La stessa password Fisconline viene mantenuta.
- Il contatore torna a 30 giorni solo dopo il testo ufficiale "Ripristino password effettuato con successo".
- Il motore DCO di emissione e stampa non viene modificato.
