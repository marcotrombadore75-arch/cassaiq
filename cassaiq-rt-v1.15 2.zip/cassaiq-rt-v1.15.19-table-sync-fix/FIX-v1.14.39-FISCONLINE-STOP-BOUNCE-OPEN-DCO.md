# CassaIQ RT v1.14.39 — Fisconline: stop rimbalzo + apertura DCO affidabile

## Diagnosi dal log reale
Login Fisconline riuscito (hasUserInfo:true, P.IVA corretta, link DCO presente
su InstradamentofcWeb/home). Due difetti:

1. RIMBALZO iniziale portale<->wizard ~10 volte: dopo il login, l'app navigava
   a DCO_URLS.entry (wizard) anche quando finiva su portale.agenziaentrate.gov.it,
   che rimbalzava a wizard, e cosi' via.
2. Una volta stabile sulla home giusta, NON apriva il DCO: il flag anti-doppio
   introdotto prima restava "incastrato" a true dopo il rimbalzo, mandando l'app
   in polling infinito.

## Correzioni
1. **Guard anti-rimbalzo**: si va al wizard UNA sola volta (dcoWizardEntered);
   entro 8s non si ripete, si lascia che il portale instradi verso la home.
2. **Apertura DCO senza flag incastrabile**: rimosso dcoOpeningServiceLink.
   Ora, sulla home autenticata col link presente, si naviga direttamente
   all'href ufficiale del DCO, con guard basato su URL+tempo (non si ripete la
   stessa navigazione entro 6s). Prima si prova il click sul comando, poi
   fallback su href.

## Href DCO confermato dal log
https://ivaservizi.agenziaentrate.gov.it/ser/documenticommercialionline/

## Invariato
Login Fisconline (selettori diretti), cifratura credenziali, emissione,
anti-doppia-emissione, numero documento ufficiale, stampa MUNBYN, SPID.

## Da verificare su iPad
Dopo login Fisconline: niente piu' rimbalzo, l'app apre il DCO da sola e
arriva alla schermata di emissione. Poi vendita di prova.
