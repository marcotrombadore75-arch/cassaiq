# CassaIQ RT — baseline v1.14.51

Baseline prepared from `cassaiq-rt-v1.14.51-elimina-tavolo`.

- App version: 1.14.51
- iOS build: 81
- Android versionCode: 81
- Android web assets synchronized from `www/` so the v1.14.51 Tavoli / Elimina-Libera fix is present on Android too.
- iOS web assets were already aligned with `www/` (apart from Capacitor/Cordova generated files).
- RevenueCat Android remains configured as in the supplied project for testing; before a Play production release, run `npm run android:release-check` and use the production `goog_...` public SDK key if required.

Development commands:

- iOS: `npm install && npm run ios:sync && npm run ios:open`
- Android: `npm install && npm run sync && npm run open`
