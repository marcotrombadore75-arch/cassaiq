# CassaIQ RT v1.14.89 / build 120

## Ingredienti e supplementi

- Nel pannello **SUPPL.** ogni ingrediente è centrato tra i comandi **−** e **+**.
- **+** aggiunge l’ingrediente/supplemento e somma il prezzo configurato.
- **−** segnala la rimozione dell’ingrediente e **non modifica il prezzo**.
- Toccando di nuovo lo stesso segno si annulla la modifica; passando da − a + (o viceversa) lo stato viene sostituito.
- In carrello e comanda le modifiche sono mostrate con `+` / `−`.
- In cucina vengono stampate entrambe le indicazioni.
- Nel documento fiscale vengono emesse come righe aggiuntive solo le aggiunte a pagamento; le rimozioni non generano storni o sconti.
- Compatibilità mantenuta con i supplementi salvati dalle versioni precedenti: senza `kind` vengono interpretati come aggiunte.
