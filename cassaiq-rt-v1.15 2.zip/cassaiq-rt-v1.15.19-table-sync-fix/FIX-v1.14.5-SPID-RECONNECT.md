# CassaIQ RT 1.14.5 — Fix collegamento SPID/DCO

Versione: **1.14.5**  
Build iOS: **35**  
Android versionCode: **35**

## Problema corretto

Premendo **Collega con SPID**, CassaIQ poteva riaprire una vecchia finestra DCO nascosta, leggere per un istante una pagina precedente e segnare il DCO come collegato senza aver verificato la sessione corrente. La finestra si apriva e si chiudeva subito.

## Correzioni

- ogni collegamento SPID parte da una nuova finestra InAppBrowser;
- la vecchia finestra nascosta viene chiusa e invalidata prima del nuovo tentativo;
- gli eventi provenienti da browser precedenti vengono ignorati;
- il vecchio indicatore verde viene rimosso all'avvio del nuovo collegamento;
- CassaIQ segna il DCO come collegato solo sulla pagina ufficiale `#/home`;
- vengono verificati due volte: sessione utente, caricamento completo, voce Generazione, voce Visualizzazione e titolo Documento commerciale;
- i passaggi tra utenza di lavoro e DCO non aspettano più il callback del contesto WebKit durante la navigazione;
- un tentativo precedente non può più annullare o convalidare quello nuovo in ritardo.

La parte Epson, la vendita DCO, il recupero PDF e la stampa MUNBYN restano invariati.
