# CassaIQ RT v1.14.51 — baseline + diagnostica tempi

Questa build deriva dalla v1.14.51 stabile e aggiunge **solo** la diagnostica tempi dell'emissione DCO.

## Importante
- Polling generale DCO invariato: 1100 ms.
- Primo tick invariato: 350 ms.
- Nessun fast-final a 250 ms.
- Timeout, verifiche fiscali, anti-doppia-emissione, recupero documento e stampa invariati.
- Versione funzionale: 1.14.51.
- Build di test: iOS 84 / Android versionCode 84.

Serve come baseline per confrontare i tempi con la build ottimizzata.
