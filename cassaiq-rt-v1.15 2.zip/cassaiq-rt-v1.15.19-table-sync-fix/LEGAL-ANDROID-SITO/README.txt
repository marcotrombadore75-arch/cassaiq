CASSAIQ RT — PAGINE LEGALI ANDROID

Caricare nella root del sito menoova.it questi due file:
- cassaiq-privacy-android.html
- cassaiq-termini-android.html

Gli URL attesi dalla v1.14.71 sono:
https://menoova.it/cassaiq-privacy-android.html
https://menoova.it/cassaiq-termini-android.html

Dopo il caricamento, aprire entrambi gli URL in un browser e verificare che rispondano senza login o redirect.
