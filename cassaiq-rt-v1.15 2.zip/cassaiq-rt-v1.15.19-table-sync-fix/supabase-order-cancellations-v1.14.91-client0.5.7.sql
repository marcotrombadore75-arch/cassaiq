-- CassaIQ Client v0.5.7 / CassaIQ RT v1.14.91
-- Annullamento piatti/comande senza cancellazione fisica delle righe.
-- Eseguire UNA VOLTA nel SQL Editor dello stesso progetto Supabase di CassaIQ.

alter table public.order_items
  add column if not exists cancelled_quantity numeric(12,3) not null default 0,
  add column if not exists cancelled_at timestamptz,
  add column if not exists cancelled_by_device_id uuid,
  add column if not exists cancellation_note text;

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname='order_items_cancelled_quantity_check'
  ) then
    alter table public.order_items
      add constraint order_items_cancelled_quantity_check
      check (cancelled_quantity >= 0 and cancelled_quantity <= quantity);
  end if;
  if not exists (
    select 1 from pg_constraint where conname='order_items_cancelled_by_device_id_fkey'
  ) then
    alter table public.order_items
      add constraint order_items_cancelled_by_device_id_fkey
      foreign key (cancelled_by_device_id)
      references public.cassaiq_client_devices(id) on delete set null;
  end if;
end $$;

create table if not exists public.order_cancellations (
  id uuid primary key default gen_random_uuid(),
  event_id uuid,
  owner_user_id uuid not null references auth.users(id) on delete cascade,
  table_id uuid references public.restaurant_tables(id) on delete set null,
  order_id uuid not null references public.orders(id) on delete cascade,
  order_item_id uuid not null references public.order_items(id) on delete cascade,
  product_name text not null,
  quantity numeric(12,3) not null check (quantity > 0),
  reason text,
  created_by_device_id uuid references public.cassaiq_client_devices(id) on delete set null,
  created_at timestamptz not null default now()
);

create index if not exists order_cancellations_order_idx
  on public.order_cancellations(owner_user_id,order_id,created_at desc);
create index if not exists order_cancellations_event_idx
  on public.order_cancellations(event_id);

alter table public.order_cancellations enable row level security;

drop policy if exists order_cancellations_owner_all on public.order_cancellations;
create policy order_cancellations_owner_all on public.order_cancellations
for all
using (auth.uid()=owner_user_id)
with check (auth.uid()=owner_user_id);

create or replace function public.cassaiq_client_cancel_order_items(
  p_device_id uuid,
  p_device_token text,
  p_order_id uuid,
  p_items jsonb,
  p_reason text default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_owner uuid;
  v_table_id uuid;
  v_status text;
  v_item jsonb;
  v_item_id uuid;
  v_cancel_id uuid;
  v_qty numeric(12,3);
  v_original numeric(12,3);
  v_cancelled numeric(12,3);
  v_remaining numeric(12,3);
  v_name text;
  v_total numeric(12,2);
  v_remaining_qty numeric(12,3);
  v_processed integer:=0;
  v_table_status text;
  v_items jsonb;
begin
  select d.owner_user_id into v_owner
  from public.cassaiq_client_devices d
  where d.id=p_device_id
    and d.status='active'
    and d.token_hash=encode(digest(coalesce(p_device_token,''),'sha256'),'hex');

  if v_owner is null then raise exception 'DEVICE_NOT_AUTHORIZED'; end if;

  select o.table_id,o.status
    into v_table_id,v_status
  from public.orders o
  where o.id=p_order_id and o.owner_user_id=v_owner
  for update;

  if v_table_id is null then raise exception 'ORDER_NOT_AVAILABLE'; end if;
  if v_status not in ('sent','cancelled') then raise exception 'ORDER_NOT_CANCELLABLE'; end if;

  if p_items is null
     or jsonb_typeof(p_items)<>'array'
     or jsonb_array_length(p_items)=0
     or jsonb_array_length(p_items)>200
  then
    raise exception 'INVALID_CANCELLATION_ITEMS';
  end if;

  for v_item in select value from jsonb_array_elements(p_items)
  loop
    begin
      v_item_id:=(v_item->>'order_item_id')::uuid;
      v_qty:=(v_item->>'quantity')::numeric;
      v_cancel_id:=coalesce(nullif(v_item->>'cancel_id','')::uuid,gen_random_uuid());
    exception when others then
      raise exception 'INVALID_CANCELLATION_ITEM';
    end;

    if v_qty<=0 or v_qty>99 then raise exception 'INVALID_CANCELLATION_ITEM'; end if;

    -- Un retry con lo stesso cancel_id non deve togliere la quantità due volte.
    if exists(
      select 1 from public.order_cancellations c
      where c.id=v_cancel_id and c.owner_user_id=v_owner
    ) then
      continue;
    end if;

    select oi.quantity,coalesce(oi.cancelled_quantity,0),oi.product_name
      into v_original,v_cancelled,v_name
    from public.order_items oi
    where oi.id=v_item_id
      and oi.order_id=p_order_id
      and oi.owner_user_id=v_owner
    for update;

    if not found then raise exception 'ORDER_ITEM_NOT_AVAILABLE'; end if;

    v_remaining:=greatest(v_original-v_cancelled,0);
    if v_qty>v_remaining then raise exception 'CANCEL_QUANTITY_TOO_HIGH'; end if;

    update public.order_items
    set cancelled_quantity=v_cancelled+v_qty,
        cancelled_at=now(),
        cancelled_by_device_id=p_device_id,
        cancellation_note=nullif(left(coalesce(p_reason,''),200),'')
    where id=v_item_id;

    insert into public.order_cancellations(
      id,event_id,owner_user_id,table_id,order_id,order_item_id,
      product_name,quantity,reason,created_by_device_id,created_at
    )
    values(
      v_cancel_id,null,v_owner,v_table_id,p_order_id,v_item_id,
      v_name,v_qty,nullif(left(coalesce(p_reason,''),200),''),p_device_id,now()
    );

    v_processed:=v_processed+1;
  end loop;

  select coalesce(sum(greatest(oi.quantity-coalesce(oi.cancelled_quantity,0),0)*oi.unit_price),0),
         coalesce(sum(greatest(oi.quantity-coalesce(oi.cancelled_quantity,0),0)),0)
    into v_total,v_remaining_qty
  from public.order_items oi
  where oi.order_id=p_order_id and oi.owner_user_id=v_owner;

  update public.orders
  set subtotal=v_total,
      total=v_total,
      status=case when v_remaining_qty<=0 then 'cancelled' else status end,
      updated_at=now()
  where id=p_order_id and owner_user_id=v_owner;

  if exists(
    select 1
    from public.orders o
    join public.order_items oi on oi.order_id=o.id and oi.owner_user_id=v_owner
    where o.owner_user_id=v_owner
      and o.table_id=v_table_id
      and o.status in ('sent','accepted')
      and greatest(oi.quantity-coalesce(oi.cancelled_quantity,0),0)>0
  ) then
    v_table_status:='occupied';
  else
    v_table_status:='free';
  end if;

  update public.restaurant_tables
  set status=v_table_status,updated_at=now()
  where id=v_table_id and owner_user_id=v_owner;

  update public.cassaiq_client_devices
  set last_seen_at=now()
  where id=p_device_id;

  select coalesce(jsonb_agg(
    jsonb_build_object(
      'id',oi.id,
      'product_id',oi.product_id,
      'product_name',oi.product_name,
      'quantity',oi.quantity,
      'cancelled_quantity',coalesce(oi.cancelled_quantity,0),
      'remaining_quantity',greatest(oi.quantity-coalesce(oi.cancelled_quantity,0),0),
      'unit_price',oi.unit_price,
      'line_total',greatest(oi.quantity-coalesce(oi.cancelled_quantity,0),0)*oi.unit_price,
      'notes',coalesce(oi.notes,''),
      'cancelled_at',oi.cancelled_at,
      'cancellation_note',coalesce(oi.cancellation_note,'')
    ) order by oi.created_at
  ),'[]'::jsonb)
  into v_items
  from public.order_items oi
  where oi.order_id=p_order_id and oi.owner_user_id=v_owner;

  return jsonb_build_object(
    'ok',true,
    'order_id',p_order_id,
    'processed',v_processed,
    'status',case when v_remaining_qty<=0 then 'cancelled' else 'sent' end,
    'total',v_total,
    'table_status',v_table_status,
    'items',v_items
  );
end;
$$;

revoke all on function public.cassaiq_client_cancel_order_items(uuid,text,uuid,jsonb,text) from public;
grant execute on function public.cassaiq_client_cancel_order_items(uuid,text,uuid,jsonb,text) to anon,authenticated;

-- Aggiorna lo storico delle comande aperte restituendo anche le quantità annullate.
create or replace function public.cassaiq_client_table_orders(
  p_device_id uuid,
  p_device_token text,
  p_table_id uuid
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_owner uuid;
  v_orders jsonb;
begin
  select d.owner_user_id into v_owner
  from public.cassaiq_client_devices d
  where d.id=p_device_id
    and d.status='active'
    and d.token_hash=encode(digest(coalesce(p_device_token,''),'sha256'),'hex');
  if v_owner is null then raise exception 'DEVICE_NOT_AUTHORIZED'; end if;

  if not exists(
    select 1 from public.restaurant_tables t
    where t.id=p_table_id and t.owner_user_id=v_owner and t.active=true
  ) then raise exception 'TABLE_NOT_AVAILABLE'; end if;

  update public.cassaiq_client_devices set last_seen_at=now() where id=p_device_id;

  select coalesce(jsonb_agg(
    jsonb_build_object(
      'id',o.id,
      'status',o.status,
      'notes',coalesce(o.notes,''),
      'subtotal',o.subtotal,
      'total',o.total,
      'created_at',o.created_at,
      'updated_at',o.updated_at,
      'created_by_device_id',o.created_by_device_id,
      'items',(
        select coalesce(jsonb_agg(
          jsonb_build_object(
            'id',oi.id,
            'product_id',oi.product_id,
            'product_name',oi.product_name,
            'quantity',oi.quantity,
            'cancelled_quantity',coalesce(oi.cancelled_quantity,0),
            'remaining_quantity',greatest(oi.quantity-coalesce(oi.cancelled_quantity,0),0),
            'unit_price',oi.unit_price,
            'line_total',greatest(oi.quantity-coalesce(oi.cancelled_quantity,0),0)*oi.unit_price,
            'notes',coalesce(oi.notes,''),
            'cancelled_at',oi.cancelled_at,
            'cancellation_note',coalesce(oi.cancellation_note,'')
          ) order by oi.created_at
        ),'[]'::jsonb)
        from public.order_items oi
        where oi.order_id=o.id and oi.owner_user_id=v_owner
      )
    ) order by o.created_at
  ),'[]'::jsonb)
  into v_orders
  from public.orders o
  where o.owner_user_id=v_owner
    and o.table_id=p_table_id
    and o.status in ('sent','accepted');

  return jsonb_build_object('table_id',p_table_id,'orders',v_orders);
end;
$$;

revoke all on function public.cassaiq_client_table_orders(uuid,text,uuid) from public;
grant execute on function public.cassaiq_client_table_orders(uuid,text,uuid) to anon,authenticated;
