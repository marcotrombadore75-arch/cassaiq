# CassaIQ RT v1.14.66 — Operazioni di emergenza da regolarizzare

Versione: 1.14.66  
iOS build: 97  
Android versionCode: 97

## Obiettivo
Aggiunge una gestione prudente delle vendite DCO che non possono essere completate per assenza di rete o indisponibilità del portale.

La sezione si chiama **Operazioni di emergenza da regolarizzare** e non presenta le righe salvate come documenti fiscali già emessi.

## Comportamento
- Nuovo pulsante in Impostazioni → Catalogo e vendite → Operazioni di emergenza.
- Se il dispositivo è offline quando si tenta di emettere via DCO, CassaIQ propone di salvare la vendita senza stampare nulla.
- Se una emissione DCO si interrompe prima della fase irreversibile, la vendita viene salvata automaticamente come **DA REGOLARIZZARE**.
- Se l'esito è incerto dopo l'armamento/invio finale, la vendita viene salvata come **ESITO DA VERIFICARE** e non è reinviabile finché l'utente non verifica il DCO.
- La regolarizzazione è esclusivamente manuale: un pulsante **Invia al DCO** per ogni singola operazione.
- Dopo emissione positiva la riga diventa **REGOLARIZZATA** e conserva identificativo/numero DCO.
- Nessun pulsante “Invia tutto”.
- Nessuna stampa viene eseguita quando una vendita viene soltanto registrata come emergenza.

## Rete e DCO
- `online` / `offline` aggiornano lo stato della connessione e avvisano quando internet torna disponibile.
- Il ritorno di internet non provoca alcuna emissione automatica.
- La pagina Operazioni di emergenza distingue tra internet disponibile e sessione DCO realmente verificata.
- **Verifica DCO** controlla una sessione già aperta; se necessario può avviare il ricollegamento Fisconline, senza inviare vendite.

## Sicurezza anti-duplicazione
- Un'operazione con stato **ESITO DA VERIFICARE** non può essere inviata.
- “Ho verificato: non emessa” richiede conferma esplicita e libera il lock soltanto se il pending DCO appartiene a quella stessa operazione.
- Se l'app viene interrotta durante una regolarizzazione, al riavvio lo stato viene ricostruito in modo prudente dal lock DCO.

## Motore fiscale
Il motore DCO rapido / operation isolation / Android Active WebView resta invariato rispetto alla base v1.14.65, salvo i punti di integrazione necessari per usare una vendita già memorizzata e marcare l'esito della regolarizzazione.

## Tavoli e CassaIQ Client
Se la vendita di emergenza nasce da un tavolo, CassaIQ conserva anche il contesto del tavolo e gli ID delle comande. Il tavolo non viene chiuso al momento del salvataggio offline. Dopo la regolarizzazione DCO riuscita, CassaIQ prova a chiudere le comande memorizzate e libera il tavolo soltanto se non risultano altre comande aperte. Un eventuale errore di sincronizzazione del tavolo non modifica lo stato fiscale già regolarizzato e viene segnalato separatamente.
