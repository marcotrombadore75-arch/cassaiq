-- CassaIQ RT v1.15.12
-- ESEGUI UNA SOLA VOLTA nel SQL Editor del progetto Supabase CassaIQ.
-- Aggiunge allo storico vendite i metadati dell'annullamento DCO.
-- Non emette, annulla o modifica alcun documento fiscale: salva solo lo stato applicativo.

alter table public.sales
  add column if not exists void_status text,
  add column if not exists voided_at timestamptz,
  add column if not exists void_reason text,
  add column if not exists void_original_number text,
  add column if not exists void_document_id text,
  add column if not exists void_document_number text,
  add column if not exists void_document_date text;

create index if not exists sales_void_status_idx on public.sales(void_status);

comment on column public.sales.void_status is 'Stato annullamento DCO: annullata oppure esito_da_verificare.';
comment on column public.sales.voided_at is 'Data/ora in cui CassaIQ ha ricevuto evidenza positiva dell annullamento DCO.';
comment on column public.sales.void_original_number is 'Progressivo del documento DCO originario annullato.';
comment on column public.sales.void_document_id is 'Identificativo tecnico del nuovo documento DCO di annullo.';
comment on column public.sales.void_document_number is 'Progressivo del nuovo documento fiscale di annullo.';
comment on column public.sales.void_document_date is 'Data del nuovo documento fiscale di annullo.';
