// swift-tools-version: 5.9

import PackageDescription

let package = Package(
    name: "CordovaPluginInappbrowser",
    platforms: [.iOS(.v15)],
    products: [
        .library(
            name: "CordovaPluginInappbrowser",
            targets: ["CordovaPluginInappbrowser"]
        )
    ],
    dependencies: [
        .package(url: "https://github.com/ionic-team/capacitor-swift-pm.git", from: "8.4.2")
    ],
    targets: [
        .target(
            name: "CordovaPluginInappbrowser",
            dependencies: [
                .product(name: "Cordova", package: "capacitor-swift-pm")
            ],
            path: ".",
            publicHeadersPath: ".",
            linkerSettings: [
                .linkedFramework("CoreGraphics")
            ]
        )
    ]
)