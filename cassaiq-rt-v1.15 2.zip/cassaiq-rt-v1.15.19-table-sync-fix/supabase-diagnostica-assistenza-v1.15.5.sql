-- CassaIQ RT v1.15.5
-- Diagnostica manuale assistenza -> Supabase
-- Eseguire UNA SOLA VOLTA nel progetto Supabase di CassaIQ.

create table if not exists public.cassaiq_support_diagnostics (
  id uuid primary key default gen_random_uuid(),
  short_code text not null unique,
  owner_user_id uuid not null,
  created_at timestamptz not null default now(),
  app_name text not null default 'CassaIQ RT',
  app_version text,
  build text,
  platform text,
  summary text,
  payload jsonb not null,
  status text not null default 'new'
);

create index if not exists cassaiq_support_diagnostics_created_at_idx
  on public.cassaiq_support_diagnostics (created_at desc);

create index if not exists cassaiq_support_diagnostics_owner_user_id_idx
  on public.cassaiq_support_diagnostics (owner_user_id, created_at desc);

alter table public.cassaiq_support_diagnostics enable row level security;

-- Il client non legge e non scrive direttamente la tabella.
revoke all on table public.cassaiq_support_diagnostics from anon, authenticated;

create or replace function public.cassaiq_submit_diagnostic(p_payload jsonb)
returns text
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_uid uuid := auth.uid();
  v_code text;
  v_attempt integer := 0;
begin
  if v_uid is null then
    raise exception 'AUTH_REQUIRED';
  end if;

  if p_payload is null or jsonb_typeof(p_payload) <> 'object' then
    raise exception 'INVALID_DIAGNOSTIC_PAYLOAD';
  end if;

  if octet_length(p_payload::text) > 250000 then
    raise exception 'DIAGNOSTIC_TOO_LARGE';
  end if;

  loop
    v_attempt := v_attempt + 1;
    v_code := 'CQ-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8));

    begin
      insert into public.cassaiq_support_diagnostics (
        short_code,
        owner_user_id,
        app_name,
        app_version,
        build,
        platform,
        summary,
        payload
      ) values (
        v_code,
        v_uid,
        left(coalesce(p_payload->>'app_name', 'CassaIQ RT'), 80),
        left(coalesce(p_payload->>'app_version', ''), 40),
        left(coalesce(p_payload->>'build', ''), 40),
        left(coalesce(p_payload->>'platform', ''), 40),
        left(coalesce(p_payload->>'summary', 'Invio manuale assistenza'), 250),
        p_payload
      );
      exit;
    exception when unique_violation then
      if v_attempt >= 5 then raise; end if;
    end;
  end loop;

  return v_code;
end;
$$;

revoke all on function public.cassaiq_submit_diagnostic(jsonb) from public;
grant execute on function public.cassaiq_submit_diagnostic(jsonb) to authenticated;

comment on table public.cassaiq_support_diagnostics is
  'Report diagnostici CassaIQ inviati manualmente dal cliente su richiesta dell’assistenza.';
