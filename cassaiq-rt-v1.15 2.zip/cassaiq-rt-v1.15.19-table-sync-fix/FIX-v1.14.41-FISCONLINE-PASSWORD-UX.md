# CassaIQ RT v1.14.41 — Fisconline password UX

- Base: ZIP funzionante v1.14.39 stop-bounce-open-DCO fornito dall’utente.
- Non modifica il flusso IAM -> utenza -> DCO verificato funzionante.
- Credenziali rifiutate: dialog grande e visibile, nessun retry automatico.
- Password scaduta: dialog dedicato, apertura del sito ufficiale Servizi Telematici nel browser esterno.
- Il rinnovo password NON viene automatizzato dentro CassaIQ.
- Dopo il rinnovo l’utente inserisce soltanto la nuova password; username/CF e PIN restano nel Keychain/Keystore.
- Rilevamento PASSWORD_EXPIRED ampliato anche alla schermata vecchia password / nuova password / conferma.
- Password Fisconline: validazione locale 8-15 caratteri.
- URL esterno ufficiale: https://telematici.agenziaentrate.gov.it/
