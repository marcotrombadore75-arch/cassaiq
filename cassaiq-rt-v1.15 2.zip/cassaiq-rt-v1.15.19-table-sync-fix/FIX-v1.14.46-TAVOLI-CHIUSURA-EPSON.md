# CassaIQ RT v1.14.46

- In testata il comando **Tavoli** sostituisce **Chiusura giornaliera**.
- Nuova pagina Tavoli con creazione, rinomina, aggiornamento e disattivazione dei tavoli sincronizzati con CassaIQ Client.
- Lo stato libero/occupato/conto richiesto viene letto da `restaurant_tables`.
- La **Chiusura giornaliera** è stata spostata in **Configura CassaIQ → Epson RT** ed è visibile solo quando la modalità fiscale attiva è Epson.
- Nessuna modifica al motore Fisconline/DCO, riconnessione o stampa DCO.
- Versione 1.14.46 · iOS build 76 · Android versionCode 76.
