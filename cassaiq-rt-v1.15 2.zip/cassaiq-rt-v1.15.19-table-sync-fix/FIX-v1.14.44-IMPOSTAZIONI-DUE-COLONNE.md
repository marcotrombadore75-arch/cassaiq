# CassaIQ RT v1.14.44 — Impostazioni a due colonne

- Colonna sinistra: Categorie, Reparti, Prodotti, Statistiche vendite.
- Colonna destra: Area utente, Configura CassaIQ, Abbonamento, FAQ e assistenza.
- Divisorio verticale centrale su tablet/desktop.
- Layout mobile a colonna singola con separazione orizzontale fra le due aree.
- Nessuna modifica alla logica DCO/Fisconline, vendita o stampa.
