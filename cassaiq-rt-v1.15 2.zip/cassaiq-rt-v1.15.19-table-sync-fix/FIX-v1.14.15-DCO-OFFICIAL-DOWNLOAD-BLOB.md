# CassaIQ RT v1.14.15 — Download PDF ufficiale DCO

- Versione app: 1.14.15
- Build iOS: 45
- Android versionCode: 45

## Correzione

Il recupero PDF non usa più come percorso principale una richiesta HTTP costruita da CassaIQ. Dopo l’emissione viene azionato il comando ufficiale **Scarica e stampa file** del portale. CassaIQ intercetta le risposte Blob, ArrayBuffer, XHR, fetch e object URL create dalla pagina.

Se iOS trasforma il download ufficiale in una navigazione verso `/stampa/`, il plugin nativo recupera il file usando i cookie della sessione WebKit, verifica la firma `%PDF`, salva il documento e lo converte per la MUNBYN da 80 mm.

## Sicurezza

- lo stato PDF precedente viene cancellato prima di una nuova vendita;
- il documento viene identificato solo tramite l’ID della schermata corrente;
- nessuna nuova emissione viene avviata durante il recupero;
- il browser resta aperto fino al salvataggio o a un errore esplicito;
- il carrello viene svuotato solo dopo acquisizione del PDF e registrazione della vendita.
