# CassaIQ RT v1.14.79 / build 110

- Corretto il caricamento del logo nel WebView nativo: `Carica logo` usa ora il collegamento HTML diretto `label for=input`, già utilizzato con successo per le immagini prodotto.
- `Prova stampa logo` e `Rimuovi logo` restano cliccabili anche senza logo e mostrano un messaggio esplicativo invece di apparire disabilitati.
- L’interruttore di stampa resta disabilitato finché non viene caricato un logo.
- Nessuna modifica al motore fiscale DCO/Epson, alle note prodotto o alla stampa cucina.
