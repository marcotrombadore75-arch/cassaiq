CassaIQ RT v1.15.16 - pacchetto iOS stabile

Questo ZIP mantiene il progetto Xcode iOS gia validato della base CassaIQ.
Non contiene node_modules: sul Mac eseguire normalmente:

npm install
npm run ios:add
npm run ios:sync
npm run ios:open

IMPORTANTE:
- ios:add ora e' sicuro anche se la cartella ios esiste: NON la ricrea e NON cancella la configurazione Xcode stabile.
- le versioni Capacitor/RevenueCat sono bloccate alle stesse versioni della base funzionante.
- Package.resolved di Xcode e' incluso.
