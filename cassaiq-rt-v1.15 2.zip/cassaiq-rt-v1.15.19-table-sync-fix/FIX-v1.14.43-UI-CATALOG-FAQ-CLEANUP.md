# CassaIQ RT v1.14.43

Aggiornamento UI/catalogo/FAQ senza modifiche al motore Fisconline/DCO.

- Libreria immagini: rimosse dalla visualizzazione le voci con nome duplicato. Gli asset/ID storici restano disponibili internamente per non rompere prodotti già salvati.
- Nuova installazione/account: nessuna categoria `Generale` viene creata automaticamente; l’elenco parte senza categorie.
- FAQ > Primi passi: rimossa la prima domanda sulla preparazione iniziale.
- FAQ > Epson e rete locale > indirizzo IP: procedura aggiornata a `3333` → tasto chiave → `19` → `Subtotale`; l’IP appare sul display della cassa.
