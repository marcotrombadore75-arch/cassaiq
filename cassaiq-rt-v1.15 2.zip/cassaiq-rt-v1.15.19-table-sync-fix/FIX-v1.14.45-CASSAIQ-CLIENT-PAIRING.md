# CassaIQ RT v1.14.45

- Aggiunta sezione CassaIQ Client in Configura CassaIQ.
- Generazione codice monouso di 6 cifre tramite `cassaiq_create_pairing_code()`.
- Validità codice: 5 minuti con countdown visibile.
- Elenco dispositivi Client collegati e comando Revoca.
- Rimossa intestazione ridondante dalla pagina Impostazioni.
- Nessuna modifica al motore Fisconline/DCO, stampa o riconnessione.
