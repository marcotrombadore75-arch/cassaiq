# CassaIQ RT v1.14.21

- Sezione obbligatoria Dati dell’attività nell’Area DCO.
- Ragione sociale, Partita IVA, indirizzo, civico, CAP, Comune e Provincia richiesti prima di collegare o usare il DCO.
- Profilo attività salvato localmente e congelato nella vendita per ristampe coerenti.
- Nuovo layout ESC/POS 80 mm: intestazione e riferimenti centrati; articoli, IVA, prezzi, totali e pagamenti a tutta larghezza.
- Il PDF ufficiale resta opzionale e non blocca la stampa al cliente.
- Versione 1.14.21, build/versionCode 51.
