-- CassaIQ RT v1.14.76 / Client v0.4.8 - note per singolo prodotto
-- Eseguire UNA VOLTA nel SQL Editor di Supabase.
-- Non modifica le tabelle: order_items.notes esiste gia'. Aggiorna solo la RPC di invio comanda.

create or replace function public.cassaiq_client_send_order(
  p_device_id uuid,
  p_device_token text,
  p_table_id uuid,
  p_items jsonb,
  p_notes text default null
)
returns jsonb
language plpgsql
security definer
set search_path=public,extensions
as $$
declare
  v_owner uuid;
  v_order_id uuid:=gen_random_uuid();
  v_item jsonb;
  v_product_id uuid;
  v_name text;
  v_db_price numeric(12,2);
  v_variable boolean;
  v_qty numeric(12,3);
  v_unit numeric(12,2);
  v_total numeric(12,2):=0;
begin
  select d.owner_user_id into v_owner
  from public.cassaiq_client_devices d
  where d.id=p_device_id
    and d.status='active'
    and d.token_hash=encode(digest(coalesce(p_device_token,''),'sha256'),'hex');
  if v_owner is null then raise exception 'DEVICE_NOT_AUTHORIZED'; end if;

  if not exists(select 1 from public.restaurant_tables t where t.id=p_table_id and t.owner_user_id=v_owner and t.active=true)
    then raise exception 'TABLE_NOT_AVAILABLE';
  end if;
  if p_items is null or jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 or jsonb_array_length(p_items)>200
    then raise exception 'INVALID_ORDER_ITEMS';
  end if;

  insert into public.orders(id,owner_user_id,table_id,created_by,created_by_device_id,status,notes,subtotal,total,created_at,updated_at)
  values(v_order_id,v_owner,p_table_id,null,p_device_id,'sent',nullif(left(coalesce(p_notes,''),500),''),0,0,now(),now());

  for v_item in select value from jsonb_array_elements(p_items)
  loop
    begin
      v_product_id:=(v_item->>'product_id')::uuid;
      v_qty:=(v_item->>'quantity')::numeric;
    exception when others then
      raise exception 'INVALID_ORDER_ITEM';
    end;
    if v_qty<=0 or v_qty>99 then raise exception 'INVALID_ORDER_ITEM'; end if;

    select p.name,p.price,coalesce((to_jsonb(p)->>'variable_price')::boolean,false)
    into v_name,v_db_price,v_variable
    from public.products p
    where p.id=v_product_id and p.user_id=v_owner and coalesce(p.active,true)=true;
    if not found then raise exception 'PRODUCT_NOT_AVAILABLE'; end if;

    if v_variable then
      begin v_unit:=(v_item->>'unit_price')::numeric; exception when others then raise exception 'INVALID_VARIABLE_PRICE'; end;
      if v_unit<0 or v_unit>999999 then raise exception 'INVALID_VARIABLE_PRICE'; end if;
    else
      v_unit:=v_db_price;
    end if;

    v_total:=v_total+(v_qty*v_unit);
    insert into public.order_items(id,order_id,owner_user_id,product_id,product_name,quantity,unit_price,line_total,notes,created_at)
    values(gen_random_uuid(),v_order_id,v_owner,v_product_id,v_name,v_qty,v_unit,v_qty*v_unit,nullif(left(coalesce(v_item->>'notes',''),300),''),now());
  end loop;

  update public.orders set subtotal=v_total,total=v_total,updated_at=now() where id=v_order_id;
  update public.restaurant_tables set status='occupied',updated_at=now() where id=p_table_id and owner_user_id=v_owner;
  update public.cassaiq_client_devices set last_seen_at=now() where id=p_device_id;

  return jsonb_build_object('order_id',v_order_id,'total',v_total,'status','sent');
end;
$$;

revoke all on function public.cassaiq_client_send_order(uuid,text,uuid,jsonb,text) from public;
grant execute on function public.cassaiq_client_send_order(uuid,text,uuid,jsonb,text) to anon,authenticated;
