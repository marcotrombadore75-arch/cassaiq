-- CassaIQ RT v1.6 — subtotale e sconto a importo
ALTER TABLE public.sales
ADD COLUMN IF NOT EXISTS subtotal NUMERIC(12,2) NOT NULL DEFAULT 0,
ADD COLUMN IF NOT EXISTS discount_amount NUMERIC(12,2) NOT NULL DEFAULT 0;

UPDATE public.sales
SET subtotal = total
WHERE subtotal = 0 AND total IS NOT NULL;
