# CassaIQ 1.13.0 — Test stampante MUNBYN 80 mm

Questa versione aggiunge un laboratorio hardware separato dall'integrazione fiscale Epson.

## Stampante usata per il test

Dati letti dal foglio di autotest fornito:

- protocollo: EPSON ESC/POS;
- velocità: 300 mm/s;
- carta: 80 mm, larghezza di stampa 72 mm;
- taglierina: attiva;
- interfacce: USB, seriale, LAN e Bluetooth;
- nome Bluetooth: `TM-m30-b001`;
- PIN Bluetooth: `0000`;
- indirizzo IP: `192.168.1.201`;
- DHCP: disattivato;
- porta ESC/POS prevista: `9100`.

## Importante

Le stampe prodotte da questa schermata sono prove non fiscali. Non vengono inviate all'Agenzia delle Entrate e non sostituiscono il documento fiscale Epson.

## Primo test consigliato: rete

1. Collega iPad/Android e stampante alla stessa rete.
2. Apri CassaIQ → Impostazioni → Test stampante 80 mm.
3. Lascia IP `192.168.1.201` e porta `9100`.
4. Premi **Stampa test completo**.
5. Verifica testo, avanzamento e taglio.
6. Prova separatamente **Taglia carta** e **Apri cassetto**.

Se non stampa, verifica che l'indirizzo del tablet sia nella stessa sottorete `192.168.1.x` e che nessun altro dispositivo stia usando `192.168.1.201`.

## Test Bluetooth su iPhone/iPad

1. Accendi la stampante e avvicinala all'iPad.
2. Apri CassaIQ → Impostazioni → Test stampante 80 mm.
3. Premi **Cerca stampanti Bluetooth** e consenti l'accesso Bluetooth.
4. Seleziona `TM-m30-b001`.
5. Premi **Collega** e poi **Stampa test**.

La ricerca iOS usa Bluetooth Low Energy e individua automaticamente il primo canale scrivibile esposto dalla stampante. Se il dispositivo non compare, usa temporaneamente la rete e comunica il messaggio mostrato dall'app.

## Test Bluetooth su Android

1. Associa prima `TM-m30-b001` dalle Impostazioni Bluetooth di Android usando il PIN `0000`.
2. Nell'app premi **Cerca stampanti Bluetooth**.
3. Seleziona la stampante associata, premi **Collega** e poi **Stampa test**.

Android usa il profilo seriale Bluetooth SPP/ESC-POS.

## Risultato atteso

La stampa deve contenere:

- `CASSAIQ` in evidenza;
- `TEST STAMPANTE 80 MM`;
- due prodotti di prova;
- totale `EUR 15,50`;
- tipo di collegamento;
- dicitura `STAMPA NON FISCALE`;
- taglio automatico finale.
