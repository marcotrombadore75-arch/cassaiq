-- CassaIQ RT v1.14.78
-- Logo opzionale del Documento Commerciale DCO.
-- Il logo viene usato solo per la stampa locale ESC/POS e non modifica i dati fiscali inviati all'Agenzia delle Entrate.

alter table public.business_profiles
  add column if not exists receipt_logo_data text,
  add column if not exists receipt_logo_enabled boolean not null default false;

alter table public.business_profiles
  drop constraint if exists business_profiles_receipt_logo_size_check;

alter table public.business_profiles
  add constraint business_profiles_receipt_logo_size_check
  check (receipt_logo_data is null or length(receipt_logo_data) <= 500000);

comment on column public.business_profiles.receipt_logo_data is
  'Logo PNG ottimizzato in data URL, usato esclusivamente per la stampa locale del documento commerciale DCO.';

comment on column public.business_profiles.receipt_logo_enabled is
  'Abilita la stampa del logo sul documento commerciale DCO.';
