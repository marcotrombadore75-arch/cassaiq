# CassaIQ RT v1.14.65 — Impostazioni riorganizzate

Modifica esclusivamente organizzativa/UI, basata su v1.14.64.

- Gestione CassaIQ Client spostata in una voce dedicata nelle Impostazioni.
- “Configura CassaIQ” rinominato in “Documento Commerciale Online”.
- Nuova voce “Configura stampante”.
- Configurazione stampanti separata in Epson RT e stampante di rete ESC/POS.
- La configurazione MUNBYN/rete è stata spostata fuori dalla schermata DCO.
- Nessuna modifica al motore di emissione DCO, all’isolamento operazioni, ai timer 350/1100 ms, all’anti-doppia-emissione o alla stampa nativa.

Versione: 1.14.65
Build iOS: 96
Android versionCode: 96
