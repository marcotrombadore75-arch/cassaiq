-- CassaIQ RT - opzioni prezzo sul tasto prodotto
-- show_price     : mostra o nasconde il prezzo sul tasto in cassa
-- variable_price : prodotto a prezzo variabile (es. a peso); l'importo
--                  viene digitato sul tastierino al momento della vendita
alter table public.products add column if not exists show_price boolean not null default true;
alter table public.products add column if not exists variable_price boolean not null default false;
