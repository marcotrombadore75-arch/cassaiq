# CassaIQ RT 1.14.6 — SPID con apertura DCO automatica

Versione: **1.14.6**  
Build iOS: **36**  
Android versionCode: **36**

## Correzione

- L’utente completa soltanto SPID/CIE/CNS.
- CassaIQ riconosce la pagina autenticata “Fatture e corrispettivi”.
- Apre automaticamente il servizio Documento Commerciale Online.
- Gestisce in automatico anche le pagine ufficiali di instradamento `InstradamentofcWeb`.
- Verifica due volte la home DCO prima di segnare il collegamento come attivo.
- Impedisce cicli infiniti con un limite ai tentativi di instradamento.
- La finestra viene nascosta solo dopo “DCO collegato e verificato”.

La vendita DCO, il recupero PDF, Epson e MUNBYN non sono stati modificati.
